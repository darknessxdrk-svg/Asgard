/**
 * Asgard Cloud Functions
 * 
 * Bu dosya tüm kritik secret'ları server tarafında tutar.
 * Client APK içinde hiçbir secret kalmaz.
 * 
 * Deploy:
 *   cd functions
 *   npm install
 *   firebase functions:secrets:set FCM_SERVICE_ACCOUNT_JSON
 *   firebase functions:secrets:set CLOUDINARY_API_SECRET
 *   firebase functions:secrets:set CLOUDINARY_API_KEY
 *   firebase functions:secrets:set CLOUDINARY_CLOUD_NAME
 *   firebase functions:secrets:set AGORA_APP_CERTIFICATE
 *   firebase functions:secrets:set AGORA_APP_ID
 *   firebase functions:secrets:set GEMINI_API_KEY
 *   firebase deploy --only functions
 */

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore } = require("firebase-admin/firestore");

initializeApp();

// ── Secret tanımları ──────────────────────────────────────────────────────────
const FCM_SA_JSON        = defineSecret("FCM_SERVICE_ACCOUNT_JSON");
const CDN_API_SECRET     = defineSecret("CLOUDINARY_API_SECRET");
const CDN_API_KEY        = defineSecret("CLOUDINARY_API_KEY");
const CDN_CLOUD_NAME     = defineSecret("CLOUDINARY_CLOUD_NAME");
const AGORA_CERTIFICATE  = defineSecret("AGORA_APP_CERTIFICATE");
const AGORA_ID           = defineSecret("AGORA_APP_ID");
const GEMINI_KEY         = defineSecret("GEMINI_API_KEY");

// ── Yardımcı: Auth token doğrula ─────────────────────────────────────────────
function requireAuth(auth) {
  if (!auth || !auth.uid) {
    throw new HttpsError("unauthenticated", "Giriş yapmanız gerekiyor.");
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. FCM BİLDİRİM — sendNotification
//    Client: receiverUID + mesaj içeriği gönderir
//    Server: mtoken'ı Firestore'dan okur, FCM SA key ile bildirim gönderir
// ─────────────────────────────────────────────────────────────────────────────
exports.sendNotification = onCall(
  { secrets: [FCM_SA_JSON] },
  async (request) => {
    requireAuth(request.auth);

    const { receiverUID, title, body, type, extraData } = request.data;
    if (!receiverUID || !title || !body) {
      throw new HttpsError("invalid-argument", "receiverUID, title ve body zorunlu.");
    }

    // mtoken'ı Firestore'dan güvenli şekilde oku
    const db = getFirestore();
    const userDoc = await db.collection("users").doc(receiverUID).get();
    if (!userDoc.exists) throw new HttpsError("not-found", "Kullanıcı bulunamadı.");
    const mtoken = userDoc.data().mtoken;
    if (!mtoken) return { success: false, reason: "no_token" };

    // FCM SA JSON'ı secret'tan oku
    const saJson = JSON.parse(FCM_SA_JSON.value());
    const projectId = saJson.project_id;

    // googleapis_auth yerine manuel JWT + token al
    const { GoogleAuth } = require("google-auth-library");
    const auth = new GoogleAuth({
      credentials: saJson,
      scopes: ["https://www.googleapis.com/auth/firebase.messaging"],
    });
    const client = await auth.getClient();
    const accessToken = (await client.getAccessToken()).token;

    const isCall = type === "incoming_call";
    const message = {
      token: mtoken,
      notification: { title, body },
      data: {
        type: type || "chat",
        title,
        body,
        senderUID: request.auth.uid,
        ...(extraData || {}),
      },
      android: {
        priority: "high",
        notification: {
          channel_id: isCall ? "asgard_calls" : "asgardappid",
          notification_priority: "PRIORITY_MAX",
          default_sound: true,
          default_vibrate_timings: true,
          ...(isCall ? { visibility: "PUBLIC" } : {}),
        },
      },
      apns: {
        headers: { "apns-priority": "10" },
        payload: { aps: { sound: "default", "content-available": 1 } },
      },
    };

    const https = require("https");
    const payload = JSON.stringify({ message });

    await new Promise((resolve, reject) => {
      const options = {
        hostname: "fcm.googleapis.com",
        path: `/v1/projects/${projectId}/messages:send`,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      };
      const req = https.request(options, (res) => {
        let data = "";
        res.on("data", (c) => (data += c));
        res.on("end", () => {
          if (res.statusCode === 200) resolve(data);
          else reject(new HttpsError("internal", `FCM ${res.statusCode}: ${data}`));
        });
      });
      req.on("error", reject);
      req.write(payload);
      req.end();
    });

    return { success: true };
  }
);

// ─────────────────────────────────────────────────────────────────────────────
// 2. CLOUDİNARY İMZA — getCloudinarySignature
//    Client: upload parametrelerini gönderir
//    Server: HMAC-SHA1 imzayı hesaplar, döner
//    Upload: client direkt Cloudinary'ye yapar (secret APK'da yok)
// ─────────────────────────────────────────────────────────────────────────────
exports.getCloudinarySignature = onCall(
  { secrets: [CDN_API_SECRET, CDN_API_KEY, CDN_CLOUD_NAME] },
  async (request) => {
    requireAuth(request.auth);

    const { folder, resourceType } = request.data;
    if (!folder) throw new HttpsError("invalid-argument", "folder zorunlu.");

    const allowedFolders = ["asgard_images", "asgard_audio"];
    if (!allowedFolders.includes(folder)) {
      throw new HttpsError("permission-denied", "İzin verilmeyen klasör.");
    }

    const crypto = require("crypto");
    const timestamp = Math.floor(Date.now() / 1000);
    const toSign = `folder=${folder}&timestamp=${timestamp}${CDN_API_SECRET.value()}`;
    const signature = crypto.createHash("sha1").update(toSign).digest("hex");

    return {
      signature,
      timestamp,
      apiKey: CDN_API_KEY.value(),
      cloudName: CDN_CLOUD_NAME.value(),
      folder,
      resourceType: resourceType || "image",
    };
  }
);

// ─────────────────────────────────────────────────────────────────────────────
// 3. AGORA TOKEN — getAgoraToken
//    Client: channelName + uid gönderir
//    Server: app certificate ile token üretir, döner
// ─────────────────────────────────────────────────────────────────────────────
exports.getAgoraToken = onCall(
  { secrets: [AGORA_ID, AGORA_CERTIFICATE] },
  async (request) => {
    requireAuth(request.auth);

    const { channelName, uid } = request.data;
    if (!channelName) throw new HttpsError("invalid-argument", "channelName zorunlu.");

    const appId = AGORA_ID.value();
    const appCertificate = AGORA_CERTIFICATE.value();

    if (!appId || !appCertificate) {
      // Certificate yoksa test modu — boş token döner
      return { token: "", appId };
    }

    // AccessToken2 (RTC Token 007) — Node.js implementasyonu
    const crypto = require("crypto");

    const now = Math.floor(Date.now() / 1000);
    const expireTs = now + 3600;
    const salt = now & 0xffffffff;
    const uidStr = (uid || 0).toString();

    // Service privileges
    const privileges = {
      1: expireTs, // JOIN_CHANNEL
      2: expireTs, // PUBLISH_AUDIO
      3: expireTs, // PUBLISH_VIDEO
    };

    // Pack service
    function packUint16(v) {
      const b = Buffer.allocUnsafe(2);
      b.writeUInt16LE(v, 0);
      return b;
    }
    function packUint32(v) {
      const b = Buffer.allocUnsafe(4);
      b.writeUInt32LE(v >>> 0, 0);
      return b;
    }
    function packString(s) {
      const enc = Buffer.from(s, "utf8");
      return Buffer.concat([packUint16(enc.length), enc]);
    }

    const sortedPrivs = Object.entries(privileges).sort(([a], [b]) => a - b);
    let serviceBody = Buffer.concat([
      packString(channelName),
      packString(uidStr),
      packUint16(sortedPrivs.length),
      ...sortedPrivs.flatMap(([k, v]) => [packUint16(parseInt(k)), packUint32(v)]),
    ]);

    const body = Buffer.concat([
      packString(""),          // version
      packUint32(expireTs),
      packUint32(now),
      packUint32(salt),
      packUint16(1),           // 1 service
      packUint16(1),           // SERVICE_TYPE_RTC = 1
      serviceBody,
    ]);

    const signingStr = appCertificate + now.toString() + salt.toString() + expireTs.toString();
    const sig = crypto
      .createHmac("sha256", Buffer.from(signingStr, "utf8"))
      .update(Buffer.from(appId + now.toString() + salt.toString() + expireTs.toString(), "utf8"))
      .digest();

    const content = Buffer.concat([
      packUint16(sig.length),
      sig,
      body,
    ]);

    const token = "007" + appId + content.toString("base64url");
    return { token, appId };
  }
);

// ─────────────────────────────────────────────────────────────────────────────
// 4. GEMİNİ AI — askAI
//    Client: soru/mesaj gönderir, sistem prompt'u server'da
//    Server: Gemini API key ile istek atar, yanıtı döner
// ─────────────────────────────────────────────────────────────────────────────
exports.askAI = onCall(
  { secrets: [GEMINI_KEY] },
  async (request) => {
    requireAuth(request.auth);

    const { prompt, context, systemPrompt } = request.data;
    if (!prompt) throw new HttpsError("invalid-argument", "prompt zorunlu.");

    // Rate limit — kullanıcı başına dakikada max 10 istek
    const db = getFirestore();
    const rateLimitRef = db.collection("_rate_limits").doc(request.auth.uid);
    const now = Date.now();
    const windowMs = 60_000;
    const maxRequests = 10;

    await db.runTransaction(async (tx) => {
      const doc = await tx.get(rateLimitRef);
      const data = doc.exists ? doc.data() : { count: 0, windowStart: now };
      if (now - data.windowStart > windowMs) {
        tx.set(rateLimitRef, { count: 1, windowStart: now });
      } else if (data.count >= maxRequests) {
        throw new HttpsError("resource-exhausted", "Çok fazla istek. Bir dakika bekleyin.");
      } else {
        tx.update(rateLimitRef, { count: data.count + 1 });
      }
    });

    const https = require("https");
    const geminiKey = GEMINI_KEY.value();

    const contents = [];
    if (context && Array.isArray(context)) {
      contents.push(...context);
    }
    contents.push({ role: "user", parts: [{ text: prompt }] });

    const reqBody = JSON.stringify({
      system_instruction: {
        parts: [{ text: systemPrompt || "Sen Asgard sohbet asistanisin. Kisa ve Turkce cevap ver." }],
      },
      contents,
      generationConfig: { maxOutputTokens: 800 },
    });

    const result = await new Promise((resolve, reject) => {
      const options = {
        hostname: "generativelanguage.googleapis.com",
        path: `/v1beta/models/gemini-2.0-flash:generateContent?key=${geminiKey}`,
        method: "POST",
        headers: { "Content-Type": "application/json" },
      };
      const req = https.request(options, (res) => {
        let data = "";
        res.on("data", (c) => (data += c));
        res.on("end", () => resolve({ status: res.statusCode, body: data }));
      });
      req.on("error", reject);
      req.write(reqBody);
      req.end();
    });

    const parsed = JSON.parse(result.body);
    if (result.status !== 200) {
      const code = parsed.error?.code || result.status;
      if (code === 429) throw new HttpsError("resource-exhausted", "AI kota doldu. Biraz bekleyin.");
      if (code === 403) throw new HttpsError("permission-denied", "AI erişim reddedildi.");
      throw new HttpsError("internal", `AI hatası (${code})`);
    }

    const reply = parsed.candidates?.[0]?.content?.parts?.[0]?.text ?? "Yanıt alınamadı";
    return { reply };
  }
);
