import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../../services/cloudinary_service.dart';
import '../../../themes/colors.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Ana Kanallar Ekranı — WhatsApp tarzı, tek sayfa
// ─────────────────────────────────────────────────────────────────────────────
class ChannelsScreen extends StatefulWidget {
  final bool isEmbedded;
  const ChannelsScreen({super.key, this.isEmbedded = false});
  @override State<ChannelsScreen> createState() => _ChannelsScreenState();
}

class _ChannelsScreenState extends State<ChannelsScreen> {
  final _uid = FirebaseAuth.instance.currentUser?.uid ?? '';
  final _db = FirebaseFirestore.instance;
  String _search = '';
  final _searchCtrl = TextEditingController();
  bool _searchOpen = false;

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),

      body: StreamBuilder<QuerySnapshot>(
        // ✅ FIX: Tüm kanalları tek seferde yüklemek yerine limit ekle
        stream: _db.collection('channels').limit(100).snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
          }
          final all = snap.data!.docs;
          final myChannels = all.where((d) =>
              ((d.data() as Map)['followers'] as List? ?? []).contains(_uid)).toList();
          final discover = all.where((d) =>
              !((d.data() as Map)['followers'] as List? ?? []).contains(_uid)).toList();

          // Arama filtresi
          List<QueryDocumentSnapshot> filterList(List<QueryDocumentSnapshot> list) {
            if (_search.isEmpty) return list;
            return list.where((d) {
              final name = ((d.data() as Map)['name'] ?? '').toString().toLowerCase();
              return name.contains(_search.toLowerCase());
            }).toList();
          }

          final myFiltered = filterList(myChannels);
          final discoverFiltered = filterList(discover);

          return CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            slivers: [
              // Embed edildiğinde üst boşluk verme, standalone'da SafeArea padding
              if (!widget.isEmbedded)
                SliverToBoxAdapter(child: SizedBox(height: MediaQuery.of(context).padding.top)),
              // Arama çubuğu
              SliverToBoxAdapter(child: Padding(
                padding: EdgeInsets.fromLTRB(14, widget.isEmbedded ? 8.0 : 12.0, 14, 4),
                child: Theme(
                  data: Theme.of(context).copyWith(
                    inputDecorationTheme: const InputDecorationTheme(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                    ),
                  ),
                  child: Container(
                  height: 40,
                  decoration: BoxDecoration(
                    color: const Color(0xFF1C1C1C),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Row(children: [
                    const SizedBox(width: 12),
                    const Icon(Icons.search, color: Colors.white38, size: 18),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(
                      controller: _searchCtrl,
                      style: const TextStyle(color: Colors.white, fontSize: 13),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        hintText: 'Kanal ara...',
                        hintStyle: TextStyle(color: Colors.white30, fontSize: 13),
                        isDense: true, contentPadding: EdgeInsets.zero,
                      ),
                      onChanged: (v) => setState(() => _search = v),
                    )),
                    if (_search.isNotEmpty)
                      GestureDetector(
                        onTap: () { _searchCtrl.clear(); setState(() => _search = ''); },
                        child: const Padding(padding: EdgeInsets.only(right: 10),
                            child: Icon(Icons.close, color: Colors.white38, size: 16)),
                      ),
                  ]),
                ),
                ),
              )),

              // Kanal Oluştur butonu
              SliverToBoxAdapter(child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
                child: GestureDetector(
                  onTap: _showCreateChannel,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 11),
                    decoration: BoxDecoration(
                      color: ColorsManager.darkPrimary,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.add_rounded, color: Colors.white, size: 18),
                      SizedBox(width: 6),
                      Text('Kanal Oluştur', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
                    ]),
                  ),
                ),
              )),

              // Takip Ettiklerim bölümü
              if (myFiltered.isNotEmpty) ...[
                SliverToBoxAdapter(child: _SectionHeader(
                  icon: Icons.bookmark_rounded,
                  title: 'Takip Ettiklerim',
                  count: myFiltered.length,
                )),
                SliverList(delegate: SliverChildBuilderDelegate(
                  (_, i) => _ChannelTile(doc: myFiltered[i], uid: _uid),
                  childCount: myFiltered.length,
                )),
              ] else if (_search.isEmpty && myChannels.isEmpty)
                SliverToBoxAdapter(child: _emptySection(
                  icon: Icons.bookmark_border_rounded,
                  title: 'Takip ettiğin kanal yok',
                  subtitle: 'Aşağıdan kanallar keşfedebilirsin',
                )),

              // Keşfet bölümü
              if (discoverFiltered.isNotEmpty) ...[
                SliverToBoxAdapter(child: _SectionHeader(
                  icon: Icons.explore_outlined,
                  title: 'Keşfet',
                  count: discoverFiltered.length,
                )),
                SliverList(delegate: SliverChildBuilderDelegate(
                  (_, i) => _ChannelTile(doc: discoverFiltered[i], uid: _uid, showFollow: true),
                  childCount: discoverFiltered.length,
                )),
              ],

              if (all.isEmpty)
                SliverToBoxAdapter(child: _emptySection(
                  icon: Icons.campaign_outlined,
                  title: 'Henüz kanal yok',
                  subtitle: '+ Kanal Oluştur ile ilk kanalı sen aç',
                )),

              const SliverToBoxAdapter(child: SizedBox(height: 100)),
            ],
          );
        },
      ),
    );
  }

  Widget _emptySection({required IconData icon, required String title, required String subtitle}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 64, height: 64,
          decoration: BoxDecoration(shape: BoxShape.circle,
              color: ColorsManager.darkPrimary.withOpacity(0.07),
              border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.12))),
          child: Icon(icon, size: 28, color: ColorsManager.darkPrimary.withOpacity(0.4))),
        const SizedBox(height: 12),
        Text(title, style: const TextStyle(color: Colors.white54, fontSize: 14, fontWeight: FontWeight.w500)),
        const SizedBox(height: 5),
        Text(subtitle, style: const TextStyle(color: Colors.white24, fontSize: 12), textAlign: TextAlign.center),
      ]),
    );
  }

  void _showCreateChannel() {
    final nameCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    String? photoUrl;
    bool uploading = false;

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => StatefulBuilder(builder: (ctx, setSt) => Padding(
        padding: EdgeInsets.fromLTRB(20, 16, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const Text('Kanal Oluştur', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: () async {
              final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80);
              if (picked == null) return;
              setSt(() => uploading = true);
              final url = await CloudinaryService.uploadImage(picked.path);
              setSt(() { photoUrl = url; uploading = false; });
            },
            child: Container(width: 84, height: 84,
              decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF252525),
                  border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.4), width: 2)),
              child: ClipOval(child: uploading
                  ? const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary, strokeWidth: 2))
                  : photoUrl != null
                      ? CachedNetworkImage(imageUrl: photoUrl!, fit: BoxFit.cover)
                      : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.add_photo_alternate_outlined, color: ColorsManager.darkPrimary, size: 28),
                          Text('Fotoğraf', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 9)),
                        ])),
            ),
          ),
          const SizedBox(height: 18),
          _buildField(nameCtrl, 'Kanal Adı *'),
          const SizedBox(height: 12),
          _buildField(descCtrl, 'Açıklama (isteğe bağlı)', maxLines: 2),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: ColorsManager.darkPrimary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                padding: const EdgeInsets.symmetric(vertical: 14), elevation: 0),
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              await _db.collection('channels').add({
                'name': nameCtrl.text.trim(), 'description': descCtrl.text.trim(),
                'photo': photoUrl ?? '', 'ownerUID': _uid, 'followers': [_uid],
                'whoCanPost': 'owner', 'createdAt': Timestamp.now(),
              });
              if (ctx.mounted) Navigator.pop(ctx);
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('${nameCtrl.text.trim()} kanalı oluşturuldu'),
                  backgroundColor: ColorsManager.darkPrimary));
            },
            child: const Text('Oluştur', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
          )),
        ]),
      )),
    );
  }

  static Widget _buildField(TextEditingController ctrl, String label, {int maxLines = 1}) {
    return TextField(controller: ctrl, style: const TextStyle(color: Colors.white, fontSize: 14),
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label, labelStyle: const TextStyle(color: Colors.white38, fontSize: 13),
        filled: true, fillColor: const Color(0xFF252525),
        border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(12)),
        focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: ColorsManager.darkPrimary, width: 1.5), borderRadius: BorderRadius.circular(12)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12)));
  }
}

// ─────────────────────────────────────────────────────────────────────────────
class _SectionHeader extends StatelessWidget {
  final IconData icon;
  final String title;
  final int count;
  const _SectionHeader({required this.icon, required this.title, required this.count});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
      child: Row(children: [
        Icon(icon, size: 14, color: ColorsManager.darkPrimary),
        const SizedBox(width: 6),
        Text(title, style: TextStyle(color: ColorsManager.darkPrimary,
            fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
        const SizedBox(width: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 1),
          decoration: BoxDecoration(
            color: ColorsManager.darkPrimary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text('$count', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 10, fontWeight: FontWeight.w600)),
        ),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
class _ChannelAvatar extends StatelessWidget {
  final String photo;
  final double size;
  const _ChannelAvatar({required this.photo, this.size = 52});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle,
        gradient: photo.isEmpty ? LinearGradient(
            colors: [ColorsManager.darkPrimary.withOpacity(0.85), const Color(0xFF4A0000)],
            begin: Alignment.topLeft, end: Alignment.bottomRight) : null,
        border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.3), width: 1.5)),
      child: ClipOval(child: photo.isNotEmpty
          ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
              errorWidget: (_, __, ___) => Icon(Icons.campaign_rounded, color: Colors.white, size: size * 0.45))
          : Center(child: Icon(Icons.campaign_rounded, color: Colors.white, size: size * 0.45))),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
class _ChannelTile extends StatelessWidget {
  final QueryDocumentSnapshot doc;
  final String uid;
  final bool showFollow;
  const _ChannelTile({required this.doc, required this.uid, this.showFollow = false});

  String _fmt(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '$n';
  }

  @override
  Widget build(BuildContext context) {
    final data = doc.data() as Map<String, dynamic>;
    final name = data['name'] ?? '';
    final desc = data['description'] ?? '';
    final photo = data['photo'] ?? '';
    final followers = (data['followers'] as List? ?? []);
    final isFollowing = followers.contains(uid);
    final isOwner = (data['ownerUID'] ?? '') == uid;

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => ChannelPage(channelId: doc.id, channelData: data))),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        decoration: BoxDecoration(
          color: const Color(0xFF161616),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            _ChannelAvatar(photo: photo, size: 50),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(name,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14),
                    maxLines: 1, overflow: TextOverflow.ellipsis)),
                if (isOwner)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: ColorsManager.darkPrimary.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text('Sahibi', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 10, fontWeight: FontWeight.w600)),
                  ),
              ]),
              if (desc.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(desc, style: const TextStyle(color: Colors.white38, fontSize: 11, height: 1.3),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
              const SizedBox(height: 5),
              Row(children: [
                Icon(Icons.people_outline, size: 11, color: ColorsManager.darkPrimary.withOpacity(0.6)),
                const SizedBox(width: 3),
                Text('${_fmt(followers.length)} takipçi',
                    style: TextStyle(color: ColorsManager.darkPrimary.withOpacity(0.7), fontSize: 11)),
              ]),
            ])),
            if (showFollow && !isOwner) ...[
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () async {
                  final ref = FirebaseFirestore.instance.collection('channels').doc(doc.id);
                  if (isFollowing) await ref.update({'followers': FieldValue.arrayRemove([uid])});
                  else await ref.update({'followers': FieldValue.arrayUnion([uid])});
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: isFollowing ? Colors.transparent : ColorsManager.darkPrimary,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: isFollowing ? Colors.white24 : ColorsManager.darkPrimary),
                  ),
                  child: Text(isFollowing ? 'Bırak' : 'Takip',
                      style: TextStyle(
                          color: isFollowing ? Colors.white38 : Colors.white,
                          fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ]),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Kanal Sayfası
// ─────────────────────────────────────────────────────────────────────────────
class ChannelPage extends StatefulWidget {
  final String channelId;
  final Map<String, dynamic> channelData;
  const ChannelPage({super.key, required this.channelId, required this.channelData});
  @override State<ChannelPage> createState() => _ChannelPageState();
}

class _ChannelPageState extends State<ChannelPage> {
  final _ctrl = TextEditingController();
  final _uid = FirebaseAuth.instance.currentUser?.uid ?? '';
  final _db = FirebaseFirestore.instance;
  bool _isOwner = false;
  bool _canPost = false;
  Map<String, dynamic> _data = {};

  @override
  void initState() {
    super.initState();
    _data = Map<String, dynamic>.from(widget.channelData);
    _updatePermissions();
  }

  void _updatePermissions() {
    _isOwner = (_data['ownerUID'] ?? '') == _uid;
    _canPost = _isOwner || (_data['whoCanPost'] ?? 'owner') == 'all';
  }

  String _fmt(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '$n';
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: _db.collection('channels').doc(widget.channelId).snapshots(),
      builder: (ctx, channelSnap) {
        if (channelSnap.hasData && channelSnap.data!.exists) {
          _data = channelSnap.data!.data() as Map<String, dynamic>;
          _updatePermissions();
        }
        final name = _data['name'] ?? '';
        final desc = _data['description'] ?? '';
        final photo = _data['photo'] ?? '';
        final followers = (_data['followers'] as List? ?? []);
        final isFollowing = followers.contains(_uid);
        final whoCanPost = _data['whoCanPost'] ?? 'owner';

        return Scaffold(
          backgroundColor: const Color(0xFF0D0D0D),
          appBar: AppBar(
            backgroundColor: const Color(0xFF111111),
            leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
            titleSpacing: 0,
            title: Row(children: [
              _ChannelAvatar(photo: photo, size: 36),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                Text('${_fmt(followers.length)} takipçi', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 11)),
              ])),
            ]),
            actions: [
              if (!_isOwner)
                TextButton(
                  onPressed: () async {
                    final ref = _db.collection('channels').doc(widget.channelId);
                    if (isFollowing) await ref.update({'followers': FieldValue.arrayRemove([_uid])});
                    else await ref.update({'followers': FieldValue.arrayUnion([_uid])});
                  },
                  child: Text(isFollowing ? 'Bırak' : 'Takip',
                      style: TextStyle(color: isFollowing ? Colors.white38 : ColorsManager.darkPrimary, fontWeight: FontWeight.w600)),
                ),
              if (_isOwner)
                IconButton(
                  icon: const Icon(Icons.settings_outlined, color: Colors.white70),
                  onPressed: () => _showSettings(whoCanPost),
                  tooltip: 'Kanal Ayarları',
                ),
              const SizedBox(width: 4),
            ],
          ),
          body: Column(children: [
            if (desc.isNotEmpty)
              Container(
                width: double.infinity, color: const Color(0xFF111111),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(children: [
                  Icon(Icons.info_outline, size: 13, color: ColorsManager.darkPrimary.withOpacity(0.7)),
                  const SizedBox(width: 8),
                  Expanded(child: Text(desc,
                      style: const TextStyle(color: Colors.white38, fontSize: 12, height: 1.3),
                      maxLines: 2, overflow: TextOverflow.ellipsis)),
                ]),
              ),
            if (!_isOwner && whoCanPost == 'owner')
              Container(
                width: double.infinity, color: const Color(0xFF0A0A0A),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: const Row(children: [
                  Icon(Icons.lock_outline, size: 13, color: Colors.orange),
                  SizedBox(width: 6),
                  Text('Yalnızca kanal sahibi yayın yapabilir',
                      style: TextStyle(color: Colors.orange, fontSize: 11, fontStyle: FontStyle.italic)),
                ]),
              ),
            Expanded(child: StreamBuilder<QuerySnapshot>(
              stream: _db.collection('channels').doc(widget.channelId)
                  .collection('posts').orderBy('timestamp', descending: true).snapshots(),
              builder: (ctx, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
                final posts = snap.data!.docs;
                if (posts.isEmpty) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.broadcast_on_personal_outlined, size: 48, color: Colors.white12),
                  const SizedBox(height: 12),
                  const Text('Henüz yayın yok', style: TextStyle(color: Colors.white24, fontSize: 15)),
                  if (_isOwner) ...[
                    const SizedBox(height: 6),
                    Text('Aşağıdan ilk yayınını paylaş',
                        style: TextStyle(color: ColorsManager.darkPrimary.withOpacity(0.5), fontSize: 12)),
                  ],
                ]));
                return Container(
                  color: const Color(0xFF0D0D0D),
                  child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                  itemCount: posts.length,
                  itemBuilder: (_, i) {
                    final pdata = posts[i].data() as Map<String, dynamic>;
                    final ts = (pdata['timestamp'] as Timestamp?)?.toDate() ?? DateTime.now();
                    final likes = (pdata['likes'] as List? ?? []);
                    final isPostOwner = (pdata['ownerUID'] ?? '') == _uid || _isOwner;
                    return _PostCard(
                      postId: posts[i].id, channelId: widget.channelId,
                      content: pdata['content'] ?? '',
                      imageUrl: pdata['imageUrl'] ?? '',
                      isPinned: pdata['pinned'] == true,
                      timestamp: ts,
                      likes: likes, isLiked: likes.contains(_uid),
                      isOwner: isPostOwner, uid: _uid,
                    ));
                  },
                );
              },
            )),
            if (_canPost) _PostInputBar(ctrl: _ctrl, onSendMedia: (text, imageUrl) async {
              if (text.isEmpty && imageUrl == null) return;
              _ctrl.clear();
              await _db.collection('channels').doc(widget.channelId).collection('posts').add({
                'content': text,
                'imageUrl': imageUrl ?? '',
                'timestamp': Timestamp.now(),
                'likes': [],
                'ownerUID': _uid,
                'pinned': false,
              });
            }),
          ]),
        );
      },
    );
  }

  void _showSettings(String whoCanPost) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _ChannelSettingsSheet(channelId: widget.channelId, channelData: _data, uid: _uid),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
class _PostCard extends StatelessWidget {
  final String postId, channelId, content, uid;
  final String imageUrl;
  final DateTime timestamp;
  final List likes;
  final bool isLiked, isOwner, isPinned;
  const _PostCard({required this.postId, required this.channelId, required this.content,
      required this.timestamp, required this.likes, required this.isLiked,
      required this.isOwner, required this.uid,
      this.imageUrl = '', this.isPinned = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.08)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (isPinned)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(children: [
              Icon(Icons.push_pin_rounded, color: ColorsManager.darkPrimary, size: 13),
              const SizedBox(width: 4),
              Text('Sabitlendi', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 11, fontWeight: FontWeight.w600)),
            ]),
          ),
        if (imageUrl.isNotEmpty)
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: CachedNetworkImage(
              imageUrl: imageUrl,
              width: double.infinity,
              fit: BoxFit.cover,
              placeholder: (_, __) => Container(height: 150, color: const Color(0xFF1A1A1A),
                  child: const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary, strokeWidth: 2))),
              errorWidget: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
        if (imageUrl.isNotEmpty && content.isNotEmpty) const SizedBox(height: 8),
        if (content.isNotEmpty)
          Text(content, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.45)),
        const SizedBox(height: 10),
        Row(children: [
          const Icon(Icons.access_time_rounded, color: Colors.white24, size: 12),
          const SizedBox(width: 4),
          Text(DateFormat('dd MMM HH:mm', 'tr').format(timestamp),
              style: const TextStyle(color: Colors.white24, fontSize: 11)),
          const Spacer(),
          if (isOwner) ...[
            // Sabitle butonu
            GestureDetector(
              onTap: () async {
                await FirebaseFirestore.instance.collection('channels').doc(channelId)
                    .collection('posts').doc(postId).update({'pinned': !isPinned});
              },
              child: Padding(padding: const EdgeInsets.only(right: 10),
                  child: Icon(isPinned ? Icons.push_pin_rounded : Icons.push_pin_outlined,
                      color: isPinned ? ColorsManager.darkPrimary : Colors.white24, size: 18)),
            ),
            GestureDetector(
              onTap: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: const Color(0xFF1A1A1A),
                    title: const Text('Yayını Sil', style: TextStyle(color: Colors.white, fontSize: 16)),
                    content: const Text('Bu yayın silinecek. Emin misin?', style: TextStyle(color: Colors.white54)),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
                      TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil', style: TextStyle(color: Colors.redAccent))),
                    ]),
                );
                if (confirm == true) {
                  await FirebaseFirestore.instance.collection('channels').doc(channelId).collection('posts').doc(postId).delete();
                }
              },
              child: const Padding(padding: EdgeInsets.only(right: 10),
                  child: Icon(Icons.delete_outline, color: Colors.white24, size: 18)),
            ),
          ],
          GestureDetector(
            onTap: () async {
              final ref = FirebaseFirestore.instance.collection('channels').doc(channelId).collection('posts').doc(postId);
              if (isLiked) await ref.update({'likes': FieldValue.arrayRemove([uid])});
              else await ref.update({'likes': FieldValue.arrayUnion([uid])});
            },
            child: Row(children: [
              Icon(isLiked ? Icons.thumb_up_rounded : Icons.thumb_up_outlined,
                  color: isLiked ? ColorsManager.darkPrimary : Colors.white24, size: 16),
              const SizedBox(width: 5),
              Text('${likes.length}',
                  style: TextStyle(color: isLiked ? ColorsManager.darkPrimary : Colors.white38,
                      fontSize: 12, fontWeight: FontWeight.w500)),
            ]),
          ),
        ]),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
class _PostInputBar extends StatefulWidget {
  final TextEditingController ctrl;
  final Future<void> Function(String text, String? imageUrl) onSendMedia;
  const _PostInputBar({required this.ctrl, required this.onSendMedia});
  @override State<_PostInputBar> createState() => _PostInputBarState();
}

class _PostInputBarState extends State<_PostInputBar> {
  String? _pendingImageUrl;
  bool _uploading = false;

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (picked == null) return;
    setState(() => _uploading = true);
    final url = await CloudinaryService.uploadImage(picked.path);
    setState(() { _pendingImageUrl = url; _uploading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      if (_pendingImageUrl != null)
        Container(
          margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          height: 80,
          child: Stack(children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: CachedNetworkImage(imageUrl: _pendingImageUrl!, fit: BoxFit.cover, width: double.infinity),
            ),
            Positioned(top: 4, right: 4,
              child: GestureDetector(
                onTap: () => setState(() => _pendingImageUrl = null),
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                  child: const Icon(Icons.close, color: Colors.white, size: 14),
                ),
              ),
            ),
          ]),
        ),
      Container(
        color: const Color(0xFF111111),
        padding: EdgeInsets.fromLTRB(12, 8, 12, 8 + MediaQuery.of(context).padding.bottom),
        child: Row(children: [
          if (_uploading)
            const SizedBox(width: 36, height: 36,
                child: Padding(padding: EdgeInsets.all(8),
                    child: CircularProgressIndicator(strokeWidth: 2, color: ColorsManager.darkPrimary)))
          else
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                padding: const EdgeInsets.all(8),
                child: Icon(Icons.photo_outlined, color: ColorsManager.darkPrimary, size: 22),
              ),
            ),
          const SizedBox(width: 6),
          Expanded(child: TextField(
            controller: widget.ctrl,
            style: const TextStyle(color: Colors.white, fontSize: 14),
            maxLines: 4, minLines: 1,
            decoration: InputDecoration(
              hintText: 'Yayın yaz...',
              hintStyle: const TextStyle(color: Colors.white38, fontSize: 14),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              filled: true,
              fillColor: const Color(0xFF1A1A1A),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.4)),
              ),
            ),
          )),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () async {
              final text = widget.ctrl.text.trim();
              if (text.isEmpty && _pendingImageUrl == null) return;
              await widget.onSendMedia(text, _pendingImageUrl);
              setState(() => _pendingImageUrl = null);
            },
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: ColorsManager.darkPrimary,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.4), blurRadius: 8)],
              ),
              child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
            ),
          ),
        ]),
      ),
    ]);
  }
}

class _ChannelSettingsSheet extends StatefulWidget {
  final String channelId, uid;
  final Map<String, dynamic> channelData;
  const _ChannelSettingsSheet({required this.channelId, required this.channelData, required this.uid});
  @override State<_ChannelSettingsSheet> createState() => _ChannelSettingsSheetState();
}

class _ChannelSettingsSheetState extends State<_ChannelSettingsSheet> {
  late String _whoCanPost;
  late TextEditingController _nameCtrl;
  late TextEditingController _descCtrl;
  String? _photoUrl;
  bool _uploading = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _whoCanPost = widget.channelData['whoCanPost'] ?? 'owner';
    _nameCtrl = TextEditingController(text: widget.channelData['name'] ?? '');
    _descCtrl = TextEditingController(text: widget.channelData['description'] ?? '');
    final photo = widget.channelData['photo'] ?? '';
    _photoUrl = photo.isEmpty ? null : photo;
  }

  @override void dispose() { _nameCtrl.dispose(); _descCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final followers = (widget.channelData['followers'] as List? ?? []);
    return DraggableScrollableSheet(
      initialChildSize: 0.85, minChildSize: 0.5, maxChildSize: 0.95, expand: false,
      builder: (ctx, scrollCtrl) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFF1A1A1A),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [
              Container(padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: ColorsManager.darkPrimary.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                child: Icon(Icons.settings_outlined, color: ColorsManager.darkPrimary, size: 16)),
              const SizedBox(width: 10),
              const Text('Kanal Ayarları', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17)),
              const Spacer(),
              if (_saving)
                const SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(color: ColorsManager.darkPrimary, strokeWidth: 2)),
            ])),
          const SizedBox(height: 4),
          const Divider(color: Colors.white10),
          Expanded(child: ListView(
            controller: scrollCtrl,
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              // Profil foto
              Center(child: GestureDetector(
                onTap: () async {
                  final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80);
                  if (picked == null) return;
                  setState(() => _uploading = true);
                  final url = await CloudinaryService.uploadImage(picked.path);
                  setState(() { _photoUrl = url; _uploading = false; });
                },
                child: Stack(children: [
                  Container(width: 80, height: 80,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF252525),
                        border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.4), width: 2)),
                    child: ClipOval(child: _uploading
                        ? const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary, strokeWidth: 2))
                        : _photoUrl != null
                            ? CachedNetworkImage(imageUrl: _photoUrl!, fit: BoxFit.cover)
                            : Center(child: Icon(Icons.campaign_rounded, color: ColorsManager.darkPrimary, size: 32)))),
                  Positioned(bottom: 0, right: 0, child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(color: ColorsManager.darkPrimary, shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF1A1A1A), width: 2)),
                    child: const Icon(Icons.edit, color: Colors.white, size: 12))),
                ]),
              )),
              const SizedBox(height: 20),
              _label('Kanal Adı'),
              const SizedBox(height: 8),
              _field(_nameCtrl, 'Kanal adı'),
              const SizedBox(height: 16),
              _label('Açıklama'),
              const SizedBox(height: 8),
              _field(_descCtrl, 'Kanal açıklaması', maxLines: 3),
              const SizedBox(height: 20),
              _label('Kim Yayın Yapabilir'),
              const SizedBox(height: 10),
              _PermissionTile(
                title: 'Yalnızca Ben',
                subtitle: 'Sadece kanal sahibi yayın yapabilir',
                icon: Icons.admin_panel_settings_outlined,
                selected: _whoCanPost == 'owner',
                onTap: () => setState(() => _whoCanPost = 'owner'),
              ),
              const SizedBox(height: 8),
              _PermissionTile(
                title: 'Tüm Aboneler',
                subtitle: 'Kanalı takip eden herkes yayın yapabilir',
                icon: Icons.people_outlined,
                selected: _whoCanPost == 'all',
                onTap: () => setState(() => _whoCanPost = 'all'),
              ),
              const SizedBox(height: 24),
              _label('Aboneler (${followers.length})'),
              const SizedBox(height: 10),
              ...followers.map((fuid) => _SubscriberTile(
                  uid: fuid.toString(),
                  ownerUID: widget.uid,
                  channelId: widget.channelId)),
              const SizedBox(height: 24),
              SizedBox(width: double.infinity, child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: ColorsManager.darkPrimary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 14), elevation: 0),
                onPressed: _saving ? null : () async {
                  if (_nameCtrl.text.trim().isEmpty) return;
                  setState(() => _saving = true);
                  await FirebaseFirestore.instance.collection('channels').doc(widget.channelId).update({
                    'name': _nameCtrl.text.trim(),
                    'description': _descCtrl.text.trim(),
                    'photo': _photoUrl ?? '',
                    'whoCanPost': _whoCanPost,
                  });
                  setState(() => _saving = false);
                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Kanal güncellendi'),
                        backgroundColor: ColorsManager.darkPrimary));
                  }
                },
                child: const Text('Kaydet', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)),
              )),
              const SizedBox(height: 12),
              SizedBox(width: double.infinity, child: OutlinedButton.icon(
                icon: const Icon(Icons.delete_forever_outlined, color: Colors.redAccent, size: 18),
                label: const Text('Kanalı Sil', style: TextStyle(color: Colors.redAccent, fontSize: 14)),
                style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.redAccent),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 12)),
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: const Color(0xFF1A1A1A),
                      title: const Text('Kanalı Sil', style: TextStyle(color: Colors.white)),
                      content: const Text('Bu kanal ve tüm yayınları silinecek. Bu işlem geri alınamaz.',
                          style: TextStyle(color: Colors.white54, height: 1.4)),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
                        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold))),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await FirebaseFirestore.instance.collection('channels').doc(widget.channelId).delete();
                    if (context.mounted) {
                      Navigator.pop(context);
                      Navigator.pop(context);
                    }
                  }
                },
              )),
            ],
          )),
        ]),
      ),
    );
  }

  Widget _label(String text) => Text(text,
      style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 0.5));

  Widget _field(TextEditingController ctrl, String hint, {int maxLines = 1}) {
    return TextField(
      controller: ctrl, style: const TextStyle(color: Colors.white, fontSize: 14), maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint, hintStyle: const TextStyle(color: Colors.white24, fontSize: 13),
        filled: true, fillColor: const Color(0xFF252525),
        border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(12)),
        focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: ColorsManager.darkPrimary, width: 1.5),
            borderRadius: BorderRadius.circular(12)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10)),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
class _PermissionTile extends StatelessWidget {
  final String title, subtitle;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _PermissionTile({required this.title, required this.subtitle, required this.icon,
      required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? ColorsManager.darkPrimary.withOpacity(0.1) : const Color(0xFF252525),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? ColorsManager.darkPrimary : Colors.transparent, width: 1.5),
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: selected ? ColorsManager.darkPrimary.withOpacity(0.15) : Colors.white10,
                borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, color: selected ? ColorsManager.darkPrimary : Colors.white38, size: 18)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(color: selected ? Colors.white : Colors.white70,
                fontWeight: FontWeight.w600, fontSize: 13)),
            const SizedBox(height: 2),
            Text(subtitle, style: const TextStyle(color: Colors.white38, fontSize: 11, height: 1.3)),
          ])),
          if (selected) Icon(Icons.check_circle_rounded, color: ColorsManager.darkPrimary, size: 20),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
class _SubscriberTile extends StatelessWidget {
  final String uid, ownerUID, channelId;
  const _SubscriberTile({required this.uid, required this.ownerUID, required this.channelId});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance.collection('users').doc(uid).get(),
      builder: (ctx, snap) {
        if (!snap.hasData) return const ColoredBox(color: Color(0xFF0D0D0D), child: SizedBox.shrink());
        final data = snap.data!.data() as Map<String, dynamic>?;
        if (data == null) return const ColoredBox(color: Color(0xFF0D0D0D), child: SizedBox.shrink());
        final name = data['name'] ?? 'Kullanıcı';
        final photo = data['profilePic'] ?? '';
        final isOwner = uid == ownerUID;
        final isCurrentUser = uid == FirebaseAuth.instance.currentUser?.uid;

        return Container(
          margin: const EdgeInsets.only(bottom: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(color: const Color(0xFF222222), borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            CircleAvatar(
              radius: 18, backgroundColor: const Color(0xFF333333),
              backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
              child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white38, size: 18) : null),
            const SizedBox(width: 10),
            Expanded(child: Text(name,
                style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500))),
            if (isOwner)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                    color: ColorsManager.darkPrimary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8)),
                child: Text('Sahip', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 10)))
            else if (!isCurrentUser && ownerUID == FirebaseAuth.instance.currentUser?.uid)
              GestureDetector(
                onTap: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: const Color(0xFF1A1A1A),
                      title: const Text('Aboneyi Çıkar', style: TextStyle(color: Colors.white, fontSize: 15)),
                      content: Text('$name kanaldan çıkarılacak.', style: const TextStyle(color: Colors.white54)),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
                        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Çıkar', style: TextStyle(color: Colors.redAccent))),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await FirebaseFirestore.instance.collection('channels').doc(channelId)
                        .update({'followers': FieldValue.arrayRemove([uid])});
                  }
                },
                child: const Icon(Icons.remove_circle_outline, color: Colors.redAccent, size: 20)),
          ]),
        );
      },
    );
  }
}
