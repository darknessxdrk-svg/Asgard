import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../../services/database.dart';
import '../../../themes/colors.dart';

class StarredMessagesScreen extends StatelessWidget {
  const StarredMessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('⭐ Yıldızlı Mesajlar', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: DatabaseMethods.getStarredMessages(),
        builder: (ctx, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
          final msgs = snap.data!.docs;
          if (msgs.isEmpty) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.star_border_rounded, size: 64.sp, color: Colors.white12),
            const SizedBox(height: 16),
            const Text('Yıldızlı mesaj yok', style: TextStyle(color: Colors.white38, fontSize: 16)),
            const SizedBox(height: 8),
            const Text('Mesaja uzun basarak yıldızla', style: TextStyle(color: Colors.white24, fontSize: 13)),
          ]));

          return Container(
            color: const Color(0xFF0D0D0D),
            child: ListView.builder(
            itemCount: msgs.length,
            itemBuilder: (ctx, i) {
              final data = msgs[i].data() as Map<String, dynamic>;
              final msg = data['message'] as String? ?? '';
              final sender = data['senderName'] as String? ?? '';
              final ts = data['starredAt'] as Timestamp?;
              final dateStr = ts != null ? DateFormat('dd MMM, HH:mm', 'tr').format(ts.toDate()) : '';

              return Container(
                margin: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                decoration: BoxDecoration(
                  color: const Color(0xFF111111),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.amber.withOpacity(0.2)),
                ),
                child: ListTile(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                  leading: Container(padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(color: Colors.amber.withOpacity(0.1), shape: BoxShape.circle),
                      child: const Icon(Icons.star_rounded, color: Colors.amber, size: 20)),
                  title: _buildMsgPreview(msg),
                  subtitle: Padding(padding: const EdgeInsets.only(top: 4),
                      child: Row(children: [
                        Text(sender, style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12)),
                        const Text(' · ', style: TextStyle(color: Colors.white24)),
                        Text(dateStr, style: const TextStyle(color: Colors.white24, fontSize: 12)),
                      ])),
                  trailing: IconButton(
                    icon: const Icon(Icons.star_rounded, color: Colors.amber, size: 20),
                    onPressed: () => DatabaseMethods.unstarMessage(msgs[i].id),
                  ),
                ),
              ));
            },
          );
        },
      ),
    );
  }

  Widget _buildMsgPreview(String msg) {
    if (msg.startsWith('[resim]:')) return Row(children: [const Icon(Icons.image, color: Colors.white38, size: 16), const SizedBox(width: 6), const Text('Fotoğraf', style: TextStyle(color: Colors.white70))]);
    if (msg.startsWith('[ses]:')) return Row(children: [const Icon(Icons.mic, color: Colors.white38, size: 16), const SizedBox(width: 6), const Text('Ses mesajı', style: TextStyle(color: Colors.white70))]);
    if (msg.startsWith('[konum]:')) return Row(children: [const Icon(Icons.location_on, color: Colors.green, size: 16), const SizedBox(width: 6), const Text('Konum', style: TextStyle(color: Colors.white70))]);
    if (msg.startsWith('[dosya]:')) return Row(children: [const Icon(Icons.attach_file, color: Colors.blue, size: 16), const SizedBox(width: 6), const Text('Dosya', style: TextStyle(color: Colors.white70))]);
    if (msg.startsWith('[anket]:')) return Row(children: [const Icon(Icons.poll, color: Colors.orange, size: 16), const SizedBox(width: 6), const Text('Anket', style: TextStyle(color: Colors.white70))]);
    return Text(msg, style: const TextStyle(color: Colors.white, fontSize: 14), maxLines: 2, overflow: TextOverflow.ellipsis);
  }
}
