import 'package:easy_localization/easy_localization.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_core/firebase_core.dart' show Firebase;

import 'asgard.dart';
import 'firebase_options.dart';
import 'helpers/notifications.dart';
import 'helpers/notifications_instance.dart';
import 'router/app_routes.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  if (message.data['type'] == 'incoming_call') {
    final callId = message.data['callId'] ?? '';
    final callerName = message.data['callerName'] ?? 'Arama';
    final isVideo = message.data['isVideo'] == 'true';

    final androidDetails = AndroidNotificationDetails(
      'asgard_calls',
      'Aramalar',
      channelDescription: 'Gelen arama bildirimleri',
      importance: Importance.max,
      priority: Priority.max,
      fullScreenIntent: true,
      category: AndroidNotificationCategory.call,
      ongoing: true,
      autoCancel: false,
      playSound: true,
      enableVibration: true,
      visibility: NotificationVisibility.public,
      actions: const [
        AndroidNotificationAction(
          'reject_call',
          'Reddet',
          cancelNotification: true,
          showsUserInterface: false,
        ),
        AndroidNotificationAction(
          'accept_call',
          'Cevapla',
          cancelNotification: true,
          showsUserInterface: true,
        ),
      ],
    );
    final plugin = FlutterLocalNotificationsPlugin();
    await plugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
      onDidReceiveNotificationResponse: (details) async {
        // Handled in main app
      },
    );
    await plugin.show(
      callId.hashCode,
      callerName,
      isVideo ? '📹 Görüntülü arama' : '📞 Sesli arama',
      NotificationDetails(android: androidDetails),
      payload: 'call:$callId:$callerName:$isVideo',
    );
  }
}

String? _pendingCallPayload;

Future<void> main() async {
  // Flutter engine hemen başlat
  WidgetsFlutterBinding.ensureInitialized();

  // Status bar tamamen şeffaf, edge-to-edge tam ekran
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF0D0D0D),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Tüm init'leri paralel çalıştır - en hızlı yol
  await Future.wait([
    EasyLocalization.ensureInitialized(),
    Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform),
    ScreenUtil.ensureScreenSize(),
  ]);

  // Bildirim sistemi başlat
  await HelperNotification.initialize(flutterLocalNotificationsPlugin);

  // Bildirim action handler (cevapla/reddet)
  await flutterLocalNotificationsPlugin.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ),
    onDidReceiveNotificationResponse: (NotificationResponse response) {
      final payload = response.payload ?? '';
      if (payload.startsWith('call:')) {
        final parts = payload.split(':');
        if (parts.length >= 3) {
          final callId = parts[1];
          final callerName = parts[2];
          final isVideo = parts.length > 3 && parts[3] == 'true';
          if (response.actionId == 'reject_call') {
            // Reddet - Firestore güncelle
            FirebaseFirestore.instance
                .collection('calls')
                .doc(callId)
                .update({'status': 'rejected'}).catchError((_) {});
          } else {
            // Cevapla veya bildirime tıkla - arama ekranını aç
            _pendingCallPayload = 'call:$callId:$callerName:$isVideo';
          }
        }
      }
    },
  );

  // Arama bildirimi için özel kanal (Android 8+)
  const callChannel = AndroidNotificationChannel(
    'asgard_calls',
    'Aramalar',
    description: 'Gelen arama bildirimleri',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );
  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(callChannel);
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Uygulama AÇIKKEN gelen FCM mesajlarını göster
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    final notification = message.notification;
    if (notification != null) {
      HelperNotification.showNotification(
        notification.title ?? '',
        notification.body ?? '',
        flutterLocalNotificationsPlugin,
      );
    }
  });

  // Uygulamayı HEMEN başlat - initApp arka planda çalışacak
  // Pending call from notification
  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('tr'), Locale('en'), Locale('ar'), Locale('de'), Locale('es'), Locale('fr'), Locale('hi'), Locale('it'), Locale('ja'), Locale('ko'), Locale('pt'), Locale('ru'), Locale('zh')],
      path: 'assets/translations',
      startLocale: const Locale('tr'),
      child: Asgard(appRoute: AppRoute()),
    ),
  );
}
