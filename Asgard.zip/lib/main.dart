import 'package:easy_localization/easy_localization.dart';
import 'services/local_cache.dart';
import 'services/message_queue_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_core/firebase_core.dart' show Firebase;

import 'asgard.dart';
import 'firebase_options.dart';
import 'helpers/notifications.dart';
import 'helpers/notifications_instance.dart';
import 'router/app_routes.dart';
import 'helpers/app_state.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Kotlin AsgardMessagingService tarafından handle ediliyor
  // Bu handler sadece Flutter engine için kayıt amaçlı
}

/// Bildirim action handler (uygulama açıkken)
void _onNotificationAction(NotificationResponse response) {
  if (response.actionId == 'reply_action') {
    _handleInlineReply(response);
  } else {
    _handleCallAction(response.actionId, response.payload);
  }
}

@pragma('vm:entry-point')
void _onNotificationActionBackground(NotificationResponse response) {
  if (response.actionId == 'reply_action') {
    _handleInlineReply(response);
  } else {
    _handleCallAction(response.actionId, response.payload);
  }
}

Future<void> _handleInlineReply(NotificationResponse response) async {
  final replyText = response.input?.trim() ?? '';
  final payload = response.payload ?? '';
  if (replyText.isEmpty || !payload.startsWith('chat:')) return;

  final parts = payload.split(':');
  if (parts.length < 3) return;
  final senderUID = parts[1];

  try {
    // Mesaj kuyruğunu başlat (offline → online geçişte otomatik flush)
  MessageQueueService.instance.start();

  FirebaseFirestore.instance.settings = const Settings(persistenceEnabled: true, cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED);
  await Firebase.initializeApp();
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final chatRoomID = [currentUser.uid, senderUID]..sort();
    final roomID = chatRoomID.join('_');

    await FirebaseFirestore.instance
        .collection('chats')
        .doc(roomID)
        .collection('messages')
        .add({
      'senderID': currentUser.uid,
      'receiverID': senderUID,
      'message': replyText,
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'delivered',
      'senderName': currentUser.displayName ?? '',
    });

    // Bildirimi kapat - "yükleniyorda kalma" sorunu çözülür
    await FlutterLocalNotificationsPlugin()
        .cancel(senderUID.hashCode);

  } catch (_) {}
}

void _handleCallAction(String? actionId, String? payload) {
  if (payload == null) return;

  if (payload.startsWith('call:')) {
    final parts = payload.split(':');
    if (parts.length < 2) return;
    final callId = parts[1];
    if (actionId == 'reject_call') {
      FirebaseFirestore.instance
          .collection('calls')
          .doc(callId)
          .update({'status': 'rejected'}).catchError((_) {});
      FlutterLocalNotificationsPlugin().cancel(callId.hashCode);
    }
  } else if (payload.startsWith('chat:') && actionId == 'reply_action') {
    // Inline reply: bildirimden direkt mesaj gönder
    final parts = payload.split(':');
    if (parts.length < 3) return;
    final senderUID = parts[1]; // mesajı gönderen kişi = bizim alıcımız
    final replyText = actionId; // NOT: reply text NotificationResponse.input'tan gelir
    // Bu kısım onDidReceiveNotificationResponse'da handle edilir
  }
}

Future<void> main() async {
  // Flutter engine hemen başlat
  WidgetsFlutterBinding.ensureInitialized();
  // Offline cache başlat
  await LocalCache.init();

  // Status bar tamamen şeffaf, edge-to-edge tam ekran
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF0D0D0D),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Tüm init'leri paralel çalıştır - en hızlı yol
  await Future.wait([
    EasyLocalization.ensureInitialized(),
    Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform),
    ScreenUtil.ensureScreenSize(),
  ]);

  // Bildirim sistemi başlat
  await flutterLocalNotificationsPlugin.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ),
    onDidReceiveNotificationResponse: _onNotificationAction,
    onDidReceiveBackgroundNotificationResponse: _onNotificationActionBackground,
  );

  // Arama bildirimi için özel kanal (Android 8+)
  const callChannel = AndroidNotificationChannel(
    'asgard_calls',
    'Aramalar',
    description: 'Gelen arama bildirimleri',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );
  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(callChannel);
  // Uygulama AÇIKKEN gelen FCM mesajlarını filtrele
  // FCM listener - app lifetime, intentional no cancel
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    final type = message.data['type'] ?? 'chat';

    // FIX BİLDİRİM: Arama bildirimi — uygulama açıkken gösterme
    // asgard.dart içindeki Firestore listener zaten dialog açıyor
    if (type == 'incoming_call') return;

    // FIX BİLDİRİM: Arama ekranındayken hiç bildirim gösterme
    if (AppState.instance.isInCallScreen) return;

    final senderUID = message.data['uid'] ?? '';

    // FIX BİLDİRİM: O kişiyle zaten chat ekranındaysak bildirim gösterme
    if (AppState.instance.activeChatUID != null &&
        AppState.instance.activeChatUID == senderUID) return;

    final notif = message.notification;
    final title = notif?.title ?? message.data['name'] ?? message.data['title'] ?? '';
    final body  = notif?.body  ?? message.data['body']  ?? '';
    if (title.isEmpty && body.isEmpty) return;

    HelperNotification.showNotification(
      title,
      body,
      flutterLocalNotificationsPlugin,
      senderUID: senderUID,
      receiverUID: message.data['receiverUID'] ?? '',
    );
  });

  // Uygulamayı HEMEN başlat - initApp arka planda çalışacak
  // Offline mesaj kuyruğunu başlat
  MessageQueueService.instance.start();

  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('tr'), Locale('en'), Locale('ar'), Locale('de'), Locale('es'), Locale('fr'), Locale('hi'), Locale('it'), Locale('ja'), Locale('ko'), Locale('pt'), Locale('ru'), Locale('zh')],
      path: 'assets/translations',
      startLocale: const Locale('tr'),
      child: Asgard(appRoute: AppRoute()),
    ),
  );
}
