import 'package:easy_localization/easy_localization.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_core/firebase_core.dart' show Firebase;

import 'asgard.dart';
import 'firebase_options.dart';
import 'helpers/notifications.dart';
import 'helpers/notifications_instance.dart';
import 'router/app_routes.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  // Arama bildirimi gelince local notification göster (uygulama kapalıyken)
  if (message.data['type'] == 'incoming_call') {
    const androidDetails = AndroidNotificationDetails(
      'asgard_calls',
      'Aramalar',
      importance: Importance.max,
      priority: Priority.max,
      fullScreenIntent: true,
      category: AndroidNotificationCategory.call,
      ongoing: true,
      autoCancel: false,
      playSound: true,
      enableVibration: true,
      visibility: NotificationVisibility.public,
    );
    final plugin = FlutterLocalNotificationsPlugin();
    await plugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
    );
    await plugin.show(
      message.data['callId'].hashCode,
      message.data['callerName'] ?? 'Arama',
      message.data['isVideo'] == 'true'
          ? 'Görüntülü arama geliyor...'
          : 'Sesli arama geliyor...',
      const NotificationDetails(android: androidDetails),
      payload: 'call:${message.data['callId']}:${message.data['callerName']}:${message.data['isVideo']}',
    );
  }
}

/// Bildirim action handler (uygulama açıkken)
void _onNotificationAction(NotificationResponse response) {
  if (response.actionId == 'reply_action') {
    _handleInlineReply(response);
  } else {
    _handleCallAction(response.actionId, response.payload);
  }
}

@pragma('vm:entry-point')
void _onNotificationActionBackground(NotificationResponse response) {
  if (response.actionId == 'reply_action') {
    _handleInlineReply(response);
  } else {
    _handleCallAction(response.actionId, response.payload);
  }
}

Future<void> _handleInlineReply(NotificationResponse response) async {
  final replyText = response.input?.trim() ?? '';
  final payload = response.payload ?? '';
  if (replyText.isEmpty || !payload.startsWith('chat:')) return;

  final parts = payload.split(':');
  if (parts.length < 3) return;
  final senderUID = parts[1]; // karşı tarafın UID'i
  // final myUID = parts[2];   // bizim UID'imiz

  try {
    await Firebase.initializeApp();
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final chatRoomID = [currentUser.uid, senderUID]..sort();
    final roomID = chatRoomID.join('_');
    final ts = Timestamp.now();

    await FirebaseFirestore.instance
        .collection('chats')
        .doc(roomID)
        .collection('messages')
        .add({
      'senderID': currentUser.uid,
      'receiverID': senderUID,
      'message': replyText,
      'timestamp': ts,
      'status': 'delivered',
      'senderName': currentUser.displayName ?? '',
    });
  } catch (_) {}
}

void _handleCallAction(String? actionId, String? payload) {
  if (payload == null) return;

  if (payload.startsWith('call:')) {
    final parts = payload.split(':');
    if (parts.length < 2) return;
    final callId = parts[1];
    if (actionId == 'reject_call') {
      FirebaseFirestore.instance
          .collection('calls')
          .doc(callId)
          .update({'status': 'rejected'}).catchError((_) {});
      FlutterLocalNotificationsPlugin().cancel(callId.hashCode);
    }
  } else if (payload.startsWith('chat:') && actionId == 'reply_action') {
    // Inline reply: bildirimden direkt mesaj gönder
    final parts = payload.split(':');
    if (parts.length < 3) return;
    final senderUID = parts[1]; // mesajı gönderen kişi = bizim alıcımız
    final replyText = actionId; // NOT: reply text NotificationResponse.input'tan gelir
    // Bu kısım onDidReceiveNotificationResponse'da handle edilir
  }
}

Future<void> main() async {
  // Flutter engine hemen başlat
  WidgetsFlutterBinding.ensureInitialized();

  // Status bar tamamen şeffaf, edge-to-edge tam ekran
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF0D0D0D),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Tüm init'leri paralel çalıştır - en hızlı yol
  await Future.wait([
    EasyLocalization.ensureInitialized(),
    Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform),
    ScreenUtil.ensureScreenSize(),
  ]);

  // Bildirim sistemi başlat
  await flutterLocalNotificationsPlugin.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ),
    onDidReceiveNotificationResponse: _onNotificationAction,
    onDidReceiveBackgroundNotificationResponse: _onNotificationActionBackground,
  );

  // Arama bildirimi için özel kanal (Android 8+)
  const callChannel = AndroidNotificationChannel(
    'asgard_calls',
    'Aramalar',
    description: 'Gelen arama bildirimleri',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );
  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(callChannel);
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Uygulama AÇIKKEN gelen FCM mesajlarını göster
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    final type = message.data['type'] ?? 'chat';
    if (type == 'incoming_call') {
      // Arama bildirimi - background handler ile aynı
      _firebaseMessagingBackgroundHandler(message);
      return;
    }
    // Mesaj bildirimi - data'dan oku (notification payload yok)
    final title = message.data['name'] ?? message.data['title'] ?? '';
    final body = message.data['body'] ?? '';
    if (title.isNotEmpty || body.isNotEmpty) {
      HelperNotification.showNotification(
        title,
        body,
        flutterLocalNotificationsPlugin,
        senderUID: message.data['uid'] ?? '',
        receiverUID: message.data['receiverUID'] ?? '',
      );
    }
  });

  // Uygulamayı HEMEN başlat - initApp arka planda çalışacak
  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('tr'), Locale('en'), Locale('ar'), Locale('de'), Locale('es'), Locale('fr'), Locale('hi'), Locale('it'), Locale('ja'), Locale('ko'), Locale('pt'), Locale('ru'), Locale('zh')],
      path: 'assets/translations',
      startLocale: const Locale('tr'),
      child: Asgard(appRoute: AppRoute()),
    ),
  );
}
