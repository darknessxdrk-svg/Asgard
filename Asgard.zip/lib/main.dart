import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:firebase_messaging/firebase_messaging.dart';

import 'asgard.dart';
import 'firebase_options.dart';
import 'helpers/notifications.dart';
import 'helpers/notifications_instance.dart';
import 'router/app_routes.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Arka planda gelen mesajlar - Firebase otomatik gösterir
}

Future<void> main() async {
  // Flutter engine hemen başlat
  WidgetsFlutterBinding.ensureInitialized();

  // Status bar tamamen şeffaf, edge-to-edge tam ekran
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF0D0D0D),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Tüm init'leri paralel çalıştır - en hızlı yol
  await Future.wait([
    EasyLocalization.ensureInitialized(),
    Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform),
    ScreenUtil.ensureScreenSize(),
  ]);

  // Bildirim sistemi başlat
  await HelperNotification.initialize(flutterLocalNotificationsPlugin);
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Uygulama AÇIKKEN gelen FCM mesajlarını göster
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    final notification = message.notification;
    if (notification != null) {
      HelperNotification.showNotification(
        notification.title ?? '',
        notification.body ?? '',
        flutterLocalNotificationsPlugin,
      );
    }
  });

  // Uygulamayı HEMEN başlat - initApp arka planda çalışacak
  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('tr'), Locale('en'), Locale('ar'), Locale('de'), Locale('es'), Locale('fr'), Locale('hi'), Locale('it'), Locale('ja'), Locale('ko'), Locale('pt'), Locale('ru'), Locale('zh')],
      path: 'assets/translations',
      startLocale: const Locale('tr'),
      child: Asgard(appRoute: AppRoute()),
    ),
  );
}
