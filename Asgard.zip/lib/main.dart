import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_core/firebase_core.dart' show Firebase;

import 'asgard.dart';
import 'firebase_options.dart';
import 'helpers/notifications.dart';
import 'helpers/notifications_instance.dart';
import 'router/app_routes.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  // Arama bildirimi gelince local notification göster (uygulama kapalıyken)
  if (message.data['type'] == 'incoming_call') {
    const androidDetails = AndroidNotificationDetails(
      'asgard_calls',
      'Aramalar',
      importance: Importance.max,
      priority: Priority.max,
      fullScreenIntent: true,
      category: AndroidNotificationCategory.call,
      ongoing: true,
      autoCancel: false,
      playSound: true,
      enableVibration: true,
      visibility: NotificationVisibility.public,
    );
    final plugin = FlutterLocalNotificationsPlugin();
    await plugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
    );
    await plugin.show(
      message.data['callId'].hashCode,
      message.data['callerName'] ?? 'Arama',
      message.data['isVideo'] == 'true'
          ? 'Görüntülü arama geliyor...'
          : 'Sesli arama geliyor...',
      const NotificationDetails(android: androidDetails),
      payload: 'call:${message.data['callId']}:${message.data['callerName']}:${message.data['isVideo']}',
    );
  }
}

Future<void> main() async {
  // Flutter engine hemen başlat
  WidgetsFlutterBinding.ensureInitialized();

  // Status bar tamamen şeffaf, edge-to-edge tam ekran
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF0D0D0D),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Tüm init'leri paralel çalıştır - en hızlı yol
  await Future.wait([
    EasyLocalization.ensureInitialized(),
    Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform),
    ScreenUtil.ensureScreenSize(),
  ]);

  // Bildirim sistemi başlat
  await HelperNotification.initialize(flutterLocalNotificationsPlugin);

  // Arama bildirimi için özel kanal (Android 8+)
  const callChannel = AndroidNotificationChannel(
    'asgard_calls',
    'Aramalar',
    description: 'Gelen arama bildirimleri',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );
  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(callChannel);
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Uygulama AÇIKKEN gelen FCM mesajlarını göster
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    final notification = message.notification;
    if (notification != null) {
      HelperNotification.showNotification(
        notification.title ?? '',
        notification.body ?? '',
        flutterLocalNotificationsPlugin,
      );
    }
  });

  // Uygulamayı HEMEN başlat - initApp arka planda çalışacak
  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('tr'), Locale('en'), Locale('ar'), Locale('de'), Locale('es'), Locale('fr'), Locale('hi'), Locale('it'), Locale('ja'), Locale('ko'), Locale('pt'), Locale('ru'), Locale('zh')],
      path: 'assets/translations',
      startLocale: const Locale('tr'),
      child: Asgard(appRoute: AppRoute()),
    ),
  );
}
