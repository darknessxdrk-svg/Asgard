import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Global FlutterLocalNotificationsPlugin instance
/// main.dart'ta initialize edilir, her yerden import edilebilir
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();
