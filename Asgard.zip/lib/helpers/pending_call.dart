/// Bildirimden açılan uygulamada bekleyen arama payload'ı
String? pendingCallPayload;
