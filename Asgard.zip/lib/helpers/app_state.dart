/// Uygulama genelinde aktif ekran bilgisi
/// Bildirim filtrelemesi için kullanılır
class AppState {
  AppState._();
  static final AppState instance = AppState._();

  /// Şu an açık olan chat ekranının karşı taraf UID'i
  /// null = chat ekranında değil
  String? activeChatUID;

  /// Şu an arama ekranında mı
  bool isInCallScreen = false;
}
