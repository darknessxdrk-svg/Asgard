import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'notifications_instance.dart';

class HelperNotification {
  static Future<void> initialize(
      FlutterLocalNotificationsPlugin plugin) async {
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: false, // FCM kendi bildirimi göstermesin
      badge: true,
      sound: false,
    );
  }

  static Future<void> showNotification(
    String title,
    String body,
    FlutterLocalNotificationsPlugin plugin, {
    String senderUID = '',
    String receiverUID = '',
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'asgardappid',
      'Asgard Mesajlar',
      channelDescription: 'Asgard mesaj bildirimleri',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      visibility: NotificationVisibility.public,
      actions: const [
        AndroidNotificationAction(
          'reply_action',
          'Yanıtla 💬',
          inputs: [
            AndroidNotificationActionInput(label: 'Mesaj yaz...'),
          ],
          cancelNotification: false,
          showsUserInterface: false,
        ),
      ],
    );

    await flutterLocalNotificationsPlugin.show(
      senderUID.isNotEmpty ? senderUID.hashCode : 0,
      title,
      body,
      NotificationDetails(android: androidDetails),
      payload: 'chat:$senderUID:$receiverUID',
    );
  }
}
