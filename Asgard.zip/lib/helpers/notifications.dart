import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/services.dart';
import 'notifications_instance.dart';

class HelperNotification {
  // Native Android reply için MethodChannel
  static const _channel = MethodChannel('com.asgard/notifications');

  static Future<void> initialize(
      FlutterLocalNotificationsPlugin plugin) async {
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: false,
      badge: true,
      sound: false,
    );
  }

  static Future<void> showNotification(
    String title,
    String body,
    FlutterLocalNotificationsPlugin plugin, {
    String senderUID = '',
    String receiverUID = '',
  }) async {
    try {
      // Native Kotlin tarafına gönder - orası RemoteInput ile bildirim gösterir
      await _channel.invokeMethod('showMessageNotification', {
        'title': title,
        'body': body,
        'senderUID': senderUID,
        'receiverUID': receiverUID,
        'notifId': senderUID.isNotEmpty ? senderUID.hashCode : 0,
      });
    } catch (_) {
      // Native çalışmazsa flutter_local_notifications ile fallback
      final androidDetails = AndroidNotificationDetails(
        'asgardappid',
        'Asgard Mesajlar',
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        enableVibration: true,
        visibility: NotificationVisibility.public,
        actions: const [
          AndroidNotificationAction(
            'reply_action', 'Yanıtla 💬',
            inputs: [AndroidNotificationActionInput(label: 'Mesaj yaz...')],
            cancelNotification: false,
            showsUserInterface: false,
          ),
        ],
      );
      await flutterLocalNotificationsPlugin.show(
        senderUID.isNotEmpty ? senderUID.hashCode : 0,
        title,
        body,
        NotificationDetails(android: androidDetails),
        payload: 'chat:$senderUID:$receiverUID',
      );
    }
  }
}
