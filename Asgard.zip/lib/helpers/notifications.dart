import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class HelperNotification {
  static Future<void> initialize(
      FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin) async {
    const initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const initializationSettingsDarwin = DarwinInitializationSettings();

    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsDarwin,
    );
    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }

  static Future<void> showNotification(
    String title,
    String body,
    FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin, {
    String senderUID = '',
    String receiverUID = '',
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'asgardappid',
      'Asgard Mesajlar',
      channelDescription: 'Asgard mesaj bildirimleri',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      visibility: NotificationVisibility.public,
      icon: '@mipmap/ic_launcher',
      // Inline reply action
      actions: <AndroidNotificationAction>[
        AndroidNotificationAction(
          'reply_action',
          'Yanıtla',
          inputs: const <AndroidNotificationActionInput>[
            AndroidNotificationActionInput(label: 'Mesaj yaz...'),
          ],
          cancelNotification: false,
          showsUserInterface: false,
        ),
      ],
    );
    final notifDetails = NotificationDetails(
      android: androidDetails,
      iOS: const DarwinNotificationDetails(),
    );
    // Her gönderici için ayrı bildirim ID (üst üste gelmesin)
    final notifId = senderUID.isNotEmpty ? senderUID.hashCode : 0;
    await flutterLocalNotificationsPlugin.show(
      notifId,
      title,
      body,
      notifDetails,
      payload: 'chat:$senderUID:$receiverUID',
    );
  }
}
