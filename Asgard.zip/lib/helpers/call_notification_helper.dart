import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../main.dart' show flutterLocalNotificationsPlugin;

/// Gelen arama için tam ekran + sesli bildirim
class CallNotificationHelper {
  static Future<void> showIncomingCall({
    required String callId,
    required String callerName,
    required bool isVideo,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'asgard_calls',
      'Aramalar',
      channelDescription: 'Gelen arama bildirimleri',
      importance: Importance.max,
      priority: Priority.max,
      fullScreenIntent: true,
      category: AndroidNotificationCategory.call,
      ongoing: true,
      autoCancel: false,
      playSound: true,
      enableVibration: true,
      visibility: NotificationVisibility.public,
      sound: RawResourceAndroidNotificationSound('notification'),
      actions: <AndroidNotificationAction>[
        AndroidNotificationAction(
          'reject_call',
          'Reddet',
          cancelNotification: true,
          showsUserInterface: false,
        ),
        AndroidNotificationAction(
          'accept_call',
          'Kabul Et',
          cancelNotification: true,
          showsUserInterface: true,
        ),
      ],
    );

    const notifDetails = NotificationDetails(android: androidDetails);

    await flutterLocalNotificationsPlugin.show(
      callId.hashCode,
      callerName,
      isVideo ? '📹 Görüntülü arama geliyor...' : '📞 Sesli arama geliyor...',
      notifDetails,
      payload: 'call:$callId:${callerName}:$isVideo',
    );
  }

  static Future<void> dismissCallNotification(String callId) async {
    await flutterLocalNotificationsPlugin.cancel(callId.hashCode);
  }
}
