import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'notifications_instance.dart';

class CallNotificationHelper {
  static Future<void> showIncomingCall({
    required String callId,
    required String callerName,
    required bool isVideo,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'asgard_calls',
      'Aramalar',
      channelDescription: 'Gelen arama bildirimleri',
      importance: Importance.max,
      priority: Priority.max,
      fullScreenIntent: true,
      category: AndroidNotificationCategory.call,
      ongoing: true,
      autoCancel: false,
      playSound: true,
      enableVibration: true,
      visibility: NotificationVisibility.public,
      actions: const [
        AndroidNotificationAction(
          'reject_call',
          'Reddet 📵',
          cancelNotification: true,
          showsUserInterface: false,
        ),
        AndroidNotificationAction(
          'accept_call',
          'Cevapla 📞',
          cancelNotification: true,
          showsUserInterface: true,
        ),
      ],
    );

    await flutterLocalNotificationsPlugin.show(
      callId.hashCode,
      callerName,
      isVideo ? '📹 Görüntülü arama geliyor...' : '📞 Sesli arama geliyor...',
      NotificationDetails(android: androidDetails),
      payload: 'call:$callId:$callerName:$isVideo',
    );
  }

  static Future<void> dismissCallNotification(String callId) async {
    await flutterLocalNotificationsPlugin.cancel(callId.hashCode);
  }
}
