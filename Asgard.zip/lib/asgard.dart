import 'package:app_links/app_links.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:pub_semver/pub_semver.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'features/splash/splash_screen.dart';
import 'router/app_routes.dart';
import 'router/routes.dart';
import 'services/database.dart';
import 'themes/colors.dart';

class Asgard extends StatefulWidget {
  final AppRoute appRoute;
  const Asgard({super.key, required this.appRoute});
  @override
  State<Asgard> createState() => _AsgardState();
}

class _AsgardState extends State<Asgard> with WidgetsBindingObserver {
  bool _showSplash = true;
  String? _pendingRoute;
  final _navigatorKey = GlobalKey<NavigatorState>();
  final _appLinks = AppLinks();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initRoute();
    _initDeepLinks();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      DatabaseMethods.setOnline(true);
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.detached) {
      DatabaseMethods.setOnline(false);
    }
  }

  Future<void> _initDeepLinks() async {
    try {
      final uri = await _appLinks.getInitialAppLink();
      if (uri != null) _handleDeepLink(uri);
    } catch (_) {}
    _appLinks.allUriLinkStream.listen(_handleDeepLink);
  }

  void _handleDeepLink(Uri uri) {
    if (uri.scheme != 'asgard') return;
    if (FirebaseAuth.instance.currentUser == null) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final nav = _navigatorKey.currentState;
      if (nav == null) return;
      if (uri.host == 'group' && uri.pathSegments.isNotEmpty) {
        nav.pushNamed(Routes.groupChatPage,
            arguments: {'groupId': uri.pathSegments.first, 'groupName': 'Grup'});
      } else if (uri.host == 'add' && uri.pathSegments.isNotEmpty) {
        nav.pushNamed(Routes.searchScreen, arguments: uri.pathSegments.first);
      }
    });
  }

  Future<void> _initRoute() async {
    String route = Routes.loginScreen;
    try {
      try {
        final packageInfo = await PackageInfo.fromPlatform();
        final doc = await FirebaseFirestore.instance
            .collection('version')
            .doc('newest')
            .get();
        if (doc.exists && doc['version'] != null) {
          final serverVer = Version.parse(doc['version'].toString());
          final appVer = Version.parse(packageInfo.version);
          if (serverVer.compareTo(appVer) > 0) {
            route = Routes.updateScreen;
          }
        }
      } catch (_) {}

      if (route != Routes.updateScreen) {
        final user = await FirebaseAuth.instance.authStateChanges().first;
        if (user == null || !user.emailVerified) {
          route = Routes.loginScreen;
        } else {
          try {
            final userDoc = await FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .get();
            if (!userDoc.exists) {
              await FirebaseFirestore.instance
                  .collection('users')
                  .doc(user.uid)
                  .set({
                'uid': user.uid,
                'name': user.displayName ??
                    user.email?.split('@').first ??
                    'Kullanıcı',
                'email': user.email ?? '',
                'username':
                    (user.email?.split('@').first ?? 'user_${user.uid.substring(0, 6)}')
                        .toLowerCase()
                        .replaceAll(RegExp(r'[^a-z0-9_]'), '_'),
                'profilePic': user.photoURL ?? '',
                'isOnline': 'false',
                'mtoken': '',
              });
            }
          } catch (_) {}

          final prefs = await SharedPreferences.getInstance();
          final localAuth = prefs.getBool('auth_screen_enabled') ?? false;
          route = localAuth ? Routes.authScreen : Routes.homeScreen;
        }
      }

      try {
        final messaging = FirebaseMessaging.instance;
        await messaging.requestPermission();
        FirebaseMessaging.onBackgroundMessage(_bgHandler);
        messaging.onTokenRefresh.listen((token) async {
          await DatabaseMethods.updateUserDetails({'mtoken': token});
        });
      } catch (_) {}
    } catch (_) {}

    if (!mounted) return;

    if (!_showSplash) {
      _navigateTo(route);
    } else {
      _pendingRoute = route;
    }
  }

  void _onSplashComplete() {
    if (!mounted) return;
    setState(() => _showSplash = false);
    final route = _pendingRoute;
    if (route != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _navigateTo(route));
    }
  }

  void _navigateTo(String route) {
    _navigatorKey.currentState?.pushNamedAndRemoveUntil(route, (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      child: MaterialApp(
        navigatorKey: _navigatorKey,
        title: 'Asgard',
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        themeMode: ThemeMode.dark,
        darkTheme: _buildDarkTheme(),
        theme: _buildLightTheme(),
        initialRoute: Routes.loginScreen,
        onGenerateRoute: widget.appRoute.onGenerateRoute,
        debugShowCheckedModeBanner: false,
        builder: (context, child) {
          if (_showSplash) {
            return SplashScreen(onComplete: _onSplashComplete);
          }
          return child ?? const SizedBox.shrink();
        },
      ),
    );
  }

  // ─── KARANLIK TEMA ────────────────────────────────────────────────────────
  // canvasColor: ListView, TabBarView, BottomSheet ve tüm Material arka planı
  // surface: Card, Dialog, BottomNavigationBar arka planı
  // Bu iki renk OLMADAN Flutter gri/beyaz varsayılan Canvas Color kullanır
  ThemeData _buildDarkTheme() => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        // ✅ KRİTİK: bu 3 renk gri ekranı önler
        canvasColor: const Color(0xFF0D0D0D),
        scaffoldBackgroundColor: const Color(0xFF0D0D0D),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFE53935),
          primaryContainer: Color(0xFFB71C1C),
          secondary: Color(0xFFFF5252),
          surface: Color(0xFF0D0D0D),       // Card, BottomSheet arkaplanı
          surfaceContainerHighest: Color(0xFF1A1A1A),
          surfaceContainer: Color(0xFF111111),
          error: Colors.redAccent,
          onPrimary: Colors.white,
          onSecondary: Colors.white,
          onSurface: Colors.white,
          onSurfaceVariant: Color(0xFFCCCCCC),
          outline: Color(0xFF333333),
        ),
        primaryColor: const Color(0xFFE53935),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF111111),
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
        textSelectionTheme: const TextSelectionThemeData(
          cursorColor: Color(0xFFE53935),
          selectionHandleColor: Color(0xFFE53935),
          selectionColor: Color(0x55E53935),
        ),
        progressIndicatorTheme: const ProgressIndicatorThemeData(
          color: Color(0xFFE53935),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFFE53935),
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFE53935),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF1A1A1A),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xFFE53935), width: 2),
            borderRadius: BorderRadius.circular(12),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xFF333333)),
            borderRadius: BorderRadius.circular(12),
          ),
          hintStyle: const TextStyle(color: Colors.white38),
        ),
        cardTheme: CardTheme(
          color: const Color(0xFF1A1A1A),
          elevation: 4,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
        ),
        dividerColor: const Color(0xFF2A2A2A),
        iconTheme: const IconThemeData(color: Colors.white70),
        switchTheme: SwitchThemeData(
          thumbColor: WidgetStateProperty.resolveWith((s) =>
              s.contains(WidgetState.selected)
                  ? const Color(0xFFE53935)
                  : Colors.grey),
          trackColor: WidgetStateProperty.resolveWith((s) =>
              s.contains(WidgetState.selected)
                  ? const Color(0x55E53935)
                  : Colors.grey.shade800),
        ),
        listTileTheme: const ListTileThemeData(
          iconColor: Color(0xFFE53935),
          tileColor: Colors.transparent,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Color(0xFF111111),
          selectedItemColor: Color(0xFFE53935),
          unselectedItemColor: Colors.white38,
        ),
        tabBarTheme: const TabBarTheme(
          labelColor: Color(0xFFE53935),
          unselectedLabelColor: Colors.white38,
          indicatorColor: Color(0xFFE53935),
          dividerColor: Colors.transparent,
        ),
        bottomSheetTheme: const BottomSheetThemeData(
          backgroundColor: Color(0xFF1A1A1A),
          modalBackgroundColor: Color(0xFF1A1A1A),
          surfaceTintColor: Colors.transparent,
        ),
        dialogTheme: const DialogTheme(
          backgroundColor: Color(0xFF1A1A1A),
          surfaceTintColor: Colors.transparent,
        ),
        popupMenuTheme: const PopupMenuThemeData(
          color: Color(0xFF1A1A1A),
          surfaceTintColor: Colors.transparent,
        ),
        drawerTheme: const DrawerThemeData(
          backgroundColor: Color(0xFF0D0D0D),
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Color(0xFF111111),
          indicatorColor: Color(0x33E53935),
          iconTheme: WidgetStatePropertyAll(
            IconThemeData(color: Colors.white70),
          ),
        ),
      );

  // ─── AYDINLIK TEMA ────────────────────────────────────────────────────────
  ThemeData _buildLightTheme() => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        canvasColor: const Color(0xFFF5F7FA),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF1976D2),
          secondary: Color(0xFF42A5F5),
          surface: Color(0xFFFFFFFF),
          error: Colors.red,
          onSurface: Colors.black87,
        ),
        primaryColor: const Color(0xFF1976D2),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1565C0),
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF1976D2),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          focusedBorder: OutlineInputBorder(
            borderSide:
                const BorderSide(color: Color(0xFF1976D2), width: 2),
            borderRadius: BorderRadius.circular(12),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 2,
          shadowColor: Colors.black12,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
        ),
        dividerColor: const Color(0xFFEEEEEE),
        iconTheme: const IconThemeData(color: Color(0xFF1976D2)),
        switchTheme: SwitchThemeData(
          thumbColor: WidgetStateProperty.resolveWith((s) =>
              s.contains(WidgetState.selected)
                  ? const Color(0xFF1976D2)
                  : Colors.grey),
          trackColor: WidgetStateProperty.resolveWith((s) =>
              s.contains(WidgetState.selected)
                  ? const Color(0x551976D2)
                  : Colors.grey.shade300),
        ),
        listTileTheme: const ListTileThemeData(
          iconColor: Color(0xFF1976D2),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Colors.white,
          selectedItemColor: Color(0xFF1976D2),
          unselectedItemColor: Colors.black38,
        ),
        tabBarTheme: const TabBarTheme(
          labelColor: Color(0xFF1976D2),
          unselectedLabelColor: Colors.black38,
          indicatorColor: Color(0xFF1976D2),
        ),
      );
}

@pragma('vm:entry-point')
Future<void> _bgHandler(RemoteMessage message) async {}
