import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:pub_semver/pub_semver.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'features/splash/splash_screen.dart';
import 'router/app_routes.dart';
import 'router/routes.dart';
import 'services/database.dart';
import 'themes/colors.dart';

class Asgard extends StatefulWidget {
  final AppRoute appRoute;
  const Asgard({super.key, required this.appRoute});

  @override
  State<Asgard> createState() => _AsgardState();
}

class _AsgardState extends State<Asgard> {
  bool _showSplash = true;
  String _initialRoute = Routes.loginScreen; // varsayılan
  bool _routeReady = false;

  @override
  void initState() {
    super.initState();
    // Native splash hemen kaldır → Flutter UI (splash animasyonu) gösterilir
    // Route belirlemeyi arka planda başlat
    _initRoute();
  }

  Future<void> _initRoute() async {
    String route = Routes.loginScreen;
    try {
      // Version kontrolü
      int compareResult = 0;
      try {
        PackageInfo packageInfo = await PackageInfo.fromPlatform();
        DocumentSnapshot doc = await FirebaseFirestore.instance
            .collection('version').doc('newest').get();
        if (doc.exists && doc['version'] != null) {
          compareResult = Version.parse(doc['version'])
              .compareTo(Version.parse(packageInfo.version));
        }
      } catch (_) {}

      // ✅ FIX: > 0 demek sunucu versiyonu daha yeni → güncelleme gerekli
      // != 0 yanlıştı: uygulamanın daha yeni versiyonu da update ekranına götürüyordu
      if (compareResult > 0) {
        route = Routes.updateScreen;
      } else {
        final user = await FirebaseAuth.instance.authStateChanges().first;
        if (user == null || !user.emailVerified) {
          route = Routes.loginScreen;
        } else {
          try {
            final userDoc = await FirebaseFirestore.instance
                .collection('users').doc(user.uid).get();
            if (!userDoc.exists) {
              await FirebaseFirestore.instance
                  .collection('users').doc(user.uid).set({
                'uid': user.uid,
                'name': user.displayName ?? user.email?.split('@').first ?? 'Kullanıcı',
                'email': user.email ?? '',
                'username': (user.email?.split('@').first ?? 'user_${user.uid.substring(0, 6)}')
                    .toLowerCase().replaceAll(RegExp(r'[^a-z0-9_]'), '_'),
                'profilePic': user.photoURL ?? '',
                'isOnline': 'false',
                'mtoken': '',
              });
            }
          } catch (_) {}
          SharedPreferences prefs = await SharedPreferences.getInstance();
          bool localAuth = prefs.getBool('auth_screen_enabled') ?? false;
          route = localAuth ? Routes.authScreen : Routes.homeScreen;
        }
      }

      // Token yenileme
      FirebaseAuth.instance.authStateChanges().listen((_) {});
      final messaging = FirebaseMessaging.instance;
      await messaging.requestPermission();
      FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
      messaging.onTokenRefresh.listen((fcmToken) async {
        await DatabaseMethods.updateUserDetails({'mtoken': fcmToken});
      });
    } catch (_) {}

    if (mounted) {
      setState(() {
        _initialRoute = route;
        _routeReady = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      child: MaterialApp(
        title: 'Asgard',
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        themeMode: ThemeMode.dark,
        darkTheme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: const ColorScheme.dark(
            primary: ColorsManager.darkPrimary,
            secondary: ColorsManager.darkPrimaryLight,
            surface: ColorsManager.darkSurface,
            error: Colors.redAccent,
          ),
          primaryColor: ColorsManager.darkPrimary,
          scaffoldBackgroundColor: ColorsManager.darkBackground,
          appBarTheme: const AppBarTheme(
            backgroundColor: ColorsManager.darkAppBar,
            foregroundColor: Colors.white,
            elevation: 0,
            centerTitle: true,
            titleTextStyle: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
          textSelectionTheme: const TextSelectionThemeData(
            cursorColor: ColorsManager.darkPrimary,
            selectionHandleColor: ColorsManager.darkPrimary,
            selectionColor: Color(0x55E53935),
          ),
          progressIndicatorTheme: const ProgressIndicatorThemeData(
            color: ColorsManager.darkPrimary,
          ),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: ColorsManager.darkPrimary,
            foregroundColor: Colors.white,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorsManager.darkPrimary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: ColorsManager.darkSurface,
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(
                  color: ColorsManager.darkPrimary, width: 2),
              borderRadius: BorderRadius.circular(12),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFF333333)),
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          cardTheme: CardTheme(
            color: ColorsManager.darkSurface,
            elevation: 4,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
          ),
          dividerColor: const Color(0xFF2A2A2A),
          iconTheme: const IconThemeData(color: Colors.white70),
          switchTheme: SwitchThemeData(
            thumbColor: WidgetStateProperty.resolveWith((s) =>
                s.contains(WidgetState.selected)
                    ? ColorsManager.darkPrimary
                    : Colors.grey),
            trackColor: WidgetStateProperty.resolveWith((s) =>
                s.contains(WidgetState.selected)
                    ? const Color(0x55E53935)
                    : Colors.grey.shade800),
          ),
          listTileTheme:
              const ListTileThemeData(iconColor: ColorsManager.darkPrimary),
          bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: Color(0xFF111111),
            selectedItemColor: ColorsManager.darkPrimary,
            unselectedItemColor: Colors.white38,
          ),
          tabBarTheme: const TabBarTheme(
            labelColor: ColorsManager.darkPrimary,
            unselectedLabelColor: Colors.white38,
            indicatorColor: ColorsManager.darkPrimary,
          ),
        ),
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          colorScheme: const ColorScheme.light(
            primary: ColorsManager.lightPrimary,
            secondary: ColorsManager.lightPrimaryLight,
            surface: ColorsManager.lightSurface,
            error: Colors.red,
          ),
          primaryColor: ColorsManager.lightPrimary,
          scaffoldBackgroundColor: ColorsManager.lightBackground,
          appBarTheme: const AppBarTheme(
            backgroundColor: ColorsManager.lightAppBar,
            foregroundColor: Colors.white,
            elevation: 0,
            centerTitle: true,
            titleTextStyle: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
          textSelectionTheme: const TextSelectionThemeData(
            cursorColor: ColorsManager.lightPrimary,
            selectionHandleColor: ColorsManager.lightPrimary,
            selectionColor: Color(0x551976D2),
          ),
          progressIndicatorTheme: const ProgressIndicatorThemeData(
            color: ColorsManager.lightPrimary,
          ),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: ColorsManager.lightPrimary,
            foregroundColor: Colors.white,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorsManager.lightPrimary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(
                  color: ColorsManager.lightPrimary, width: 2),
              borderRadius: BorderRadius.circular(12),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          cardTheme: CardTheme(
            color: Colors.white,
            elevation: 2,
            shadowColor: Colors.black12,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
          ),
          dividerColor: const Color(0xFFEEEEEE),
          iconTheme: const IconThemeData(color: ColorsManager.lightPrimary),
          switchTheme: SwitchThemeData(
            thumbColor: WidgetStateProperty.resolveWith((s) =>
                s.contains(WidgetState.selected)
                    ? ColorsManager.lightPrimary
                    : Colors.grey),
            trackColor: WidgetStateProperty.resolveWith((s) =>
                s.contains(WidgetState.selected)
                    ? const Color(0x551976D2)
                    : Colors.grey.shade300),
          ),
          listTileTheme:
              const ListTileThemeData(iconColor: ColorsManager.lightPrimary),
          bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: Colors.white,
            selectedItemColor: ColorsManager.lightPrimary,
            unselectedItemColor: Colors.black38,
          ),
          tabBarTheme: const TabBarTheme(
            labelColor: ColorsManager.lightPrimary,
            unselectedLabelColor: Colors.black38,
            indicatorColor: ColorsManager.lightPrimary,
          ),
        ),
        onGenerateRoute: widget.appRoute.onGenerateRoute,
        initialRoute: _initialRoute,
        debugShowCheckedModeBanner: false,
        builder: (context, child) {
          // Splash animasyonu tamamlanana VEYA route hazır olana kadar göster
          if (_showSplash) {
            return SplashScreen(onComplete: () {
              if (mounted) {
                // Route henüz hazır değilse bekle
                if (_routeReady) {
                  setState(() => _showSplash = false);
                } else {
                  // Route hazır olunca splash'ı kaldır
                  _waitForRouteAndHideSplash();
                }
              }
            });
          }
          return child ?? const SizedBox();
        },
      ),
    );
  }

  Future<void> _waitForRouteAndHideSplash() async {
    // Route hazır olana kadar bekle (max 5 saniye)
    for (int i = 0; i < 50; i++) {
      await Future.delayed(const Duration(milliseconds: 100));
      if (_routeReady && mounted) {
        setState(() => _showSplash = false);
        return;
      }
    }
    // Timeout - yine de devam et
    if (mounted) setState(() => _showSplash = false);
  }
}

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {}
