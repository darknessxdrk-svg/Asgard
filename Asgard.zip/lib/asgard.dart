import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:pub_semver/pub_semver.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'features/splash/splash_screen.dart';
import 'features/call/ui/call_screen.dart';
import 'helpers/call_notification_helper.dart';
import 'router/app_routes.dart';
import 'router/routes.dart';
import 'services/database.dart';
import 'helpers/app_state.dart';
import 'themes/colors.dart';

class Asgard extends StatefulWidget {
  final AppRoute appRoute;
  const Asgard({super.key, required this.appRoute});

  @override
  State<Asgard> createState() => _AsgardState();
}

class _AsgardState extends State<Asgard> with WidgetsBindingObserver {
  bool _showSplash = true;
  String _initialRoute = Routes.loginScreen;
  bool _routeReady = false;
  final _appLinks = AppLinks();
  final _navigatorKey = GlobalKey<NavigatorState>();

  // FIX AUTH/LISTENER: tüm subscription'lar tek yerde takip ediliyor
  StreamSubscription<QuerySnapshot>? _callSub;
  StreamSubscription<User?>? _authSub;       // authStateChanges leak fix
  StreamSubscription<Uri>? _deepLinkSub;     // deep link listener leak fix
  StreamSubscription<String>? _fcmTokenSub;  // FCM token refresh leak fix

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initRoute();
    _initDeepLinks();
    _listenIncomingCalls();
  }

  final Set<String> _shownCallIds = {};

  // FIX AUTH/LISTENER: authStateChanges listener artık _authSub'a assign ediliyor
  void _listenIncomingCalls() {
    _authSub = FirebaseAuth.instance.authStateChanges().listen((user) {
      _callSub?.cancel();
      _callSub = null;
      if (user == null) return;
      _callSub = FirebaseFirestore.instance
          .collection('calls')
          .where('calleeId', isEqualTo: user.uid)
          .where('status', isEqualTo: 'ringing')
          .snapshots()
          .listen((snap) {
        for (final doc in snap.docChanges) {
          if (doc.type != DocumentChangeType.added) continue;
          final callId = doc.doc.id;
          if (_shownCallIds.contains(callId)) continue;
          _shownCallIds.add(callId);

          final data = doc.doc.data()!;
          final callerName = (data['callerName'] as String?) ?? '';
          final callerUID = (data['callerId'] as String?) ?? '';
          final isVideo = data['isVideo'] == true;

          final ctx = _navigatorKey.currentContext;
          final isAppForeground = ctx != null && ctx.mounted;

          if (!isAppForeground) {
            // FIX BİLDİRİM: Uygulama arka planda/kapalıysa bildirim göster
            CallNotificationHelper.showIncomingCall(
              callId: callId,
              callerName: callerName,
              isVideo: isVideo,
            );
          } else {
            // FIX BİLDİRİM: Uygulama ön plandaysa bildirim yok, sadece dialog
            showDialog(
              context: ctx,
              barrierDismissible: false,
              builder: (_) => IncomingCallScreen(
                callId: callId,
                callerName: callerName,
                callerUID: callerUID,
                isVideo: isVideo,
              ),
            ).then((_) {
              _shownCallIds.remove(callId);
              CallNotificationHelper.dismissCallNotification(callId);
            });
          }
        }
      });
    });
  }

  @override
  void dispose() {
    // FIX MEMORY: tüm subscription'lar dispose'da iptal ediliyor
    _callSub?.cancel();
    _authSub?.cancel();
    _deepLinkSub?.cancel();
    _fcmTokenSub?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      DatabaseMethods.setOnline(true);
    } else if (state == AppLifecycleState.paused ||
               state == AppLifecycleState.detached) {
      DatabaseMethods.setOnline(false);
    }
  }

  // FIX AUTH/LISTENER: deep link subscription artık _deepLinkSub'a assign ediliyor
  Future<void> _initDeepLinks() async {
    try {
      final uri = await _appLinks.getInitialAppLink();
      if (uri != null) _handleDeepLink(uri);
    } catch (_) {}

    _deepLinkSub = _appLinks.allUriLinkStream.listen((uri) {
      _handleDeepLink(uri);
    });
  }

  void _handleDeepLink(Uri uri) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    String? groupId;
    String? username;

    if (uri.scheme == 'asgard') {
      if (uri.host == 'group' && uri.pathSegments.isNotEmpty) {
        groupId = uri.pathSegments.first;
      } else if (uri.host == 'add' && uri.pathSegments.isNotEmpty) {
        username = uri.pathSegments.first;
      }
    } else if (uri.scheme == 'https' && uri.host.contains('asgard')) {
      groupId = uri.queryParameters['groupId'] ?? uri.queryParameters['id'];
      username = uri.queryParameters['username'];
    }

    // FIX ANDROID SECURITY: deep link input validation — boş/tehlikeli değerleri reddet
    final safeGroupId = groupId?.replaceAll(RegExp(r'[^a-zA-Z0-9_\-]'), '');
    final safeUsername = username?.replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '');

    if (safeGroupId != null && safeGroupId.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_navigatorKey.currentState != null) {
          _navigatorKey.currentState!.pushNamed(
            Routes.groupChatPage,
            arguments: {'groupId': safeGroupId, 'groupName': 'Grup'},
          );
        }
      });
    } else if (safeUsername != null && safeUsername.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_navigatorKey.currentState != null) {
          _navigatorKey.currentState!.pushNamed(
            Routes.searchScreen,
            arguments: safeUsername,
          );
        }
      });
    }
  }

  Future<void> _initRoute() async {
    String route = Routes.loginScreen;
    try {
      int compareResult = 0;
      try {
        PackageInfo packageInfo = await PackageInfo.fromPlatform();
        DocumentSnapshot doc = await FirebaseFirestore.instance
            .collection('version').doc('newest').get();
        if (doc.exists && doc['version'] != null) {
          compareResult = Version.parse(doc['version'] as String)
              .compareTo(Version.parse(packageInfo.version));
        }
      } catch (_) {}

      if (compareResult > 0) {
        route = Routes.updateScreen;
      } else {
        final user = await FirebaseAuth.instance.authStateChanges().first;
        if (user == null || !user.emailVerified) {
          route = Routes.loginScreen;
        } else {
          try {
            final userDoc = await FirebaseFirestore.instance
                .collection('users').doc(user.uid).get();
            if (!userDoc.exists) {
              await FirebaseFirestore.instance
                  .collection('users').doc(user.uid).set({
                'uid': user.uid,
                'name': user.displayName ?? user.email?.split('@').first ?? 'Kullanıcı',
                'email': user.email ?? '',
                'username': (user.email?.split('@').first ?? 'user_${user.uid.substring(0, 6)}')
                    .toLowerCase().replaceAll(RegExp(r'[^a-z0-9_]'), '_'),
                'profilePic': user.photoURL ?? '',
                'isOnline': false,
                'mtoken': '',
              });
            }
          } catch (_) {}
          SharedPreferences prefs = await SharedPreferences.getInstance();
          bool localAuth = prefs.getBool('auth_screen_enabled') ?? false;
          route = localAuth ? Routes.authScreen : Routes.homeScreen;
          DatabaseMethods.setOnline(true);
        }
      }

      // FIX AUTH/LISTENER: FCM token refresh subscription leak fix
      final messaging = FirebaseMessaging.instance;
      await messaging.requestPermission();
      _fcmTokenSub = messaging.onTokenRefresh.listen((fcmToken) async {
        await DatabaseMethods.updateUserDetails({'mtoken': fcmToken});
      });

      // FIX: gereksiz boş authStateChanges listener kaldırıldı (eski: .listen((_) {}))
    } catch (_) {}

    if (mounted) {
      setState(() {
        _initialRoute = route;
        _routeReady = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      child: MaterialApp(
        navigatorKey: _navigatorKey,
        title: 'Asgard',
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        themeMode: ThemeMode.dark,
        darkTheme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: const ColorScheme.dark(
            primary: ColorsManager.darkPrimary,
            secondary: ColorsManager.darkPrimaryLight,
            surface: ColorsManager.darkBackground,
            surfaceContainerLowest: Color(0xFF080808),
            surfaceContainerLow: Color(0xFF0D0D0D),
            surfaceContainer: Color(0xFF111111),
            surfaceContainerHigh: Color(0xFF161616),
            surfaceContainerHighest: Color(0xFF1A1A1A),
            onSurface: Colors.white,
            onSurfaceVariant: Colors.white70,
            outline: Color(0xFF333333),
            outlineVariant: Color(0xFF1E1E1E),
            error: Colors.redAccent,
          ),
          primaryColor: ColorsManager.darkPrimary,
          scaffoldBackgroundColor: ColorsManager.darkBackground,
          canvasColor: ColorsManager.darkBackground,
          cardColor: ColorsManager.darkSurface,
          dialogBackgroundColor: ColorsManager.darkSurface,
          unselectedWidgetColor: Colors.white54,
          dividerColor: Colors.white10,
          appBarTheme: const AppBarTheme(
            backgroundColor: ColorsManager.darkAppBar,
            foregroundColor: Colors.white,
            elevation: 0,
            centerTitle: true,
            titleTextStyle: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
          textSelectionTheme: const TextSelectionThemeData(
            cursorColor: ColorsManager.darkPrimary,
            selectionHandleColor: ColorsManager.darkPrimary,
            selectionColor: Color(0x55E53935),
          ),
          progressIndicatorTheme: const ProgressIndicatorThemeData(
            color: ColorsManager.darkPrimary,
          ),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: ColorsManager.darkPrimary,
            foregroundColor: Colors.white,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorsManager.darkPrimary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: ColorsManager.darkSurface,
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: ColorsManager.darkPrimary, width: 2),
              borderRadius: BorderRadius.circular(12),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFF333333)),
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          cardTheme: CardTheme(
            color: ColorsManager.darkSurface,
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          iconTheme: const IconThemeData(color: Colors.white70),
          switchTheme: SwitchThemeData(
            thumbColor: WidgetStateProperty.resolveWith((s) =>
                s.contains(WidgetState.selected) ? ColorsManager.darkPrimary : Colors.grey),
            trackColor: WidgetStateProperty.resolveWith((s) =>
                s.contains(WidgetState.selected) ? const Color(0x55E53935) : Colors.grey.shade800),
          ),
          listTileTheme: const ListTileThemeData(
            iconColor: ColorsManager.darkPrimary,
            tileColor: Colors.transparent,
            textColor: Colors.white,
          ),
          bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: Color(0xFF111111),
            selectedItemColor: ColorsManager.darkPrimary,
            unselectedItemColor: Colors.white38,
          ),
          tabBarTheme: const TabBarTheme(
            labelColor: ColorsManager.darkPrimary,
            unselectedLabelColor: Colors.white38,
            indicatorColor: ColorsManager.darkPrimary,
          ),
        ),
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          colorScheme: const ColorScheme.light(
            primary: ColorsManager.lightPrimary,
            secondary: ColorsManager.lightPrimaryLight,
            surface: ColorsManager.lightSurface,
            error: Colors.red,
          ),
          primaryColor: ColorsManager.lightPrimary,
          scaffoldBackgroundColor: ColorsManager.lightBackground,
          appBarTheme: const AppBarTheme(
            backgroundColor: ColorsManager.lightAppBar,
            foregroundColor: Colors.white,
            elevation: 0,
            centerTitle: true,
            titleTextStyle: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
          textSelectionTheme: const TextSelectionThemeData(
            cursorColor: ColorsManager.lightPrimary,
            selectionHandleColor: ColorsManager.lightPrimary,
            selectionColor: Color(0x551976D2),
          ),
          progressIndicatorTheme: const ProgressIndicatorThemeData(
            color: ColorsManager.lightPrimary,
          ),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: ColorsManager.lightPrimary,
            foregroundColor: Colors.white,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorsManager.lightPrimary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: ColorsManager.lightPrimary, width: 2),
              borderRadius: BorderRadius.circular(12),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          cardTheme: CardTheme(
            color: Colors.white,
            elevation: 2,
            shadowColor: Colors.black12,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          dividerColor: const Color(0xFFEEEEEE),
          iconTheme: const IconThemeData(color: ColorsManager.lightPrimary),
          switchTheme: SwitchThemeData(
            thumbColor: WidgetStateProperty.resolveWith((s) =>
                s.contains(WidgetState.selected) ? ColorsManager.lightPrimary : Colors.grey),
            trackColor: WidgetStateProperty.resolveWith((s) =>
                s.contains(WidgetState.selected) ? const Color(0x551976D2) : Colors.grey.shade300),
          ),
          listTileTheme: const ListTileThemeData(iconColor: ColorsManager.lightPrimary),
          bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: Colors.white,
            selectedItemColor: ColorsManager.lightPrimary,
            unselectedItemColor: Colors.black38,
          ),
          tabBarTheme: const TabBarTheme(
            labelColor: ColorsManager.lightPrimary,
            unselectedLabelColor: Colors.black38,
            indicatorColor: ColorsManager.lightPrimary,
          ),
        ),
        onGenerateRoute: widget.appRoute.onGenerateRoute,
        initialRoute: _initialRoute,
        debugShowCheckedModeBanner: false,
        builder: (context, child) {
          if (_showSplash) {
            return Material(
              color: const Color(0xFF0D0D0D),
              child: SplashScreen(onComplete: () {
                if (mounted) {
                  if (_routeReady) {
                    if (mounted) setState(() => _showSplash = false);
                  } else {
                    _waitForRouteAndHideSplash();
                  }
                }
              }),
            );
          }
          return Material(
            color: const Color(0xFF0D0D0D),
            child: child ?? const SizedBox(),
          );
        },
      ),
    );
  }

  Future<void> _waitForRouteAndHideSplash() async {
    for (int i = 0; i < 50; i++) {
      await Future.delayed(const Duration(milliseconds: 100));
      if (_routeReady && mounted) {
        if (mounted) setState(() => _showSplash = false);
        return;
      }
    }
    if (mounted) setState(() => _showSplash = false);
  }
}
