import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/foundation.dart';

/// Agora token servisi — App Certificate artık Cloud Function'da.
/// Client sadece channelName gönderir, server token + appId döner.
class AgoraTokenService {
  static final _functions = FirebaseFunctions.instance;

  /// Token ve appId al. Certificate yoksa boş token döner (test modu).
  static Future<({String token, String appId})> getToken({
    required String channelName,
    int uid = 0,
  }) async {
    try {
      final result = await _functions
          .httpsCallable('getAgoraToken')
          .call({'channelName': channelName, 'uid': uid});

      final data  = Map<String, dynamic>.from(result.data as Map);
      final token = data['token'] as String? ?? '';
      final appId = data['appId'] as String? ?? '';
      return (token: token, appId: appId);
    } catch (e) {
      debugPrint('Agora token alınamadı: $e');
      return (token: '', appId: '');
    }
  }
}
