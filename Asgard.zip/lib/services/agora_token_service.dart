import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';

/// Agora AccessToken2 (RTC Token 007) Builder
/// Resmi Python implementasyonundan Dart'a çevrildi
/// https://github.com/AgoraIO/Tools/blob/master/DynamicKey/AgoraDynamicKey/python3/src/AccessToken2.py
class AgoraTokenService {
  static const String _appCertificate =
      String.fromEnvironment('AGORA_APP_CERTIFICATE', defaultValue: '');
  static const String _appId =
      String.fromEnvironment('AGORA_APP_ID', defaultValue: '');

  static const int _kJoinChannel = 1;
  static const int _kPublishAudioStream = 2;
  static const int _kPublishVideoStream = 3;

  static String? buildToken({
    required String channelName,
    int uid = 0,
    int expireSeconds = 3600,
  }) {
    if (_appId.isEmpty || _appCertificate.isEmpty) return null;

    try {
      final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      final expireTs = now + expireSeconds;
      final salt = now & 0xFFFFFFFF;

      // Service: RTC = 1
      // Service privileges
      final serviceRtc = _ServiceRtc(
        channelName: channelName,
        uid: uid.toString(),
      );
      serviceRtc.addPrivilege(_kJoinChannel, expireTs);
      serviceRtc.addPrivilege(_kPublishAudioStream, expireTs);
      serviceRtc.addPrivilege(_kPublishVideoStream, expireTs);

      // AccessToken2 body
      final body = _packBody(
        appId: _appId,
        expire: expireTs,
        salt: salt,
        issueTs: now,
        services: {1: serviceRtc},
      );

      // Sign with HMAC-SHA256
      final signing = _sign(
        appCertificate: _appCertificate,
        issueTs: now,
        salt: salt,
        expire: expireTs,
        services: {1: serviceRtc},
      );

      final sigBytes = Hmac(sha256, utf8.encode(signing))
          .convert(utf8.encode(_appId + now.toString() + salt.toString() + expireTs.toString()))
          .bytes;

      final content = _ByteBuffer();
      content.putUint16(sigBytes.length);
      content.addAll(sigBytes);
      content.addAll(body);

      return '007$_appId${base64Url.encode(content.toUint8List())}';
    } catch (e) {
      return null;
    }
  }

  static String _sign({
    required String appCertificate,
    required int issueTs,
    required int salt,
    required int expire,
    required Map<int, _ServiceRtc> services,
  }) {
    return appCertificate + issueTs.toString() + salt.toString() + expire.toString();
  }

  static List<int> _packBody({
    required String appId,
    required int expire,
    required int salt,
    required int issueTs,
    required Map<int, _ServiceRtc> services,
  }) {
    final buf = _ByteBuffer();
    // Version: 2 bytes "00"
    buf.putString('');
    buf.putUint32(expire);
    buf.putUint32(issueTs);
    buf.putUint32(salt);
    buf.putUint16(services.length);
    for (final entry in services.entries) {
      buf.putUint16(entry.key);
      buf.addAll(entry.value.pack());
    }
    return buf.toList();
  }
}

class _ServiceRtc {
  final String channelName;
  final String uid;
  final Map<int, int> _privileges = {};

  _ServiceRtc({required this.channelName, required this.uid});

  void addPrivilege(int privilege, int expire) {
    _privileges[privilege] = expire;
  }

  List<int> pack() {
    final buf = _ByteBuffer();
    buf.putString(channelName);
    buf.putString(uid);
    buf.putUint16(_privileges.length);
    final sorted = _privileges.entries.toList()
      ..sort((a, b) => a.key.compareTo(b.key));
    for (final e in sorted) {
      buf.putUint16(e.key);
      buf.putUint32(e.value);
    }
    return buf.toList();
  }
}

class _ByteBuffer {
  final List<int> _buf = [];

  void putUint16(int v) {
    _buf.add(v & 0xFF);
    _buf.add((v >> 8) & 0xFF);
  }

  void putUint32(int v) {
    _buf.add(v & 0xFF);
    _buf.add((v >> 8) & 0xFF);
    _buf.add((v >> 16) & 0xFF);
    _buf.add((v >> 24) & 0xFF);
  }

  void putString(String s) {
    final bytes = utf8.encode(s);
    putUint16(bytes.length);
    _buf.addAll(bytes);
  }

  void addAll(List<int> bytes) {
    _buf.addAll(bytes);
  }

  List<int> toList() => List.from(_buf);
  Uint8List toUint8List() => Uint8List.fromList(_buf);
}
