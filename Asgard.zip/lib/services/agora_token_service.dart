import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';

/// Agora RTC Token Builder
/// Agora'nın açık kaynak algoritmasının Dart implementasyonu
/// Kaynak: https://github.com/AgoraIO/Tools/tree/master/DynamicKey/AgoraDynamicKey
class AgoraTokenService {
  static const String _appCertificate = String.fromEnvironment(
    'AGORA_APP_CERTIFICATE',
    defaultValue: '',
  );
  static const String _appId = String.fromEnvironment(
    'AGORA_APP_ID',
    defaultValue: '',
  );

  static const int _rolePublisher = 1;
  static const int _privilegeJoinChannel = 1;
  static const int _privilegePublishAudioStream = 2;
  static const int _privilegePublishVideoStream = 3;

  /// RTC token üret
  /// [channelName]: Agora channel adı (callId)
  /// [uid]: kullanıcı ID (0 = rastgele)
  /// [expireSeconds]: token geçerlilik süresi (varsayılan 1 saat)
  static String? buildToken({
    required String channelName,
    int uid = 0,
    int expireSeconds = 3600,
  }) {
    if (_appId.isEmpty || _appCertificate.isEmpty) return null;

    final currentTime = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final expireTime = currentTime + expireSeconds;
    final salt = _randomInt();

    // Privileges
    final privileges = <int, int>{
      _privilegeJoinChannel: expireTime,
      _privilegePublishAudioStream: expireTime,
      _privilegePublishVideoStream: expireTime,
    };

    // Message = appId + account + channelName + salt + ts + privileges
    final msg = _packMessage(
      appId: _appId,
      account: uid.toString(),
      channelName: channelName,
      salt: salt,
      ts: currentTime,
      privileges: privileges,
    );

    // HMAC-SHA256 imzala
    final key = utf8.encode(_appCertificate);
    final hmac = Hmac(sha256, key);
    final signature = hmac.convert(msg).bytes;

    // Token = "006" + appId + base64(signature + msg)
    final content = Uint8List.fromList([...signature, ...msg]);
    final base64Content = base64.encode(content);
    return '006$_appId$base64Content';
  }

  static int _randomInt() {
    final now = DateTime.now().millisecondsSinceEpoch;
    return (now % 0x7FFFFFFF).toInt();
  }

  static List<int> _packMessage({
    required String appId,
    required String account,
    required String channelName,
    required int salt,
    required int ts,
    required Map<int, int> privileges,
  }) {
    final buf = <int>[];

    // Pack uint32 (little-endian)
    void packUint32(int v) {
      buf.addAll([v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF]);
    }

    // Pack string (uint16 length + bytes)
    void packString(String s) {
      final bytes = utf8.encode(s);
      buf.addAll([(bytes.length) & 0xFF, (bytes.length >> 8) & 0xFF]);
      buf.addAll(bytes);
    }

    // Pack map<uint16, uint32>
    void packMap(Map<int, int> m) {
      buf.addAll([(m.length) & 0xFF, (m.length >> 8) & 0xFF]);
      m.forEach((k, v) {
        buf.addAll([k & 0xFF, (k >> 8) & 0xFF]);
        packUint32(v);
      });
    }

    packString(appId);
    packString(account);
    packString(channelName);
    packUint32(salt);
    packUint32(ts);
    packMap(privileges);

    return buf;
  }
}
