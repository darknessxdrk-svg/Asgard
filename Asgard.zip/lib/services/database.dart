import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../features/chat/data/model/message.dart';

class DatabaseMethods {
  /// FIX FIRESTORE: chatId uid1_uid2 formatı tahmin edilebilir.
  /// Firestore Security Rules ile korunmalı:
  ///   allow read, write: if request.auth.uid in [uid1, uid2]
  /// (Opsiyonel gelecek iyileştirme: random UUID chatId + lookup subcollection)
  static String getChatRoomId(String uid1, String uid2) {
    // FIX: her iki uid'in de boş olmadığını doğrula
    assert(uid1.isNotEmpty && uid2.isNotEmpty, 'getChatRoomId: uid boş olamaz');
    final ids = [uid1, uid2]..sort();
    return ids.join('_');
  }

  static String getChatRoomID(String uid1, String uid2) => getChatRoomId(uid1, uid2);

  static final _auth = FirebaseAuth.instance;
  static final _fireStore = FirebaseFirestore.instance;

  // ── FIX #5: addUserDetails currentUser! → null-safe ─────────────────────
  static Future<void> addUserDetails(Map<String, dynamic> data,
      [SetOptions? options]) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore.collection('users').doc(uid).set(data, options);
  }

  static Future<void> updateUserDetails(Map<String, dynamic> data,
      [SetOptions? options]) async {
    try {
      final uid = _auth.currentUser?.uid;
      if (uid == null) return;
      await _fireStore
          .collection('users')
          .doc(uid)
          .set(data, SetOptions(merge: true));
    } catch (e) {
      debugPrint('[updateUserDetails] hata: $e');
    }
  }

  static Future<bool> isUsernameAvailable(String username) async {
    final u = username.toLowerCase().trim();
    try {
      final reserved = await _fireStore.collection('usernames').doc(u).get();
      if (reserved.exists) return false;
      final query = await _fireStore
          .collection('users')
          .where('username', isEqualTo: u)
          .limit(1)
          .get();
      return query.docs.isEmpty;
    } catch (e) {
      debugPrint('[Username] isUsernameAvailable hata: $e');
      return false;
    }
  }

  static Future<bool> reserveUsername(String username, String uid) async {
    final u = username.toLowerCase().trim();
    try {
      await _fireStore.runTransaction((tx) async {
        final ref = _fireStore.collection('usernames').doc(u);
        final snap = await tx.get(ref);
        if (snap.exists) throw Exception('alindi');
        tx.set(ref, {'uid': uid, 'reservedAt': FieldValue.serverTimestamp()});
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> releaseUsername(String username) async {
    try {
      await _fireStore
          .collection('usernames')
          .doc(username.toLowerCase().trim())
          .delete();
    } catch (e) {
      debugPrint('[releaseUsername] hata: $e');
    }
  }

  static Future<Map<String, dynamic>?> getUserByUsername(String username) async {
    final query = await _fireStore
        .collection('users')
        .where('username', isEqualTo: username.toLowerCase())
        .get();
    if (query.docs.isEmpty) return null;
    return query.docs.first.data();
  }

  // ── FIX #5: currentUser! → null-safe (contacts) ─────────────────────────
  static Future<void> addContact(String contactUid) async {
    final myUid = _auth.currentUser?.uid;
    if (myUid == null) return;
    await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .set({'uid': contactUid, 'addedAt': Timestamp.now()});
  }

  static Future<void> removeContact(String contactUid) async {
    final myUid = _auth.currentUser?.uid;
    if (myUid == null) return;
    await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .delete();
  }

  static Stream<QuerySnapshot> getContacts() {
    final myUid = _auth.currentUser?.uid ?? '';
    return _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .snapshots();
  }

  static Future<bool> isContact(String contactUid) async {
    final myUid = _auth.currentUser?.uid;
    if (myUid == null) return false;
    final doc = await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .get();
    return doc.exists;
  }

  // ── FIX #2: Pagination — tüm mesajları tek seferde çekmez ───────────────
  static Stream<QuerySnapshot> getMessages(String userID, String otherUserID,
      {int pageSize = 40, DocumentSnapshot? lastDoc}) {
    final chatRoomID = getChatRoomID(userID, otherUserID);
    var query = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(pageSize);
    if (lastDoc != null) query = query.startAfterDocument(lastDoc);
    return query.snapshots();
  }

  /// Infinite scroll — bir sonraki sayfayı çek
  static Future<QuerySnapshot> loadMoreMessages(
      String userID, String otherUserID,
      {int pageSize = 40, required DocumentSnapshot lastDoc}) {
    final chatRoomID = getChatRoomID(userID, otherUserID);
    return _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .startAfterDocument(lastDoc)
        .limit(pageSize)
        .get();
  }

  // ── FIX #10: Gerçek silme (delete) yapıyor, update değil ─────────────────
  // ── FIX #3: Batch limit için 400'lük parçalara böler ─────────────────────
  static Future<void> deleteExpiredMessages(String otherUserID) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    try {
      final now = Timestamp.now();
      final expired = await _fireStore
          .collection('chats')
          .doc(chatRoomID)
          .collection('messages')
          .where('autoDelete', isEqualTo: true)
          .where('expiresAt', isLessThanOrEqualTo: now)
          .get();
      if (expired.docs.isEmpty) return;

      const batchSize = 400;
      for (int i = 0; i < expired.docs.length; i += batchSize) {
        final chunk = expired.docs
            .sublist(i, (i + batchSize).clamp(0, expired.docs.length));
        final batch = _fireStore.batch();
        for (final doc in chunk) {
          batch.delete(doc.reference); // Gerçek silme
        }
        await batch.commit();
      }
    } catch (e) {
      debugPrint('[deleteExpiredMessages] hata: $e');
    }
  }

  static Future<void> sendMessage(String message, String receiverID,
      {int? autoDeleteSeconds, Map<String, dynamic>? replyTo}) async {
    final currentUserID = _auth.currentUser?.uid;
    if (currentUserID == null) return; // FIX #5
    final currentUserName = _auth.currentUser?.displayName ??
        _auth.currentUser?.email?.split('@').first ?? '';
    final timestamp = Timestamp.now();
    final chatRoomID = getChatRoomID(currentUserID, receiverID);

    Timestamp? expiresAt;
    if (autoDeleteSeconds != null) {
      expiresAt = Timestamp.fromDate(
          DateTime.now().add(Duration(seconds: autoDeleteSeconds)));
    }

    final Message newMessage = Message(
      senderID: currentUserID,
      senderName: currentUserName,
      message: message,
      receiverID: receiverID,
      timestamp: timestamp,
      status: 'delivered',
    );

    final msgData = newMessage.toMap();
    if (replyTo != null) {
      msgData['replyTo'] = {
        'message': (replyTo['message'] ?? '').toString().length > 60
            ? '${(replyTo['message'] ?? '').toString().substring(0, 60)}...'
            : replyTo['message'] ?? '',
        'senderID': replyTo['senderID'] ?? '',
        'msgId': replyTo['msgId'] ?? '',
      };
    }
    if (expiresAt != null) {
      msgData['expiresAt'] = expiresAt;
      msgData['autoDelete'] = true;
    }

    await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .add(msgData);

    try {
      final myContactRef = _fireStore
          .collection('users')
          .doc(currentUserID)
          .collection('contacts')
          .doc(receiverID);
      final theirContactRef = _fireStore
          .collection('users')
          .doc(receiverID)
          .collection('contacts')
          .doc(currentUserID);

      final myContact = await myContactRef.get();
      if (!myContact.exists) {
        await myContactRef.set(
            {'uid': receiverID, 'addedAt': timestamp}, SetOptions(merge: true));
      }
      final theirContact = await theirContactRef.get();
      if (!theirContact.exists) {
        await theirContactRef.set({'uid': currentUserID, 'addedAt': timestamp},
            SetOptions(merge: true));
      }
    } catch (e) {
      debugPrint('[sendMessage] contacts güncelleme hatası: $e');
    }
  }

  // ── FIX #3: Batch limit koruması (.limit(400)) ───────────────────────────
  static Future<void> markMessagesAsRead(String otherUserID,
      {bool readReceiptsEnabled = true}) async {
    if (!readReceiptsEnabled) return;
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return; // FIX #5
    final chatRoomID = getChatRoomID(myUID, otherUserID);

    final unread = await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .where('receiverID', isEqualTo: myUID)
        .where('status', isEqualTo: 'delivered')
        .limit(400) // FIX: batch 500 limitini asla aşmaz
        .get();

    if (unread.docs.isEmpty) return;
    final batch = _fireStore.batch();
    for (var doc in unread.docs) {
      batch.update(doc.reference, {'status': 'read'});
    }
    await batch.commit();
  }

  // ── Grup metodları ──────────────────────────────────────────────────────
  static Future<String> createGroup(String name, List<String> memberUIDs) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) throw Exception('Kullanıcı oturumu yok');
    final members = {...memberUIDs, uid}.toList();
    final doc = await _fireStore.collection('groups').add({
      'name': name,
      'members': members,
      'admins': [uid],
      'photo': '',
      'description': '',
      'createdBy': uid,
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': '',
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  static Stream<QuerySnapshot> getUserGroups() {
    final uid = _auth.currentUser?.uid;
    return _fireStore
        .collection('groups')
        .where('members', arrayContains: uid)
        .snapshots();
  }

  static Future<void> sendMessageAsAI(String message, String receiverID) async {
    final currentUserID = _auth.currentUser?.uid;
    if (currentUserID == null) return; // FIX #5
    final chatRoomID = getChatRoomID(currentUserID, receiverID);
    final timestamp = Timestamp.now();
    await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .add({
      'senderID': 'AI_BOT',
      'senderName': 'Asgard AI',
      'message': message,
      'receiverID': receiverID,
      'timestamp': timestamp,
      'status': 'delivered',
      'isAI': true,
    });
  }

  static Future<void> sendGroupMessage(String groupId, String message) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final user = await _fireStore.collection('users').doc(uid).get();
    final name = user.data()?['name'] ?? '';
    final msgRef =
        _fireStore.collection('groups').doc(groupId).collection('messages');
    final msgId = msgRef.doc().id;
    await msgRef.doc(msgId).set({
      'message': message,
      'senderID': uid,
      'senderName': name,
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'delivered',
      'seenBy': [uid],
    });
    await _fireStore.collection('groups').doc(groupId).update({
      'lastMessage': message.startsWith('[') ? '📎 Medya' : message,
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> sendGroupMessageAsAI(String groupId, String message) async {
    final msgRef =
        _fireStore.collection('groups').doc(groupId).collection('messages');
    final msgId = msgRef.doc().id;
    await msgRef.doc(msgId).set({
      'message': message,
      'senderID': 'AI_BOT',
      'senderName': 'Asgard AI',
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'delivered',
      'seenBy': [],
    });
    await _fireStore.collection('groups').doc(groupId).update({
      'lastMessage':
          '🤖 AI: ${message.length > 40 ? message.substring(0, 40) + '...' : message}',
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> markGroupMessageSeen(
      String groupId, String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore
        .collection('groups')
        .doc(groupId)
        .collection('messages')
        .doc(messageId)
        .update({'seenBy': FieldValue.arrayUnion([uid])});
  }

  static Stream<QuerySnapshot> getGroupMessages(String groupId) {
    return _fireStore
        .collection('groups')
        .doc(groupId)
        .collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots();
  }

  // ── Mesaj Silme ──────────────────────────────────────────────────────────
  static Future<void> deleteMessageForMe(
      String messageId, String otherUserID) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return; // FIX #5
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .doc(messageId);
    final doc = await ref.get();
    if (!doc.exists) return;
    final data = doc.data() ?? {};
    final List hiddenFor = List.from(data['hiddenFor'] ?? []);
    if (!hiddenFor.contains(myUID)) {
      hiddenFor.add(myUID);
      await ref.update({'hiddenFor': hiddenFor});
    }
  }

  static Future<void> deleteMessageForEveryone(
      String messageId, String otherUserID) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return; // FIX #5
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .doc(messageId);
    final doc = await ref.get();
    if (!doc.exists) return;
    final senderID = (doc.data() as Map?)?['senderID'];
    if (senderID != myUID) return;
    await ref.update({'message': '🚫 Bu mesaj silindi', 'deleted': true});
  }

  // ── Mesaj Düzenleme ──────────────────────────────────────────────────────
  static Future<void> editMessage(
      String messageId, String otherUserID, String newText) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return; // FIX #5
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .doc(messageId);
    final doc = await ref.get();
    if (!doc.exists) return;
    final senderID = (doc.data() as Map?)?['senderID'];
    if (senderID != myUID) return;
    await ref.update({'message': newText, 'edited': true});
  }

  // ── Mesaj Sabitleme ──────────────────────────────────────────────────────
  static Future<void> pinMessage(
      String messageId, String otherUserID, String messageText) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return; // FIX #5
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).update({
      'pinnedMessage': {'id': messageId, 'text': messageText},
    });
  }

  static Future<void> unpinMessage(String otherUserID) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return; // FIX #5
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .update({'pinnedMessage': FieldValue.delete()});
  }

  static Stream<DocumentSnapshot> getChatRoomStream(String otherUserID) {
    final myUID = _auth.currentUser?.uid ?? '';
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    return _fireStore.collection('chats').doc(chatRoomID).snapshots();
  }

  // ── Emoji Reaksiyon ──────────────────────────────────────────────────────
  static Future<void> addReaction(
      String messageId, String otherUserID, String emoji) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return; // FIX #5
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .doc(messageId);
    await ref.update({'reactions.$myUID': emoji});
  }

  // ── Yazıyor Göstergesi ───────────────────────────────────────────────────
  static Future<void> setTyping(String otherUserID, bool isTyping) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).set({
      'typing_$myUID': isTyping,
    }, SetOptions(merge: true));
  }

  static Stream<DocumentSnapshot> getTypingStream(String otherUserID) {
    final myUID = _auth.currentUser?.uid ?? '';
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    return _fireStore.collection('chats').doc(chatRoomID).snapshots();
  }

  // ── FIX #4: isOnline bool olarak tutulmalı, string değil ────────────────
  static Future<void> setOnline(bool online) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      await _fireStore.collection('users').doc(uid).set({
        'isOnline': online, // FIX: bool, eski: 'true'/'false' string
        if (!online) 'lastSeen': DateTime.now().millisecondsSinceEpoch,
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('[setOnline] hata: $e');
    }
  }

  static Future<void> updateLastSeen() async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return;
    await _fireStore.collection('users').doc(myUID).update({
      'lastSeen': DateTime.now().millisecondsSinceEpoch,
      'isOnline': false, // FIX: bool
    });
  }

  static Stream<DocumentSnapshot> getUserStream(String uid) {
    return _fireStore.collection('users').doc(uid).snapshots();
  }

  // ── Favori Mesajlar ──────────────────────────────────────────────────────
  static Future<void> starMessage(
      String messageId, Map<String, dynamic> msgData) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore
        .collection('users')
        .doc(uid)
        .collection('starred')
        .doc(messageId)
        .set({
      ...msgData,
      'starredAt': Timestamp.now(),
      'originalMessageId': messageId,
    });
  }

  static Future<void> unstarMessage(String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore
        .collection('users')
        .doc(uid)
        .collection('starred')
        .doc(messageId)
        .delete();
  }

  static Stream<QuerySnapshot> getStarredMessages() {
    final uid = _auth.currentUser?.uid ?? '';
    return _fireStore
        .collection('users')
        .doc(uid)
        .collection('starred')
        .orderBy('starredAt', descending: true)
        .snapshots();
  }

  static Future<bool> isMessageStarred(String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return false;
    final doc = await _fireStore
        .collection('users')
        .doc(uid)
        .collection('starred')
        .doc(messageId)
        .get();
    return doc.exists;
  }
}
