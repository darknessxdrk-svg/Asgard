import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../features/chat/data/model/message.dart';

class DatabaseMethods {
  static String getChatRoomId(String uid1, String uid2) {
    final ids = [uid1, uid2]..sort();
    return ids.join('_');
  }

  // Tek yerde tanımlı — eski duplicate kaldırıldı
  static String getChatRoomID(String uid1, String uid2) => getChatRoomId(uid1, uid2);

  static final _auth = FirebaseAuth.instance;
  static final _fireStore = FirebaseFirestore.instance;

  static Future<void> addUserDetails(Map<String, dynamic> data,
      [SetOptions? options]) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore.collection('users').doc(uid).set(data, options);
  }

  static Future<void> updateUserDetails(Map<String, dynamic> data,
      [SetOptions? options]) async {
    try {
      final uid = _auth.currentUser?.uid;
      if (uid == null) return;
      await _fireStore
          .collection('users')
          .doc(uid)
          .set(data, SetOptions(merge: true));
    } catch (_) {}
  }

  static Future<bool> isUsernameAvailable(String username) async {
    final u = username.toLowerCase().trim();
    try {
      // 1) Atomik 'usernames' koleksiyonunu kontrol et
      final reserved = await _fireStore.collection('usernames').doc(u).get();
      if (reserved.exists) return false;
      // 2) users koleksiyonunda da kontrol et (eski kayıtlar için)
      final query = await _fireStore
          .collection('users')
          .where('username', isEqualTo: u)
          .limit(1)
          .get();
      return query.docs.isEmpty;
    } catch (e) {
      if (kDebugMode) debugPrint('[Username] isUsernameAvailable hata: \$e');
      return false;
    }
  }

  /// Kullanıcı adını atomik olarak rezerve et
  static Future<bool> reserveUsername(String username, String uid) async {
    final u = username.toLowerCase().trim();
    try {
      await _fireStore.runTransaction((tx) async {
        final ref = _fireStore.collection('usernames').doc(u);
        final snap = await tx.get(ref);
        if (snap.exists) throw Exception('alindi');
        tx.set(ref, {'uid': uid, 'reservedAt': FieldValue.serverTimestamp()});
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Eski kullanıcı adı rezervasyonunu sil
  static Future<void> releaseUsername(String username) async {
    try {
      await _fireStore.collection('usernames').doc(username.toLowerCase().trim()).delete();
    } catch (_) {}
  }

  static Future<Map<String, dynamic>?> getUserByUsername(String username) async {
    final query = await _fireStore
        .collection('users')
        .where('username', isEqualTo: username.toLowerCase())
        .get();
    if (query.docs.isEmpty) return null;
    return query.docs.first.data();
  }

  static Future<void> addContact(String contactUid) async {
    final myUid = _auth.currentUser!.uid;
    await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .set({'uid': contactUid, 'addedAt': Timestamp.now()});
  }

  static Future<void> removeContact(String contactUid) async {
    final myUid = _auth.currentUser!.uid;
    await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .delete();
  }

  static Stream<QuerySnapshot> getContacts() {
    final myUid = _auth.currentUser!.uid;
    return _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .snapshots();
  }

  static Future<bool> isContact(String contactUid) async {
    final myUid = _auth.currentUser!.uid;
    final doc = await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .get();
    return doc.exists;
  }

  static Stream<QuerySnapshot> getMessages(String userID, String otherUserID) {
    String chatRoomID = getChatRoomID(userID, otherUserID);
    return _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(100) // Pagination: sadece son 100 mesaj — büyük sohbette performans ve maliyet
        .snapshots();
  }

  /// Süresi dolmuş mesajları sil - sohbet açılınca çağrılır
  static Future<void> deleteExpiredMessages(String otherUserID) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    try {
      final now = Timestamp.now();
      final expired = await _fireStore
          .collection('chats')
          .doc(chatRoomID)
          .collection('messages')
          .where('autoDelete', isEqualTo: true)
          .get();
      // Batch ile gerçekten sil (overwrite değil)
      const chunkSize = 450;
      final toDelete = expired.docs.where((doc) {
        final expiresAt = doc.data()['expiresAt'] as Timestamp?;
        return expiresAt != null && expiresAt.compareTo(now) <= 0;
      }).toList();
      for (var i = 0; i < toDelete.length; i += chunkSize) {
        final chunk = toDelete.sublist(i, (i + chunkSize).clamp(0, toDelete.length));
        final batch = _fireStore.batch();
        for (final doc in chunk) {
          batch.delete(doc.reference);
        }
        await batch.commit();
      }
    } catch (_) {}
  }

  static Future<void> sendMessage(String message, String receiverID,
      {int? autoDeleteSeconds, Map<String, dynamic>? replyTo}) async {
    final currentUserID = _auth.currentUser?.uid;
    if (currentUserID == null) return; // crash önleme
    final currentUserName = _auth.currentUser?.displayName ??
        _auth.currentUser?.email?.split('@').first ?? '';
    final timestamp = Timestamp.now();
    final chatRoomID = getChatRoomID(currentUserID, receiverID);

    // autoDelete zamanı hesapla
    Timestamp? expiresAt;
    if (autoDeleteSeconds != null) {
      expiresAt = Timestamp.fromDate(
          DateTime.now().add(Duration(seconds: autoDeleteSeconds)));
    }

    final Message newMessage = Message(
      senderID: currentUserID,
      senderName: currentUserName,
      message: message,
      receiverID: receiverID,
      timestamp: timestamp,
      status: 'delivered',
    );

    final msgData = newMessage.toMap();
    if (replyTo != null) {
      msgData['replyTo'] = {
        'message': (replyTo['message'] ?? '').toString().length > 60
            ? '${(replyTo['message'] ?? '').toString().substring(0, 60)}...'
            : replyTo['message'] ?? '',
        'senderID': replyTo['senderID'] ?? '',
        'msgId': replyTo['msgId'] ?? '',
      };
    }
    if (expiresAt != null) {
      msgData['expiresAt'] = expiresAt;
      msgData['autoDelete'] = true;
    }

    final ref = await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .add(msgData);

    // AutoDelete: expiresAt Firestore'da saklanır
    // Silme işlemi getMessages stream'inde expiresAt kontrolüyle yapılır

    // İlk mesajda contacts'a ekle (her mesajda değil)
    try {
      final myContactRef = _fireStore
          .collection('users')
          .doc(currentUserID)
          .collection('contacts')
          .doc(receiverID);
      final theirContactRef = _fireStore
          .collection('users')
          .doc(receiverID)
          .collection('contacts')
          .doc(currentUserID);

      // Sadece yoksa ekle
      final myContact = await myContactRef.get();
      if (!myContact.exists) {
        await myContactRef.set(
            {'uid': receiverID, 'addedAt': timestamp}, SetOptions(merge: true));
      }
      final theirContact = await theirContactRef.get();
      if (!theirContact.exists) {
        await theirContactRef.set({'uid': currentUserID, 'addedAt': timestamp},
            SetOptions(merge: true));
      }
    } catch (_) {}
  }

  static Future<void> markMessagesAsRead(String otherUserID,
      {bool readReceiptsEnabled = true}) async {
    if (!readReceiptsEnabled) return;
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return;
    final chatRoomID = getChatRoomID(myUID, otherUserID);

    final unread = await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .where('receiverID', isEqualTo: myUID)
        .where('status', isEqualTo: 'delivered')
        .get();

    if (unread.docs.isEmpty) return;

    // Firestore batch limiti 500 — büyük sohbetlerde chunk'lara böl
    const chunkSize = 450;
    for (var i = 0; i < unread.docs.length; i += chunkSize) {
      final chunk = unread.docs.sublist(
        i,
        (i + chunkSize).clamp(0, unread.docs.length),
      );
      final batch = _fireStore.batch();
      for (final doc in chunk) {
        batch.update(doc.reference, {'status': 'read'});
      }
      await batch.commit();
    }
  }

  // ── Grup metodları ──────────────────────────────────────────────────────
  static Future<String> createGroup(String name, List<String> memberUIDs) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) throw Exception('Kullanıcı oturumu yok');
    final members = {...memberUIDs, uid}.toList();
    final doc = await _fireStore.collection('groups').add({
      'name': name,
      'members': members,
      'admins': [uid],
      'photo': '',
      'description': '',
      'createdBy': uid,
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': '',
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  static Stream<QuerySnapshot> getUserGroups() {
    final uid = _auth.currentUser?.uid;
    return _fireStore
        .collection('groups')
        .where('members', arrayContains: uid)
        .snapshots();
  }

  static Future<void> sendMessageAsAI(
      String message, String receiverID) async {
    final currentUserID = _auth.currentUser?.uid;
    if (currentUserID == null) return;
    final chatRoomID = getChatRoomID(currentUserID, receiverID);
    final timestamp = Timestamp.now();
    await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .add({
      'senderID': 'AI_BOT',
      'senderName': 'Asgard AI',
      'message': message,
      'receiverID': receiverID,
      'timestamp': timestamp,
      'status': 'delivered',
      'isAI': true,
    });
  }

  static Future<void> sendGroupMessage(String groupId, String message) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final user = await _fireStore.collection('users').doc(uid).get();
    final name = user.data()?['name'] ?? '';
    final msgRef =
        _fireStore.collection('groups').doc(groupId).collection('messages');
    final msgId = msgRef.doc().id;
    await msgRef.doc(msgId).set({
      'message': message,
      'senderID': uid,
      'senderName': name,
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'delivered',
      'seenBy': [uid],
    });
    await _fireStore.collection('groups').doc(groupId).update({
      'lastMessage':
          message.startsWith('[') ? '📎 Medya' : message,
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> sendGroupMessageAsAI(
      String groupId, String message) async {
    final msgRef =
        _fireStore.collection('groups').doc(groupId).collection('messages');
    final msgId = msgRef.doc().id;
    await msgRef.doc(msgId).set({
      'message': message,
      'senderID': 'AI_BOT',
      'senderName': 'Asgard AI',
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'delivered',
      'seenBy': [],
    });
    await _fireStore.collection('groups').doc(groupId).update({
      'lastMessage':
          '🤖 AI: ${message.length > 40 ? message.substring(0, 40) + '...' : message}',
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> markGroupMessageSeen(
      String groupId, String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore
        .collection('groups')
        .doc(groupId)
        .collection('messages')
        .doc(messageId)
        .update({'seenBy': FieldValue.arrayUnion([uid])});
  }

  static Stream<QuerySnapshot> getGroupMessages(String groupId) {
    return _fireStore
        .collection('groups')
        .doc(groupId)
        .collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots();
  }

  // ── Mesaj Silme ──────────────────────────────────────────────────────────
  static Future<void> deleteMessageForMe(
      String messageId, String otherUserID) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .doc(messageId);
    final doc = await ref.get();
    final data = doc.data() ?? {};
    final List hiddenFor = List.from(data['hiddenFor'] ?? []);
    if (!hiddenFor.contains(myUID)) {
      hiddenFor.add(myUID);
      await ref.update({'hiddenFor': hiddenFor});
    }
  }

  static Future<void> deleteMessageForEveryone(
      String messageId, String otherUserID) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .doc(messageId);
    // Sadece kendi mesajını silebilir — güvenlik kontrolü
    final doc = await ref.get();
    if (!doc.exists) return;
    final senderID = (doc.data() as Map?)?['senderID'];
    if (senderID != myUID) return; // Başkasının mesajını silme
    await ref.update({'message': '🚫 Bu mesaj silindi', 'deleted': true});
  }

  // ── Mesaj Düzenleme ──────────────────────────────────────────────────────
  static Future<void> editMessage(
      String messageId, String otherUserID, String newText) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .doc(messageId);
    // Sadece kendi mesajını düzenleyebilir
    final doc = await ref.get();
    if (!doc.exists) return;
    final senderID = (doc.data() as Map?)?['senderID'];
    if (senderID != myUID) return;
    await ref.update({'message': newText, 'edited': true});
  }

  // ── Mesaj Sabitleme ──────────────────────────────────────────────────────
  static Future<void> pinMessage(
      String messageId, String otherUserID, String messageText) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).update({
      'pinnedMessage': {'id': messageId, 'text': messageText},
    });
  }

  static Future<void> unpinMessage(String otherUserID) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .update({'pinnedMessage': FieldValue.delete()});
  }

  static Stream<DocumentSnapshot> getChatRoomStream(String otherUserID) {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    return _fireStore.collection('chats').doc(chatRoomID).snapshots();
  }

  // ── Emoji Reaksiyon ──────────────────────────────────────────────────────
  static Future<void> addReaction(
      String messageId, String otherUserID, String emoji) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .doc(messageId);
    await ref.update({'reactions.$myUID': emoji});
  }

  // ── Yazıyor Göstergesi ───────────────────────────────────────────────────
  static Future<void> setTyping(String otherUserID, bool isTyping) async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).set({
      'typing_$myUID': isTyping,
    }, SetOptions(merge: true));
  }

  static Stream<DocumentSnapshot> getTypingStream(String otherUserID) {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    return _fireStore.collection('chats').doc(chatRoomID).snapshots();
  }

  // ── Son Görülme ──────────────────────────────────────────────────────────
  static Future<void> setOnline(bool online) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      await _fireStore.collection('users').doc(uid).set({
        'isOnline': online,
        if (!online) 'lastSeen': DateTime.now().millisecondsSinceEpoch,
      }, SetOptions(merge: true));
    } catch (_) {}
  }

  static Future<void> updateLastSeen() async {
    final myUID = _auth.currentUser?.uid;
    if (myUID == null) return;
    await _fireStore.collection('users').doc(myUID).update({
      'lastSeen': DateTime.now().millisecondsSinceEpoch,
      'isOnline': false,
    });
  }

  static Stream<DocumentSnapshot> getUserStream(String uid) {
    return _fireStore.collection('users').doc(uid).snapshots();
  }

  // ── Favori Mesajlar ──────────────────────────────────────────────────────
  static Future<void> starMessage(
      String messageId, Map<String, dynamic> msgData) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore
        .collection('users')
        .doc(uid)
        .collection('starred')
        .doc(messageId)
        .set({
      ...msgData,
      'starredAt': Timestamp.now(),
      'originalMessageId': messageId,
    });
  }

  static Future<void> unstarMessage(String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore
        .collection('users')
        .doc(uid)
        .collection('starred')
        .doc(messageId)
        .delete();
  }

  static Stream<QuerySnapshot> getStarredMessages() {
    final uid = _auth.currentUser?.uid;
    return _fireStore
        .collection('users')
        .doc(uid)
        .collection('starred')
        .orderBy('starredAt', descending: true)
        .snapshots();
  }

  static Future<bool> isMessageStarred(String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return false;
    final doc = await _fireStore
        .collection('users')
        .doc(uid)
        .collection('starred')
        .doc(messageId)
        .get();
    return doc.exists;
  }
}
