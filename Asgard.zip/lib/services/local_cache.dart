import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter/foundation.dart';

/// ─────────────────────────────────────────────────────────────────
/// LocalCache — Hive tabanlı offline-first cache katmanı
/// ─────────────────────────────────────────────────────────────────
class LocalCache {
  static const _msgBox    = 'messages_cache';
  static const _queueBox  = 'message_queue';
  static const _userBox   = 'user_cache';
  static const _metaBox   = 'chat_meta';

  static late Box<String> _messages;
  static late Box<String> _queue;
  static late Box<String> _users;
  static late Box<String> _meta;

  static bool _initialized = false;

  /// Uygulama başında bir kez çağır
  static Future<void> init() async {
    if (_initialized) return;
    await Hive.initFlutter();
    _messages = await Hive.openBox<String>(_msgBox);
    _queue    = await Hive.openBox<String>(_queueBox);
    _users    = await Hive.openBox<String>(_userBox);
    _meta     = await Hive.openBox<String>(_metaBox);
    _initialized = true;
    debugPrint('[LocalCache] initialized');
  }

  // ── MESAJLAR ──────────────────────────────────────────────────────

  /// Son N mesajı cache'e yaz
  static Future<void> cacheMessages(
      String chatId, List<Map<String, dynamic>> msgs) async {
    final key = 'chat_$chatId';
    await _messages.put(key, jsonEncode(msgs));
  }

  /// Cache'den mesajları oku (Firestore yüklenene kadar göster)
  static List<Map<String, dynamic>> getCachedMessages(String chatId) {
    final key = 'chat_$chatId';
    final raw = _messages.get(key);
    if (raw == null) return [];
    try {
      return List<Map<String, dynamic>>.from(
          jsonDecode(raw).map((e) => Map<String, dynamic>.from(e)));
    } catch (_) {
      return [];
    }
  }

  // ── GÖNDERİM KUYRUĞU ─────────────────────────────────────────────

  /// İnternet yokken mesajı kuyruğa ekle
  static Future<String> enqueueMessage(Map<String, dynamic> msgData) async {
    final id = 'q_${DateTime.now().millisecondsSinceEpoch}';
    await _queue.put(id, jsonEncode(msgData));
    debugPrint('[Queue] enqueued: $id');
    return id;
  }

  /// Kuyruktaki tüm bekleyen mesajları getir
  static List<Map<String, dynamic>> getPendingMessages() {
    return _queue.keys.map((k) {
      try {
        final data = Map<String, dynamic>.from(jsonDecode(_queue.get(k as String)!));
        data['_queueId'] = k;
        return data;
      } catch (_) {
        return <String, dynamic>{};
      }
    }).where((m) => m.isNotEmpty).toList();
  }

  /// Kuyruktan sil (başarılı gönderim sonrası)
  static Future<void> dequeueMessage(String queueId) async {
    await _queue.delete(queueId);
  }

  /// Kuyruk boş mu?
  static bool get hasQueuedMessages => _queue.isNotEmpty;
  static int  get queueLength        => _queue.length;

  // ── KULLANICI CACHE ───────────────────────────────────────────────

  static Future<void> cacheUser(String uid, Map<String, dynamic> data) async {
    await _users.put('user_$uid', jsonEncode(data));
  }

  static Map<String, dynamic>? getCachedUser(String uid) {
    final raw = _users.get('user_$uid');
    if (raw == null) return null;
    try { return Map<String, dynamic>.from(jsonDecode(raw)); } catch (_) { return null; }
  }

  // ── META (last seen, unread count vb.) ────────────────────────────

  static Future<void> setMeta(String key, dynamic value) async {
    await _meta.put(key, jsonEncode(value));
  }

  static dynamic getMeta(String key) {
    final raw = _meta.get(key);
    if (raw == null) return null;
    try { return jsonDecode(raw); } catch (_) { return null; }
  }

  // ── TEMİZLİK ─────────────────────────────────────────────────────

  static Future<void> clearChat(String chatId) async {
    await _messages.delete('chat_$chatId');
  }

  static Future<void> clearAll() async {
    await _messages.clear();
    await _queue.clear();
    await _users.clear();
    await _meta.clear();
  }

  static Future<void> dispose() async {
    await Hive.close();
  }
}
