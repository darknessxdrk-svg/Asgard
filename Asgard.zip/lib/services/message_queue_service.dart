import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'local_cache.dart';
import 'database.dart';

/// ─────────────────────────────────────────────────────────────────
/// MessageQueueService — Offline mesaj kuyruğu
/// İnternet kesilince mesajları Hive'a yazar,
/// bağlantı gelince otomatik Firestore'a gönderir.
/// ─────────────────────────────────────────────────────────────────
class MessageQueueService {
  static MessageQueueService? _instance;
  static MessageQueueService get instance =>
      _instance ??= MessageQueueService._();
  MessageQueueService._();

  StreamSubscription<List<ConnectivityResult>>? _connectSub;
  bool _isFlushing = false;
  bool _isOnline   = true;

  /// Başlat — main.dart'ta çağır
  void start() {
    _connectSub = Connectivity()
        .onConnectivityChanged
        .listen((results) async {
      final online = results.any((r) => r != ConnectivityResult.none);
      if (!_isOnline && online) {
        debugPrint('[Queue] Back online — flushing queue...');
        await flushQueue();
      }
      _isOnline = online;
    });

    // İlk bağlantı durumunu kontrol et
    Connectivity().checkConnectivity().then((results) {
      _isOnline = results.any((r) => r != ConnectivityResult.none);
    });
  }

  void stop() {
    _connectSub?.cancel();
  }

  /// Mesaj gönder — online ise direkt, offline ise kuyruğa
  Future<MessageSendResult> sendMessage({
    required String message,
    required String receiverID,
    Map<String, dynamic>? replyTo,
    int? autoDeleteSeconds,
  }) async {
    if (_isOnline) {
      try {
        await DatabaseMethods.sendMessage(
          message,
          receiverID,
          replyTo: replyTo,
          autoDeleteSeconds: autoDeleteSeconds,
        );
        return MessageSendResult.sent;
      } catch (e) {
        debugPrint('[Queue] Send failed, queuing: $e');
      }
    }

    // Offline → kuyruğa ekle, UI'da hemen göster (optimistic)
    final qId = await LocalCache.enqueueMessage({
      'message': message,
      'receiverID': receiverID,
      'replyTo': replyTo,
      'autoDeleteSeconds': autoDeleteSeconds,
      'status': 'pending',
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });

    debugPrint('[Queue] Message queued: $qId (total: ${LocalCache.queueLength})');
    return MessageSendResult.queued;
  }

  /// Kuyruktaki mesajları Firestore'a gönder
  Future<void> flushQueue() async {
    if (_isFlushing) return;
    _isFlushing = true;

    final pending = LocalCache.getPendingMessages();
    debugPrint('[Queue] Flushing ${pending.length} messages...');

    for (final msg in pending) {
      try {
        await DatabaseMethods.sendMessage(
          msg['message'] as String,
          msg['receiverID'] as String,
          replyTo: msg['replyTo'] as Map<String, dynamic>?,
          autoDeleteSeconds: msg['autoDeleteSeconds'] as int?,
        );
        await LocalCache.dequeueMessage(msg['_queueId'] as String);
        debugPrint('[Queue] Flushed: ${msg["_queueId"]}');
      } catch (e) {
        debugPrint('[Queue] Flush failed for ${msg["_queueId"]}: $e');
        break; // Hata olursa dur, tekrar dene
      }
    }

    _isFlushing = false;
  }

  bool get isOnline => _isOnline;
  int  get queueLength => LocalCache.queueLength;
}

enum MessageSendResult { sent, queued, failed }
