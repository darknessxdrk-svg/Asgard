import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'local_cache.dart';

/// ─────────────────────────────────────────────────────────────────
/// SmartRealtimeService — Akıllı realtime yönetimi
///
/// Sadece aktif chat realtime, diğerleri lazy/get()
/// Event-based delta update (tüm listeyi değil tek mesajı güncelle)
/// ─────────────────────────────────────────────────────────────────
class SmartRealtimeService {
  static final _db   = FirebaseFirestore.instance;
  static final _auth = FirebaseAuth.instance;

  // Aktif subscriptions
  static final Map<String, StreamSubscription> _subs = {};
  static final Map<String, StreamController<List<Map<String,dynamic>>>> _controllers = {};

  // ── AKTİF CHAT STREAM ─────────────────────────────────────────────

  /// Sadece aktif chat için realtime stream başlat
  static Stream<List<Map<String, dynamic>>> watchChat(
      String chatId, {int pageSize = 40}) {
    // Zaten izleniyorsa mevcut stream'i döndür
    if (_controllers.containsKey(chatId)) {
      return _controllers[chatId]!.stream;
    }

    final controller = StreamController<List<Map<String, dynamic>>>.broadcast();
    _controllers[chatId] = controller;

    // Önce cache'den yükle (offline-first)
    final cached = LocalCache.getCachedMessages(chatId);
    if (cached.isNotEmpty) {
      controller.add(cached);
    }

    // Sonra Firestore'dan realtime
    final uid = _auth.currentUser?.uid ?? '';
    final sub = _db
        .collection('chats').doc(chatId)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(pageSize)
        .snapshots()
        .listen((snap) {
      final msgs = snap.docs
          .map((d) => {'id': d.id, ...d.data()})
          .toList();

      // Cache'e yaz
      LocalCache.cacheMessages(chatId, msgs);
      controller.add(msgs);

      debugPrint('[SmartRT] Chat $chatId: ${msgs.length} msgs (delta: ${snap.docChanges.length} changes)');
    }, onError: (e) {
      debugPrint('[SmartRT] Error: $e');
    });

    _subs[chatId] = sub;
    return controller.stream;
  }

  /// Chat ekranı kapatılınca subscription durdur
  static void unwatchChat(String chatId) {
    _subs[chatId]?.cancel();
    _subs.remove(chatId);
    _controllers[chatId]?.close();
    _controllers.remove(chatId);
    debugPrint('[SmartRT] Unwatched: $chatId');
  }

  // ── LAZY LOAD (Settings, Profile vb.) ────────────────────────────

  /// Tek seferlik Firestore fetch — realtime değil
  static Future<Map<String, dynamic>?> fetchOnce(
      String collection, String docId) async {
    try {
      // Önce cache'e bak
      final cached = LocalCache.getCachedUser(docId);
      if (cached != null) {
        // Arka planda güncelle
        _refreshInBackground(collection, docId);
        return cached;
      }

      final doc = await _db.collection(collection).doc(docId).get();
      if (!doc.exists) return null;
      final data = doc.data() ?? {};

      // Cache'e yaz
      if (collection == 'users') {
        await LocalCache.cacheUser(docId, data);
      }

      return data;
    } catch (e) {
      debugPrint('[SmartRT] fetchOnce error: $e');
      return LocalCache.getCachedUser(docId); // Fallback to cache
    }
  }

  static void _refreshInBackground(String collection, String docId) {
    Future.microtask(() async {
      try {
        final doc = await _db.collection(collection).doc(docId).get();
        if (doc.exists && doc.data() != null) {
          if (collection == 'users') {
            await LocalCache.cacheUser(docId, doc.data()!);
          }
        }
      } catch (_) {}
    });
  }

  // ── DELTA UPDATE ─────────────────────────────────────────────────

  /// Tek bir mesajı güncelle (tüm listeyi rebuild etme)
  static Future<void> updateSingleMessage(
      String chatId, String msgId, Map<String, dynamic> updates) async {
    try {
      await _db
          .collection('chats').doc(chatId)
          .collection('messages').doc(msgId)
          .set(updates, SetOptions(merge: true));
    } catch (e) {
      debugPrint('[SmartRT] updateSingleMessage error: $e');
    }
  }

  // ── TEMİZLİK ─────────────────────────────────────────────────────

  static void disposeAll() {
    for (final sub in _subs.values) sub.cancel();
    for (final ctrl in _controllers.values) ctrl.close();
    _subs.clear();
    _controllers.clear();
  }
}
