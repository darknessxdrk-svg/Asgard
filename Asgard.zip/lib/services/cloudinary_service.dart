import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class CloudinaryService {
  static const String _cloudName = 'du2zynivm';
  static const String _apiKey =
      String.fromEnvironment('CLOUDINARY_API_KEY', defaultValue: '');
  static const String _apiSecret =
      String.fromEnvironment('CLOUDINARY_API_SECRET', defaultValue: '');

  static Future<String?> uploadImage(String filePath) async {
    return await _upload(filePath, 'image', 'asgard_images');
  }

  static Future<String?> uploadAudio(String filePath) async {
    return await _upload(filePath, 'video', 'asgard_audio');
  }

  static Future<String?> _upload(
      String filePath, String resourceType, String folder) async {
    if (_apiKey.isEmpty || _apiSecret.isEmpty) {
      debugPrint('Cloudinary: API key/secret eksik.');
      return null;
    }
    try {
      final timestamp = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      final toSign = 'folder=$folder&timestamp=$timestamp$_apiSecret';
      final signature = sha1.convert(utf8.encode(toSign)).toString();

      final uri = Uri.parse(
        'https://api.cloudinary.com/v1_1/$_cloudName/$resourceType/upload',
      );
      final file = await http.MultipartFile.fromPath('file', filePath);
      final request = http.MultipartRequest('POST', uri);
      request.fields['api_key'] = _apiKey;
      request.fields['timestamp'] = timestamp.toString();
      request.fields['signature'] = signature;
      request.fields['folder'] = folder;
      request.files.add(file);

      final streamed = await request.send().timeout(const Duration(seconds: 60));
      final body = await streamed.stream.bytesToString();

      if (streamed.statusCode == 200) {
        final json = jsonDecode(body) as Map<String, dynamic>;
        return json['secure_url'] as String?;
      } else {
        debugPrint('Cloudinary hata ${streamed.statusCode}: $body');
        return null;
      }
    } catch (e) {
      debugPrint('Upload hatası: $e');
      return null;
    }
  }
}
