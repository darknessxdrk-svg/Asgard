import 'dart:convert';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

/// Cloudinary yükleme servisi — API secret artık Cloud Function'da.
/// Akış:
///   1. Server'dan imza al  (secret orada kalır, client'a gelmez)
///   2. İmzayla direkt Cloudinary'ye yükle
class CloudinaryService {
  static final _functions = FirebaseFunctions.instance;

  static Future<String?> uploadImage(String filePath) async {
    return await _upload(filePath, 'image', 'asgard_images');
  }

  static Future<String?> uploadAudio(String filePath) async {
    return await _upload(filePath, 'video', 'asgard_audio');
  }

  static Future<String?> _upload(
      String filePath, String resourceType, String folder) async {
    try {
      // 1) Server'dan imza al
      final result = await _functions
          .httpsCallable('getCloudinarySignature')
          .call({'folder': folder, 'resourceType': resourceType});

      final data      = Map<String, dynamic>.from(result.data as Map);
      final signature = data['signature'] as String;
      final timestamp = data['timestamp'].toString();
      final apiKey    = data['apiKey'] as String;
      final cloudName = data['cloudName'] as String;

      // 2) Direkt Cloudinary'ye yükle
      final uri = Uri.parse(
        'https://api.cloudinary.com/v1_1/$cloudName/$resourceType/upload',
      );
      final file    = await http.MultipartFile.fromPath('file', filePath);
      final request = http.MultipartRequest('POST', uri);
      request.fields['api_key']   = apiKey;
      request.fields['timestamp'] = timestamp;
      request.fields['signature'] = signature;
      request.fields['folder']    = folder;
      request.files.add(file);

      final streamed = await request.send().timeout(const Duration(seconds: 60));
      final body     = await streamed.stream.bytesToString();

      if (streamed.statusCode == 200) {
        final parsed = jsonDecode(body) as Map<String, dynamic>;
        return parsed['secure_url'] as String?;
      } else {
        debugPrint('Cloudinary hata ${streamed.statusCode}: $body');
        return null;
      }
    } catch (e) {
      debugPrint('Upload hatası: $e');
      return null;
    }
  }
}
