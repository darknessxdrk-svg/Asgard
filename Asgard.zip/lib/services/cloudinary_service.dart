import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

class CloudinaryService {
  static const String _cloudName = 'du2zynivm';
  static const String _apiKey =
      String.fromEnvironment('CLOUDINARY_API_KEY', defaultValue: '');
  static const String _apiSecret =
      String.fromEnvironment('CLOUDINARY_API_SECRET', defaultValue: '');

  static const int _maxImageBytes = 10 * 1024 * 1024;  // 10 MB
  static const int _maxAudioBytes = 25 * 1024 * 1024;  // 25 MB

  static Future<String?> uploadImage(String filePath) async {
    return await _upload(filePath, 'image', 'asgard_images', _maxImageBytes);
  }

  static Future<String?> uploadVideo(String filePath) async {
    return await _upload(filePath, 'video', 'asgard_videos', 100 * 1024 * 1024);
  }

  static Future<String?> uploadAudio(String filePath) async {
    return await _upload(filePath, 'video', 'asgard_audio', _maxAudioBytes);
  }

  static Future<String?> _upload(
      String filePath, String resourceType, String folder, int maxBytes) async {
    if (_apiKey.isEmpty || _apiSecret.isEmpty) {
      debugPrint('Cloudinary: API key/secret eksik.');
      return null;
    }

    // Dosya boyutu kontrolü
    try {
      final fileSize = await File(filePath).length();
      if (fileSize > maxBytes) {
        debugPrint('Cloudinary: Dosya çok büyük (${fileSize ~/ 1024}KB)');
        return null;
      }
    } catch (e) {
      debugPrint('Cloudinary: Dosya okunamadı: $e');
      return null;
    }

    try {
      final timestamp = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      final toSign = 'folder=$folder&timestamp=$timestamp$_apiSecret';
      final signature = sha1.convert(utf8.encode(toSign)).toString();

      final uri = Uri.parse(
        'https://api.cloudinary.com/v1_1/$_cloudName/$resourceType/upload',
      );

      final file = await http.MultipartFile.fromPath('file', filePath);
      final request = http.MultipartRequest('POST', uri);
      request.fields['api_key'] = _apiKey;
      request.fields['timestamp'] = timestamp.toString();
      request.fields['signature'] = signature;
      request.fields['folder'] = folder;
      request.files.add(file);

      final streamedResponse =
          await request.send().timeout(const Duration(seconds: 60));
      final body = await streamedResponse.stream.bytesToString();

      if (streamedResponse.statusCode == 200) {
        final json = jsonDecode(body);
        if (json is! Map<String, dynamic>) return null;
        return json['secure_url'] as String?;
      } else {
        debugPrint('Cloudinary hata ${streamedResponse.statusCode}: $body');
        return null;
      }
    } catch (e) {
      debugPrint('Upload hatası: $e');
      return null;
    }
  }
}
