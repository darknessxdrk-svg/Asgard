import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class AIService {
  static const String _geminiKey =
      String.fromEnvironment('GEMINI_API_KEY', defaultValue: '');

  static Future<String> ask({
    required String prompt,
    List<Map<String, dynamic>>? context,
    String? systemPrompt,
  }) async {
    if (_geminiKey.isEmpty) return '⚠️ Gemini API anahtarı eksik.';
    try {
      final contents = <Map<String, dynamic>>[];
      if (context != null) contents.addAll(context);
      contents.add({'role': 'user', 'parts': [{'text': prompt}]});

      final response = await http.post(
        Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$_geminiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'system_instruction': {'parts': [{'text': systemPrompt ?? 'Sen Asgard sohbet asistanisin. Kisa ve Turkce cevap ver.'}]},
          'contents': contents,
          'generationConfig': {'maxOutputTokens': 800},
        }),
      );
      if (response.statusCode != 200) {
        final data = jsonDecode(response.body);
        final code = data['error']?['code'] ?? response.statusCode;
        if (code == 429) return '⚠️ AI kota doldu. Biraz bekleyip tekrar deneyin.';
        if (code == 403) return '⚠️ AI erişim reddedildi.';
        return '⚠️ AI şu an yanıt veremiyor (kod: $code).';
      }
      final data = jsonDecode(response.body);
      return data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? 'Yanıt alınamadı';
    } catch (e) {
      if (kDebugMode) debugPrint('AI hata: $e');
      return '⚠️ Bağlantı hatası. İnternet bağlantını kontrol et.';
    }
  }

  static Future<String> translate({
    required String text,
    required String targetLanguage,
  }) async {
    return ask(
      prompt: '$targetLanguage diline çevir, sadece çeviriyi yaz:\n\n$text',
      systemPrompt: 'Sadece çeviriyi yaz, hiçbir açıklama ekleme.',
    );
  }
}
