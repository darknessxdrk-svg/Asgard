import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/foundation.dart';

/// AI servisi — Gemini API key artık Cloud Function'da.
/// Client secret tutmaz, sadece soru/context gönderir.
class AIService {
  static final _fn = FirebaseFunctions.instance;

  /// Tek seferlik AI yanıtı — sohbet asistanı, @ai komutu vb.
  static Future<String> ask({
    required String prompt,
    List<Map<String, dynamic>>? context,
    String? systemPrompt,
  }) async {
    try {
      final result = await _fn.httpsCallable('askAI').call({
        'prompt': prompt,
        if (context != null) 'context': context,
        if (systemPrompt != null) 'systemPrompt': systemPrompt,
      });
      final data = Map<String, dynamic>.from(result.data as Map);
      return data['reply'] as String? ?? 'Yanıt alınamadı';
    } on FirebaseFunctionsException catch (e) {
      debugPrint('AI hata: ${e.code} — ${e.message}');
      if (e.code == 'resource-exhausted') {
        return '⚠️ AI kota doldu. Biraz bekleyip tekrar deneyin.';
      }
      if (e.code == 'permission-denied') {
        return '⚠️ AI erişim reddedildi.';
      }
      return '⚠️ AI şu an yanıt veremiyor. Tekrar deneyin.';
    } catch (e) {
      debugPrint('AI bağlantı hatası: $e');
      return '⚠️ Bağlantı hatası. İnternet bağlantını kontrol et.';
    }
  }

  /// Çeviri
  static Future<String> translate({
    required String text,
    required String targetLanguage,
  }) async {
    return ask(
      prompt: '$targetLanguage diline çevir, sadece çeviriyi yaz:\n\n$text',
      systemPrompt: 'Sadece çeviriyi yaz, hiçbir açıklama ekleme.',
    );
  }
}
