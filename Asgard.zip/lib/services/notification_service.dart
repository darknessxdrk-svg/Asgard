import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:googleapis_auth/auth_io.dart';
import 'package:http/http.dart' as http;

/// FCM v1 HTTP API ile push bildirimi gönderir.
/// Kimlik doğrulama için Google Service Account JSON kullanır.
/// JSON, GitHub Secret olarak base64 encode edilmiş şekilde saklanır:
///   --dart-define=FCM_SERVICE_ACCOUNT_JSON_B64=<base64_json>
class NotificationService extends ChangeNotifier {
  static const String _projectId = 'asgardchat-f3880';

  // Service account JSON (base64) — GitHub Secret: FCM_SERVICE_ACCOUNT_JSON_B64
  // Firebase Console → Project Settings → Service Accounts → Generate new private key
  static const String _saJsonB64 = String.fromEnvironment(
    'FCM_SERVICE_ACCOUNT_JSON_B64',
    defaultValue: '',
  );

  // Cache: access token (1 saat geçerli)
  static String? _cachedToken;
  static DateTime? _tokenExpiry;

  Future<String?> _getAccessToken() async {
    // Cache geçerliyse kullan
    if (_cachedToken != null &&
        _tokenExpiry != null &&
        DateTime.now().isBefore(_tokenExpiry!)) {
      return _cachedToken;
    }

    if (_saJsonB64.isEmpty) {
      debugPrint('FCM: FCM_SERVICE_ACCOUNT_JSON_B64 eksik.');
      return null;
    }

    try {
      final jsonStr = utf8.decode(base64.decode(_saJsonB64));
      final credentials = ServiceAccountCredentials.fromJson(jsonDecode(jsonStr));
      final scopes = ['https://www.googleapis.com/auth/firebase.messaging'];
      final client = await clientViaServiceAccount(credentials, scopes);
      final token = client.credentials.accessToken.data;
      _cachedToken = token;
      _tokenExpiry = DateTime.now().add(const Duration(minutes: 55));
      client.close();
      return token;
    } catch (e) {
      debugPrint('FCM token hatası: $e');
      return null;
    }
  }

  Future<void> sendPushMessage(
    String receiverMToken,
    String senderMToken,
    String message,
    String senderName,
    String senderID,
    String? senderUserProfilePic, {
    String receiverUID = '',
  }) async {
    if (receiverMToken.isEmpty) return;

    final token = await _getAccessToken();
    if (token == null) return;

    try {
      final uri = Uri.parse(
        'https://fcm.googleapis.com/v1/projects/$_projectId/messages:send',
      );
      final body = jsonEncode({
        'message': {
          'token': receiverMToken,
          'data': {
            'name': senderName,
            'body': message,
            'title': senderName,
            'type': 'chat',
            'uid': senderID,
            'receiverUID': receiverUID,
            'mtoken': senderMToken,
            'isOnline': 'true',
            'profilePic': senderUserProfilePic ?? '',
          },
          'android': {'priority': 'high'},
          'apns': {
            'headers': {'apns-priority': '10'},
            'payload': {'aps': {'content-available': 1}}
          }
        }
      });

      final response = await http.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: body,
      );

      if (response.statusCode != 200) {
        debugPrint('FCM hata ${response.statusCode}: ${response.body}');
        // Token süresi dolmuşsa cache temizle
        if (response.statusCode == 401) {
          _cachedToken = null;
          _tokenExpiry = null;
        }
      }
    } catch (e) {
      debugPrint('FCM gönderim hatası: $e');
    }
  }

  Future<void> sendCallNotification({
    required String receiverToken,
    required String callerName,
    required String callerUID,
    required String callId,
    required bool isVideo,
  }) async {
    if (receiverToken.isEmpty) return;
    final token = await _getAccessToken();
    if (token == null) return;
    try {
      final uri = Uri.parse(
        'https://fcm.googleapis.com/v1/projects/$_projectId/messages:send',
      );
      final body = jsonEncode({
        'message': {
          'token': receiverToken,
          'notification': {
            'title': callerName,
            'body': isVideo ? 'Goruntulu arama geliyor...' : 'Sesli arama geliyor...',
          },
          'data': {
            'type': 'incoming_call',
            'callId': callId,
            'callerName': callerName,
            'callerUID': callerUID,
            'isVideo': isVideo.toString(),
          },
          'android': {
            'priority': 'high',
            'notification': {
              'channel_id': 'asgard_calls',
              'sound': 'default',
              'click_action': 'FLUTTER_NOTIFICATION_CLICK',
              'notification_priority': 'PRIORITY_MAX',
              'visibility': 'PUBLIC',
              'default_vibrate_timings': true,
              'default_sound': true,
            },
          },
          'apns': {
            'headers': {'apns-priority': '10'},
            'payload': {
              'aps': {
                'sound': 'default',
                'badge': 1,
                'content-available': 1,
              }
            }
          },
        }
      });
      await http.post(uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: body,
      );
    } catch (e) {
      debugPrint('FCM call notification error: $e');
    }
  }
}
