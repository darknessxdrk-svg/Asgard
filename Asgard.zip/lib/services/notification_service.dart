import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/foundation.dart';

/// Bildirim servisi — FCM SA key artık Cloud Function'da.
/// Client hiçbir secret tutmaz.
class NotificationService extends ChangeNotifier {
  static final _functions = FirebaseFunctions.instance;

  /// Mesaj bildirimi
  Future<void> sendPushMessage(
    String receiverMToken, // artık kullanılmıyor, server Firestore'dan okur
    String senderMToken,
    String message,
    String senderName,
    String senderID,
    String? senderUserProfilePic, {
    String receiverUID = '',
  }) async {
    if (receiverUID.isEmpty) return;
    try {
      await _functions.httpsCallable('sendNotification').call({
        'receiverUID': receiverUID,
        'title': senderName,
        'body': message,
        'type': 'chat',
        'extraData': {
          'name': senderName,
          'profilePic': senderUserProfilePic ?? '',
        },
      });
    } catch (e) {
      debugPrint('Bildirim gönderilemedi: \$e');
    }
  }

  /// Arama bildirimi
  Future<void> sendCallNotification({
    required String receiverToken,
    required String callerName,
    required String callerUID,
    required String callId,
    required bool isVideo,
    required String receiverUID,
  }) async {
    if (receiverUID.isEmpty) return;
    try {
      await _functions.httpsCallable('sendNotification').call({
        'receiverUID': receiverUID,
        'title': callerName,
        'body': isVideo ? '📹 Görüntülü arama geliyor...' : '📞 Sesli arama geliyor...',
        'type': 'incoming_call',
        'extraData': {
          'callId': callId,
          'callerName': callerName,
          'callerUID': callerUID,
          'isVideo': isVideo.toString(),
        },
      });
    } catch (e) {
      debugPrint('Arama bildirimi gönderilemedi: \$e');
    }
  }
}
