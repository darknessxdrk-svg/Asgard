import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:googleapis_auth/auth_io.dart';
import 'package:http/http.dart' as http;

class NotificationService extends ChangeNotifier {
  static const String _projectId = 'asgardchat-f3880';
  static const String _saJsonB64 = String.fromEnvironment(
    'FCM_SERVICE_ACCOUNT_JSON_B64',
    defaultValue: '',
  );
  static String? _cachedToken;
  static DateTime? _tokenExpiry;

  Future<String?> _getAccessToken() async {
    if (_cachedToken != null &&
        _tokenExpiry != null &&
        DateTime.now().isBefore(_tokenExpiry!)) {
      return _cachedToken;
    }
    if (_saJsonB64.isEmpty) return null;
    try {
      // FIX DATA: json parse crash guard — base64/json hatalıysa graceful fail
      final String jsonStr;
      try {
        jsonStr = utf8.decode(base64.decode(_saJsonB64));
      } catch (e) {
        debugPrint('[FCM] SA JSON base64 decode hatası: $e');
        return null;
      }
      final Map<String, dynamic> jsonMap;
      try {
        final decoded = jsonDecode(jsonStr);
        if (decoded is! Map<String, dynamic>) {
          debugPrint('[FCM] SA JSON geçersiz format');
          return null;
        }
        jsonMap = decoded;
      } catch (e) {
        debugPrint('[FCM] SA JSON parse hatası: $e');
        return null;
      }
      final credentials = ServiceAccountCredentials.fromJson(jsonMap);
      final scopes = ['https://www.googleapis.com/auth/firebase.messaging'];
      final client = await clientViaServiceAccount(credentials, scopes);
      _cachedToken = client.credentials.accessToken.data;
      _tokenExpiry = DateTime.now().add(const Duration(minutes: 55));
      client.close();
      return _cachedToken;
    } catch (e) {
      debugPrint('FCM token hatası: $e');
      return null;
    }
  }

  Future<void> _post(String token, Map<String, dynamic> message) async {
    try {
      final response = await http.post(
        Uri.parse(
            'https://fcm.googleapis.com/v1/projects/$_projectId/messages:send'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'message': message}),
      );
      if (response.statusCode == 401) {
        // Token süresi dolmuş — cache'i temizle, bir sonraki çağrıda yenilenir
        _cachedToken = null;
        _tokenExpiry = null;
        debugPrint('[FCM] Access token süresi doldu, yenilendi');
      }
      if (response.statusCode != 200) {
        // FIX #9: Hataları sessiz geçirme — logla
        debugPrint('[FCM] ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      debugPrint('[FCM] HTTP hata: $e');
    }
  }

  /// Mesaj bildirimi — payload alanları validate edilir
  Future<void> sendPushMessage(
    String receiverMToken,
    String senderMToken,
    String message,
    String senderName,
    String senderID,
    String? senderUserProfilePic, {
    String receiverUID = '',
  }) async {
    // FIX #11: Payload güvenlik doğrulaması — boş/geçersiz değerleri reddet
    if (receiverMToken.isEmpty) return;
    if (senderID.isEmpty) {
      debugPrint('[FCM] sendPushMessage: senderID boş, gönderim atlandı');
      return;
    }
    final sanitizedMessage = message.length > 200
        ? '${message.substring(0, 200)}...'
        : message;
    final sanitizedName =
        senderName.isEmpty ? 'Kullanıcı' : senderName.substring(0, senderName.length.clamp(0, 50));

    final token = await _getAccessToken();
    if (token == null) {
      debugPrint('[FCM] Access token alınamadı, bildirim gönderilemedi');
      return;
    }
    await _post(token, {
      'token': receiverMToken,
      'notification': {
        'title': sanitizedName,
        'body': sanitizedMessage,
      },
      'data': {
        'type': 'chat',
        'title': sanitizedName,
        'body': sanitizedMessage,
        'name': sanitizedName,
        'uid': senderID,
        'receiverUID': receiverUID,
        'mtoken': senderMToken,
        'isOnline': 'true',
        'profilePic': senderUserProfilePic ?? '',
      },
      'android': {
        'priority': 'high',
        'notification': {
          'channel_id': 'asgardappid',
          'notification_priority': 'PRIORITY_MAX',
          'default_sound': true,
          'default_vibrate_timings': true,
        },
      },
    });
  }

  /// Arama bildirimi - tam ekran, ses çalar
  Future<void> sendCallNotification({
    required String receiverToken,
    required String callerName,
    required String callerUID,
    required String callId,
    required bool isVideo,
  }) async {
    if (receiverToken.isEmpty) return;
    final token = await _getAccessToken();
    if (token == null) return;
    await _post(token, {
      'token': receiverToken,
      // notification payload - MIUI gösterir, ses çalar
      'notification': {
        'title': callerName,
        'body': isVideo ? '📹 Görüntülü arama geliyor...' : '📞 Sesli arama geliyor...',
      },
      'data': {
        'type': 'incoming_call',
        'callId': callId,
        'callerName': callerName,
        'callerUID': callerUID,
        'isVideo': isVideo.toString(),
      },
      'android': {
        'priority': 'high',
        'notification': {
          'channel_id': 'asgard_calls',
          'notification_priority': 'PRIORITY_MAX',
          'default_sound': true,
          'default_vibrate_timings': true,
          'visibility': 'PUBLIC',
        },
      },
      'apns': {
        'headers': {'apns-priority': '10'},
        'payload': {
          'aps': {'sound': 'default', 'content-available': 1}
        },
      },
    });
  }
}
