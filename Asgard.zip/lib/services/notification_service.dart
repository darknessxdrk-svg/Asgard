import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:googleapis_auth/auth_io.dart';
import 'package:http/http.dart' as http;

class NotificationService extends ChangeNotifier {
  static const String _projectId = 'asgardchat-f3880';
  static const String _saJsonB64 = String.fromEnvironment(
    'FCM_SERVICE_ACCOUNT_JSON_B64',
    defaultValue: '',
  );
  static String? _cachedToken;
  static DateTime? _tokenExpiry;

  Future<String?> _getAccessToken() async {
    if (_cachedToken != null &&
        _tokenExpiry != null &&
        DateTime.now().isBefore(_tokenExpiry!)) {
      return _cachedToken;
    }
    if (_saJsonB64.isEmpty) return null;
    try {
      final jsonStr = utf8.decode(base64.decode(_saJsonB64));
      final credentials = ServiceAccountCredentials.fromJson(jsonDecode(jsonStr));
      final scopes = ['https://www.googleapis.com/auth/firebase.messaging'];
      final client = await clientViaServiceAccount(credentials, scopes);
      _cachedToken = client.credentials.accessToken.data;
      _tokenExpiry = DateTime.now().add(const Duration(minutes: 55));
      client.close();
      return _cachedToken;
    } catch (e) {
      debugPrint('FCM token hatası: $e');
      return null;
    }
  }

  Future<void> _post(String token, Map<String, dynamic> message) async {
    try {
      final response = await http.post(
        Uri.parse('https://fcm.googleapis.com/v1/projects/$_projectId/messages:send'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'message': message}),
      );
      if (response.statusCode == 401) {
        _cachedToken = null;
        _tokenExpiry = null;
      }
    } catch (e) {
      debugPrint('FCM hata: $e');
    }
  }

  Future<void> sendPushMessage(
    String receiverMToken,
    String senderMToken,
    String message,
    String senderName,
    String senderID,
    String? senderUserProfilePic, {
    String receiverUID = '',
  }) async {
    if (receiverMToken.isEmpty) return;
    final token = await _getAccessToken();
    if (token == null) return;
    await _post(token, {
      'token': receiverMToken,
      'notification': {'title': senderName, 'body': message},
      'data': {
        'type': 'chat',
        'title': senderName,
        'body': message,
        'name': senderName,
        'uid': senderID,
        'receiverUID': receiverUID,
        'mtoken': senderMToken,
        'isOnline': 'true',
        'profilePic': senderUserProfilePic ?? '',
      },
      'android': {
        'priority': 'high',
        'notification': {
          'channel_id': 'asgardappid',
          'notification_priority': 'PRIORITY_MAX',
          'default_sound': true,
          'default_vibrate_timings': true,
        },
      },
    });
  }

  Future<void> sendCallNotification({
    required String receiverToken,
    required String callerName,
    required String callerUID,
    required String callId,
    required bool isVideo,
    String receiverUID = '',
  }) async {
    if (receiverToken.isEmpty) return;
    final token = await _getAccessToken();
    if (token == null) return;
    await _post(token, {
      'token': receiverToken,
      'notification': {
        'title': callerName,
        'body': isVideo ? '📹 Görüntülü arama geliyor...' : '📞 Sesli arama geliyor...',
      },
      'data': {
        'type': 'incoming_call',
        'callId': callId,
        'callerName': callerName,
        'callerUID': callerUID,
        'isVideo': isVideo.toString(),
      },
      'android': {
        'priority': 'high',
        'notification': {
          'channel_id': 'asgard_calls',
          'notification_priority': 'PRIORITY_MAX',
          'default_sound': true,
          'default_vibrate_timings': true,
          'visibility': 'PUBLIC',
        },
      },
      'apns': {
        'headers': {'apns-priority': '10'},
        'payload': {'aps': {'sound': 'default', 'content-available': 1}},
      },
    });
  }
}
