import 'dart:io';
import '../channels/ui/channels_screen.dart';
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';

import '../../services/cloudinary_service.dart';
import '../chat/ui/image_editor_screen.dart';
import '../../themes/colors.dart';

class _StatusesContent extends StatefulWidget {
  const _StatusesContent();
  @override State<_StatusesContent> createState() => _StatusesContentState();
}

class _StatusesContentState extends State<_StatusesContent> {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  bool _uploading = false;

  String? get _uid => _auth.currentUser?.uid;

  // 24 saat filtresi
  bool _isAlive(Timestamp? ts) {
    if (ts == null) return false;
    return ts.toDate().isAfter(DateTime.now().subtract(const Duration(hours: 24)));
  }

  Future<void> _postStatus(String content, String type, {String note = ''}) async {
    final uid = _uid;
    if (uid == null) return;
    final userData = (await _db.collection('users').doc(uid).get()).data() ?? {};
    await _db.collection('statuses').add({
      'uid': uid,
      'userName': userData['name'] ?? '',
      'userPhoto': userData['profilePic'] ?? '',
      'content': content,
      'type': type,
      'note': note,
      'createdAt': Timestamp.now(),
      'expiresAt': Timestamp.fromDate(DateTime.now().add(const Duration(hours: 24))),
      'viewedBy': [],
    });
  }

  Future<void> _pickAndPost(ImageSource src) async {
    // Bottom sheet'i kapat
    if (mounted) Navigator.of(context).pop();
    
    final picked = await ImagePicker().pickImage(source: src, imageQuality: 85);
    if (picked == null) return;
    if (!mounted) return;

    // Editör aç
    final editedFile = await ImageEditorScreen.editFile(context, File(picked.path));
    final finalFile = editedFile ?? File(picked.path);
    if (!mounted) return;

    // Not dialog
    String note = '';
    if (mounted) {
      final ctrl = TextEditingController();
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: const Text('Not Ekle', style: TextStyle(color: Colors.white, fontSize: 16)),
          content: TextField(
            controller: ctrl,
            style: const TextStyle(color: Colors.white),
            maxLength: 100,
            decoration: InputDecoration(
              hintText: 'Bir şeyler yaz...',
              hintStyle: const TextStyle(color: Colors.white38),
              counterStyle: const TextStyle(color: Colors.white24),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.3)),
                  borderRadius: BorderRadius.circular(10)),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ColorsManager.darkPrimary),
                  borderRadius: BorderRadius.circular(10)),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx),
                child: const Text('Atla', style: TextStyle(color: Colors.white38))),
            TextButton(
                onPressed: () { note = ctrl.text.trim(); Navigator.pop(ctx); },
                child: Text('Tamam', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold))),
          ],
        ),
      );
    }
    if (!mounted) return;
    setState(() => _uploading = true);
    final url = await CloudinaryService.uploadImage(finalFile.path);
    if (url != null) await _postStatus(url, 'image', note: note);
    if (mounted) setState(() => _uploading = false);
  }

  void _showAddStatus() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        ListTile(leading: Icon(Icons.text_fields, color: ColorsManager.darkPrimary),
            title: const Text('Metin Durumu', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _showTextStatus(); }),
        ListTile(leading: Icon(Icons.photo, color: ColorsManager.darkPrimary),
            title: const Text('Fotoğraf', style: TextStyle(color: Colors.white)),
            onTap: () { _pickAndPost(ImageSource.gallery); }),
        ListTile(leading: Icon(Icons.videocam, color: ColorsManager.darkPrimary),
            title: const Text('Video', style: TextStyle(color: Colors.white)),
            onTap: () { _pickVideo(); }),
        ListTile(leading: Icon(Icons.camera_alt, color: ColorsManager.darkPrimary),
            title: const Text('Kamera', style: TextStyle(color: Colors.white)),
            onTap: () { _pickAndPost(ImageSource.camera); }),
        Gap(8.h),
      ])),
    );
  }

  void _showTextStatus() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Metin Durumu', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: ctrl, autofocus: true, maxLines: 4, maxLength: 200,
          style: const TextStyle(color: Colors.white, fontSize: 18),
          decoration: const InputDecoration(
            hintText: 'Ne düşünüyorsun?',
            hintStyle: TextStyle(color: Colors.white24),
            border: InputBorder.none,
            counterStyle: TextStyle(color: Colors.white24),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
              onPressed: () async {
                if (ctrl.text.trim().isEmpty) return;
                Navigator.pop(ctx);
                await _postStatus(ctrl.text.trim(), 'text');
              },
              child: Text('Paylaş', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      floatingActionButton: _uploading
          ? FloatingActionButton(backgroundColor: ColorsManager.darkPrimary,
              onPressed: null, child: const CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
          : FloatingActionButton(backgroundColor: ColorsManager.darkPrimary,
              onPressed: _showAddStatus, child: const Icon(Icons.add, color: Colors.white)),
      body: StreamBuilder<QuerySnapshot>(
        stream: _uid != null
            ? _db.collection('users').doc(_uid).collection('contacts').snapshots()
            : const Stream.empty(),
        builder: (ctx0, contactSnap) {
          final contactUIDs = (contactSnap.data?.docs ?? []).map((d) => d.id).toSet();
          return StreamBuilder<QuerySnapshot>(
            stream: _db.collection('statuses').snapshots(),
            builder: (ctx, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));

          final all = snap.data!.docs.where((d) {
            final data = d.data() as Map<String, dynamic>;
            final sUID = data['uid'] as String? ?? '';
            return _isAlive(data['createdAt'] as Timestamp?) &&
                (sUID == _uid || contactUIDs.contains(sUID));
          }).toList();

          // UID'ye göre grupla
          final Map<String, List<QueryDocumentSnapshot>> grouped = {};
          for (final doc in all) {
            final data = doc.data() as Map<String, dynamic>;
            final uid = data['uid'] as String? ?? '';
            grouped.putIfAbsent(uid, () => []).add(doc);
          }

          // Kendi statuslarını ayır
          final myStatuses = grouped[_uid] ?? [];
          final othersMap = Map<String, List<QueryDocumentSnapshot>>.from(grouped)
            ..remove(_uid);

          return ListView(padding: EdgeInsets.only(top: 12.h), children: [

            // ── Benim Durum ───────────────────────────────────────────────
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Benim Durum', style: TextStyle(color: Colors.white38, fontSize: 12.sp, fontWeight: FontWeight.w600)),
                Gap(8.h),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: GestureDetector(
                    onTap: _showAddStatus,
                    child: Stack(children: [
                      Container(width: 54.w, height: 54.h,
                        decoration: BoxDecoration(shape: BoxShape.circle,
                            border: Border.all(
                                color: myStatuses.isEmpty ? Colors.white24 : ColorsManager.darkPrimary,
                                width: 2)),
                        child: ClipOval(child: _MyAvatar())),
                      Positioned(bottom: 0, right: 0,
                        child: Container(width: 20, height: 20,
                          decoration: BoxDecoration(
                              color: ColorsManager.darkPrimary, shape: BoxShape.circle,
                              border: Border.all(color: const Color(0xFF0D0D0D), width: 2)),
                          child: const Icon(Icons.add, size: 12, color: Colors.white))),
                    ]),
                  ),
                  title: const Text('Durumumu Ekle', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: myStatuses.isEmpty
                      ? const Text('Durum paylaşmak için dokun', style: TextStyle(color: Colors.white38, fontSize: 12))
                      : Text('${myStatuses.length} durum paylaşıldı', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12)),
                  trailing: myStatuses.isEmpty ? null : IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    tooltip: 'Tüm durumları sil',
                    onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(
                      backgroundColor: const Color(0xFF1A1A1A),
                      title: const Text('Tüm durumları sil?', style: TextStyle(color: Colors.white)),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
                        TextButton(onPressed: () async {
                          Navigator.pop(context);
                          for (final s in myStatuses) await _db.collection('statuses').doc(s.id).delete();
                        }, child: const Text('Sil', style: TextStyle(color: Colors.red))),
                      ],
                    )),
                  ),
                  onTap: myStatuses.isEmpty ? _showAddStatus : () => _openViewer(myStatuses),
                ),
              ]),
            ),

            if (othersMap.isNotEmpty) ...[
              Padding(padding: EdgeInsets.fromLTRB(16.w, 16.h, 16.w, 6.h),
                  child: Text('Son Güncellemeler', style: TextStyle(color: Colors.white38, fontSize: 12.sp, fontWeight: FontWeight.w600))),
              ...othersMap.entries.map((e) => _StatusTile(
                uid: e.key,
                statuses: e.value,
                viewerUID: _uid ?? '',
                onTap: () => _openViewer(e.value, uid: e.key),
              )),
            ],

            if (myStatuses.isEmpty && othersMap.isEmpty)
              Center(child: Padding(
                padding: EdgeInsets.only(top: 80.h),
                child: Column(children: [
                  Icon(Icons.circle_outlined, size: 64.sp, color: Colors.white12),
                  Gap(16.h),
                  const Text('Henüz durum yok', style: TextStyle(color: Colors.white38, fontSize: 16)),
                  Gap(8.h),
                  const Text('+ butonuna basarak durum paylaş', style: TextStyle(color: Colors.white24, fontSize: 13)),
                ]),
              )),

            Gap(80.h),
          ]);
            },
          );
        },
      ),
    );
  }

  Future<void> _openViewer(List<QueryDocumentSnapshot> statuses, {String? uid}) async {
    if (statuses.isEmpty) return;
    final data = statuses.first.data() as Map<String, dynamic>;
    String name = data['userName'] ?? '';
    String photo = data['userPhoto'] ?? '';
    // Firestore'dan güncel bilgi al
    final statusUid = uid ?? data['uid'] ?? _uid ?? '';
    if (statusUid.isNotEmpty) {
      try {
        final userDoc = await FirebaseFirestore.instance.collection('users').doc(statusUid).get();
        final userData = userDoc.data();
        if (userData != null) {
          name = userData['name'] ?? name;
          photo = userData['profilePic'] ?? photo;
        }
      } catch (_) {}
    }
    if (!mounted) return;
    final myUID = _uid ?? '';
    Navigator.push(context, MaterialPageRoute(builder: (_) => _StatusViewPage(
      statuses: statuses,
      name: name.isEmpty ? 'Kullanıcı' : name,
      photo: photo,
      viewerUID: myUID,
      isOwner: uid == null || statusUid == myUID,
    )));
  }
}

// ── Kendi avatar widget ───────────────────────────────────────────────────────
class _MyAvatar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return Container(color: Colors.white12, child: const Icon(Icons.person, color: Colors.white38));
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (_, snap) {
        final photo = (snap.data?.data() as Map?)?.get('profilePic') ?? '';
        if (photo.isEmpty) return Container(color: const Color(0xFF1A1A1A), child: const Icon(Icons.person, color: Colors.white38));
        return CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
            errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white38));
      },
    );
  }
}

extension _MapGet on Map {
  dynamic get(String key) => this[key];
}

// ── Başkasının durum tile'ı ───────────────────────────────────────────────────
class _StatusTile extends StatelessWidget {
  final String uid;
  final List<QueryDocumentSnapshot> statuses;
  final String viewerUID;
  final VoidCallback onTap;
  const _StatusTile({required this.uid, required this.statuses, required this.viewerUID, required this.onTap});

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'az önce';
    if (diff.inMinutes < 60) return '${diff.inMinutes} dk önce';
    return '${diff.inHours} saat önce';
  }

  @override
  Widget build(BuildContext context) {
    final allViewed = statuses.every((s) {
      try {
        final vb = List<dynamic>.from((s.data() as Map?)?['viewedBy'] ?? []);
        return vb.contains(viewerUID);
      } catch (_) { return false; }
    });
    final ts = (statuses.first.data() as Map)['createdAt'] as Timestamp?;
    final timeStr = ts != null ? _timeAgo(ts.toDate()) : '';

    // Her zaman Firestore'dan güncel kullanıcı bilgisi çek
    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance.collection('users').doc(uid).get(),
      builder: (ctx, snap) {
        final userData = snap.data?.data() as Map<String, dynamic>?;
        final name = userData?['name'] ?? (statuses.first.data() as Map)['userName'] ?? 'Kullanıcı';
        final photo = userData?['profilePic'] ?? (statuses.first.data() as Map)['userPhoto'] ?? '';

        return ListTile(
          contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 4.h),
          leading: GestureDetector(
            onTap: photo.isNotEmpty ? () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => _FullPhotoViewPage(url: photo))) : null,
            child: Container(
              width: 54.w, height: 54.h,
              decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: allViewed ? Colors.white24 : ColorsManager.darkPrimary, width: 2.5)),
              child: ClipOval(child: photo.isNotEmpty
                  ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                      errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white38))
                  : Container(color: const Color(0xFF1A1A1A), child: const Icon(Icons.person, color: Colors.white38))),
            ),
          ),
          title: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          subtitle: Text(timeStr, style: const TextStyle(color: Colors.white38, fontSize: 12)),
          onTap: onTap,
        );
      },
    );
  }
}

// ── Status Viewer ─────────────────────────────────────────────────────────────
class _StatusViewPage extends StatefulWidget {
  final List<QueryDocumentSnapshot> statuses;
  final String name, photo, viewerUID;
  final bool isOwner;
  const _StatusViewPage({required this.statuses, required this.name, required this.photo, required this.viewerUID, this.isOwner = false});
  @override State<_StatusViewPage> createState() => _StatusViewPageState();
}

class _StatusViewPageState extends State<_StatusViewPage> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  int _current = 0;
  late List<QueryDocumentSnapshot> _localStatuses;
  final TextEditingController _replyCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _localStatuses = List.from(widget.statuses);
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 6));
    _ctrl.addStatusListener((s) { if (s == AnimationStatus.completed) _next(); });
    _ctrl.forward();
    _markViewed();
  }

  void _next() {
    if (_current < _localStatuses.length - 1) { setState(() => _current++); _ctrl.reset(); _ctrl.forward(); }
    else Navigator.pop(context);
  }
  void _prev() {
    if (_current > 0) { setState(() => _current--); _ctrl.reset(); _ctrl.forward(); }
    else { _ctrl.reset(); _ctrl.forward(); }
  }

  Future<void> _markViewed() async {
    if (widget.viewerUID.isEmpty) return;
    for (final s in _localStatuses) {
      try {
        // FIX FIREBASE: viewedBy array büyümesini sınırla
        final existing = List<dynamic>.from((s.data() as Map?)?['viewedBy'] ?? []);
        if (!existing.contains(widget.viewerUID)) {
          if (existing.length < 500) {
            await s.reference.update({'viewedBy': FieldValue.arrayUnion([widget.viewerUID])});
          }
          // 500'den fazla izleyici varsa sadece sayacı güncelle (array'e ekleme)
        }
      } catch (_) {}
    }
  }

  @override
  void dispose() { _ctrl.dispose(); _replyCtrl.dispose(); super.dispose(); }

  Future<void> _sendReply() async {
    final text = _replyCtrl.text.trim();
    if (text.isEmpty) return;
    final statusOwnerUID = (_localStatuses.first.data() as Map)['uid'] as String? ?? '';
    if (statusOwnerUID.isEmpty) return;
    try {
      // Sohbet odasına mesaj yaz
      final myUID = widget.viewerUID;
      final ids = [myUID, statusOwnerUID]..sort();
      final roomID = ids.join('_');
      await FirebaseFirestore.instance
          .collection('chats')
          .doc(roomID)
          .collection('messages')
          .add({
        'senderID': myUID,
        'receiverID': statusOwnerUID,
        'message': '↩️ Durumuna yanıt: $text',
        'timestamp': Timestamp.now(),
        'status': 'delivered',
      });
      _replyCtrl.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Yanıt gönderildi'), backgroundColor: Color(0xFF1A1A1A)));
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final data = _localStatuses[_current].data() as Map<String, dynamic>;
    final type = data['type'] ?? 'text';
    final content = data['content'] ?? '';
    final note = (data['note'] ?? '').toString();
    final pad = MediaQuery.of(context).padding;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onLongPressStart: (_) => _ctrl.stop(),
        onLongPressEnd: (_) => _ctrl.forward(),
        onTapUp: (d) {
          final x = d.globalPosition.dx;
          final w = MediaQuery.of(context).size.width;
          if (x < w / 3) _prev(); else _next();
        },
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Stack(fit: StackFit.expand, children: [

            // İçerik
            if (type == 'image')
              Image.network(content, fit: BoxFit.cover,
                loadingBuilder: (c, child, p) => p == null ? child
                    : Container(color: Colors.black, child: Center(
                        child: CircularProgressIndicator(color: ColorsManager.darkPrimary,
                            value: p.expectedTotalBytes != null ? p.cumulativeBytesLoaded / p.expectedTotalBytes! : null))),
                errorBuilder: (c, e, s) => Container(color: const Color(0xFF111111),
                    child: const Center(child: Icon(Icons.broken_image, color: Colors.white38, size: 64))),
              )
            else
              Container(
                decoration: BoxDecoration(gradient: LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [const Color(0xFF0D0D0D), ColorsManager.darkPrimary.withOpacity(0.3)])),
                child: Center(child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 80),
                  child: Text(content, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w600, height: 1.5), textAlign: TextAlign.center),
                )),
              ),

            // Üst gradient
            Positioned(top: 0, left: 0, right: 0, height: 120,
              child: Container(decoration: const BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.black87, Colors.transparent])))),

            // Alt not bar - reply varsa üstünde göster
            if (note.isNotEmpty)
              Positioned(
                bottom: widget.isOwner ? (pad.bottom + 16) : 80,
                left: 16, right: 16,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Text(note, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4)),
                ),
              ),

            // Progress barlar
            Positioned(top: pad.top + 8, left: 8, right: 8,
              child: Row(children: List.generate(_localStatuses.length, (i) =>
                Expanded(child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: ClipRRect(borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: i < _current ? 1.0 : (i == _current ? _ctrl.value : 0.0),
                      backgroundColor: Colors.white30, color: Colors.white, minHeight: 3)),
                )),
              )),
            ),

            // Profil
            Positioned(top: pad.top + 18, left: 16, right: 60,
              child: Row(children: [
                CircleAvatar(radius: 20,
                    backgroundImage: widget.photo.isNotEmpty ? NetworkImage(widget.photo) : null,
                    backgroundColor: Colors.white24,
                    child: widget.photo.isEmpty ? const Icon(Icons.person, color: Colors.white38) : null),
                const SizedBox(width: 10),
                Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text(widget.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                  Text(() {
                    final ts = (data['createdAt'] as Timestamp?)?.toDate();
                    if (ts == null) return '';
                    final diff = DateTime.now().difference(ts);
                    if (diff.inMinutes < 60) return '${diff.inMinutes} dk önce';
                    return '${diff.inHours} saat önce';
                  }(), style: const TextStyle(color: Colors.white60, fontSize: 11)),
                ]),
              ]),
            ),

            // Kapat + Sil
            Positioned(top: pad.top + 8, right: 4,
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                if (widget.isOwner)
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    onPressed: () async {
                      final doc = _localStatuses[_current];
                      await FirebaseFirestore.instance.collection('statuses').doc(doc.id).delete();
                      if (mounted) setState(() {
                        _localStatuses.removeAt(_current);
                        if (_localStatuses.isEmpty) { if (mounted) Navigator.pop(context); return; }
                        if (_current >= _localStatuses.length) _current = _localStatuses.length - 1;
                        _ctrl.reset(); _ctrl.forward();
                      });
                    },
                  ),
                IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Navigator.pop(context)),
              ])),

            // Görüntüleyenler (sadece kendi durumunda)
            if (widget.isOwner)
              Positioned(bottom: 0, left: 0, right: 0,
                child: GestureDetector(
                  onTap: () {
                    final docId = _localStatuses[_current].id;
                    showModalBottomSheet(
                      context: context,
                      backgroundColor: const Color(0xFF1A1A1A),
                      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
                      builder: (_) => StreamBuilder<DocumentSnapshot>(
                        stream: FirebaseFirestore.instance.collection('statuses').doc(docId).snapshots(),
                        builder: (_, snap) {
                          final viewers = List<String>.from(
                            (snap.data?.data() as Map?)?['viewedBy'] ?? []);
                          return Column(mainAxisSize: MainAxisSize.min, children: [
                            const SizedBox(height: 12),
                            Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
                            const SizedBox(height: 16),
                            Text('Görüntüleyenler (${viewers.length})', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                            const SizedBox(height: 8),
                            viewers.isEmpty
                              ? const Padding(padding: EdgeInsets.all(32), child: Text('Henüz kimse görüntülemedi', style: TextStyle(color: Colors.white38)))
                              : SizedBox(height: 250, child: ListView.builder(
                                  itemCount: viewers.length,
                                  itemBuilder: (_, i) => FutureBuilder<DocumentSnapshot>(
                                    future: FirebaseFirestore.instance.collection('users').doc(viewers[i]).get(),
                                    builder: (_, uSnap) {
                                      final d = uSnap.data?.data() as Map<String, dynamic>?;
                                      final photo = d?['profilePic'] ?? '';
                                      return ListTile(
                                        leading: CircleAvatar(
                                          backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                                          child: photo.isEmpty ? const Icon(Icons.person) : null),
                                        title: Text(d?['name'] ?? viewers[i], style: const TextStyle(color: Colors.white)),
                                      );
                                    },
                                  ),
                                )),
                            const SizedBox(height: 20),
                          ]);
                        },
                      ),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                    decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black87, Colors.transparent])),
                    child: Row(children: [
                      const Icon(Icons.remove_red_eye_outlined, color: Colors.white70, size: 18),
                      const SizedBox(width: 8),
                      StreamBuilder<DocumentSnapshot>(
                        stream: FirebaseFirestore.instance.collection('statuses').doc(_localStatuses[_current].id).snapshots(),
                        builder: (_, snap) {
                          final vCount = ((snap.data?.data() as Map?)?['viewedBy'] as List? ?? []).length;
                          return Text('$vCount görüntüledi', style: const TextStyle(color: Colors.white70, fontSize: 13));
                        },
                      ),
                    ]),
                  ),
                )),

            // Hikaye yanıtlama (kendi durumu değilse)
            if (!widget.isOwner)
              Positioned(bottom: 0, left: 0, right: 0,
                child: Container(
                  padding: EdgeInsets.fromLTRB(12, 8, 12, MediaQuery.of(context).padding.bottom + 8),
                  decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black87, Colors.transparent])),
                  child: Row(children: [
                    Expanded(
                      child: TextField(
                        controller: _replyCtrl,
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        decoration: InputDecoration(
                          hintText: '${widget.name} durumuna yanıtla...',
                          hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                          filled: true,
                          fillColor: Colors.white12,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: _sendReply,
                      child: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(color: ColorsManager.darkPrimary, shape: BoxShape.circle),
                        child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                      ),
                    ),
                  ]),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}

// ── Ana UpdatesTab: Durum + Kanallar ──────────────────────────────────────────
class UpdatesTab extends StatefulWidget {
  const UpdatesTab({super.key});
  @override State<UpdatesTab> createState() => _UpdatesTabState();
}

class _UpdatesTabState extends State<UpdatesTab> with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF0D0D0D),
      child: Column(
      children: [
        Container(
          color: const Color(0xFF111111),
          child: TabBar(
            controller: _tab,
            indicatorColor: ColorsManager.darkPrimary,
            labelColor: ColorsManager.darkPrimary,
            unselectedLabelColor: Colors.white38,
            labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            dividerColor: Colors.transparent,
            dividerHeight: 0,
            indicator: UnderlineTabIndicator(
              borderSide: BorderSide(color: ColorsManager.darkPrimary, width: 2),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
            ),
            tabs: const [
              Tab(text: 'Durum'),
              Tab(text: 'Kanallar'),
            ],
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tab,
            children: const [
              _StatusesContent(),
              _ChannelsContent(),
            ],
          ),
        ),
      ],
      ),
    );
  }
}

// ── Kanallar İçerik Widget ─────────────────────────────────────────────────
class _ChannelsContent extends StatelessWidget {
  const _ChannelsContent();
  @override
  Widget build(BuildContext context) => const ChannelsScreen(isEmbedded: true);
}

// ── Tam Ekran Profil Fotoğrafı (Updates) ─────────────────────────────────────
class _FullPhotoViewPage extends StatelessWidget {
  final String url;
  const _FullPhotoViewPage({required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D0D),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Center(
          child: InteractiveViewer(
            minScale: 0.5, maxScale: 4.0,
            child: CachedNetworkImage(
              imageUrl: url, fit: BoxFit.contain,
              placeholder: (_, __) => const CircularProgressIndicator(color: Colors.white),
              errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white38, size: 80),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Video Status Player ────────────────────────────────────────────────────
class _VideoStatusPlayer extends StatefulWidget {
  final String url;
  const _VideoStatusPlayer({required this.url});
  @override State<_VideoStatusPlayer> createState() => _VideoStatusPlayerState();
}
class _VideoStatusPlayerState extends State<_VideoStatusPlayer> {
  late VideoPlayerController _ctrl;
  bool _initialized = false;
  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (mounted) { setState(() => _initialized = true); _ctrl.play(); _ctrl.setLooping(true); }
      });
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => _initialized
    ? AspectRatio(aspectRatio: _ctrl.value.aspectRatio, child: VideoPlayer(_ctrl))
    : const Center(child: CircularProgressIndicator(color: Colors.white));
}
