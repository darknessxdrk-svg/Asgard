import 'dart:io';
import '../channels/ui/channels_screen.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';

import '../../services/cloudinary_service.dart';
import '../chat/ui/image_editor_screen.dart';
import '../../themes/colors.dart';

class _StatusesContent extends StatefulWidget {
  const _StatusesContent();
  @override State<_StatusesContent> createState() => _StatusesContentState();
}

class _StatusesContentState extends State<_StatusesContent> {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  bool _uploading = false;

  String? get _uid => _auth.currentUser?.uid;

  // 24 saat filtresi
  bool _isAlive(Timestamp? ts) {
    if (ts == null) return false;
    return ts.toDate().isAfter(DateTime.now().subtract(const Duration(hours: 24)));
  }

  Future<void> _postStatus(String content, String type, {String note = ''}) async {
    final uid = _uid;
    if (uid == null) return;
    final userData = (await _db.collection('users').doc(uid).get()).data() ?? {};
    await _db.collection('statuses').add({
      'uid': uid,
      'userName': userData['name'] ?? '',
      'userPhoto': userData['profilePic'] ?? '',
      'content': content,
      'type': type,
      'note': note,
      'createdAt': Timestamp.now(),
      'expiresAt': Timestamp.fromDate(DateTime.now().add(const Duration(hours: 24))),
      'viewedBy': [],
    });
  }

  Future<void> _pickAndPost(ImageSource src) async {
    final picked = await ImagePicker().pickImage(source: src, imageQuality: 80);
    if (picked == null) return;
    if (!mounted) return;
    // Fotoğrafı editöre gönder
    final editedFile = await ImageEditorScreen.editFile(context, File(picked.path));
    if (editedFile == null) return; // kullanıcı iptal etti
    final File pickedFile = editedFile;
    // Not dialog
    String note = '';
    if (mounted) {
      final ctrl = TextEditingController();
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: const Text('Not Ekle', style: TextStyle(color: Colors.white, fontSize: 16)),
          content: TextField(
            controller: ctrl,
            style: const TextStyle(color: Colors.white),
            maxLength: 100,
            decoration: InputDecoration(
              hintText: 'Bir şeyler yaz...',
              hintStyle: const TextStyle(color: Colors.white38),
              counterStyle: const TextStyle(color: Colors.white24),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.3)),
                  borderRadius: BorderRadius.circular(10)),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ColorsManager.darkPrimary),
                  borderRadius: BorderRadius.circular(10)),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx),
                child: const Text('Atla', style: TextStyle(color: Colors.white38))),
            TextButton(
                onPressed: () { note = ctrl.text.trim(); Navigator.pop(ctx); },
                child: Text('Tamam', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold))),
          ],
        ),
      );
    }
    if (!mounted) return;
    setState(() => _uploading = true);
    final url = await CloudinaryService.uploadImage(picked.path);
    if (url != null) await _postStatus(url, 'image', note: note);
    if (mounted) setState(() => _uploading = false);
  }

  void _showAddStatus() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        ListTile(leading: Icon(Icons.text_fields, color: ColorsManager.darkPrimary),
            title: const Text('Metin Durumu', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _showTextStatus(); }),
        ListTile(leading: Icon(Icons.photo, color: ColorsManager.darkPrimary),
            title: const Text('Fotoğraf', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _pickAndPost(ImageSource.gallery); }),
        ListTile(leading: Icon(Icons.camera_alt, color: ColorsManager.darkPrimary),
            title: const Text('Kamera', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _pickAndPost(ImageSource.camera); }),
        Gap(8.h),
      ])),
    );
  }

  void _showTextStatus() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Metin Durumu', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: ctrl, autofocus: true, maxLines: 4, maxLength: 200,
          style: const TextStyle(color: Colors.white, fontSize: 18),
          decoration: const InputDecoration(
            hintText: 'Ne düşünüyorsun?',
            hintStyle: TextStyle(color: Colors.white24),
            border: InputBorder.none,
            counterStyle: TextStyle(color: Colors.white24),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
              onPressed: () async {
                if (ctrl.text.trim().isEmpty) return;
                Navigator.pop(ctx);
                await _postStatus(ctrl.text.trim(), 'text');
              },
              child: Text('Paylaş', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      floatingActionButton: _uploading
          ? FloatingActionButton(backgroundColor: ColorsManager.darkPrimary,
              onPressed: null, child: const CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
          : FloatingActionButton(backgroundColor: ColorsManager.darkPrimary,
              onPressed: _showAddStatus, child: const Icon(Icons.add, color: Colors.white)),
      body: StreamBuilder<QuerySnapshot>(
        // Sadece kişi listesindeki kişilerin durumları
        stream: _uid != null
            ? _db.collection('users').doc(_uid).collection('contacts').snapshots()
            : const Stream.empty(),
        builder: (ctx, contactSnap) {
          final contactUIDs = (contactSnap.data?.docs ?? []).map((d) => d.id).toSet();

          return StreamBuilder<QuerySnapshot>(
            stream: _db.collection('statuses').snapshots(),
            builder: (ctx2, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));

          // Sadece kişiler + kendim
          final all = snap.data!.docs.where((d) {
            final data = d.data() as Map<String, dynamic>;
            final statusUID = data['uid'] as String? ?? '';
            return _isAlive(data['createdAt'] as Timestamp?) &&
                (statusUID == _uid || contactUIDs.contains(statusUID));
          }).toList();

          final Map<String, List<QueryDocumentSnapshot>> grouped = {};
          for (final doc in all) {
            final data = doc.data() as Map<String, dynamic>;
            final uid = data['uid'] as String? ?? '';
            grouped.putIfAbsent(uid, () => []).add(doc);
          }

          final myStatuses = grouped[_uid] ?? [];
          final othersMap = Map<String, List<QueryDocumentSnapshot>>.from(grouped)
            ..remove(_uid);

          return ListView(padding: EdgeInsets.only(top: 12.h), children: [

            // ── Benim Durum ───────────────────────────────────────────────
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Benim Durum', style: TextStyle(color: Colors.white38, fontSize: 12.sp, fontWeight: FontWeight.w600)),
                Gap(8.h),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: GestureDetector(
                    onTap: _showAddStatus,
                    child: Stack(children: [
                      Container(width: 54.w, height: 54.h,
                        decoration: BoxDecoration(shape: BoxShape.circle,
                            border: Border.all(
                                color: myStatuses.isEmpty ? Colors.white24 : ColorsManager.darkPrimary,
                                width: 2)),
                        child: ClipOval(child: _MyAvatar())),
                      Positioned(bottom: 0, right: 0,
                        child: Container(width: 20, height: 20,
                          decoration: BoxDecoration(
                              color: ColorsManager.darkPrimary, shape: BoxShape.circle,
                              border: Border.all(color: const Color(0xFF0D0D0D), width: 2)),
                          child: const Icon(Icons.add, size: 12, color: Colors.white))),
                    ]),
                  ),
                  title: const Text('Durumumu Ekle', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: myStatuses.isEmpty
                      ? const Text('Durum paylaşmak için dokun', style: TextStyle(color: Colors.white38, fontSize: 12))
                      : Text('${myStatuses.length} durum paylaşıldı', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12)),
                  onTap: myStatuses.isEmpty ? _showAddStatus : () => _openViewer(myStatuses),
                ),
              ]),
            ),

            if (othersMap.isNotEmpty) ...[
              Padding(padding: EdgeInsets.fromLTRB(16.w, 16.h, 16.w, 6.h),
                  child: Text('Son Güncellemeler', style: TextStyle(color: Colors.white38, fontSize: 12.sp, fontWeight: FontWeight.w600))),
              ...othersMap.entries.map((e) => _StatusTile(
                uid: e.key,
                statuses: e.value,
                viewerUID: _uid ?? '',
                onTap: () => _openViewer(e.value, uid: e.key),
              )),
            ],

            if (myStatuses.isEmpty && othersMap.isEmpty)
              Center(child: Padding(
                padding: EdgeInsets.only(top: 80.h),
                child: Column(children: [
                  Icon(Icons.circle_outlined, size: 64.sp, color: Colors.white12),
                  Gap(16.h),
                  const Text('Henüz durum yok', style: TextStyle(color: Colors.white38, fontSize: 16)),
                  Gap(8.h),
                  const Text('+ butonuna basarak durum paylaş', style: TextStyle(color: Colors.white24, fontSize: 13)),
                ]),
              )),

            Gap(80.h),
          ]);
            }, // inner StreamBuilder
          );
        }, // outer StreamBuilder
      ),
    );
  }

  Future<void> _openViewer(List<QueryDocumentSnapshot> statuses, {String? uid}) async {
    if (statuses.isEmpty) return;
    final data = statuses.first.data() as Map<String, dynamic>;
    String name = data['userName'] ?? '';
    String photo = data['userPhoto'] ?? '';
    // Firestore'dan güncel bilgi al
    final statusUid = uid ?? data['uid'] ?? _uid ?? '';
    if (statusUid.isNotEmpty) {
      try {
        final userDoc = await FirebaseFirestore.instance.collection('users').doc(statusUid).get();
        final userData = userDoc.data();
        if (userData != null) {
          name = userData['name'] ?? name;
          photo = userData['profilePic'] ?? photo;
        }
      } catch (_) {}
    }
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => _StatusViewPage(
      statuses: statuses,
      name: name.isEmpty ? 'Kullanıcı' : name,
      photo: photo,
      viewerUID: _uid ?? '',
    )));
  }
}

// ── Kendi avatar widget ───────────────────────────────────────────────────────
class _MyAvatar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return Container(color: Colors.white12, child: const Icon(Icons.person, color: Colors.white38));
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (_, snap) {
        final photo = (snap.data?.data() as Map?)?.get('profilePic') ?? '';
        if (photo.isEmpty) return Container(color: const Color(0xFF1A1A1A), child: const Icon(Icons.person, color: Colors.white38));
        return CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
            errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white38));
      },
    );
  }
}

extension _MapGet on Map {
  dynamic get(String key) => this[key];
}

// ── Başkasının durum tile'ı ───────────────────────────────────────────────────
class _StatusTile extends StatelessWidget {
  final String uid;
  final List<QueryDocumentSnapshot> statuses;
  final String viewerUID;
  final VoidCallback onTap;
  const _StatusTile({required this.uid, required this.statuses, required this.viewerUID, required this.onTap});

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'az önce';
    if (diff.inMinutes < 60) return '${diff.inMinutes} dk önce';
    return '${diff.inHours} saat önce';
  }

  @override
  Widget build(BuildContext context) {
    final allViewed = statuses.every((s) => ((s.data() as Map)['viewedBy'] as List? ?? []).contains(viewerUID));
    final ts = (statuses.first.data() as Map)['createdAt'] as Timestamp?;
    final timeStr = ts != null ? _timeAgo(ts.toDate()) : '';

    // Her zaman Firestore'dan güncel kullanıcı bilgisi çek
    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance.collection('users').doc(uid).get(),
      builder: (ctx, snap) {
        final userData = snap.data?.data() as Map<String, dynamic>?;
        final name = userData?['name'] ?? (statuses.first.data() as Map)['userName'] ?? 'Kullanıcı';
        final photo = userData?['profilePic'] ?? (statuses.first.data() as Map)['userPhoto'] ?? '';

        return ListTile(
          contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 4.h),
          leading: GestureDetector(
            onTap: photo.isNotEmpty ? () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => _FullPhotoViewPage(url: photo))) : null,
            child: Container(
              width: 54.w, height: 54.h,
              decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: allViewed ? Colors.white24 : ColorsManager.darkPrimary, width: 2.5)),
              child: ClipOval(child: photo.isNotEmpty
                  ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                      errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white38))
                  : Container(color: const Color(0xFF1A1A1A), child: const Icon(Icons.person, color: Colors.white38))),
            ),
          ),
          title: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          subtitle: Text(timeStr, style: const TextStyle(color: Colors.white38, fontSize: 12)),
          onTap: onTap,
        );
      },
    );
  }
}

// ── Status Viewer ─────────────────────────────────────────────────────────────
class _StatusViewPage extends StatefulWidget {
  final List<QueryDocumentSnapshot> statuses;
  final String name, photo, viewerUID;
  const _StatusViewPage({required this.statuses, required this.name, required this.photo, required this.viewerUID});
  @override State<_StatusViewPage> createState() => _StatusViewPageState();
}

class _StatusViewPageState extends State<_StatusViewPage> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  int _current = 0;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 6));
    _ctrl.addStatusListener((s) { if (s == AnimationStatus.completed) _next(); });
    _ctrl.forward();
    _markViewed();
  }

  void _next() {
    if (_current < widget.statuses.length - 1) { setState(() => _current++); _ctrl.reset(); _ctrl.forward(); }
    else Navigator.pop(context);
  }
  void _prev() {
    if (_current > 0) { setState(() => _current--); _ctrl.reset(); _ctrl.forward(); }
    else { _ctrl.reset(); _ctrl.forward(); }
  }

  Future<void> _markViewed() async {
    for (final s in widget.statuses) {
      await s.reference.update({'viewedBy': FieldValue.arrayUnion([widget.viewerUID])});
    }
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final data = widget.statuses[_current].data() as Map<String, dynamic>;
    final type = data['type'] ?? 'text';
    final content = data['content'] ?? '';
    final note = (data['note'] ?? '').toString();
    final pad = MediaQuery.of(context).padding;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onLongPressStart: (_) => _ctrl.stop(),
        onLongPressEnd: (_) => _ctrl.forward(),
        onTapUp: (d) {
          final x = d.globalPosition.dx;
          final w = MediaQuery.of(context).size.width;
          if (x < w / 3) _prev(); else _next();
        },
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Stack(fit: StackFit.expand, children: [

            // İçerik
            if (type == 'image')
              Image.network(content, fit: BoxFit.contain,
                loadingBuilder: (c, child, p) => p == null ? child
                    : Container(color: Colors.black, child: Center(
                        child: CircularProgressIndicator(color: ColorsManager.darkPrimary,
                            value: p.expectedTotalBytes != null ? p.cumulativeBytesLoaded / p.expectedTotalBytes! : null))),
                errorBuilder: (c, e, s) => Container(color: const Color(0xFF111111),
                    child: const Center(child: Icon(Icons.broken_image, color: Colors.white38, size: 64))),
              )
            else
              Container(
                decoration: BoxDecoration(gradient: LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [const Color(0xFF0D0D0D), ColorsManager.darkPrimary.withOpacity(0.3)])),
                child: Center(child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 80),
                  child: Text(content, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w600, height: 1.5), textAlign: TextAlign.center),
                )),
              ),

            // Üst gradient
            Positioned(top: 0, left: 0, right: 0, height: 120,
              child: Container(decoration: const BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.black87, Colors.transparent])))),

            // Alt not bar
            Positioned(bottom: 0, left: 0, right: 0,
              child: Container(
                padding: EdgeInsets.fromLTRB(20, 28, 20, pad.bottom + 20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter,
                      colors: [Colors.black87, Colors.transparent])),
                child: note.isNotEmpty ? Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Text(note, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4)),
                ) : const SizedBox.shrink(),
              ),
            ),

            // Progress barlar
            Positioned(top: pad.top + 8, left: 8, right: 8,
              child: Row(children: List.generate(widget.statuses.length, (i) =>
                Expanded(child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: ClipRRect(borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: i < _current ? 1.0 : (i == _current ? _ctrl.value : 0.0),
                      backgroundColor: Colors.white30, color: Colors.white, minHeight: 3)),
                )),
              )),
            ),

            // Profil
            Positioned(top: pad.top + 18, left: 16, right: 60,
              child: Row(children: [
                CircleAvatar(radius: 20,
                    backgroundImage: widget.photo.isNotEmpty ? NetworkImage(widget.photo) : null,
                    backgroundColor: Colors.white24,
                    child: widget.photo.isEmpty ? const Icon(Icons.person, color: Colors.white38) : null),
                const SizedBox(width: 10),
                Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text(widget.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                  Text(() {
                    final ts = (data['createdAt'] as Timestamp?)?.toDate();
                    if (ts == null) return '';
                    final diff = DateTime.now().difference(ts);
                    if (diff.inMinutes < 60) return '${diff.inMinutes} dk önce';
                    return '${diff.inHours} saat önce';
                  }(), style: const TextStyle(color: Colors.white60, fontSize: 11)),
                ]),
              ]),
            ),

            // Kapat
            Positioned(top: pad.top + 8, right: 4,
              child: IconButton(
                  icon: const Icon(Icons.close, color: Colors.white),
                  onPressed: () => Navigator.pop(context))),
          ]),
        ),
      ),
    );
  }
}

// ── Ana UpdatesTab: Durum + Kanallar ──────────────────────────────────────────
class UpdatesTab extends StatefulWidget {
  const UpdatesTab({super.key});
  @override State<UpdatesTab> createState() => _UpdatesTabState();
}

class _UpdatesTabState extends State<UpdatesTab> with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF0D0D0D),
      child: Column(
      children: [
        Container(
          color: const Color(0xFF111111),
          child: TabBar(
            controller: _tab,
            indicatorColor: ColorsManager.darkPrimary,
            labelColor: ColorsManager.darkPrimary,
            unselectedLabelColor: Colors.white38,
            labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            dividerColor: Colors.transparent,
            dividerHeight: 0,
            indicator: UnderlineTabIndicator(
              borderSide: BorderSide(color: ColorsManager.darkPrimary, width: 2),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
            ),
            tabs: const [
              Tab(text: 'Durum'),
              Tab(text: 'Kanallar'),
            ],
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tab,
            children: const [
              _StatusesContent(),
              _ChannelsContent(),
            ],
          ),
        ),
      ],
      ),
    );
  }
}

// ── Kanallar İçerik Widget ─────────────────────────────────────────────────
class _ChannelsContent extends StatelessWidget {
  const _ChannelsContent();
  @override
  Widget build(BuildContext context) => const ChannelsScreen(isEmbedded: true);
}

// ── Tam Ekran Profil Fotoğrafı (Updates) ─────────────────────────────────────
class _FullPhotoViewPage extends StatelessWidget {
  final String url;
  const _FullPhotoViewPage({required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D0D),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Center(
          child: InteractiveViewer(
            minScale: 0.5, maxScale: 4.0,
            child: CachedNetworkImage(
              imageUrl: url, fit: BoxFit.contain,
              placeholder: (_, __) => const CircularProgressIndicator(color: Colors.white),
              errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white38, size: 80),
            ),
          ),
        ),
      ),
    );
  }
}
