import '../../core/utils/string_ext.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

import '../../helpers/extensions.dart';
import '../../router/routes.dart';
import '../../services/database.dart';
import '../../themes/colors.dart';
import '../chat/ui/group_chat_page.dart';

class ChatsTab extends StatefulWidget {
  const ChatsTab({super.key});
  @override State<ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<ChatsTab> {
  late final Stream<QuerySnapshot> _contactsStream;
  late final Stream<QuerySnapshot> _groupsStream;

  @override
  void initState() {
    super.initState();
    _contactsStream = DatabaseMethods.getContacts();
    _groupsStream = DatabaseMethods.getUserGroups();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: StreamBuilder<QuerySnapshot>(
        stream: _contactsStream,
        builder: (context, contactSnapshot) {
          return StreamBuilder<QuerySnapshot>(
            stream: _groupsStream,
            builder: (context, groupSnapshot) {
              if (contactSnapshot.connectionState == ConnectionState.waiting ||
                  groupSnapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(color: ColorsManager.darkPrimary),
                );
              }

              final contacts = contactSnapshot.data?.docs ?? [];
              final groups = (groupSnapshot.data?.docs ?? [])
                ..sort((a, b) {
                  final aT = ((a.data() as Map)['lastMessageTime'] as Timestamp?)
                          ?.millisecondsSinceEpoch ?? 0;
                  final bT = ((b.data() as Map)['lastMessageTime'] as Timestamp?)
                          ?.millisecondsSinceEpoch ?? 0;
                  return bT.compareTo(aT);
                });

              if (contacts.isEmpty && groups.isEmpty) {
                return Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF1A1A1A),
                        border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.2)),
                      ),
                      child: Icon(Icons.people_outline, size: 48.sp, color: Colors.white24),
                    ),
                    Gap(20.h),
                    const Text('Henüz kişi yok',
                        style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                    Gap(8.h),
                    const Text('Kişi eklemek için sağ üstteki\nmenüyü kullanın',
                        style: TextStyle(color: Colors.white38, fontSize: 14),
                        textAlign: TextAlign.center),
                  ]),
                );
              }

              final List<Widget> items = [];

              if (groups.isNotEmpty) {
                items.add(_sectionHeader('Gruplar'));
                for (final g in groups) {
                  final data = g.data() as Map<String, dynamic>;
                  items.add(_GroupTile(groupId: g.id, data: data));
                }
                items.add(const Divider(height: 1, color: Colors.white10));
              }

              if (contacts.isNotEmpty) {
                if (groups.isNotEmpty) items.add(_sectionHeader('Sohbetler'));
                for (final doc in contacts) {
                  final uid = (doc.data() as Map<String, dynamic>?)?['uid'] as String? ?? doc.id;
                  items.add(_ContactTile(key: ValueKey(uid), contactUid: uid));
                }
              }

              return ListView(
                children: items,
              );
            },
          );
        },
      ),
    );
  }

  Widget _sectionHeader(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
    child: Text(title,
        style: const TextStyle(color: Colors.white38, fontSize: 12, fontWeight: FontWeight.w600)),
  );
}

// ── Grup Tile ────────────────────────────────────────────────────────────────
class _GroupTile extends StatelessWidget {
  final String groupId;
  final Map<String, dynamic> data;
  const _GroupTile({required this.groupId, required this.data});

  @override
  Widget build(BuildContext context) {
    final memberCount = (data['members'] as List?)?.length ?? 0;
    final photo = (data['photo'] as String?) ?? '';
    return ListTile(
      tileColor: const Color(0xFF0D0D0D),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        width: 50, height: 50,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: ColorsManager.darkPrimary.withOpacity(0.15),
          border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.4)),
        ),
        child: ClipOval(
          child: photo.isNotEmpty
              ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                  errorWidget: (_, __, ___) =>
                      const Icon(Icons.group, color: ColorsManager.darkPrimary, size: 24))
              : const Icon(Icons.group, color: ColorsManager.darkPrimary, size: 24),
        ),
      ),
      title: Text(data['name'] ?? '',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15)),
      subtitle: Text(
        (data['lastMessage'] as String?)?.isNotEmpty == true
            ? data['lastMessage']
            : '$memberCount üye',
        style: const TextStyle(color: Colors.white38, fontSize: 12),
        maxLines: 1, overflow: TextOverflow.ellipsis,
      ),
      trailing: const Icon(Icons.chevron_right, color: Colors.white24, size: 20),
      onTap: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => GroupChatPage(groupId: groupId, groupName: data['name'] ?? ''))),
    );
  }
}

// ── Contact Tile ─────────────────────────────────────────────────────────────
class _ContactTile extends StatefulWidget {
  final String contactUid;
  const _ContactTile({required this.contactUid, super.key});
  @override State<_ContactTile> createState() => _ContactTileState();
}

class _ContactTileState extends State<_ContactTile> {
  Map<String, dynamic>? _data;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.contactUid)
          .get();
      if (mounted) {
        setState(() {
          _data = doc.data();
          _loaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Container(
        height: 72,
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: const Color(0xFF111111),
          borderRadius: BorderRadius.circular(14),
        ),
      );
    }

    final data = _data;
    if (data == null) {
      return ListTile(
        tileColor: const Color(0xFF0D0D0D),
        leading: const CircleAvatar(
          backgroundColor: Color(0xFF1A1A1A),
          child: Icon(Icons.person, color: Colors.white38),
        ),
        title: const Text('Kullanıcı', style: TextStyle(color: Colors.white)),
        onTap: () => context.pushNamed(Routes.chatScreen,
            arguments: {'uid': widget.contactUid, 'name': 'Kullanıcı'}),
      );
    }

    final isOnline = data['isOnline']?.toString() == 'true';
    final photo = data['profilePic'] as String? ?? '';
    final name = data['name'] as String? ?? '';
    final username = data['username'] as String? ?? '';

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF1E1E1E)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: Stack(clipBehavior: Clip.none, children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: isOnline
                    ? ColorsManager.darkPrimary.withOpacity(0.8)
                    : const Color(0xFF2A2A2A),
                width: 2,
              ),
            ),
            child: ClipOval(
              child: photo.isNotEmpty
                  ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                      errorWidget: (_, __, ___) =>
                          const Icon(Icons.person, color: Colors.white38))
                  : Image.asset('assets/images/user.png', fit: BoxFit.cover),
            ),
          ),
          if (isOnline)
            Positioned(
              bottom: 0, right: 0,
              child: Container(
                width: 12, height: 12,
                decoration: BoxDecoration(
                  color: ColorsManager.darkPrimary,
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFF111111), width: 2),
                ),
              ),
            ),
        ]),
        title: Text(name,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15),
            overflow: TextOverflow.ellipsis),
        subtitle: Text(
          isOnline ? context.tr('online') : context.tr('offline'),
          style: TextStyle(
            color: isOnline ? ColorsManager.darkPrimary.withOpacity(0.7) : Colors.white24,
            fontSize: 12,
          ),
        ),
        trailing: username.isNotEmpty
            ? Text('@${capFirst(username)}',
                style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12))
            : const Icon(Icons.chevron_right, color: Colors.white24, size: 20),
        onTap: () => context.pushNamed(Routes.chatScreen, arguments: data),
        onLongPress: () => _showActions(context, data),
      ),
    );
  }

  void _showActions(BuildContext context, Map<String, dynamic> data) {
    final uid = widget.contactUid;
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 40, height: 4,
            margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
                color: Colors.white24, borderRadius: BorderRadius.circular(2)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Row(children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: const Color(0xFF2A2A2A),
                backgroundImage: (data['profilePic'] ?? '').isNotEmpty
                    ? NetworkImage(data['profilePic']) : null,
                child: (data['profilePic'] ?? '').isEmpty
                    ? const Icon(Icons.person, color: Colors.white38) : null,
              ),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(data['name'] ?? '',
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                Text('@${(data['username'] ?? capFirst(''))}',
                    style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 13)),
              ]),
            ]),
          ),
          const Divider(color: Colors.white10),
          ListTile(
            leading: const Icon(Icons.delete_outline_rounded, color: Colors.red),
            title: const Text('Sohbeti Sil', style: TextStyle(color: Colors.white)),
            onTap: () {
              Navigator.pop(context);
              _confirmDelete(context, data, uid);
            },
          ),
          ListTile(
            leading: const Icon(Icons.person_remove_outlined, color: Colors.red),
            title: const Text('Kişiyi Kaldır', style: TextStyle(color: Colors.white)),
            onTap: () async {
              Navigator.pop(context);
              await DatabaseMethods.removeContact(uid);
            },
          ),
          ListTile(
            leading: const Icon(Icons.block_rounded, color: Colors.red),
            title: const Text('Engelle', style: TextStyle(color: Colors.white)),
            onTap: () async {
              Navigator.pop(context);
              final myUid = FirebaseAuth.instance.currentUser?.uid;
              if (myUid != null) {
                await FirebaseFirestore.instance
                    .collection('users').doc(myUid)
                    .collection('blocked').doc(uid)
                    .set({'blockedAt': FieldValue.serverTimestamp()});
              }
            },
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  void _confirmDelete(BuildContext context, Map<String, dynamic> data, String uid) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Sohbeti Sil', style: TextStyle(color: Colors.white)),
        content: Text('${data['name']} ile tüm mesajlar silinecek. Emin misiniz?',
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final myUid = FirebaseAuth.instance.currentUser?.uid;
              if (myUid == null) return;
              final chatRoomId = ([myUid, uid]..sort()).join('_');
              final msgs = await FirebaseFirestore.instance
                  .collection('chats').doc(chatRoomId).collection('messages').get();
              final batch = FirebaseFirestore.instance.batch();
              for (final doc in msgs.docs) batch.delete(doc.reference);
              await batch.commit();
            },
            child: const Text('Sil',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

// ── Tam Ekran Fotoğraf ───────────────────────────────────────────────────────
class _FullPhotoPage extends StatelessWidget {
  final String url;
  const _FullPhotoPage({required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Center(
          child: InteractiveViewer(
            minScale: 0.5, maxScale: 4.0,
            child: CachedNetworkImage(
              imageUrl: url, fit: BoxFit.contain,
              placeholder: (_, __) =>
                  const CircularProgressIndicator(color: Colors.white),
              errorWidget: (_, __, ___) =>
                  const Icon(Icons.person, color: Colors.white38, size: 80),
            ),
          ),
        ),
      ),
    );
  }
}
