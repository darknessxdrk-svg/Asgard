import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

import '../../helpers/extensions.dart';
import '../../router/routes.dart';
import '../../services/database.dart';
import '../../themes/colors.dart';
import '../chat/ui/group_chat_page.dart';

class ChatsTab extends StatefulWidget {
  const ChatsTab({super.key});
  @override State<ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<ChatsTab> {
  late final Stream<QuerySnapshot> _contactsStream;
  late final Stream<QuerySnapshot> _groupsStream;

  @override
  void initState() {
    super.initState();
    _contactsStream = DatabaseMethods.getContacts();
    _groupsStream = DatabaseMethods.getUserGroups();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _contactsStream,
      builder: (context, contactSnapshot) {
        return StreamBuilder<QuerySnapshot>(
          stream: _groupsStream,
          builder: (context, groupSnapshot) {
            final contacts = contactSnapshot.data?.docs ?? [];
            final groups = (groupSnapshot.data?.docs ?? [])
              ..sort((a, b) {
                final aT = ((a.data() as Map)['lastMessageTime'] as Timestamp?)?.millisecondsSinceEpoch ?? 0;
                final bT = ((b.data() as Map)['lastMessageTime'] as Timestamp?)?.millisecondsSinceEpoch ?? 0;
                return bT.compareTo(aT);
              });

            final isLoading = contactSnapshot.connectionState == ConnectionState.waiting &&
                groupSnapshot.connectionState == ConnectionState.waiting;

            if (isLoading) {
              return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
            }

            if (contacts.isEmpty && groups.isEmpty) {
              return Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF1A1A1A),
                      border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.2)),
                    ),
                    child: Icon(Icons.people_outline, size: 48.sp, color: Colors.white24),
                  ),
                  Gap(20.h),
                  const Text('Henüz kişi yok',
                      style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  Gap(8.h),
                  const Text('Kişi eklemek için sağ üstteki\nmenüyü kullanın',
                      style: TextStyle(color: Colors.white38, fontSize: 14), textAlign: TextAlign.center),
                ]),
              );
            }

            return ListView(
              children: [
                if (groups.isNotEmpty) ...[
                  _sectionHeader('Gruplar'),
                  ...groups.map((g) {
                    final data = g.data() as Map<String, dynamic>;
                    return _GroupTile(groupId: g.id, data: data);
                  }),
                  const Divider(height: 1, color: Colors.white10),
                ],
                if (contacts.isNotEmpty) ...[
                  if (groups.isNotEmpty) _sectionHeader('Sohbetler'),
                  ...contacts.map((doc) {
                    final data = doc.data() as Map<String, dynamic>?;
                    final contactUid = data?['uid'] as String? ?? doc.id;
                    return _ContactTile(contactUid: contactUid);
                  }),
                ],
              ],
            );
          },
        );
      },
    );
  }

  Widget _sectionHeader(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
    child: Text(title,
        style: const TextStyle(color: Colors.white38, fontSize: 12, fontWeight: FontWeight.w600)),
  );
}

class _GroupTile extends StatelessWidget {
  final String groupId;
  final Map<String, dynamic> data;
  const _GroupTile({required this.groupId, required this.data});

  @override
  Widget build(BuildContext context) {
    final memberCount = (data['members'] as List?)?.length ?? 0;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Builder(builder: (ctx) {
        final photo = (data['photo'] as String?) ?? '';
        return GestureDetector(
          onTap: photo.isNotEmpty ? () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => _FullPhotoPage(url: photo))) : null,
          child: Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: ColorsManager.darkPrimary.withOpacity(0.15),
              border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.4)),
            ),
            child: ClipOval(
              child: photo.isNotEmpty
                  ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                      errorWidget: (_, __, ___) => const Icon(Icons.group, color: ColorsManager.darkPrimary, size: 24))
                  : const Icon(Icons.group, color: ColorsManager.darkPrimary, size: 24),
            ),
          ),
        );
      }),
      title: Text(data['name'] ?? '',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15)),
      subtitle: Text(
        (data['lastMessage'] as String?)?.isNotEmpty == true ? data['lastMessage'] : '$memberCount üye',
        style: const TextStyle(color: Colors.white38, fontSize: 12),
        maxLines: 1, overflow: TextOverflow.ellipsis,
      ),
      trailing: const Icon(Icons.chevron_right, color: Colors.white24, size: 20),
      onTap: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => GroupChatPage(groupId: groupId, groupName: data['name'] ?? ''))),
    );
  }
}

class _ContactTile extends StatelessWidget {
  final String contactUid;
  const _ContactTile({required this.contactUid});

  void _openFullPhoto(BuildContext context, String photoUrl) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => _FullPhotoPage(url: photoUrl)));
  }

  @override
  Widget build(BuildContext context) {
    // ✅ FIX: StreamBuilder kullan — online durumu gerçek zamanlı güncellenir
    // ve FutureBuilder'ın her rebuild'de yeniden fetch yapması engellenir
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(contactUid).snapshots(),
      builder: (context, userSnap) {
        if (!userSnap.hasData) return const SizedBox.shrink();
        final data = userSnap.data!.data() as Map<String, dynamic>?;
        if (data == null) return const SizedBox.shrink();
        final bool isOnline = data['isOnline']?.toString() == 'true';
        final String photo = data['profilePic'] ?? '';

        return Container(
          margin: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
          decoration: BoxDecoration(
            color: const Color(0xFF111111),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF1E1E1E)),
          ),
          child: ListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 6.h),
            leading: Stack(children: [
              GestureDetector(
                onTap: photo.isNotEmpty ? () => _openFullPhoto(context, photo) : null,
                child: Container(
                  width: 50.w, height: 50.h,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isOnline ? ColorsManager.darkPrimary.withOpacity(0.8) : const Color(0xFF2A2A2A),
                      width: 2,
                    ),
                    boxShadow: isOnline
                        ? [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.3), blurRadius: 8)]
                        : null,
                  ),
                  child: ClipOval(
                    child: photo.isNotEmpty
                        ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                            placeholder: (c, u) => Image.asset('assets/images/loading.gif'),
                            errorWidget: (c, u, e) => const Icon(Icons.person, color: Colors.white38))
                        : Image.asset('assets/images/user.png', fit: BoxFit.cover),
                  ),
                ),
              ),
              if (isOnline)
                Positioned(bottom: 0, right: 0,
                  child: Container(width: 13, height: 13,
                    decoration: BoxDecoration(
                      color: ColorsManager.darkPrimary, shape: BoxShape.circle,
                      border: Border.all(color: const Color(0xFF111111), width: 2),
                    ),
                  ),
                ),
            ]),
            title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(data['name'] ?? '',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15),
                  overflow: TextOverflow.ellipsis),
              if (data['username'] != null)
                Text('@${data['username']}',
                    style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12)),
            ]),
            subtitle: Text(
              isOnline ? context.tr('online') : context.tr('offline'),
              style: TextStyle(
                color: isOnline ? ColorsManager.darkPrimary.withOpacity(0.7) : Colors.white24,
                fontSize: 12,
              ),
            ),
            trailing: const Icon(Icons.chevron_right, color: Colors.white24, size: 20),
            onTap: () => context.pushNamed(Routes.chatScreen, arguments: data),
            onLongPress: () => _showContactActions(context, data, contactUid),
          ),
        );
      },
    );
  }

  void _showContactActions(BuildContext context, Map<String, dynamic> data, String uid) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        // Profil özeti
        Padding(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Row(children: [
            CircleAvatar(radius: 24,
                backgroundImage: (data['profilePic'] ?? '').isNotEmpty ? NetworkImage(data['profilePic']) : null,
                backgroundColor: const Color(0xFF2A2A2A),
                child: (data['profilePic'] ?? '').isEmpty ? const Icon(Icons.person, color: Colors.white38) : null),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(data['name'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              Text('@${data['username'] ?? ''}', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 13)),
            ]),
          ]),
        ),
        const Divider(color: Colors.white10),
        ListTile(
          leading: const Icon(Icons.notifications_off_outlined, color: Colors.orange),
          title: const Text('Sessize Al', style: TextStyle(color: Colors.white)),
          subtitle: const Text('Bu sohbetin bildirimlerini kapat', style: TextStyle(color: Colors.white38, fontSize: 12)),
          onTap: () {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${data['name']} sessize alındı'), backgroundColor: Colors.orange));
          },
        ),
        ListTile(
          leading: const Icon(Icons.delete_outline_rounded, color: Colors.red),
          title: const Text('Sohbeti Sil', style: TextStyle(color: Colors.white)),
          subtitle: const Text('Tüm mesajlar silinecek', style: TextStyle(color: Colors.white38, fontSize: 12)),
          onTap: () {
            Navigator.pop(context);
            _confirmDeleteChat(context, data, uid);
          },
        ),
        ListTile(
          leading: const Icon(Icons.person_remove_outlined, color: Colors.red),
          title: const Text('Kişiyi Kaldır', style: TextStyle(color: Colors.white)),
          onTap: () async {
            Navigator.pop(context);
            await DatabaseMethods.removeContact(uid);
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Kişi kaldırıldı')));
          },
        ),
        ListTile(
          leading: const Icon(Icons.block_rounded, color: Colors.red),
          title: const Text('Engelle', style: TextStyle(color: Colors.white)),
          onTap: () async {
            Navigator.pop(context);
            final myUid = FirebaseAuth.instance.currentUser?.uid;
            if (myUid != null) {
              await FirebaseFirestore.instance.collection('users').doc(myUid)
                  .collection('blocked').doc(uid).set({'blockedAt': FieldValue.serverTimestamp()});
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Kullanıcı engellendi'), backgroundColor: Colors.red));
            }
          },
        ),
        const SizedBox(height: 8),
      ])),
    );
  }

  void _confirmDeleteChat(BuildContext context, Map<String, dynamic> data, String uid) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Sohbeti Sil', style: TextStyle(color: Colors.white)),
        content: Text('${data['name']} ile tüm mesajlar silinecek. Emin misiniz?',
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final myUid = FirebaseAuth.instance.currentUser?.uid;
              if (myUid == null) return;
              final chatId = [myUid, uid]..sort();
              final chatRoomId = chatId.join('_');
              // Mesajları sil
              final msgs = await FirebaseFirestore.instance
                  .collection('chats').doc(chatRoomId).collection('messages').get();
              final batch = FirebaseFirestore.instance.batch();
              for (final doc in msgs.docs) batch.delete(doc.reference);
              await batch.commit();
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Sohbet silindi'), backgroundColor: Colors.red));
            },
            child: const Text('Sil', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

// ── Tam Ekran Profil Fotoğrafı ───────────────────────────────────────────────
class _FullPhotoPage extends StatelessWidget {
  final String url;
  const _FullPhotoPage({required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Center(
          child: Hero(
            tag: url,
            child: InteractiveViewer(
              minScale: 0.5,
              maxScale: 4.0,
              child: CachedNetworkImage(
                imageUrl: url,
                fit: BoxFit.contain,
                placeholder: (_, __) => const CircularProgressIndicator(color: Colors.white),
                errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white38, size: 80),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
