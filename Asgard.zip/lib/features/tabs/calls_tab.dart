import '../call/ui/call_screen.dart';
import '../../core/utils/string_ext.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../themes/colors.dart';

class CallsTab extends StatelessWidget {
  const CallsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .collection('contacts')
            .snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData || snap.data!.docs.isEmpty) {
            return Container(
              color: const Color(0xFF0D0D0D),
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle, color: const Color(0xFF1A1A1A),
                      border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.3)),
                    ),
                    child: Icon(Icons.call_outlined, size: 48.sp, color: ColorsManager.darkPrimary),
                  ),
                  SizedBox(height: 20.h),
                  Text('Arama Yapılacak Kişi Yok',
                      style: TextStyle(color: Colors.white, fontSize: 18.sp, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8.h),
                  Text('Kişi ekleyerek arama başlatabilirsin',
                      style: TextStyle(color: Colors.white38, fontSize: 13.sp)),
                ]),
              ),
            );
          }
          final contacts = snap.data!.docs;
          return ListView.builder(
            padding: EdgeInsets.only(top: 8.h),
            itemCount: contacts.length,
            itemBuilder: (ctx, i) {
              final contactUid = contacts[i].id;
              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance.collection('users').doc(contactUid).get(),
                builder: (ctx, uSnap) {
                  if (!uSnap.hasData) return const SizedBox();
                  final data = uSnap.data!.data() as Map<String, dynamic>?;
                  if (data == null) return const SizedBox();
                  final name = data['name'] ?? '';
                  final photo = data['profilePic'] ?? '';
                  return ListTile(
                    contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 4.h),
                    leading: CircleAvatar(
                      radius: 24.r,
                      backgroundColor: const Color(0xFF1A1A1A),
                      backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                      child: photo.isEmpty ? Icon(Icons.person, color: Colors.white38, size: 22) : null,
                    ),
                    title: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
                    subtitle: Text('@${(data['username'] ?? '').capitalizeFirst}',
                        style: TextStyle(color: Colors.white38, fontSize: 12.sp)),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                        icon: Icon(Icons.call_outlined, color: ColorsManager.darkPrimary, size: 22),
                        onPressed: () => _showCallDialog(context, name, 'voice'),
                      ),
                      IconButton(
                        icon: Icon(Icons.videocam_outlined, color: ColorsManager.darkPrimary, size: 22),
                        onPressed: () => _showCallDialog(context, name, 'video'),
                      ),
                    ]),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: ColorsManager.darkPrimary,
        child: const Icon(Icons.add_call, color: Colors.white),
        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Arama özelliği yakında eklenecek')),
        ),
      ),
    );
  }

  void _showCallDialog(BuildContext ctx, String name, String type) {
    Navigator.push(ctx, MaterialPageRoute(
      builder: (_) => CallScreen(
        callId: 'call_${FirebaseAuth.instance.currentUser?.uid ?? 'u'}_${DateTime.now().millisecondsSinceEpoch}',
        calleeName: name,
        isVideoCall: type == 'video',
      ),
    ));
  }
}
