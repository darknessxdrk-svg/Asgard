import '../call/ui/call_screen.dart';
import '../../core/utils/string_ext.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../themes/colors.dart';

class CallsTab extends StatelessWidget {
  const CallsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .collection('contacts')
            .snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData || snap.data!.docs.isEmpty) {
            return const ColoredBox(
              color: Color(0xFF0D0D0D),
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.call_outlined, size: 48, color: ColorsManager.darkPrimary),
                  SizedBox(height: 16),
                  Text('Arama Yapılacak Kişi Yok',
                      style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('Kişi ekleyerek arama başlatabilirsin',
                      style: TextStyle(color: Colors.white38, fontSize: 13)),
                ]),
              ),
            );
          }

          final contacts = snap.data!.docs;
          final items = <Widget>[];
          for (final doc in contacts) {
            final contactUid = doc.id;
            items.add(_CallTile(key: ValueKey(contactUid), uid: contactUid));
          }
          return ColoredBox(
            color: const Color(0xFF0D0D0D),
            child: ListView(
              padding: EdgeInsets.only(top: 8.h, bottom: 80.h),
              children: items,
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: ColorsManager.darkPrimary,
        child: const Icon(Icons.add_call, color: Colors.white),
        onPressed: () {},
      ),
    );
  }
}

// ── Arama Tile (FutureBuilder YOK) ────────────────────────────────────────
class _CallTile extends StatefulWidget {
  final String uid;
  const _CallTile({required this.uid, super.key});
  @override
  State<_CallTile> createState() => _CallTileState();
}

class _CallTileState extends State<_CallTile> {
  Map<String, dynamic>? _data;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(widget.uid).get();
      if (mounted) setState(() { _data = doc.data(); _loaded = true; });
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return const ColoredBox(
        color: Color(0xFF0D0D0D),
        child: SizedBox(height: 68),
      );
    }
    final data = _data;
    if (data == null) return const SizedBox.shrink();

    final name = data['name'] as String? ?? '';
    final photo = data['profilePic'] as String? ?? '';
    final username = data['username'] as String? ?? '';

    return ListTile(
      tileColor: const Color(0xFF0D0D0D),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: CircleAvatar(
        radius: 24,
        backgroundColor: const Color(0xFF1A1A1A),
        backgroundImage: photo.isNotEmpty ? CachedNetworkImageProvider(photo) : null,
        child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white38, size: 22) : null,
      ),
      title: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
      subtitle: Text('@${capFirst(username)}',
          style: const TextStyle(color: Colors.white38, fontSize: 12)),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(
          icon: const Icon(Icons.call_outlined, color: ColorsManager.darkPrimary, size: 22),
          onPressed: () => _showCallDialog(context, name, false),
        ),
        IconButton(
          icon: const Icon(Icons.videocam_outlined, color: ColorsManager.darkPrimary, size: 22),
          onPressed: () => _showCallDialog(context, name, true),
        ),
      ]),
    );
  }

  void _showCallDialog(BuildContext ctx, String name, bool isVideo) {
    Navigator.push(
      ctx,
      MaterialPageRoute(
        builder: (_) => CallScreen(
          callId: 'call_${FirebaseAuth.instance.currentUser?.uid ?? 'u'}_${widget.uid}_'
              '${DateTime.now().millisecondsSinceEpoch}',
          calleeName: name,
          calleeUID: widget.uid,
          isVideoCall: isVideo,
        ),
      ),
    );
  }
}
