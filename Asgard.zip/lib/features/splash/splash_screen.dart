import 'dart:math' as math;
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import '../../themes/colors.dart';

class SplashScreen extends StatefulWidget {
  final VoidCallback onComplete;
  const SplashScreen({super.key, required this.onComplete});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late AnimationController _logoCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _textCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _exitCtrl;

  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<double> _textOpacity;
  late Animation<Offset> _textSlide;
  late Animation<double> _taglineOpacity;
  late Animation<Offset> _taglineSlide;
  late Animation<double> _exitScale;
  late Animation<double> _exitOpacity;

  @override
  void initState() {
    super.initState();

    _logoCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);
    _textCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _particleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat();
    _exitCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));

    _logoScale = CurvedAnimation(parent: _logoCtrl, curve: Curves.elasticOut)
        .drive(Tween(begin: 0.0, end: 1.0));
    _logoOpacity = CurvedAnimation(parent: _logoCtrl, curve: const Interval(0.0, 0.5))
        .drive(Tween(begin: 0.0, end: 1.0));

    _textOpacity = CurvedAnimation(parent: _textCtrl, curve: const Interval(0.0, 0.6))
        .drive(Tween(begin: 0.0, end: 1.0));
    _textSlide = CurvedAnimation(parent: _textCtrl, curve: Curves.easeOutCubic)
        .drive(Tween(begin: const Offset(0, 0.4), end: Offset.zero));

    _taglineOpacity = CurvedAnimation(parent: _textCtrl, curve: const Interval(0.3, 1.0))
        .drive(Tween(begin: 0.0, end: 1.0));
    _taglineSlide = CurvedAnimation(parent: _textCtrl, curve: const Interval(0.3, 1.0, curve: Curves.easeOut))
        .drive(Tween(begin: const Offset(0, 0.6), end: Offset.zero));

    _exitScale = CurvedAnimation(parent: _exitCtrl, curve: Curves.easeInCubic)
        .drive(Tween(begin: 1.0, end: 1.15));
    _exitOpacity = CurvedAnimation(parent: _exitCtrl, curve: Curves.easeIn)
        .drive(Tween(begin: 1.0, end: 0.0));

    _runSequence();
  }

  Future<void> _runSequence() async {
    await Future.delayed(const Duration(milliseconds: 200));
    await _logoCtrl.forward();
    await Future.delayed(const Duration(milliseconds: 150));
    await _textCtrl.forward();
    await Future.delayed(const Duration(milliseconds: 900));
    _pulseCtrl.stop();
    _particleCtrl.stop();
    await _exitCtrl.forward();
    widget.onComplete();
  }

  @override
  void dispose() {
    _logoCtrl.dispose();
    _pulseCtrl.dispose();
    _textCtrl.dispose();
    _particleCtrl.dispose();
    _exitCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_exitCtrl, _logoCtrl, _textCtrl, _pulseCtrl, _particleCtrl]),
      builder: (ctx, _) {
        return Opacity(
          opacity: _exitOpacity.value,
          child: Transform.scale(
            scale: _exitScale.value,
            child: Scaffold(
              backgroundColor: ColorsManager.darkBackground,
              body: Stack(
                fit: StackFit.expand,
                children: [
                  // ── Arka plan partikülleri ──
                  CustomPaint(
                    painter: _ParticlePainter(_particleCtrl.value, _logoCtrl.value),
                  ),

                  // ── Arka plan degrade ──
                  Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.center,
                        radius: 0.8,
                        colors: [
                          ColorsManager.darkPrimary.withOpacity(0.12 * _logoCtrl.value),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),

                  // ── İçerik ──
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Spacer(flex: 2),

                      // Logo alanı
                      Transform.scale(
                        scale: _logoScale.value,
                        child: Opacity(
                          opacity: _logoOpacity.value.clamp(0.0, 1.0).toDouble(),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              // Dış halka pulse
                              Transform.scale(
                                scale: 1.0 + (_pulseCtrl.value * 0.12 * _logoCtrl.value),
                                child: Container(
                                  width: 120,
                                  height: 120,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: ColorsManager.darkPrimary.withOpacity(
                                          0.25 * (1 - _pulseCtrl.value * 0.5)),
                                      width: 1.5,
                                    ),
                                  ),
                                ),
                              ),
                              // İkinci halka
                              Transform.scale(
                                scale: 1.0 + (_pulseCtrl.value * 0.06 * _logoCtrl.value),
                                child: Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: ColorsManager.darkPrimary.withOpacity(0.35),
                                      width: 1,
                                    ),
                                  ),
                                ),
                              ),
                              // Logo dairesi
                              Container(
                                width: 82,
                                height: 82,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: ColorsManager.darkSurface,
                                  boxShadow: [
                                    BoxShadow(
                                      color: ColorsManager.darkPrimary.withOpacity(
                                          0.4 + _pulseCtrl.value * 0.2),
                                      blurRadius: 24 + _pulseCtrl.value * 8,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: ClipOval(
                                  child: Image.asset(
                                    'assets/images/logo-512.png',
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Icon(
                                      Icons.shield_rounded,
                                      color: ColorsManager.darkPrimary,
                                      size: 44,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 32),

                      // Uygulama adı
                      SlideTransition(
                        position: _textSlide,
                        child: FadeTransition(
                          opacity: _textOpacity,
                          child: ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              colors: [
                                ColorsManager.darkPrimaryLight,
                                ColorsManager.darkPrimary,
                                ColorsManager.darkPrimaryDark,
                              ],
                            ).createShader(bounds),
                            child: const Text(
                              'ASGARD',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 38,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 8,
                              ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 8),

                      // Tagline
                      SlideTransition(
                        position: _taglineSlide,
                        child: FadeTransition(
                          opacity: _taglineOpacity,
                          child: Text(
                            context.tr('splashTagline'),
                            style: const TextStyle(
                              color: Colors.white38,
                              fontSize: 13,
                              letterSpacing: 2,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ),
                      ),

                      const Spacer(flex: 2),

                      // Alt yükleme göstergesi
                      FadeTransition(
                        opacity: _taglineOpacity,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 52),
                          child: Column(
                            children: [
                              SizedBox(
                                width: 120,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: LinearProgressIndicator(
                                    value: null,
                                    minHeight: 2,
                                    backgroundColor: Colors.white10,
                                    color: ColorsManager.darkPrimary,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                context.tr('splashFrom'),
                                style: const TextStyle(
                                  color: Colors.white24,
                                  fontSize: 11,
                                  letterSpacing: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ParticlePainter extends CustomPainter {
  final double progress;
  final double opacity;
  _ParticlePainter(this.progress, this.opacity);

  @override
  void paint(Canvas canvas, Size size) {
    if (opacity < 0.1) return;
    final paint = Paint()..style = PaintingStyle.fill;
    final rng = math.Random(42);
    final cx = size.width / 2;
    final cy = size.height / 2;

    for (int i = 0; i < 28; i++) {
      final angle = (i / 28) * math.pi * 2 + progress * math.pi * 2;
      final radius = 100.0 + rng.nextDouble() * 160;
      final wobble = math.sin(progress * math.pi * 2 + i) * 12;
      final px = cx + math.cos(angle) * (radius + wobble);
      final py = cy + math.sin(angle) * (radius + wobble) * 0.85;
      final r = 1.2 + rng.nextDouble() * 2.2;
      final alpha = ((0.08 + rng.nextDouble() * 0.12) * opacity).clamp(0.0, 1.0).toDouble();

      paint.color = ColorsManager.darkPrimary.withOpacity(alpha);
      canvas.drawCircle(Offset(px, py), r, paint);
    }

    // Yatay ışık çizgisi
    final linePaint = Paint()
      ..shader = LinearGradient(colors: [
        Colors.transparent,
        ColorsManager.darkPrimary.withOpacity(0.06 * opacity),
        Colors.transparent,
      ]).createShader(Rect.fromLTWH(0, cy - 1, size.width, 2))
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(0, cy), Offset(size.width, cy), linePaint);
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => old.progress != progress || old.opacity != opacity;
}
