import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../../themes/colors.dart';

class TasksScreen extends StatefulWidget {
  final String? prefilledText;
  const TasksScreen({super.key, this.prefilledText});
  @override State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  final _uid = FirebaseAuth.instance.currentUser?.uid ?? '';
  final _db = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    if (widget.prefilledText != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _addTask(prefill: widget.prefilledText));
    }
  }

  Stream<QuerySnapshot> get _stream =>
      _db.collection('users').doc(_uid).collection('tasks')
          .orderBy('createdAt', descending: true).snapshots();

  Color _priorityColor(String p) {
    switch (p) {
      case 'Acil': return Colors.red;
      case 'Yüksek': return Colors.orange;
      case 'Normal': return Colors.blue;
      default: return Colors.white24;
    }
  }

  Widget _taskBottomSheet({
    required TextEditingController ctrl,
    String? initialPriority,
    DateTime? initialDueDate,
    required String saveLabel,
    required Future<void> Function(String title, String priority, DateTime? dueDate) onSave,
  }) {
    DateTime? dueDate = initialDueDate;
    String priority = initialPriority ?? 'Normal';

    return StatefulBuilder(builder: (ctx, setSt) => Padding(
      padding: EdgeInsets.fromLTRB(20, 16, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        Text(saveLabel == 'Kaydet' ? 'Görev Ekle' : 'Görevi Düzenle',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 16),
        TextField(
          controller: ctrl, autofocus: true, maxLines: 3, style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Görev açıkla...', hintStyle: const TextStyle(color: Colors.white24),
            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.3)), borderRadius: BorderRadius.circular(10)),
            focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: ColorsManager.darkPrimary), borderRadius: BorderRadius.circular(10)),
          ),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: GestureDetector(
            onTap: () async {
              final d = await showDatePicker(
                  context: ctx,
                  initialDate: dueDate ?? DateTime.now().add(const Duration(days: 1)),
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                  builder: (c, child) => Theme(data: ThemeData.dark(), child: child!));
              if (d != null) setSt(() => dueDate = d);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                  color: dueDate != null ? ColorsManager.darkPrimary.withOpacity(0.15) : const Color(0xFF1C1C1C),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: dueDate != null ? ColorsManager.darkPrimary.withOpacity(0.4) : Colors.white12)),
              child: Row(children: [
                Icon(Icons.calendar_today_rounded, size: 16, color: dueDate != null ? ColorsManager.darkPrimary : Colors.white38),
                const SizedBox(width: 8),
                Expanded(child: Text(dueDate != null ? DateFormat('dd MMM', 'tr').format(dueDate!) : 'Son tarih',
                    style: TextStyle(color: dueDate != null ? ColorsManager.darkPrimary : Colors.white38, fontSize: 13))),
                if (dueDate != null) GestureDetector(
                  onTap: () => setSt(() => dueDate = null),
                  child: const Icon(Icons.close, size: 14, color: Colors.white38),
                ),
              ]),
            ),
          )),
          const SizedBox(width: 10),
          Expanded(child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(color: const Color(0xFF1C1C1C), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.white12)),
            child: DropdownButton<String>(
              value: priority, dropdownColor: const Color(0xFF1A1A1A), isExpanded: true,
              style: const TextStyle(color: Colors.white),
              underline: const SizedBox.shrink(),
              items: ['Düşük', 'Normal', 'Yüksek', 'Acil'].map((p) => DropdownMenuItem(
                value: p,
                child: Text(p, style: TextStyle(color: p == 'Acil' ? Colors.red : p == 'Yüksek' ? Colors.orange : p == 'Normal' ? Colors.blue : Colors.white38)),
              )).toList(),
              onChanged: (v) { if (v != null) setSt(() => priority = v); },
            ),
          )),
        ]),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: ColorsManager.darkPrimary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)),
          onPressed: () async {
            if (ctrl.text.trim().isEmpty) return;
            await onSave(ctrl.text.trim(), priority, dueDate);
            if (ctx.mounted) Navigator.pop(ctx);
          },
          child: Text(saveLabel, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        )),
      ]),
    ));
  }

  Future<void> _addTask({String? prefill}) async {
    final ctrl = TextEditingController(text: prefill);
    await showModalBottomSheet(
      context: context, isScrollControlled: true,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _taskBottomSheet(
        ctrl: ctrl,
        saveLabel: 'Kaydet',
        onSave: (title, priority, dueDate) async {
          await _db.collection('users').doc(_uid).collection('tasks').add({
            'title': title, 'done': false, 'priority': priority,
            'dueDate': dueDate != null ? Timestamp.fromDate(dueDate) : null,
            'createdAt': FieldValue.serverTimestamp(),
          });
        },
      ),
    );
    ctrl.dispose();
  }

  Future<void> _editTask(String docId, Map<String, dynamic> data) async {
    final ctrl = TextEditingController(text: data['title'] ?? '');
    await showModalBottomSheet(
      context: context, isScrollControlled: true,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _taskBottomSheet(
        ctrl: ctrl,
        initialPriority: data['priority'] ?? 'Normal',
        initialDueDate: (data['dueDate'] as Timestamp?)?.toDate(),
        saveLabel: 'Güncelle',
        onSave: (title, priority, dueDate) async {
          await _db.collection('users').doc(_uid).collection('tasks').doc(docId).set({
            'title': title, 'priority': priority,
            'dueDate': dueDate != null ? Timestamp.fromDate(dueDate) : null,
          });
        },
      ),
    );
    ctrl.dispose();
  }

  void _showTaskMenu(BuildContext context, String docId, Map<String, dynamic> data) {
    final isDone = data['done'] == true;
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 36, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          if (!isDone) ListTile(
            leading: const Icon(Icons.edit_outlined, color: Colors.white70),
            title: const Text('Düzenle', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _editTask(docId, data); },
          ),
          ListTile(
            leading: Icon(isDone ? Icons.redo_rounded : Icons.check_circle_outline, color: Colors.green),
            title: Text(isDone ? 'Tamamlanmadı olarak işaretle' : 'Tamamlandı olarak işaretle',
                style: const TextStyle(color: Colors.white)),
            onTap: () {
              Navigator.pop(context);
              _db.collection('users').doc(_uid).collection('tasks').doc(docId).update({'done': !isDone});
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline_rounded, color: Colors.red),
            title: const Text('Sil', style: TextStyle(color: Colors.redAccent)),
            onTap: () async {
              Navigator.pop(context);
              final ok = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: const Color(0xFF1A1A1A),
                  title: const Text('Görevi Sil', style: TextStyle(color: Colors.white)),
                  content: const Text('Bu görev silinecek.', style: TextStyle(color: Colors.white54)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
                    TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil', style: TextStyle(color: Colors.red))),
                  ],
                ),
              );
              if (ok == true) {
                _db.collection('users').doc(_uid).collection('tasks').doc(docId).delete();
              }
            },
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Görevler', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: ColorsManager.darkPrimary,
        onPressed: _addTask,
        child: const Icon(Icons.add_task_rounded, color: Colors.white),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _stream,
        builder: (ctx, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
          final tasks = snap.data!.docs;
          final pending = tasks.where((t) => ((t.data() as Map<String,dynamic>?)?['done']) != true).toList();
          final done = tasks.where((t) => ((t.data() as Map<String,dynamic>?)?['done']) == true).toList();

          if (tasks.isEmpty) return const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.task_alt, size: 64, color: Colors.white12),
            SizedBox(height: 16),
            Text('Görev yok', style: TextStyle(color: Colors.white38, fontSize: 16)),
          ]));

          return ListView(padding: const EdgeInsets.all(12), children: [
            if (pending.isNotEmpty) ...[
              Text('Bekleyen (${pending.length})', style: const TextStyle(color: Colors.white38, fontSize: 12, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              ...pending.map((doc) {
                final data = doc.data() as Map<String, dynamic>;
                final title = data['title'] ?? '';
                final priority = data['priority'] ?? 'Normal';
                final color = _priorityColor(priority);
                final dueDate = (data['dueDate'] as Timestamp?)?.toDate();
                final isOverdue = dueDate != null && dueDate.isBefore(DateTime.now());
                return GestureDetector(
                  onLongPress: () => _showTaskMenu(context, doc.id, data),
                  child: Dismissible(
                    key: Key(doc.id), direction: DismissDirection.endToStart,
                    background: Container(alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20),
                        decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(14)),
                        child: const Icon(Icons.delete_outline_rounded, color: Colors.red)),
                    onDismissed: (_) => _db.collection('users').doc(_uid).collection('tasks').doc(doc.id).delete(),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(color: const Color(0xFF111111), borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: color.withOpacity(0.25))),
                      child: Row(children: [
                        GestureDetector(
                          onTap: () => _db.collection('users').doc(_uid).collection('tasks').doc(doc.id).update({'done': true}),
                          child: Container(width: 22, height: 22,
                              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 2))),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(title, style: const TextStyle(color: Colors.white, fontSize: 15)),
                          if (dueDate != null) Row(children: [
                            Icon(Icons.access_alarm_rounded, size: 12, color: isOverdue ? Colors.red : Colors.white24),
                            const SizedBox(width: 3),
                            Text(DateFormat('dd MMM', 'tr').format(dueDate),
                                style: TextStyle(color: isOverdue ? Colors.red : Colors.white24, fontSize: 11)),
                            if (isOverdue) const Text(' Gecikti!', style: TextStyle(color: Colors.red, fontSize: 10, fontWeight: FontWeight.bold)),
                          ]),
                        ])),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                              decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
                              child: Text(priority, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold))),
                          const SizedBox(width: 6),
                          GestureDetector(
                            onTap: () => _showTaskMenu(context, doc.id, data),
                            child: const Icon(Icons.more_vert_rounded, color: Colors.white24, size: 18),
                          ),
                        ]),
                      ]),
                    ),
                  ),
                );
              }),
            ],
            if (done.isNotEmpty) ...[
              const SizedBox(height: 16),
              Text('Tamamlanan (${done.length})', style: const TextStyle(color: Colors.white24, fontSize: 12, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              ...done.map((doc) {
                final data = doc.data() as Map<String, dynamic>;
                return GestureDetector(
                  onLongPress: () => _showTaskMenu(context, doc.id, data),
                  child: Dismissible(
                    key: Key(doc.id), direction: DismissDirection.endToStart,
                    background: Container(alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), color: Colors.red.withOpacity(0.2), child: const Icon(Icons.delete_outline_rounded, color: Colors.red)),
                    onDismissed: (_) => _db.collection('users').doc(_uid).collection('tasks').doc(doc.id).delete(),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(color: const Color(0xFF0A0A0A), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white10)),
                      child: Row(children: [
                        Container(width: 22, height: 22,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.green.withOpacity(0.2), border: Border.all(color: Colors.green, width: 2)),
                            child: const Icon(Icons.check_rounded, size: 14, color: Colors.green)),
                        const SizedBox(width: 12),
                        Expanded(child: Text(data['title'] ?? '', style: const TextStyle(color: Colors.white38, fontSize: 14, decoration: TextDecoration.lineThrough))),
                        GestureDetector(
                          onTap: () => _showTaskMenu(context, doc.id, data),
                          child: const Icon(Icons.more_vert_rounded, color: Colors.white24, size: 18),
                        ),
                      ]),
                    ),
                  ),
                );
              }),
            ],
            const SizedBox(height: 80),
          ]);
        },
      ),
    );
  }
}
