import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../themes/colors.dart';

class StorageScreen extends StatefulWidget {
  const StorageScreen({super.key});
  @override State<StorageScreen> createState() => _StorageScreenState();
}

class _StorageScreenState extends State<StorageScreen> {
  final _db = FirebaseFirestore.instance;
  final _uid = FirebaseAuth.instance.currentUser?.uid ?? '';

  bool _loading = true;
  int _totalMessages = 0;
  int _totalMedia = 0;
  Map<String, _ContactStats> _perContact = {};

  @override
  void initState() {
    super.initState();
    _analyze();
  }

  Future<void> _analyze() async {
    if (mounted) setState(() => _loading = true);
    try {
      // Kendi contacts listesi
      final contacts = await _db.collection('users').doc(_uid).collection('contacts').get();

      int totalMsg = 0, totalMedia = 0;
      final Map<String, _ContactStats> stats = {};

      for (final c in contacts.docs) {
        final otherUid = ((c.data() as Map<String,dynamic>?)?['uid'] ?? c.id) as String;
        final ids = [_uid, otherUid]..sort();
        final chatId = ids.join('_');

        final msgs = await _db.collection('chats').doc(chatId).collection('messages')
            .where('hiddenFor', whereNotIn: [_uid]).get().catchError((_) async {
          return await _db.collection('chats').doc(chatId).collection('messages').get();
        });

        int msgCount = 0, mediaCount = 0;
        for (final m in msgs.docs) {
          final text = ((m.data() as Map<String,dynamic>?)?['message'] ?? '') as String;
          msgCount++;
          if (text.startsWith('[resim]:') || text.startsWith('[ses]:') || text.startsWith('[dosya]:')) {
            mediaCount++;
          }
        }
        totalMsg += msgCount;
        totalMedia += mediaCount;

        // İsim al
        final userDoc = await _db.collection('users').doc(otherUid).get();
        final name = (userDoc.data()?['name'] ?? 'Kullanıcı') as String;
        final photo = (userDoc.data()?['profilePic'] ?? '') as String;

        if (msgCount > 0) {
          stats[otherUid] = _ContactStats(name: name, photo: photo, messages: msgCount, media: mediaCount);
        }
      }

      final sorted = Map.fromEntries(stats.entries.toList()..sort((a, b) => b.value.messages.compareTo(a.value.messages)));

      if (mounted) setState(() {
        _totalMessages = totalMsg;
        _totalMedia = totalMedia;
        _perContact = sorted;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Depolama Analizi', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded, color: Colors.white54), onPressed: _analyze),
        ],
      ),
      body: _loading
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              CircularProgressIndicator(color: ColorsManager.darkPrimary),
              const SizedBox(height: 16),
              const Text('Analiz yapılıyor...', style: TextStyle(color: Colors.white38)),
            ]))
          : ListView(children: [
              // Özet kartlar
              Padding(
                padding: EdgeInsets.all(16.w),
                child: Row(children: [
                  Expanded(child: _SummaryCard(icon: Icons.message_rounded, color: ColorsManager.darkPrimary,
                      label: 'Mesaj', value: _totalMessages.toString())),
                  SizedBox(width: 12.w),
                  Expanded(child: _SummaryCard(icon: Icons.perm_media_rounded, color: Colors.purple,
                      label: 'Medya', value: _totalMedia.toString())),
                  SizedBox(width: 12.w),
                  Expanded(child: _SummaryCard(icon: Icons.people_rounded, color: Colors.blue,
                      label: 'Kişi', value: _perContact.length.toString())),
                ]),
              ),

              if (_perContact.isNotEmpty) ...[
                Padding(padding: EdgeInsets.fromLTRB(16.w, 8.h, 16.w, 8.h),
                    child: Text('Kişi Bazlı Detay', style: TextStyle(color: Colors.white38, fontSize: 12.sp, fontWeight: FontWeight.w600))),

                ..._perContact.entries.map((e) {
                  final s = e.value;
                  final pct = _totalMessages > 0 ? s.messages / _totalMessages : 0.0;
                  return Container(
                    margin: EdgeInsets.symmetric(horizontal: 12.w, vertical: 3.h),
                    padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                    decoration: BoxDecoration(color: const Color(0xFF111111), borderRadius: BorderRadius.circular(14)),
                    child: Row(children: [
                      CircleAvatar(radius: 22,
                          backgroundImage: s.photo.isNotEmpty ? NetworkImage(s.photo) : null,
                          backgroundColor: const Color(0xFF2A2A2A),
                          child: s.photo.isEmpty ? const Icon(Icons.person, color: Colors.white38, size: 22) : null),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(s.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 6),
                        ClipRRect(borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(value: pct, backgroundColor: Colors.white10,
                                color: ColorsManager.darkPrimary, minHeight: 4)),
                        const SizedBox(height: 4),
                        Text('${s.messages} mesaj  ·  ${s.media} medya',
                            style: const TextStyle(color: Colors.white38, fontSize: 11)),
                      ])),
                      Text('${(pct * 100).toStringAsFixed(0)}%',
                          style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold)),
                    ]),
                  );
                }),
              ],
              SizedBox(height: 32.h),
            ]),
    );
  }
}

class _ContactStats {
  final String name, photo;
  final int messages, media;
  _ContactStats({required this.name, required this.photo, required this.messages, required this.media});
}

class _SummaryCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label, value;
  const _SummaryCard({required this.icon, required this.color, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF111111), borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2))),
      child: Column(children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 8),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 20)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 11)),
      ]),
    );
  }
}
