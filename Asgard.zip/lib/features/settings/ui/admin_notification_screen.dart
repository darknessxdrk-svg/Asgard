import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:http/http.dart' as http;
import '../../../services/notification_service.dart';
import '../../../themes/colors.dart';

class AdminNotificationScreen extends StatefulWidget {
  const AdminNotificationScreen({super.key});

  @override
  State<AdminNotificationScreen> createState() => _AdminNotificationScreenState();
}

class _AdminNotificationScreenState extends State<AdminNotificationScreen> {
  final _titleCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();
  bool _sending = false;
  bool _isAdmin = false;
  bool _checkingAdmin = true;
  String? _result;
  int _sentCount = 0;

  @override
  void initState() {
    super.initState();
    _checkAdminStatus();
  }

  Future<void> _checkAdminStatus() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      setState(() { _isAdmin = false; _checkingAdmin = false; });
      return;
    }
    try {
      // Firestore'daki admins koleksiyonunu kontrol et
      final doc = await FirebaseFirestore.instance
          .collection('admins')
          .doc(uid)
          .get();
      setState(() { _isAdmin = doc.exists; _checkingAdmin = false; });
    } catch (_) {
      setState(() { _isAdmin = false; _checkingAdmin = false; });
    }
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendToAll() async {
    if (_titleCtrl.text.trim().isEmpty || _bodyCtrl.text.trim().isEmpty) {
      _showSnack('Başlık ve mesaj zorunlu', Colors.red);
      return;
    }
    setState(() { _sending = true; _result = null; _sentCount = 0; });

    try {
      // Tüm kullanıcıların FCM token'larını al
      final users = await FirebaseFirestore.instance
          .collection('users')
          .where('mtoken', isNotEqualTo: '')
          .get();

      final tokens = users.docs
          .map((d) => d.data()['mtoken'] as String? ?? '')
          .where((t) => t.isNotEmpty)
          .toList();

      if (tokens.isEmpty) {
        setState(() { _result = 'Hiç FCM token bulunamadı'; _sending = false; });
        return;
      }

      // NotificationService ile gönder
      final service = NotificationService();

      // FIX #13: Serial for-loop yerine paralel gönderim (20'li chunk)
      // Uyarı: 1000+ kullanıcı için Cloud Function kullanılmalı.
      // Client-side gönderim timeout/rate-limit riski taşır.
      int sent = 0;
      int failed = 0;
      const chunkSize = 20;

      for (int i = 0; i < tokens.length; i += chunkSize) {
        final chunk = tokens.sublist(
            i, (i + chunkSize).clamp(0, tokens.length));
        final results = await Future.wait(
          chunk.map((token) => service
              .sendPushMessage(
                token,
                '',
                _bodyCtrl.text.trim(),
                _titleCtrl.text.trim(),
                'admin',
                null,
              )
              .then((_) => true)
              .catchError((_) => false)),
        );
        sent += results.where((r) => r).length;
        failed += results.where((r) => !r).length;
      }

      // Firestore'a bildirim kaydı bırak
      await FirebaseFirestore.instance.collection('admin_notifications').add({
        'title': _titleCtrl.text.trim(),
        'body': _bodyCtrl.text.trim(),
        'sentAt': FieldValue.serverTimestamp(),
        'sentBy': FirebaseAuth.instance.currentUser?.uid,
        'totalTokens': tokens.length,
        'sent': sent,
        'failed': failed,
      });

      setState(() {
        _sentCount = sent;
        _result = '✅ $sent kullanıcıya gönderildi${failed > 0 ? ', $failed başarısız' : ''}';
        _sending = false;
      });
      _titleCtrl.clear();
      _bodyCtrl.clear();
    } catch (e) {
      if (mounted) setState(() { _result = '❌ Hata: $e'; _sending = false; });
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: color));
  }

  @override
  Widget build(BuildContext context) {
    if (_checkingAdmin) {
      return const Scaffold(
        backgroundColor: Color(0xFF0D0D0D),
        body: Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary)),
      );
    }
    if (!_isAdmin) {
      return Scaffold(
        backgroundColor: const Color(0xFF0D0D0D),
        appBar: AppBar(
          backgroundColor: const Color(0xFF111111),
          title: const Text('Admin Paneli', style: TextStyle(color: Colors.white)),
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: const Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.lock_rounded, color: Colors.red, size: 64),
            SizedBox(height: 16),
            Text('Erişim Reddedildi', style: TextStyle(color: Colors.white, fontSize: 18)),
            SizedBox(height: 8),
            Text('Bu panel sadece adminlere açıktır',
                style: TextStyle(color: Colors.white38, fontSize: 13)),
          ]),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Admin Bildirim Paneli',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Bilgi kartı
          Container(
            padding: EdgeInsets.all(16.r),
            decoration: BoxDecoration(
              color: ColorsManager.darkPrimary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14.r),
              border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.3)),
            ),
            child: Row(children: [
              Icon(Icons.campaign_rounded, color: ColorsManager.darkPrimary, size: 24),
              SizedBox(width: 12.w),
              const Expanded(
                child: Text(
                  'Tüm Asgard kullanıcılarına anlık bildirim gönder',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ),
            ]),
          ),
          SizedBox(height: 24.h),

          // Başlık
          const Text('Bildirim Başlığı',
              style: TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.w600)),
          SizedBox(height: 8.h),
          TextField(
            controller: _titleCtrl,
            style: const TextStyle(color: Colors.white),
            maxLength: 60,
            decoration: InputDecoration(
              hintText: 'Örn: 🎉 Yeni özellik!',
              hintStyle: const TextStyle(color: Colors.white24),
              counterStyle: const TextStyle(color: Colors.white24),
              filled: true,
              fillColor: const Color(0xFF1A1A1A),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide(color: ColorsManager.darkPrimary),
              ),
            ),
          ),
          SizedBox(height: 16.h),

          // Mesaj
          const Text('Bildirim Mesajı',
              style: TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.w600)),
          SizedBox(height: 8.h),
          TextField(
            controller: _bodyCtrl,
            style: const TextStyle(color: Colors.white),
            maxLines: 4,
            maxLength: 200,
            decoration: InputDecoration(
              hintText: 'Kullanıcılara göndermek istediğin mesajı yaz...',
              hintStyle: const TextStyle(color: Colors.white24),
              counterStyle: const TextStyle(color: Colors.white24),
              filled: true,
              fillColor: const Color(0xFF1A1A1A),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide(color: ColorsManager.darkPrimary),
              ),
            ),
          ),
          SizedBox(height: 24.h),

          // Gönder butonu
          SizedBox(
            width: double.infinity,
            height: 52.h,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: ColorsManager.darkPrimary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r)),
                elevation: 0,
              ),
              onPressed: _sending ? null : _sendToAll,
              icon: _sending
                  ? SizedBox(
                      width: 20, height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.send_rounded, color: Colors.white),
              label: Text(
                _sending ? 'Gönderiliyor...' : 'Tüm Kullanıcılara Gönder',
                style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
              ),
            ),
          ),

          // Sonuç
          if (_result != null) ...[
            SizedBox(height: 16.h),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16.r),
              decoration: BoxDecoration(
                color: _result!.startsWith('✅')
                    ? Colors.green.withOpacity(0.1)
                    : Colors.red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: _result!.startsWith('✅')
                      ? Colors.green.withOpacity(0.3)
                      : Colors.red.withOpacity(0.3),
                ),
              ),
              child: Text(_result!,
                  style: TextStyle(
                    color: _result!.startsWith('✅') ? Colors.greenAccent : Colors.redAccent,
                    fontSize: 14,
                  )),
            ),
          ],

          SizedBox(height: 32.h),

          // Geçmiş bildirimler
          const Text('Gönderilen Bildirimler',
              style: TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.w600)),
          SizedBox(height: 12.h),
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('admin_notifications')
                .orderBy('sentAt', descending: true)
                .limit(10)
                .snapshots(),
            builder: (ctx, snap) {
              if (!snap.hasData || snap.data!.docs.isEmpty) {
                return const Center(
                  child: Text('Henüz bildirim gönderilmedi',
                      style: TextStyle(color: Colors.white24, fontSize: 13)),
                );
              }
              return Column(
                children: snap.data!.docs.map((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  final ts = data['sentAt'] as Timestamp?;
                  final time = ts?.toDate();
                  return Container(
                    margin: EdgeInsets.only(bottom: 10.h),
                    padding: EdgeInsets.all(14.r),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A1A),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Expanded(
                          child: Text(data['title'] ?? '',
                              style: const TextStyle(
                                  color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                              overflow: TextOverflow.ellipsis),
                        ),
                        if (time != null)
                          Text(
                            '${time.day}/${time.month} ${time.hour}:${time.minute.toString().padLeft(2, '0')}',
                            style: const TextStyle(color: Colors.white38, fontSize: 11),
                          ),
                      ]),
                      SizedBox(height: 4.h),
                      Text(data['body'] ?? '',
                          style: const TextStyle(color: Colors.white60, fontSize: 13),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                      SizedBox(height: 6.h),
                      Text(
                        '${data['sent'] ?? 0} kullanıcıya gönderildi',
                        style: TextStyle(color: Colors.green.withOpacity(0.7), fontSize: 11),
                      ),
                    ]),
                  );
                }).toList(),
              );
            },
          ),
        ]),
      ),
    );
  }
}
