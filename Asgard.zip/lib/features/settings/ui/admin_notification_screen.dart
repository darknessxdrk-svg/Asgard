import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../services/notification_service.dart';
import '../../../themes/colors.dart';

class AdminNotificationScreen extends StatefulWidget {
  const AdminNotificationScreen({super.key});
  @override
  State<AdminNotificationScreen> createState() => _AdminNotificationScreenState();
}

class _AdminNotificationScreenState extends State<AdminNotificationScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabCtrl;
  bool _isAdmin = false;
  bool _checkingAdmin = true;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkAdminStatus());
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }

  Future<void> _checkAdminStatus() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) { if (mounted) setState(() { _isAdmin = false; _checkingAdmin = false; }); return; }
    try {
      final doc = await FirebaseFirestore.instance.collection('admins').doc(uid).get();
      if (!mounted) return;
      setState(() { _isAdmin = doc.exists; _checkingAdmin = false; });
    } catch (_) { if (mounted) setState(() { _isAdmin = false; _checkingAdmin = false; }); }
  }

  @override
  Widget build(BuildContext context) {
    if (_checkingAdmin) return const Scaffold(backgroundColor: Color(0xFF0D0D0D), body: Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary)));
    if (!_isAdmin) return Scaffold(backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(backgroundColor: const Color(0xFF111111), title: const Text('Admin Paneli', style: TextStyle(color: Colors.white)), iconTheme: const IconThemeData(color: Colors.white)),
      body: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.lock_rounded, color: Colors.red, size: 64), SizedBox(height: 16), Text('Erişim Reddedildi', style: TextStyle(color: Colors.white, fontSize: 18)), SizedBox(height: 8), Text('Bu panel sadece adminlere açıktır', style: TextStyle(color: Colors.white38, fontSize: 13))])));
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Admin Paneli', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
        bottom: TabBar(controller: _tabCtrl, indicatorColor: ColorsManager.darkPrimary, labelColor: ColorsManager.darkPrimary, unselectedLabelColor: Colors.white38,
          tabs: const [Tab(icon: Icon(Icons.campaign_rounded), text: 'Bildirimler'), Tab(icon: Icon(Icons.bug_report_rounded), text: 'Hata Raporları')]),
      ),
      body: TabBarView(controller: _tabCtrl, children: const [_NotificationTab(), _ReportsTab()]),
    );
  }
}

class _NotificationTab extends StatefulWidget {
  const _NotificationTab();
  @override State<_NotificationTab> createState() => _NotificationTabState();
}

class _NotificationTabState extends State<_NotificationTab> {
  final _titleCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();
  bool _sending = false;
  String? _result;

  @override void dispose() { _titleCtrl.dispose(); _bodyCtrl.dispose(); super.dispose(); }

  Future<void> _sendToAll() async {
    if (_titleCtrl.text.trim().isEmpty || _bodyCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Başlık ve mesaj zorunlu'), backgroundColor: Colors.red)); return;
    }
    setState(() { _sending = true; _result = null; });
    try {
      final users = await FirebaseFirestore.instance.collection('users').where('mtoken', isNotEqualTo: '').get();
      final tokens = users.docs.map((d) => (d.data()['mtoken'] as String? ?? '')).where((t) => t.isNotEmpty).toList();
      if (tokens.isEmpty) { setState(() { _result = 'Hiç FCM token bulunamadı'; _sending = false; }); return; }
      final service = NotificationService();
      int sent = 0, failed = 0;
      for (int i = 0; i < tokens.length; i += 20) {
        final chunk = tokens.sublist(i, (i + 20).clamp(0, tokens.length));
        final results = await Future.wait(chunk.map((t) => service.sendPushMessage(t, '', _bodyCtrl.text.trim(), _titleCtrl.text.trim(), 'admin', null).then((_) => true).catchError((_) => false)));
        sent += results.where((r) => r).length; failed += results.where((r) => !r).length;
      }
      await FirebaseFirestore.instance.collection('admin_notifications').add({'title': _titleCtrl.text.trim(), 'body': _bodyCtrl.text.trim(), 'sentAt': FieldValue.serverTimestamp(), 'sentBy': FirebaseAuth.instance.currentUser?.uid, 'sent': sent, 'failed': failed});
      if (mounted) setState(() { _result = '✅ $sent kullanıcıya gönderildi${failed > 0 ? ", $failed başarısız" : ""}'; _sending = false; });
      _titleCtrl.clear(); _bodyCtrl.clear();
    } catch (e) { if (mounted) setState(() { _result = '❌ Hata: $e'; _sending = false; }); }
  }

  Widget _field(TextEditingController ctrl, String hint, {int maxLines = 1, int? maxLength}) => TextField(
    controller: ctrl, style: const TextStyle(color: Colors.white), maxLines: maxLines, maxLength: maxLength,
    decoration: InputDecoration(hintText: hint, hintStyle: const TextStyle(color: Colors.white24), counterStyle: const TextStyle(color: Colors.white24),
      filled: true, fillColor: const Color(0xFF1A1A1A),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12.r), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12.r), borderSide: BorderSide(color: ColorsManager.darkPrimary))));

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(padding: EdgeInsets.all(20.r), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(padding: EdgeInsets.all(16.r), decoration: BoxDecoration(color: ColorsManager.darkPrimary.withOpacity(0.1), borderRadius: BorderRadius.circular(14.r), border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.3))),
        child: Row(children: [Icon(Icons.campaign_rounded, color: ColorsManager.darkPrimary, size: 24), SizedBox(width: 12.w), const Expanded(child: Text('Tüm Asgard kullanıcılarına anlık bildirim gönder', style: TextStyle(color: Colors.white70, fontSize: 13)))])),
      SizedBox(height: 24.h),
      const Text('Bildirim Başlığı', style: TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.w600)), SizedBox(height: 8.h),
      _field(_titleCtrl, 'Örn: 🎉 Yeni özellik!', maxLength: 60), SizedBox(height: 16.h),
      const Text('Bildirim Mesajı', style: TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.w600)), SizedBox(height: 8.h),
      _field(_bodyCtrl, 'Kullanıcılara göndermek istediğin mesajı yaz...', maxLines: 4, maxLength: 200), SizedBox(height: 24.h),
      SizedBox(width: double.infinity, height: 52.h,
        child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: ColorsManager.darkPrimary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r))),
          onPressed: _sending ? null : _sendToAll,
          icon: _sending ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send_rounded, color: Colors.white),
          label: Text(_sending ? 'Gönderiliyor...' : 'Tüm Kullanıcılara Gönder', style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)))),
      if (_result != null) ...[SizedBox(height: 16.h),
        Container(width: double.infinity, padding: EdgeInsets.all(16.r),
          decoration: BoxDecoration(color: _result!.startsWith('✅') ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(12.r), border: Border.all(color: _result!.startsWith('✅') ? Colors.green.withOpacity(0.3) : Colors.red.withOpacity(0.3))),
          child: Text(_result!, style: TextStyle(color: _result!.startsWith('✅') ? Colors.greenAccent : Colors.redAccent, fontSize: 14)))],
      SizedBox(height: 32.h),
      const Text('Gönderilen Bildirimler', style: TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.w600)), SizedBox(height: 12.h),
      StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('admin_notifications').orderBy('sentAt', descending: true).limit(10).snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData || snap.data!.docs.isEmpty) return const Center(child: Text('Henüz bildirim gönderilmedi', style: TextStyle(color: Colors.white24, fontSize: 13)));
          return Column(children: snap.data!.docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            final time = (data['sentAt'] as Timestamp?)?.toDate();
            return Container(margin: EdgeInsets.only(bottom: 10.h), padding: EdgeInsets.all(14.r), decoration: BoxDecoration(color: const Color(0xFF1A1A1A), borderRadius: BorderRadius.circular(12.r)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Expanded(child: Text(data['title'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14), overflow: TextOverflow.ellipsis)),
                  if (time != null) Text('${time.day}/${time.month} ${time.hour}:${time.minute.toString().padLeft(2, '0')}', style: const TextStyle(color: Colors.white38, fontSize: 11))]),
                SizedBox(height: 4.h),
                Text(data['body'] ?? '', style: const TextStyle(color: Colors.white60, fontSize: 13), maxLines: 2, overflow: TextOverflow.ellipsis),
                SizedBox(height: 6.h),
                Text('${data['sent'] ?? 0} kullanıcıya gönderildi', style: TextStyle(color: Colors.green.withOpacity(0.7), fontSize: 11))]));
          }).toList());
        }),
    ]));
  }
}

class _ReportsTab extends StatelessWidget {
  const _ReportsTab();
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('user_reports').orderBy('createdAt', descending: true).snapshots(),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
        if (!snap.hasData || snap.data!.docs.isEmpty) return const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.check_circle_outline, color: Colors.green, size: 64), SizedBox(height: 16),
          Text('Hata raporu yok 🎉', style: TextStyle(color: Colors.white, fontSize: 16)), SizedBox(height: 8),
          Text('Henüz kullanıcı hata bildirmedi', style: TextStyle(color: Colors.white38, fontSize: 13))]));
        final docs = snap.data!.docs;
        return ListView.builder(padding: EdgeInsets.all(16.r), itemCount: docs.length, itemBuilder: (ctx, i) {
          final data = docs[i].data() as Map<String, dynamic>;
          final time = (data['createdAt'] as Timestamp?)?.toDate();
          final isResolved = (data['status'] as String? ?? 'open') == 'resolved';
          return Container(margin: EdgeInsets.only(bottom: 12.h),
            decoration: BoxDecoration(color: const Color(0xFF1A1A1A), borderRadius: BorderRadius.circular(14.r),
              border: Border.all(color: isResolved ? Colors.green.withOpacity(0.3) : Colors.orange.withOpacity(0.3))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(padding: EdgeInsets.fromLTRB(14.w, 12.h, 8.w, 4.h),
                child: Row(children: [
                  Icon(isResolved ? Icons.check_circle_rounded : Icons.bug_report_rounded, color: isResolved ? Colors.green : Colors.orange, size: 18),
                  SizedBox(width: 8.w),
                  Expanded(child: Text(data['userName'] as String? ?? 'Anonim', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14))),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: isResolved ? Colors.green.withOpacity(0.15) : Colors.orange.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                    child: Text(isResolved ? 'Çözüldü' : 'Açık', style: TextStyle(color: isResolved ? Colors.green : Colors.orange, fontSize: 11, fontWeight: FontWeight.w600)))])),
              Padding(padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 6.h),
                child: Text(data['message'] as String? ?? '', style: const TextStyle(color: Colors.white70, fontSize: 14, height: 1.4))),
              Padding(padding: EdgeInsets.fromLTRB(14.w, 0, 8.w, 10.h),
                child: Row(children: [
                  if (time != null) Text('${time.day}/${time.month}/${time.year} ${time.hour}:${time.minute.toString().padLeft(2, '0')}', style: const TextStyle(color: Colors.white38, fontSize: 11)),
                  const Spacer(),
                  IconButton(icon: const Icon(Icons.copy, size: 16, color: Colors.white38), tooltip: 'Kopyala', onPressed: () { Clipboard.setData(ClipboardData(text: data['message'] as String? ?? '')); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kopyalandı'), duration: Duration(seconds: 1))); }),
                  TextButton(onPressed: () { FirebaseFirestore.instance.collection('user_reports').doc(docs[i].id).update({'status': isResolved ? 'open' : 'resolved'}); }, child: Text(isResolved ? 'Yeniden Aç' : 'Çözüldü İşaretle', style: TextStyle(color: isResolved ? Colors.orange : Colors.green, fontSize: 12))),
                  IconButton(icon: const Icon(Icons.delete_outline, size: 16, color: Colors.red), tooltip: 'Sil', onPressed: () { FirebaseFirestore.instance.collection('user_reports').doc(docs[i].id).delete(); })]))
            ]));
        });
      });
  }
}
