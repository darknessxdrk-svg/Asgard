import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../services/database.dart';
import '../../../themes/colors.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});
  @override State<NotificationSettingsScreen> createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  bool _showPreview = true;
  bool _groupNotifs = true;
  bool _statusNotifs = true;
  bool _callNotifs = true;
  String _defaultSound = 'Varsayılan';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _showPreview = prefs.getBool('notif_preview') ?? true;
      _groupNotifs = prefs.getBool('notif_groups') ?? true;
      _statusNotifs = prefs.getBool('notif_statuses') ?? true;
      _callNotifs = prefs.getBool('notif_calls') ?? true;
      _defaultSound = prefs.getString('notif_sound') ?? 'Varsayılan';
    });
  }

  Future<void> _save(String key, dynamic value) async {
    final prefs = await SharedPreferences.getInstance();
    if (value is bool) await prefs.setBool(key, value);
    if (value is String) await prefs.setString(key, value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Bildirim Ayarları', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: ListView(children: [

        _section('Genel'),
        _switchRow(Icons.preview_rounded, Colors.blue, 'Mesaj Önizleme',
            'Bildirimde mesaj içeriği göster', _showPreview, (v) {
          setState(() => _showPreview = v);
          _save('notif_preview', v);
        }),
        _divider(),
        _switchRow(Icons.group_rounded, ColorsManager.darkPrimary, 'Grup Bildirimleri',
            'Grup mesajlarında bildirim al', _groupNotifs, (v) {
          setState(() => _groupNotifs = v);
          _save('notif_groups', v);
        }),
        _divider(),
        _switchRow(Icons.circle, Colors.green, 'Durum Bildirimleri',
            'Yeni durum paylaşıldığında bildir', _statusNotifs, (v) {
          setState(() => _statusNotifs = v);
          _save('notif_statuses', v);
        }),
        _divider(),
        _switchRow(Icons.call_rounded, Colors.teal, 'Arama Bildirimleri',
            'Gelen arama bildirimi', _callNotifs, (v) {
          setState(() => _callNotifs = v);
          _save('notif_calls', v);
        }),
        _divider(),

        _section('Bildirim Sesi'),
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
          leading: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.orange.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.music_note_rounded, color: Colors.orange, size: 22)),
          title: const Text('Bildirim Sesi', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500)),
          subtitle: Text(_defaultSound, style: const TextStyle(color: Colors.white38, fontSize: 12)),
          trailing: const Icon(Icons.chevron_right, color: Colors.white24),
          onTap: () => _showSoundPicker(),
        ),
        _divider(),

        _section('Sohbet Bazlı Ayarlar'),
        _contactNotifTiles(),

        const SizedBox(height: 32),
      ]),
    );
  }

  void _showSoundPicker() {
    final sounds = ['Varsayılan', 'Titreşim', 'Sessiz', 'Ding', 'Ping', 'Chime'];
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Bildirim Sesi', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        ...sounds.map((s) => RadioListTile<String>(
          value: s, groupValue: _defaultSound,
          title: Text(s, style: const TextStyle(color: Colors.white)),
          activeColor: ColorsManager.darkPrimary,
          onChanged: (v) {
            if (v != null) { setState(() => _defaultSound = v); _save('notif_sound', v); }
            Navigator.pop(context);
          },
        )),
        const SizedBox(height: 8),
      ])),
    );
  }

  Widget _contactNotifTiles() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).collection('contacts').snapshots(),
      builder: (ctx, snap) {
        if (!snap.hasData || snap.data!.docs.isEmpty)
          return const Padding(padding: EdgeInsets.all(16),
              child: Text('Kişi eklendikçe burada görünür', style: TextStyle(color: Colors.white24, fontSize: 13)));

        return Column(children: snap.data!.docs.map((doc) {
          final contactUid = (doc.data() as Map)['uid'] ?? doc.id;
          return FutureBuilder<DocumentSnapshot>(
            future: FirebaseFirestore.instance.collection('users').doc(contactUid).get(),
            builder: (_, uSnap) {
              final data = uSnap.data?.data() as Map<String, dynamic>?;
              if (data == null) return const ColoredBox(color: Color(0xFF0D0D0D), child: SizedBox.shrink());
              final name = data['name'] ?? '';
              return _ContactNotifRow(name: name, uid: contactUid);
            },
          );
        }).toList());
      },
    );
  }

  Widget _section(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 6),
    child: Text(title, style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 11.sp,
        fontWeight: FontWeight.w700, letterSpacing: 1.2)),
  );

  Widget _divider() => const Divider(height: 1, color: Colors.white10, indent: 56, endIndent: 16);

  Widget _switchRow(IconData icon, Color color, String title, String sub, bool value, Function(bool) onChange) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      leading: Container(padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 22)),
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500)),
      subtitle: Text(sub, style: const TextStyle(color: Colors.white38, fontSize: 12)),
      trailing: CupertinoSwitch(value: value, activeColor: ColorsManager.darkPrimary, onChanged: onChange),
    );
  }
}

class _ContactNotifRow extends StatefulWidget {
  final String name, uid;
  const _ContactNotifRow({required this.name, required this.uid});
  @override State<_ContactNotifRow> createState() => _ContactNotifRowState();
}

class _ContactNotifRowState extends State<_ContactNotifRow> {
  String _mode = 'Normal';

  @override
  Widget build(BuildContext context) {
    final modeColor = _mode == 'Sessiz' ? Colors.red : _mode == 'Titreşim' ? Colors.orange : Colors.green;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      leading: CircleAvatar(radius: 20, backgroundColor: const Color(0xFF2A2A2A),
          child: Text(widget.name.isNotEmpty ? widget.name[0].toUpperCase() : '?',
              style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold))),
      title: Text(widget.name, style: const TextStyle(color: Colors.white, fontSize: 15)),
      trailing: GestureDetector(
        onTap: () => _showModePicker(),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(color: modeColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20), border: Border.all(color: modeColor.withOpacity(0.4))),
          child: Text(_mode, style: TextStyle(color: modeColor, fontSize: 12, fontWeight: FontWeight.w600)),
        ),
      ),
    );
  }

  void _showModePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        Text(widget.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        ...['Normal', 'Titreşim', 'Sessiz'].map((m) => ListTile(
          leading: Icon(
            m == 'Sessiz' ? Icons.notifications_off_rounded :
            m == 'Titreşim' ? Icons.vibration_rounded : Icons.notifications_rounded,
            color: m == 'Sessiz' ? Colors.red : m == 'Titreşim' ? Colors.orange : Colors.green,
          ),
          title: Text(m, style: const TextStyle(color: Colors.white)),
          subtitle: Text(
            m == 'Sessiz' ? 'Hiç bildirim gelmesin' :
            m == 'Titreşim' ? 'Ses yok, sadece titreşim' : 'Ses ve titreşimle bildir',
            style: const TextStyle(color: Colors.white38, fontSize: 12),
          ),
          trailing: _mode == m ? Icon(Icons.check_rounded, color: ColorsManager.darkPrimary) : null,
          onTap: () { setState(() => _mode = m); Navigator.pop(context); },
        )),
        const SizedBox(height: 8),
      ])),
    );
  }
}
