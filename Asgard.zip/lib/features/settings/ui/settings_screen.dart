import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:local_auth/local_auth.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/widgets/modal_fit.dart';
import '../../../themes/colors.dart';
import '../../chat/ui/starred_messages_screen.dart';
import '../../profile/ui/qr_screen.dart';
import 'notification_settings_screen.dart';
import 'storage_screen.dart';
import 'account_switch_screen.dart';
import '../../channels/ui/channels_screen.dart';
import '../../tasks/ui/tasks_screen.dart';
import '../../chat/ui/ai_assistant_screen.dart';
import '../../chat/ui/secret_chat_page.dart';
import '../../../themes/styles.dart';
import 'account_settings_screen.dart';
import 'admin_notification_screen.dart';
import 'profile_settings_screen.dart';
import '../../../core/utils/font_size_provider.dart';

const bool keyAuthScreenDefaultValue = false;
const String keyAuthScreenEnabled = "auth_screen_enabled";

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isAuthScreenEnabled = false;
  bool _notificationsEnabled = true;
  bool _readReceiptsEnabled = true;
  bool _onlineStatusVisible = true;
  String _onlineVisibility = 'Herkes';
  bool _dataSaverEnabled = false;
  String _chatWallpaper = 'default';
  final LocalAuthentication auth = LocalAuthentication();
  late List<BiometricType> availableBiometric = [];
  Map<String, dynamic>? _userData;
  String _fontSize = 'Orta';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await auth.getAvailableBiometrics().then((v) => availableBiometric = v);
    });
    _loadPrefs();
    _loadUserData();
    _loadFontSize();
  }

  Future<void> _loadFontSize() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _fontSize = prefs.getString('fontSize') ?? 'Orta');
  }

  Future<void> _saveFontSize(String size) async {
    // ✅ FIX: FontSizeProvider üzerinden güncelle — tüm widget'lar haberdar olur
    await FontSizeProvider.instance.setFontSize(size);
    setState(() => _fontSize = size);
  }

    Future<void> _loadUserData() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    if (mounted) setState(() => _userData = doc.data());
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isAuthScreenEnabled = prefs.getBool(keyAuthScreenEnabled) ?? false;
      _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
      _readReceiptsEnabled = prefs.getBool('read_receipts_enabled') ?? true;
      _onlineStatusVisible = prefs.getBool('online_status_visible') ?? true;
      _onlineVisibility = prefs.getString('online_visibility') ?? 'Herkes';
      _dataSaverEnabled = prefs.getBool('data_saver') ?? false;
      _chatWallpaper = prefs.getString('chat_wallpaper') ?? 'default';
    });
  }

  Future<void> _setPref(String key, dynamic value) async {
    final prefs = await SharedPreferences.getInstance();
    if (value is bool) await prefs.setBool(key, value);
    if (value is String) await prefs.setString(key, value);
    // Firestore'a da kaydet (read receipts, online status)
    if (key == 'read_receipts_enabled' || key == 'online_status_visible') {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null) {
        await FirebaseFirestore.instance.collection('users').doc(uid).update({key: value});
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final name = _userData?['name'] ?? '';
    final photo = _userData?['profilePic'] ?? '';
    final bio = _userData?['bio'] ?? 'Hakkımda yazılmamış';

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Ayarlar', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: ListView(children: [

        // ── Profil Kartı ──────────────────────────────────────────────────
        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileSettingsScreen()))
              .then((_) => _loadUserData()),
          child: Container(
            margin: EdgeInsets.all(16.r),
            padding: EdgeInsets.all(16.r),
            decoration: BoxDecoration(
              color: const Color(0xFF111111),
              borderRadius: BorderRadius.circular(18.r),
              border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.25)),
              boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.08), blurRadius: 20)],
            ),
            child: Row(children: [
              Container(
                width: 64.w, height: 64.h,
                decoration: BoxDecoration(shape: BoxShape.circle,
                    border: Border.all(color: ColorsManager.darkPrimary, width: 2.5)),
                child: ClipOval(child: photo.isNotEmpty
                    ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover)
                    : Container(color: const Color(0xFF1A1A1A),
                        child: const Icon(Icons.person, size: 32, color: Colors.white38))),
              ),
              SizedBox(width: 14.w),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name.isNotEmpty ? name : 'İsim yok',
                    style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 4.h),
                Text(bio, style: const TextStyle(color: Colors.white54, fontSize: 13),
                    maxLines: 2, overflow: TextOverflow.ellipsis),
              ])),
              const Icon(Icons.edit_outlined, color: Colors.white24, size: 20),
            ]),
          ),
        ),

        // ── Hesap ─────────────────────────────────────────────────────────
        _sectionHeader('Hesap'),
        _tile(icon: Icons.manage_accounts_rounded, color: const Color(0xFFE53935),
            title: 'Hesap Ayarları', subtitle: 'E-posta, şifre, kullanıcı adı',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountSettingsScreen()))),
        _divider(),

        // ── Gizlilik ──────────────────────────────────────────────────────
        _sectionHeader('Gizlilik'),
        _switchTile(
          icon: Icons.done_all_rounded, color: Colors.blueAccent,
          title: 'Okundu Bilgisi', subtitle: 'Mesajlarınızın okunup okunmadığını göster',
          value: _readReceiptsEnabled,
          onChanged: (v) { setState(() => _readReceiptsEnabled = v); _setPref('read_receipts_enabled', v); },
        ),
        _divider(),
        _tile(
          icon: Icons.circle, color: Colors.green,
          title: 'Çevrimiçi Durumu',
          subtitle: _onlineVisibility,
          onTap: () => _showOnlineVisibilityPicker(),
        ),
        _divider(),

        // ── Bildirimler ────────────────────────────────────────────────────
        _sectionHeader('Bildirimler'),
        _switchTile(
          icon: Icons.notifications_outlined, color: Colors.orange,
          title: 'Bildirimler', subtitle: 'Mesaj ve grup bildirimlerini al',
          value: _notificationsEnabled,
          onChanged: (v) { setState(() => _notificationsEnabled = v); _setPref('notifications_enabled', v); },
        ),
        _divider(),
        _switchTile(
          icon: Icons.data_saver_on_outlined, color: Colors.teal,
          title: 'Veri Tasarrufu',
          subtitle: _dataSaverEnabled ? 'Açık — Medya otomatik yüklenmiyor' : 'Kapalı — Medya otomatik yükleniyor',
          value: _dataSaverEnabled,
          onChanged: (v) { setState(() => _dataSaverEnabled = v); _setPref('data_saver', v); },
        ),
        _divider(),

        // ── Görünüm ────────────────────────────────────────────────────────
        _sectionHeader('Görünüm'),
        _tile(icon: Icons.wallpaper_outlined, color: Colors.purple,
            title: 'Sohbet Duvarı Kağıdı',
            subtitle: _chatWallpaper == 'default' ? 'Varsayılan' : 'Özel',
            onTap: () => _showWallpaperPicker()),
        _divider(),
        _tile(icon: Icons.font_download_outlined, color: Colors.teal,
            title: 'Yazı Tipi Boyutu',
            subtitle: _fontSize,
            onTap: () => _showFontSizePicker()),
        _divider(),

        _tile(
          icon: Icons.star_rounded, color: Colors.amber,
          title: '⭐ Yıldızlı Mesajlar', subtitle: 'Kaydettiğin önemli mesajlar',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StarredMessagesScreen())),
        ),
        _divider(),
        _tile(
          icon: Icons.qr_code_rounded, color: Colors.green,
          title: 'QR Kodum', subtitle: 'Profil QR kodunu paylaş',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QRScreen())),
        ),
        _divider(),
        _tile(
          icon: Icons.switch_account_rounded, color: Colors.blue,
          title: 'Hesap Değiştir', subtitle: 'Farklı hesaba geç',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountSwitchScreen())),
        ),
        _divider(),
        _tile(
          icon: Icons.auto_awesome_rounded, color: Colors.purple,
          title: 'AI Asistan', subtitle: 'Gemini AI ile yazı yaz, çevir, özetle',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AIAssistantScreen())),
        ),
        _divider(),
        _tile(
          icon: Icons.broadcast_on_personal_rounded, color: Colors.teal,
          title: 'Kanallar', subtitle: 'Yayın kanallarını keşfet',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChannelsScreen())),
        ),
        _divider(),
        _tile(
          icon: Icons.task_alt_rounded, color: Colors.green,
          title: 'Görevlerim', subtitle: 'Hatırlatıcı ve yapılacaklar',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TasksScreen())),
        ),
        _divider(),
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Colors.orange.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.campaign_rounded, color: Colors.orange, size: 22),
          ),
          title: const Text('Admin Bildirim Paneli', style: TextStyle(color: Colors.white, fontSize: 15)),
          subtitle: const Text('Tüm kullanıcılara bildirim gönder', style: TextStyle(color: Colors.white38, fontSize: 12)),
          trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 14),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminNotificationScreen())),
        ),
        _divider(),

        // ── Güvenlik ──────────────────────────────────────────────────────
        _sectionHeader('Güvenlik'),
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Colors.amber.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.fingerprint, color: Colors.amber, size: 22),
          ),
          title: Text(context.tr('unlockApp'), style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500)),
          subtitle: Text(context.tr('unlockAppDesc'), style: const TextStyle(color: Colors.white38, fontSize: 12)),
          trailing: CupertinoSwitch(
            value: _isAuthScreenEnabled,
            activeColor: ColorsManager.darkPrimary,
            onChanged: (value) {
              setState(() {
                if (availableBiometric.isEmpty) {
                  AwesomeDialog(context: context, dialogType: DialogType.error,
                      animType: AnimType.topSlide, showCloseIcon: true,
                      closeIcon: const Icon(Icons.close_rounded),
                      title: context.tr('warning'), desc: context.tr('authNotSupported')).show();
                } else {
                  _isAuthScreenEnabled = value;
                  _setPref(keyAuthScreenEnabled, value);
                }
              });
            },
          ),
        ),
        _divider(),

        // ── Uygulama ─────────────────────────────────────────────────────
        _sectionHeader('Uygulama'),
        _tile(icon: Icons.language, color: Colors.blueGrey,
            title: context.tr('changeLanguage'), subtitle: 'Dil değiştir',
            onTap: () => showCupertinoModalBottomSheet(expand: false, context: context,
                backgroundColor: Colors.transparent, builder: (context) => const ModalFit())),
        _divider(),
        _tile(icon: Icons.storage_outlined, color: Colors.brown,
            title: 'Depolama ve Veri',
            subtitle: 'Önbellek, medya kullanımı',
            onTap: () => _showStorageInfo()),
        _divider(),
        _tile(icon: Icons.help_outline_rounded, color: Colors.blueAccent,
            title: 'Yardım & Geri Bildirim',
            subtitle: 'SSS, bize yazın',
            onTap: () => _showHelpSheet()),
        _divider(),
        _tile(icon: Icons.info_outline_rounded, color: Colors.white38,
            title: 'Hakkında',
            subtitle: 'Asgard v1.0.0',
            onTap: () => _showAboutDialog()),

        SizedBox(height: 32.h),
      ]),
    );
  }

  void _showOnlineVisibilityPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Çevrimiçi Durumu Göster', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 4),
        const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text('Çevrimiçi durumunuzu kimler görebilir?',
              style: TextStyle(color: Colors.white38, fontSize: 13), textAlign: TextAlign.center)),
        const SizedBox(height: 8),
        ...['Herkes', 'Kişilerim', 'Kimse'].map((opt) => RadioListTile<String>(
          value: opt, groupValue: _onlineVisibility,
          title: Text(opt, style: const TextStyle(color: Colors.white)),
          subtitle: Text(
            opt == 'Herkes' ? 'Tüm kullanıcılar görebilir' :
            opt == 'Kişilerim' ? 'Sadece kayıtlı kişileriniz' : 'Hiçbir kullanıcı göremez',
            style: const TextStyle(color: Colors.white38, fontSize: 12)),
          activeColor: ColorsManager.darkPrimary,
          onChanged: (v) async {
            if (v == null) return;
            setState(() => _onlineVisibility = v);
            await _setPref('online_visibility', v);
            final uid = FirebaseAuth.instance.currentUser?.uid;
            if (uid != null) await FirebaseFirestore.instance.collection('users').doc(uid)
                .update({'onlineVisibility': v});
            if (mounted) Navigator.pop(context);
          },
        )),
        const SizedBox(height: 8),
      ])),
    );
  }

  void _showWallpaperPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Sohbet Duvarı Kağıdı', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        SizedBox(height: 16.h),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: GridView.count(crossAxisCount: 4, shrinkWrap: true, crossAxisSpacing: 8, mainAxisSpacing: 8,
              children: [
                _wallpaperOption('default', Colors.transparent, Icons.grid_on),
                _wallpaperOption('dark', const Color(0xFF0D0D0D), Icons.nights_stay),
                _wallpaperOption('blue', Colors.blue.shade900, Icons.water),
                _wallpaperOption('red', Colors.red.shade900, Icons.local_fire_department),
              ]),
        ),
        SizedBox(height: 16.h),
      ])),
    );
  }

  Widget _wallpaperOption(String id, Color color, IconData icon) {
    final selected = _chatWallpaper == id;
    return GestureDetector(
      onTap: () { setState(() => _chatWallpaper = id); _setPref('chat_wallpaper', id); Navigator.pop(context); },
      child: Container(
        decoration: BoxDecoration(color: color == Colors.transparent ? const Color(0xFF111111) : color,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: selected ? ColorsManager.darkPrimary : Colors.white12, width: selected ? 2 : 1)),
        child: Icon(icon, color: selected ? ColorsManager.darkPrimary : Colors.white38),
      ),
    );
  }

  void _showFontSizePicker() {
    showModalBottomSheet(
      context: context, backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Yazı Tipi Boyutu', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        SizedBox(height: 8.h),
        ...['Küçük', 'Orta', 'Büyük', 'Çok Büyük'].map((s) {
          final double preview = s == 'Küçük' ? 12 : s == 'Orta' ? 15 : s == 'Büyük' ? 18 : 21;
          return RadioListTile<String>(
            value: s, groupValue: _fontSize,
            title: Row(children: [
              Text(s, style: const TextStyle(color: Colors.white)),
              const Spacer(),
              Text('Aa', style: TextStyle(color: Colors.white54, fontSize: preview)),
            ]),
            activeColor: ColorsManager.darkPrimary,
            onChanged: (val) async {
              await _saveFontSize(val!);
              if (mounted) Navigator.pop(context);
            },
          );
        }),
        SizedBox(height: 8.h),
      ])),
    );
  }

  void _showStorageInfo() {
    showModalBottomSheet(
      context: context, backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: Padding(
        padding: EdgeInsets.all(20.r),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const Text('Depolama & Veri', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
          SizedBox(height: 20.h),
          _storageRow(Icons.photo, 'Medya', '0 MB'),
          _storageRow(Icons.message, 'Mesajlar', '< 1 MB'),
          _storageRow(Icons.cached, 'Önbellek', '0 MB'),
          SizedBox(height: 16.h),
          SizedBox(width: double.infinity, child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade800,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () { Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önbellek temizlendi'))); },
            child: const Text('Önbelleği Temizle', style: TextStyle(color: Colors.white)),
          )),
        ]),
      )),
    );
  }

  Widget _storageRow(IconData icon, String label, String size) => Padding(
    padding: EdgeInsets.symmetric(vertical: 8.h),
    child: Row(children: [
      Icon(icon, color: ColorsManager.darkPrimary, size: 20),
      SizedBox(width: 12.w),
      Text(label, style: const TextStyle(color: Colors.white70)),
      const Spacer(),
      Text(size, style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.w600)),
    ]),
  );

  void _showHelpSheet() {
    showModalBottomSheet(
      context: context, backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Yardım & Geri Bildirim', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        SizedBox(height: 8.h),
        ListTile(leading: Icon(Icons.question_answer_outlined, color: ColorsManager.darkPrimary),
            title: const Text('Sık Sorulan Sorular', style: TextStyle(color: Colors.white)),
            onTap: () => Navigator.pop(context)),
        ListTile(leading: Icon(Icons.mail_outline, color: ColorsManager.darkPrimary),
            title: const Text('Bize Yazın', style: TextStyle(color: Colors.white)),
            subtitle: const Text('destek@asgard.app', style: TextStyle(color: Colors.white38, fontSize: 12)),
            onTap: () => Navigator.pop(context)),
        ListTile(leading: const Icon(Icons.bug_report_outlined, color: Colors.orange),
            title: const Text('Hata Bildir', style: TextStyle(color: Colors.white)),
            onTap: () => Navigator.pop(context)),
        SizedBox(height: 8.h),
      ])),
    );
  }

  void _showAboutDialog() {
    showAboutDialog(
      context: context,
      applicationName: 'Asgard',
      applicationVersion: '1.0.0',
      applicationLegalese: '© 2025 Asgard. Tüm hakları saklıdır.',
    );
  }

  // ── Yardımcı widget'lar ────────────────────────────────────────────────────
  Widget _sectionHeader(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 6),
    child: Text(title, style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 11.sp,
        fontWeight: FontWeight.w700, letterSpacing: 1.2)),
  );

  Widget _divider() => const Divider(height: 1, color: Colors.white10, indent: 56, endIndent: 16);

  Widget _tile({required IconData icon, required Color color, required String title,
      required String subtitle, required VoidCallback onTap}) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      leading: Container(padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 22)),
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500)),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white38, fontSize: 12)),
      trailing: const Icon(Icons.chevron_right_rounded, color: Colors.white24),
      onTap: onTap,
    );
  }

  Widget _switchTile({required IconData icon, required Color color, required String title,
      required String subtitle, required bool value, required ValueChanged<bool> onChanged}) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      leading: Container(padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 22)),
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500)),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white38, fontSize: 12)),
      trailing: CupertinoSwitch(value: value, activeColor: ColorsManager.darkPrimary, onChanged: onChanged),
    );
  }
}
