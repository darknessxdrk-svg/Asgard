import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../themes/colors.dart';

class AccountSwitchScreen extends StatefulWidget {
  const AccountSwitchScreen({super.key});
  @override State<AccountSwitchScreen> createState() => _AccountSwitchScreenState();
}

class _AccountSwitchScreenState extends State<AccountSwitchScreen> {
  List<Map<String, dynamic>> _savedAccounts = [];
  bool _loading = false;
  final _currentUid = FirebaseAuth.instance.currentUser?.uid;

  @override
  void initState() {
    super.initState();
    _loadSavedAccounts();
  }

  Future<void> _loadSavedAccounts() async {
    final prefs = await SharedPreferences.getInstance();
    final emails = prefs.getStringList('saved_account_emails') ?? [];
    final List<Map<String, dynamic>> accounts = [];
    for (final email in emails) {
      final query = await FirebaseFirestore.instance.collection('users')
          .where('email', isEqualTo: email).limit(1).get();
      if (query.docs.isNotEmpty) {
        accounts.add({...query.docs.first.data(), 'email': email});
      }
    }
    // Mevcut hesabı her zaman en üstte göster
    final current = await FirebaseFirestore.instance.collection('users').doc(_currentUid).get();
    if (current.exists) {
      final currentData = {...current.data()!, 'isCurrent': true};
      accounts.removeWhere((a) => a['uid'] == _currentUid);
      accounts.insert(0, currentData);
    }
    if (mounted) setState(() => _savedAccounts = accounts);
  }

  Future<void> _switchAccount(Map<String, dynamic> account) async {
    if (account['uid'] == _currentUid) return;
    setState(() => _loading = true);
    await FirebaseAuth.instance.signOut();
    if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/loginScreen', (_) => false);
  }

  Future<void> _addAccount() async {
    await FirebaseAuth.instance.signOut();
    if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/loginScreen', (_) => false);
  }

  Future<void> _removeAccount(String email) async {
    final prefs = await SharedPreferences.getInstance();
    final emails = prefs.getStringList('saved_account_emails') ?? [];
    emails.remove(email);
    await prefs.setStringList('saved_account_emails', emails);
    _loadSavedAccounts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Hesap Değiştir', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary))
          : ListView(children: [
              Padding(padding: EdgeInsets.fromLTRB(16.w, 20.h, 16.w, 8.h),
                  child: Text('Hesaplar', style: TextStyle(color: Colors.white38, fontSize: 12.sp, fontWeight: FontWeight.w600))),

              ..._savedAccounts.map((acc) {
                final isCurrent = acc['uid'] == _currentUid;
                final name = acc['name'] ?? 'Kullanıcı';
                final email = acc['email'] ?? '';
                final photo = acc['profilePic'] ?? '';
                return Dismissible(
                  key: Key(email),
                  direction: isCurrent ? DismissDirection.none : DismissDirection.endToStart,
                  background: Container(color: Colors.red, alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 20),
                      child: const Icon(Icons.delete_outline, color: Colors.white)),
                  onDismissed: (_) => _removeAccount(email),
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: isCurrent ? ColorsManager.darkPrimary.withOpacity(0.1) : const Color(0xFF111111),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: isCurrent ? ColorsManager.darkPrimary.withOpacity(0.4) : Colors.white10),
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
                      leading: Stack(children: [
                        CircleAvatar(radius: 26,
                            backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                            backgroundColor: const Color(0xFF2A2A2A),
                            child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white38) : null),
                        if (isCurrent) Positioned(bottom: 0, right: 0,
                            child: Container(width: 14, height: 14,
                                decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0xFF111111), width: 2)))),
                      ]),
                      title: Row(children: [
                        Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                        if (isCurrent) ...[
                          const SizedBox(width: 8),
                          Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(color: ColorsManager.darkPrimary.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(8)),
                              child: Text('Aktif', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 10, fontWeight: FontWeight.bold))),
                        ],
                      ]),
                      subtitle: Text(email, style: const TextStyle(color: Colors.white38, fontSize: 12)),
                      trailing: isCurrent
                          ? null
                          : Icon(Icons.swap_horiz_rounded, color: ColorsManager.darkPrimary),
                      onTap: isCurrent ? null : () => _switchAccount(acc),
                    ),
                  ),
                );
              }),

              // Hesap ekle butonu
              Padding(
                padding: EdgeInsets.all(16.w),
                child: OutlinedButton.icon(
                  icon: Icon(Icons.add_rounded, color: ColorsManager.darkPrimary),
                  label: Text('Başka Hesap Ekle', style: TextStyle(color: ColorsManager.darkPrimary)),
                  style: OutlinedButton.styleFrom(
                      side: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.5)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: EdgeInsets.symmetric(vertical: 14.h)),
                  onPressed: _addAccount,
                ),
              ),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Container(padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.03),
                        borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white10)),
                    child: Row(children: [
                      const Icon(Icons.info_outline, color: Colors.white24, size: 16),
                      const SizedBox(width: 8),
                      const Expanded(child: Text('Hesap eklemek için mevcut hesaptan çıkış yapılır.',
                          style: TextStyle(color: Colors.white24, fontSize: 12))),
                    ])),
              ),
              SizedBox(height: 32.h),
            ]),
    );
  }
}
