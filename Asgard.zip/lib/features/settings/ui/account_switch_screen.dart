import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../themes/colors.dart';

class AccountSwitchScreen extends StatefulWidget {
  const AccountSwitchScreen({super.key});
  @override State<AccountSwitchScreen> createState() => _AccountSwitchScreenState();
}

class _AccountSwitchScreenState extends State<AccountSwitchScreen> {
  List<Map<String, dynamic>> _savedAccounts = [];
  bool _loading = false;
  final _currentUid = FirebaseAuth.instance.currentUser?.uid;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadSavedAccounts());
  }

  Future<void> _loadSavedAccounts() async {
    final prefs = await SharedPreferences.getInstance();
    final emails = prefs.getStringList('saved_account_emails') ?? [];
    final uids = prefs.getStringList('saved_account_uids') ?? [];
    final List<Map<String, dynamic>> accounts = [];

    // UID ile çek (daha güvenilir)
    for (int i = 0; i < uids.length; i++) {
      final uid = uids[i];
      if (uid == _currentUid) continue; // aktif hesabı aşağıda ekleyeceğiz
      try {
        final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
        if (doc.exists) {
          accounts.add({...doc.data()!, 'uid': uid});
        }
      } catch (_) {
        // UID bulunamazsa email ile dene
        if (i < emails.length) {
          final query = await FirebaseFirestore.instance.collection('users')
              .where('email', isEqualTo: emails[i]).limit(1).get();
          if (query.docs.isNotEmpty) {
            accounts.add({...query.docs.first.data()});
          }
        }
      }
    }

    // Mevcut hesabı her zaman en üstte göster
    final current = await FirebaseFirestore.instance.collection('users').doc(_currentUid).get();
    if (current.exists) {
      final currentData = {...current.data()!, 'isCurrent': true, 'uid': _currentUid};
      accounts.removeWhere((a) => a['uid'] == _currentUid);
      accounts.insert(0, currentData);
    }
    if (mounted) setState(() => _savedAccounts = accounts);
  }

  Future<void> _saveCurrentAccount() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    final prefs = await SharedPreferences.getInstance();

    final emails = prefs.getStringList('saved_account_emails') ?? [];
    if (currentUser.email != null && !emails.contains(currentUser.email)) {
      emails.add(currentUser.email!);
      await prefs.setStringList('saved_account_emails', emails);
    }

    final uids = prefs.getStringList('saved_account_uids') ?? [];
    if (!uids.contains(currentUser.uid)) {
      uids.add(currentUser.uid);
      await prefs.setStringList('saved_account_uids', uids);
    }
  }

  Future<void> _switchAccount(Map<String, dynamic> account) async {
    if (account['uid'] == _currentUid) return;
    final email = account['email'] as String? ?? '';
    if (email.isEmpty) return;

    // Şifre sor
    final passCtrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Text('${account['name'] ?? email}',
            style: const TextStyle(color: Colors.white, fontSize: 16)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(email, style: const TextStyle(color: Colors.white38, fontSize: 13)),
          const SizedBox(height: 16),
          TextField(
            controller: passCtrl,
            obscureText: true,
            autofocus: true,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Şifre',
              hintStyle: const TextStyle(color: Colors.white24),
              filled: true,
              fillColor: const Color(0xFF0D0D0D),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: ColorsManager.darkPrimary)),
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('Geçiş Yap',
                style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirmed != true || passCtrl.text.isEmpty) return;
    setState(() => _loading = true);

    try {
      await _saveCurrentAccount();
      await FirebaseAuth.instance.signOut();
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: passCtrl.text,
      );
      if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/homeScreen', (_) => false);
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(e.code == 'wrong-password' ? 'Şifre yanlış' : 'Giriş başarısız: ${e.message}'),
        backgroundColor: Colors.red,
      ));
    }
  }

  Future<void> _addAccount() async {
    await _saveCurrentAccount();
    await FirebaseAuth.instance.signOut();
    if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/loginScreen', (_) => false);
  }

  Future<void> _removeAccount(String uid) async {
    final prefs = await SharedPreferences.getInstance();
    final uids = prefs.getStringList('saved_account_uids') ?? [];
    uids.remove(uid);
    await prefs.setStringList('saved_account_uids', uids);
    // Email listesini de temizle
    final acc = _savedAccounts.firstWhere((a) => a['uid'] == uid, orElse: () => {});
    if (acc['email'] != null) {
      final emails = prefs.getStringList('saved_account_emails') ?? [];
      emails.remove(acc['email']);
      await prefs.setStringList('saved_account_emails', emails);
    }
    _loadSavedAccounts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Hesap Değiştir', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary))
          : ListView(children: [
              Padding(padding: EdgeInsets.fromLTRB(16.w, 20.h, 16.w, 8.h),
                  child: Text('Hesaplar', style: TextStyle(color: Colors.white38, fontSize: 12.sp, fontWeight: FontWeight.w600))),

              ..._savedAccounts.map((acc) {
                final isCurrent = acc['uid'] == _currentUid;
                final name = acc['name'] ?? 'Kullanıcı';
                final email = acc['email'] ?? '';
                final photo = acc['profilePic'] ?? '';
                return Dismissible(
                  key: Key(email),
                  direction: isCurrent ? DismissDirection.none : DismissDirection.endToStart,
                  background: Container(color: Colors.red, alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 20),
                      child: const Icon(Icons.delete_outline, color: Colors.white)),
                  onDismissed: (_) => _removeAccount(acc['uid'] ?? ''),
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: isCurrent ? ColorsManager.darkPrimary.withOpacity(0.1) : const Color(0xFF111111),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: isCurrent ? ColorsManager.darkPrimary.withOpacity(0.4) : Colors.white10),
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
                      leading: Stack(children: [
                        CircleAvatar(radius: 26,
                            backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                            backgroundColor: const Color(0xFF2A2A2A),
                            child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white38) : null),
                        if (isCurrent) Positioned(bottom: 0, right: 0,
                            child: Container(width: 14, height: 14,
                                decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0xFF111111), width: 2)))),
                      ]),
                      title: Row(children: [
                        Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                        if (isCurrent) ...[
                          const SizedBox(width: 8),
                          Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(color: ColorsManager.darkPrimary.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(8)),
                              child: Text('Aktif', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 10, fontWeight: FontWeight.bold))),
                        ],
                      ]),
                      subtitle: Text(email, style: const TextStyle(color: Colors.white38, fontSize: 12)),
                      trailing: isCurrent
                          ? null
                          : Icon(Icons.swap_horiz_rounded, color: ColorsManager.darkPrimary),
                      onTap: isCurrent ? null : () => _switchAccount(acc),
                    ),
                  ),
                );
              }),

              // Hesap ekle butonu
              Padding(
                padding: EdgeInsets.all(16.w),
                child: OutlinedButton.icon(
                  icon: Icon(Icons.add_rounded, color: ColorsManager.darkPrimary),
                  label: Text('Başka Hesap Ekle', style: TextStyle(color: ColorsManager.darkPrimary)),
                  style: OutlinedButton.styleFrom(
                      side: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.5)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: EdgeInsets.symmetric(vertical: 14.h)),
                  onPressed: _addAccount,
                ),
              ),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Container(padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.03),
                        borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white10)),
                    child: Row(children: [
                      const Icon(Icons.info_outline, color: Colors.white24, size: 16),
                      const SizedBox(width: 8),
                      const Expanded(child: Text('Hesap eklemek için mevcut hesaptan çıkış yapılır.',
                          style: TextStyle(color: Colors.white24, fontSize: 12))),
                    ])),
              ),
              SizedBox(height: 32.h),
            ]),
    );
  }
}
