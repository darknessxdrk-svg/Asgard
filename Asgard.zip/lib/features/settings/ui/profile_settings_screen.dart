import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';

import '../../../services/cloudinary_service.dart';
import '../../../themes/colors.dart';

class ProfileSettingsScreen extends StatefulWidget {
  const ProfileSettingsScreen({super.key});
  @override State<ProfileSettingsScreen> createState() => _ProfileSettingsScreenState();
}

class _ProfileSettingsScreenState extends State<ProfileSettingsScreen> {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;
  final _nameCtrl = TextEditingController();
  final _bioCtrl = TextEditingController();
  bool _loading = true;
  bool _saving = false;
  bool _uploadingPhoto = false;
  String _photoUrl = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final doc = await _firestore.collection('users').doc(_auth.currentUser?.uid).get();
    final data = doc.data() ?? {};
    if (mounted) setState(() {
      _nameCtrl.text = data['name'] ?? '';
      _bioCtrl.text = data['bio'] ?? '';
      _photoUrl = data['profilePic'] ?? '';
      _loading = false;
    });
  }

  Future<void> _changePhoto() async {
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(
          leading: const Icon(Icons.photo_library_outlined, color: ColorsManager.darkPrimary),
          title: const Text('Galeriden Seç', style: TextStyle(color: Colors.white)),
          onTap: () => Navigator.pop(context, ImageSource.gallery),
        ),
        ListTile(
          leading: const Icon(Icons.camera_alt_outlined, color: ColorsManager.darkPrimary),
          title: const Text('Kamera', style: TextStyle(color: Colors.white)),
          onTap: () => Navigator.pop(context, ImageSource.camera),
        ),
        if (_photoUrl.isNotEmpty)
          ListTile(
            leading: const Icon(Icons.delete_outline, color: Colors.red),
            title: const Text('Fotoğrafı Kaldır', style: TextStyle(color: Colors.red)),
            onTap: () async {
              Navigator.pop(context);
              await _firestore.collection('users').doc(_auth.currentUser?.uid).update({'profilePic': ''});
              await _auth.currentUser?.updatePhotoURL('');
              if (mounted) setState(() => _photoUrl = '');
              _snack('Fotoğraf kaldırıldı');
            },
          ),
      ])),
    );
    if (src == null) return;
    final picked = await ImagePicker().pickImage(source: src, imageQuality: 80);
    if (picked == null) return;
    if (mounted) setState(() => _uploadingPhoto = true);
    try {
    final url = await CloudinaryService.uploadImage(picked.path);
    } catch (e) {
      debugPrint("[Upload] $e");
    }
    if (url != null) {
      await _firestore.collection('users').doc(_auth.currentUser?.uid).update({'profilePic': url});
      await _auth.currentUser?.updatePhotoURL(url);
      if (mounted) setState(() => _photoUrl = url);
      _snack('Fotoğraf güncellendi ✓');
    } else {
      _snack('Yükleme başarısız', error: true);
    }
    if (!mounted) return;
    setState(() => _uploadingPhoto = false);
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    final bio = _bioCtrl.text.trim();
    if (name.isEmpty) { _snack('İsim boş olamaz', error: true); return; }
    setState(() => _saving = true);
    await _firestore.collection('users').doc(_auth.currentUser?.uid).update({
      'name': name,
      'bio': bio,
    });
    await _auth.currentUser?.updateDisplayName(name);
    if (mounted) setState(() => _saving = false);
    _snack('Profil kaydedildi ✓');
  }

  void _snack(String msg, {bool error = false}) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), backgroundColor: error ? Colors.red : ColorsManager.darkPrimary));

  @override
  void dispose() {
    _nameCtrl.dispose();
    _bioCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Profil', style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          _saving
              ? const Padding(padding: EdgeInsets.all(16),
                  child: SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: ColorsManager.darkPrimary)))
              : TextButton(onPressed: _save,
                  child: const Text('Kaydet', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold))),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary))
          : ListView(children: [
              // ── Profil fotoğrafı ──
              Center(
                child: Padding(
                  padding: EdgeInsets.all(24.r),
                  child: GestureDetector(
                    onTap: _changePhoto,
                    child: Stack(alignment: Alignment.bottomRight, children: [
                      Container(
                        width: 100.w, height: 100.w,
                        decoration: BoxDecoration(shape: BoxShape.circle,
                            border: Border.all(color: ColorsManager.darkPrimary, width: 3)),
                        child: ClipOval(
                          child: _uploadingPhoto
                              ? Container(color: Colors.black54,
                                  child: const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary, strokeWidth: 2)))
                              : _photoUrl.isNotEmpty
                                  ? CachedNetworkImage(imageUrl: _photoUrl, fit: BoxFit.cover)
                                  : Container(color: const Color(0xFF1A1A1A),
                                      child: const Icon(Icons.person, size: 50, color: Colors.white38)),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(7),
                        decoration: BoxDecoration(color: ColorsManager.darkPrimary, shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFF0D0D0D), width: 2.5)),
                        child: const Icon(Icons.camera_alt, size: 14, color: Colors.white),
                      ),
                    ]),
                  ),
                ),
              ),

              _sectionHeader('Temel Bilgiler'),

              // ── İsim ──
              _fieldTile(
                icon: Icons.person_outline_rounded,
                label: 'Ad Soyad',
                child: TextField(
                  controller: _nameCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  decoration: _inputDeco('Adınızı girin'),
                ),
              ),

              const Divider(height: 1, color: Colors.white10, indent: 56, endIndent: 16),

              // ── Hakkımda ──
              _fieldTile(
                icon: Icons.info_outline_rounded,
                label: 'Hakkımda',
                child: TextField(
                  controller: _bioCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  maxLines: 3,
                  maxLength: 150,
                  decoration: _inputDeco('Kendinizi tanıtın...'),
                ),
              ),

              SizedBox(height: 24.h),
              _sectionHeader('Öneri Seçenekler'),

              // Hızlı bio seçenekleri
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Wrap(spacing: 8, runSpacing: 8,
                  children: [
                    '🤫 Meşgul',
                    '🟢 Müsaitim',
                    '🎵 Müzik dinliyorum',
                    '😴 Uyuyorum',
                    '🚗 Yoldayım',
                    '📵 Rahatsız etmeyin',
                  ].map((s) => GestureDetector(
                    onTap: () => setState(() => _bioCtrl.text = s),
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 8.h),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1A1A1A),
                        borderRadius: BorderRadius.circular(20.r),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: Text(s, style: TextStyle(color: Colors.white70, fontSize: 12.sp)),
                    ),
                  )).toList(),
                ),
              ),
              SizedBox(height: 32.h),
            ]),
    );
  }

  Widget _sectionHeader(String t) => Padding(
    padding: EdgeInsets.fromLTRB(16.w, 8.h, 16.w, 6.h),
    child: Text(t, style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 11.sp,
        fontWeight: FontWeight.w700, letterSpacing: 1.2)),
  );

  Widget _fieldTile({required IconData icon, required String label, required Widget child}) =>
    Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: EdgeInsets.only(top: 12.h),
            child: Icon(icon, color: ColorsManager.darkPrimary, size: 22)),
        SizedBox(width: 14.w),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(color: Colors.white38, fontSize: 11.sp)),
          SizedBox(height: 4.h),
          child,
        ])),
      ]),
    );

  InputDecoration _inputDeco(String hint) => InputDecoration(
    hintText: hint,
    hintStyle: const TextStyle(color: Colors.white24),
    border: InputBorder.none,
    enabledBorder: InputBorder.none,
    focusedBorder: InputBorder.none,
    filled: false,
    isDense: true,
    contentPadding: EdgeInsets.zero,
    counterStyle: const TextStyle(color: Colors.white24),
  );
}
