import '../../../core/utils/string_ext.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../services/database.dart';
import '../../../themes/colors.dart';

class AccountSettingsScreen extends StatefulWidget {
  const AccountSettingsScreen({super.key});

  @override
  State<AccountSettingsScreen> createState() => _AccountSettingsScreenState();
}

class _AccountSettingsScreenState extends State<AccountSettingsScreen> {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  String _username = '';
  String _email = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadUserData());
  }

  Future<void> _loadUserData() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final doc = await _firestore.collection('users').doc(uid).get();
    if (mounted) {
      if (mounted) setState(() {
        _username = doc.data()?['username'] ?? '';
        _email = _auth.currentUser?.email ?? '';
        _loading = false;
      });
    }
  }

  // ── Kullanıcı adı değiştir ──────────────────────────────────────────────
  void _changeUsername() {
    final ctrl = TextEditingController(text: _username);
    String? errorText;
    bool checking = false;
    bool? available; // null=kontrol yok, true=müsait, false=alınmış

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: const Text('Kullanıcı Adını Değiştir',
              style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: ctrl,
                style: const TextStyle(color: Colors.white),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9_]')),
                  LengthLimitingTextInputFormatter(20),
                ],
                onChanged: (val) async {
                  final v = val.trim().toLowerCase();
                  if (v.length < 3 || v == _username) {
                    setS(() { available = null; errorText = null; });
                    return;
                  }
                  setS(() { checking = true; available = null; errorText = null; });
                  await Future.delayed(const Duration(milliseconds: 600));
                  if (ctrl.text.trim().toLowerCase() != v) return;
                  try {
                    final q = await _firestore.collection('users')
                        .where('username', isEqualTo: v).limit(1).get();
                    if (q.docs.isEmpty) return;
                    final taken = q.docs.isNotEmpty && q.docs.first.id != _auth.currentUser?.uid;
                    setS(() {
                      checking = false;
                      available = !taken;
                      errorText = taken ? 'Bu kullanıcı adı alınmış' : null;
                    });
                  } catch (_) {
                    setS(() { checking = false; });
                  }
                },
                decoration: InputDecoration(
                  prefixText: '@',
                  prefixStyle: TextStyle(color: ColorsManager.darkPrimary),
                  hintText: 'yeni_kullanici_adi',
                  hintStyle: const TextStyle(color: Colors.white38),
                  errorText: errorText,
                  suffixIcon: checking
                      ? const SizedBox(width: 20, height: 20,
                          child: Padding(padding: EdgeInsets.all(12),
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white54)))
                      : available == null ? null
                      : Icon(available! ? Icons.check_circle_rounded : Icons.cancel_rounded,
                          color: available! ? Colors.green : Colors.red),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: available == null ? Colors.white24
                           : available! ? Colors.green.withOpacity(0.6)
                           : Colors.red.withOpacity(0.6),
                      width: 1.5,
                    ),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: available == null ? ColorsManager.darkPrimary
                           : available! ? Colors.green
                           : Colors.red,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.red),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  focusedErrorBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.red),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                ),
              ),
              if (available == true)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Row(children: [
                    Icon(Icons.check_circle_outline, color: Colors.green, size: 14),
                    SizedBox(width: 4),
                    Text('Bu kullanıcı adı müsait!',
                        style: TextStyle(color: Colors.green, fontSize: 12)),
                  ]),
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white54)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: ColorsManager.darkPrimary),
              onPressed: () async {
                final newUsername = ctrl.text.trim().toLowerCase();
                final regex = RegExp(r'^[a-z0-9_]{3,20}$');
                if (!regex.hasMatch(newUsername)) {
                  setS(() => errorText = '3-20 karakter, harf/rakam/_');
                  return;
                }
                setS(() { checking = true; errorText = null; });

                // Müsaitlik kontrolü (usernames koleksiyonu + users koleksiyonu)
                final isAvail = await DatabaseMethods.isUsernameAvailable(newUsername);
                final currentUid = _auth.currentUser?.uid ?? '';
                // Kendi mevcut adı ise geç
                if (!isAvail && newUsername != _username) {
                  setS(() { checking = false; errorText = 'Bu kullanıcı adı alınmış'; });
                  return;
                }

                // Yeni kullanıcı adını atomik olarak rezerve et
                final ok = await DatabaseMethods.reserveUsername(newUsername, _auth.currentUser?.uid ?? '');
                if (!ok) {
                  setS(() { checking = false; errorText = 'Bu kullanıcı adı az önce alındı, tekrar deneyin'; });
                  return;
                }
                // Eski kullanıcı adını serbest bırak
                if (_username.isNotEmpty) {
                  await DatabaseMethods.releaseUsername(_username);
                }
                await _firestore
                    .collection('users')
                    .doc(_auth.currentUser?.uid)
                    .update({'username': newUsername});

                if (mounted) {
                  setState(() => _username = newUsername);
                  Navigator.pop(ctx);
                  _showSnack('Kullanıcı adı güncellendi ✓');
                }
              },
              child: const Text('Kaydet'),
            ),
          ],
        ),
      ),
    );
  }

  // ── E-posta değiştir ────────────────────────────────────────────────────
  void _changeEmail() {
    final emailCtrl = TextEditingController(text: _email);
    final passCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('E-postayı Değiştir',
            style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _dialogField(emailCtrl, 'Yeni e-posta', Icons.email_outlined),
            const SizedBox(height: 12),
            _dialogField(passCtrl, 'Mevcut şifre', Icons.lock_outline,
                obscure: true),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child:
                const Text('İptal', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: ColorsManager.darkPrimary),
            onPressed: () async {
              try {
                final user = _auth.currentUser!;
                final cred = EmailAuthProvider.credential(
                    email: user.email!, password: passCtrl.text);
                await user.reauthenticateWithCredential(cred);
                await user.verifyBeforeUpdateEmail(emailCtrl.text.trim());
                if (mounted) {
                  Navigator.pop(ctx);
                  _showSnack(
                      'Doğrulama e-postası gönderildi. Onaylayınca güncellenir.');
                }
              } on FirebaseAuthException catch (e) {
                if (mounted) {
                  Navigator.pop(ctx);
                  _showSnack(_authError(e.code), error: true);
                }
              }
            },
            child: const Text('Güncelle'),
          ),
        ],
      ),
    );
  }

  // ── Şifre değiştir ──────────────────────────────────────────────────────
  void _changePassword() {
    final oldCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          String? error;
          return AlertDialog(
            backgroundColor: const Color(0xFF1A1A1A),
            title: const Text('Şifre Değiştir',
                style: TextStyle(color: Colors.white)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(oldCtrl, 'Mevcut şifre', Icons.lock_outline,
                    obscure: true),
                const SizedBox(height: 12),
                _dialogField(newCtrl, 'Yeni şifre', Icons.lock_open_outlined,
                    obscure: true),
                const SizedBox(height: 12),
                _dialogField(
                    confirmCtrl, 'Yeni şifre tekrar', Icons.lock_open_outlined,
                    obscure: true),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(error!,
                        style: const TextStyle(color: Colors.red, fontSize: 12)),
                  ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('İptal',
                    style: TextStyle(color: Colors.white54)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: ColorsManager.darkPrimary),
                onPressed: () async {
                  if (newCtrl.text != confirmCtrl.text) {
                    setS(() => error = 'Şifreler eşleşmiyor');
                    return;
                  }
                  if (newCtrl.text.length < 6) {
                    setS(() => error = 'Şifre en az 6 karakter olmalı');
                    return;
                  }
                  try {
                    final user = _auth.currentUser!;
                    final cred = EmailAuthProvider.credential(
                        email: user.email!, password: oldCtrl.text);
                    await user.reauthenticateWithCredential(cred);
                    await user.updatePassword(newCtrl.text);
                    if (mounted) {
                      Navigator.pop(ctx);
                      _showSnack('Şifre güncellendi ✓');
                    }
                  } on FirebaseAuthException catch (e) {
                    setS(() => error = _authError(e.code));
                  }
                },
                child: const Text('Değiştir'),
              ),
            ],
          );
        },
      ),
    );
  }

  // ── Hesabı sil ──────────────────────────────────────────────────────────
  void _deleteAccount() {
    final passCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Hesabı Sil',
            style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Bu işlem geri alınamaz. Tüm veriler silinecek.',
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 16),
            _dialogField(passCtrl, 'Şifrenizi girin', Icons.lock_outline,
                obscure: true),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child:
                const Text('İptal', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              try {
                final user = _auth.currentUser!;
                final uid = user.uid;

                // 1. Yeniden kimlik doğrula
                final cred = EmailAuthProvider.credential(
                    email: user.email!, password: passCtrl.text);
                await user.reauthenticateWithCredential(cred);

                // FIX #6a: Username rezervasyonunu sil
                if (_username.isNotEmpty) {
                  await DatabaseMethods.releaseUsername(_username);
                }

                // FIX #6b: FCM token'ı temizle — başkası bildirim almasın
                await _firestore.collection('users').doc(uid).update({
                  'mtoken': FieldValue.delete(),
                  'isOnline': false,
                });

                // FIX #6c: Contacts subcollection'ı sil
                final contacts = await _firestore
                    .collection('users')
                    .doc(uid)
                    .collection('contacts')
                    .get();
                if (contacts.docs.isNotEmpty) {
                  final batch = _firestore.batch();
                  for (final c in contacts.docs) {
                    batch.delete(c.reference);
                  }
                  await batch.commit();
                }

                // FIX #6d: Starred messages subcollection'ı sil
                final starred = await _firestore
                    .collection('users')
                    .doc(uid)
                    .collection('starred')
                    .get();
                if (starred.docs.isNotEmpty) {
                  final batch = _firestore.batch();
                  for (final s in starred.docs) {
                    batch.delete(s.reference);
                  }
                  await batch.commit();
                }

                // FIX #6e: Ana user dokümanını sil
                await _firestore.collection('users').doc(uid).delete();

                // FIX #6f: Firebase Auth hesabını sil (en son)
                await user.delete();

                if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
              } on FirebaseAuthException catch (e) {
                if (mounted) {
                  Navigator.pop(ctx);
                  _showSnack(_authError(e.code), error: true);
                }
              } catch (e) {
                if (mounted) {
                  Navigator.pop(ctx);
                  _showSnack('Silme sırasında hata: $e', error: true);
                }
              }
            },
            child: const Text('Hesabı Sil'),
          ),
        ],
      ),
    );
  }

  // ── Yardımcılar ─────────────────────────────────────────────────────────
  Widget _dialogField(TextEditingController ctrl, String hint, IconData icon,
      {bool obscure = false}) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white38),
        prefixIcon: Icon(icon, color: Colors.white38, size: 20),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.white24),
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: ColorsManager.darkPrimary),
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  String _authError(String code) {
    switch (code) {
      case 'wrong-password': return 'Şifre yanlış';
      case 'too-many-requests': return 'Çok fazla deneme, bekle';
      case 'email-already-in-use': return 'Bu e-posta zaten kullanımda';
      case 'invalid-email': return 'Geçersiz e-posta';
      default: return 'Bir hata oluştu: $code';
    }
  }

  void _showSnack(String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? Colors.red : ColorsManager.darkPrimary,
    ));
  }

  // ── UI ──────────────────────────────────────────────────────────────────
  @override
  void dispose() {
    ctrl.dispose();
    newCtrl.dispose();
    emailCtrl.dispose();
    passCtrl.dispose();
    confirmCtrl.dispose();
    oldCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D0D),
        title: const Text('Hesap', style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: ColorsManager.darkPrimary.withOpacity(0.3),
          ),
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: ColorsManager.darkPrimary))
          : ListView(
              children: [
                // Profil özeti
                Container(
                  margin: EdgeInsets.all(16.r),
                  padding: EdgeInsets.all(16.r),
                  decoration: BoxDecoration(
                    color: const Color(0xFF111111),
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 28.r,
                        backgroundColor: ColorsManager.darkPrimary.withOpacity(0.2),
                        child: Icon(Icons.person, color: ColorsManager.darkPrimary, size: 28),
                      ),
                      SizedBox(width: 14.w),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('@${capFirst(_username)}',
                              style: TextStyle(
                                  color: ColorsManager.darkPrimary,
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.bold)),
                          SizedBox(height: 4.h),
                          Text(_email,
                              style: TextStyle(
                                  color: Colors.white54, fontSize: 13.sp)),
                        ],
                      ),
                    ],
                  ),
                ),

                // Bölüm başlığı
                _sectionHeader('Bilgileri Değiştir'),

                _settingsTile(
                  icon: Icons.alternate_email_rounded,
                  title: 'Kullanıcı Adı',
                  subtitle: '@${capFirst(_username)}',
                  onTap: _changeUsername,
                ),
                _divider(),
                _settingsTile(
                  icon: Icons.email_outlined,
                  title: 'E-posta',
                  subtitle: _email,
                  onTap: _changeEmail,
                ),
                _divider(),
                _settingsTile(
                  icon: Icons.lock_outline_rounded,
                  title: 'Şifre',
                  subtitle: '••••••••',
                  onTap: _changePassword,
                ),

                SizedBox(height: 24.h),
                _sectionHeader('Tehlikeli Bölge'),

                _settingsTile(
                  icon: Icons.delete_forever_rounded,
                  title: 'Hesabı Sil',
                  subtitle: 'Tüm veriler kalıcı olarak silinir',
                  iconColor: Colors.red,
                  titleColor: Colors.red,
                  onTap: _deleteAccount,
                ),
                SizedBox(height: 32.h),
              ],
            ),
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16.w, 8.h, 16.w, 4.h),
      child: Text(title,
          style: TextStyle(
              color: ColorsManager.darkPrimary,
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2)),
    );
  }

  Widget _settingsTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    Color? iconColor,
    Color? titleColor,
  }) {
    return ListTile(
      onTap: onTap,
      contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 4.h),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: (iconColor ?? ColorsManager.darkPrimary).withOpacity(0.1),
          borderRadius: BorderRadius.circular(10.r),
        ),
        child: Icon(icon, color: iconColor ?? ColorsManager.darkPrimary, size: 22),
      ),
      title: Text(title,
          style: TextStyle(
              color: titleColor ?? Colors.white,
              fontSize: 15.sp,
              fontWeight: FontWeight.w500)),
      subtitle: Text(subtitle,
          style: TextStyle(color: Colors.white38, fontSize: 12.sp),
          maxLines: 1,
          overflow: TextOverflow.ellipsis),
      trailing:
          const Icon(Icons.chevron_right_rounded, color: Colors.white24, size: 20),
    );
  }

  Widget _divider() => const Divider(
      height: 1, indent: 64, endIndent: 16, color: Colors.white10);
}
