import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:pro_image_editor/pro_image_editor.dart';
import 'package:path_provider/path_provider.dart';

class ImageEditorScreen {
  static Future<File?> editFile(BuildContext context, File file) async {
    final bytes = await file.readAsBytes();
    final edited = await _openEditor(context, bytes);
    if (edited == null) return null;
    final dir = await getTemporaryDirectory();
    final path =
        '${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final out = File(path);
    await out.writeAsBytes(edited);
    return out;
  }

  static Future<Uint8List?> _openEditor(
      BuildContext context, Uint8List bytes) async {
    final resultNotifier = ValueNotifier<Uint8List?>(null);

    await Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (ctx) => ProImageEditor.memory(
          bytes,
          callbacks: ProImageEditorCallbacks(
            onImageEditingComplete: (Uint8List result) async {
              resultNotifier.value = result;
              Navigator.of(ctx).pop();
            },
            onCloseEditor: () {
              Navigator.of(ctx).pop();
            },
          ),
          configs: const ProImageEditorConfigs(
            imageGenerationConfigs: ImageGenerationConfigs(
              outputFormat: OutputFormat.jpg,
              jpegQuality: 90,
            ),
          ),
        ),
      ),
    );

    return resultNotifier.value;
  }
}
