import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import '../../../themes/colors.dart';

// ─── Entry point ─────────────────────────────────────────────────────────────
class ImageEditorScreen {
  static Future<File?> editFile(BuildContext context, File file) async {
    if (!context.mounted) return file;
    return await Navigator.push<File?>(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => _WhatsAppEditor(imageFile: file),
      ),
    ) ?? file;
  }
}

// ─── Model ───────────────────────────────────────────────────────────────────
class _Stroke {
  final List<Offset> pts;
  final Color color;
  final double width;
  _Stroke({required this.pts, required this.color, required this.width});
}

class _TextItem {
  String text;
  Color color;
  Offset pos;
  double size;
  _TextItem({required this.text, required this.color})
      : pos = const Offset(40, 200), size = 28;
}

class _EmojiItem {
  String emoji;
  Offset pos;
  double size;
  _EmojiItem({required this.emoji}) : pos = const Offset(100, 200), size = 52;
}

// ─── Painter ─────────────────────────────────────────────────────────────────
class _StrokePainter extends CustomPainter {
  final List<_Stroke> strokes;
  final _Stroke? current;
  _StrokePainter(this.strokes, this.current);

  @override
  void paint(Canvas canvas, Size size) {
    void draw(_Stroke s) {
      if (s.pts.isEmpty) return;
      final p = Paint()
        ..color = s.color
        ..strokeWidth = s.width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke;
      final path = Path()..moveTo(s.pts.first.dx, s.pts.first.dy);
      for (final pt in s.pts.skip(1)) path.lineTo(pt.dx, pt.dy);
      canvas.drawPath(path, p);
    }
    for (final s in strokes) draw(s);
    if (current != null) draw(current!);
  }

  @override
  bool shouldRepaint(_StrokePainter o) => true;
}

// ─── Main editor ─────────────────────────────────────────────────────────────
class _WhatsAppEditor extends StatefulWidget {
  final File imageFile;
  const _WhatsAppEditor({required this.imageFile});
  @override
  State<_WhatsAppEditor> createState() => _WhatsAppEditorState();
}

enum _Tool { draw, text, emoji, crop }

class _WhatsAppEditorState extends State<_WhatsAppEditor> {
  final _repaintKey = GlobalKey();
  final List<_Stroke> _strokes = [];
  _Stroke? _current;
  final List<_TextItem> _texts = [];
  final List<_EmojiItem> _emojis = [];

  _Tool _tool = _Tool.draw;
  Color _color = Colors.white;
  double _brushSize = 5;
  bool _saving = false;

  // Crop state
  final _cropKey = GlobalKey();
  Rect _cropRect = Rect.zero;
  Size _imageSize = Size.zero;
  bool _cropping = false;

  static const _colors = [
    Colors.white, Color(0xFFFF3B30), Color(0xFFFF9500),
    Color(0xFFFFCC00), Color(0xFF34C759), Color(0xFF007AFF),
    Color(0xFF5856D6), Color(0xFFFF2D55), Colors.black,
  ];

  static const _emojiOptions = [
    '❤️','😂','😍','🔥','👍','🎉','😎','💯',
    '✨','🌟','😘','🥳','👏','💪','🤩','😭',
    '🙌','💀','👀','🫶','😅','🤦','🥺','💅',
  ];

  // ── Save ──────────────────────────────────────────────────────────────────
  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await Future.delayed(const Duration(milliseconds: 80));
      final boundary = _repaintKey.currentContext
          ?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) { _pop(widget.imageFile); return; }
      final img = await boundary.toImage(pixelRatio: 2.5);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) { _pop(widget.imageFile); return; }
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/wa_edit_${DateTime.now().millisecondsSinceEpoch}.png');
      await f.writeAsBytes(data.buffer.asUint8List());
      _pop(f);
    } catch (_) { _pop(widget.imageFile); }
    setState(() => _saving = false);
  }

  void _pop(File f) { if (mounted) Navigator.pop(context, f); }

  // ── Text dialog ───────────────────────────────────────────────────────────
  void _addText() {
    final ctrl = TextEditingController();
    Color tc = Colors.white;
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (_, ss) => Dialog(
        backgroundColor: const Color(0xFF1C1C1E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Metin Ekle', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            TextField(
              controller: ctrl, autofocus: true,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Bir şeyler yaz...',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true, fillColor: Colors.white10,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
            ),
            const SizedBox(height: 14),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: _colors.take(7).map((c) =>
              GestureDetector(
                onTap: () => ss(() => tc = c),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: tc == c ? 34 : 28, height: tc == c ? 34 : 28,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    color: c, shape: BoxShape.circle,
                    border: Border.all(color: tc == c ? Colors.white : Colors.transparent, width: 2.5),
                  ),
                ),
              )
            ).toList()),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: TextButton(
                onPressed: () => Navigator.pop(ctx),
                style: TextButton.styleFrom(foregroundColor: Colors.white38),
                child: const Text('İptal'),
              )),
              const SizedBox(width: 8),
              Expanded(child: ElevatedButton(
                onPressed: () {
                  if (ctrl.text.trim().isNotEmpty) {
                    setState(() => _texts.add(_TextItem(text: ctrl.text.trim(), color: tc)));
                  }
                  Navigator.pop(ctx);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: ColorsManager.darkPrimary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('Ekle', style: TextStyle(color: Colors.white)),
              )),
            ]),
          ]),
        ),
      )),
    );
  }

  // ── Emoji sheet ───────────────────────────────────────────────────────────
  void _showEmojis() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1C1C1E),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 8),
        Container(width: 36, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 8, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 20),
          children: _emojiOptions.map((e) => GestureDetector(
            onTap: () { setState(() => _emojis_field.add(_EmojiItem(emoji: e))); Navigator.pop(context); },
            child: Center(child: Text(e, style: const TextStyle(fontSize: 30))),
          )).toList(),
        ),
      ]),
    );
  }

  final List<_EmojiItem> _emojis_field = [];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
        // ── Üst bar ───────────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(children: [
            _iconBtn(Icons.close, () => Navigator.pop(context, widget.imageFile)),
            const Spacer(),
            _toolBtn(Icons.brush_rounded, _Tool.draw, 'Çiz'),
            const SizedBox(width: 4),
            _toolBtn(Icons.text_fields_rounded, _Tool.text, 'Yazı', onTap: _addText),
            const SizedBox(width: 4),
            _toolBtn(Icons.emoji_emotions_outlined, _Tool.emoji, 'Emoji', onTap: _showEmojis),
            const SizedBox(width: 4),
            _iconBtn(Icons.undo_rounded, () {
              setState(() {
                if (_strokes.isNotEmpty) _strokes.removeLast();
                else if (_texts.isNotEmpty) _texts.removeLast();
                else if (_emojis_field.isNotEmpty) _emojis_field.removeLast();
              });
            }),
          ]),
        ),
        // ── Çizim / Görüntü alanı ─────────────────────────────────────────
        Expanded(
          child: RepaintBoundary(
            key: _repaintKey,
            child: Stack(fit: StackFit.expand, children: [
              // Fotoğraf
              Image.file(widget.imageFile, fit: BoxFit.contain),
              // Çizimler
              Positioned.fill(child: CustomPaint(painter: _StrokePainter(_strokes, _current))),
              // Metinler
              ..._texts.map((t) => _DragText(item: t, onDelete: () => setState(() => _texts.remove(t)))),
              // Emojiler
              ..._emojis_field.map((e) => _DragEmoji(item: e, onDelete: () => setState(() => _emojis_field.remove(e)))),
            ]),
          ),
        ),

              // ── Çizim gesture ─────────────────────────────────────
              if (_tool == _Tool.draw)
                Positioned.fill(
                  child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onPanStart: (d) => setState(() => _current = _Stroke(pts: [d.localPosition], color: _color, width: _brushSize)),
              onPanUpdate: (d) => setState(() => _current = _Stroke(pts: [...?_current?.pts, d.localPosition], color: _color, width: _brushSize)),
              onPanEnd: (_) => setState(() { if (_current != null) { _strokes.add(_current!); _current = null; } }),
            ),
          ),
            ]),
          ),
        ),

        // ── Alt kontroller ─────────────────────────────────────────────────
        Container(
          color: Colors.black,
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
          child: Row(children: [
            // Fırça boyutu
            if (_tool == _Tool.draw) ...[
              SizedBox(width: 80, child: Slider(
                value: _brushSize, min: 2, max: 20,
                activeColor: _color, inactiveColor: Colors.white24,
                onChanged: (v) => setState(() => _brushSize = v),
              )),
            ] else const SizedBox(width: 80),
            // Renk paleti
            Expanded(child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: _colors.map((c) => GestureDetector(
                onTap: () => setState(() => _color = c),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: _color == c ? 32 : 24, height: _color == c ? 32 : 24,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    color: c, shape: BoxShape.circle,
                    border: Border.all(color: _color == c ? Colors.white : Colors.white38, width: _color == c ? 2.5 : 1),
                  ),
                ),
              )).toList()),
            )),
            // Gönder
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _saving ? null : _save,
              child: Container(
                width: 52, height: 52,
                decoration: BoxDecoration(
                  color: ColorsManager.darkPrimary, shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.4), blurRadius: 10)],
                ),
                child: _saving
                    ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
                    : const Icon(Icons.send_rounded, color: Colors.white, size: 24),
              ),
            ),
          ]),
        ),
        ]),
      ),
    );
  }

  Widget _iconBtn(IconData icon, VoidCallback onTap, {bool active = false}) =>
    GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          color: Colors.black38, borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: Colors.white, size: 22),
      ),
    );

  Widget _toolBtn(IconData icon, _Tool tool, String label, {VoidCallback? onTap}) =>
    GestureDetector(
      onTap: () {
        setState(() => _tool = tool);
        onTap?.call();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: _tool == tool ? Colors.white.withOpacity(0.2) : Colors.black38,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: _tool == tool ? Colors.white : Colors.transparent, width: 1.5),
        ),
        child: Icon(icon, color: Colors.white, size: 22),
      ),
    );
}

// ─── Draggable items ─────────────────────────────────────────────────────────
class _DragText extends StatefulWidget {
  final _TextItem item;
  final VoidCallback onDelete;
  const _DragText({required this.item, required this.onDelete});
  @override State<_DragText> createState() => _DragTextState();
}
class _DragTextState extends State<_DragText> {
  @override
  Widget build(BuildContext context) => Positioned(
    left: widget.item.pos.dx, top: widget.item.pos.dy,
    child: GestureDetector(
      onPanUpdate: (d) => setState(() => widget.item.pos += d.delta),
      onLongPress: widget.onDelete,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.35),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(widget.item.text, style: TextStyle(
          color: widget.item.color, fontSize: widget.item.size,
          fontWeight: FontWeight.bold,
          shadows: const [Shadow(color: Colors.black87, blurRadius: 6, offset: Offset(1,1))],
        )),
      ),
    ),
  );
}

class _DragEmoji extends StatefulWidget {
  final _EmojiItem item;
  final VoidCallback onDelete;
  const _DragEmoji({required this.item, required this.onDelete});
  @override State<_DragEmoji> createState() => _DragEmojiState();
}
class _DragEmojiState extends State<_DragEmoji> {
  @override
  Widget build(BuildContext context) => Positioned(
    left: widget.item.pos.dx, top: widget.item.pos.dy,
    child: GestureDetector(
      onPanUpdate: (d) => setState(() => widget.item.pos += d.delta),
      onLongPress: widget.onDelete,
      child: Text(widget.item.emoji, style: TextStyle(fontSize: widget.item.size)),
    ),
  );
}
