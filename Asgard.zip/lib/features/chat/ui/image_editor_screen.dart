import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import '../../../themes/colors.dart';

class ImageEditorScreen {
  /// Fotoğrafı kırp/düzenle - iptal edilirse null döner
  static Future<File?> editFile(BuildContext context, File file) async {
    final cropped = await ImageCropper().cropImage(
      sourcePath: file.path,
      compressQuality: 90,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Düzenle',
          toolbarColor: const Color(0xFF111111),
          toolbarWidgetColor: Colors.white,
          backgroundColor: Colors.black,
          activeControlsWidgetColor: ColorsManager.darkPrimary,
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: false,
          hideBottomControls: false,
        ),
      ],
    );
    if (cropped == null) return null;
    return File(cropped.path);
  }
}
