import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:pro_image_editor/pro_image_editor.dart';
import 'package:path_provider/path_provider.dart';

class ImageEditorScreen {
  static Future<File?> editFile(BuildContext context, File file) async {
    final bytes = await file.readAsBytes();
    final edited = await _openEditor(context, bytes);
    if (edited == null) return null;
    final dir = await getTemporaryDirectory();
    final path =
        '${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final out = File(path);
    await out.writeAsBytes(edited);
    return out;
  }

  static Future<Uint8List?> _openEditor(
      BuildContext context, Uint8List bytes) async {
    // Sonucu bir ValueNotifier ile yakala
    final resultNotifier = ValueNotifier<Uint8List?>(null);

    await Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (ctx) => ProImageEditor.memory(
          bytes,
          callbacks: ProImageEditorCallbacks(
            onImageEditingComplete: (Uint8List result) async {
              resultNotifier.value = result;
              Navigator.of(ctx).pop();
            },
            onCloseEditor: ({required bool ignoreChanges}) {
              Navigator.of(ctx).pop();
            },
          ),
          configs: ProImageEditorConfigs(
            imageGenerationConfigs: const ImageGenerationConfigs(
              outputFormat: OutputFormat.jpg,
              jpegQuality: 90,
              captureOnlyDrawingBounds: false,
            ),
          ),
        ),
      ),
    );

    return resultNotifier.value;
  }
}
