import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:path_provider/path_provider.dart';
import '../../../themes/colors.dart';

class ImageEditorScreen {
  static Future<File?> editFile(BuildContext context, File file) async {
    // Adım 1: Kırp
    final cropped = await ImageCropper().cropImage(
      sourcePath: file.path,
      compressQuality: 95,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Kırp',
          toolbarColor: const Color(0xFF111111),
          toolbarWidgetColor: Colors.white,
          backgroundColor: Colors.black,
          activeControlsWidgetColor: ColorsManager.darkPrimary,
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: false,
        ),
      ],
    );
    final croppedFile = cropped != null ? File(cropped.path) : file;
    if (!context.mounted) return croppedFile;

    // Adım 2: Çiz/Yaz/Emoji
    final result = await Navigator.push<File?>(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => _DrawingEditor(imageFile: croppedFile),
      ),
    );
    return result ?? croppedFile;
  }
}

// ─── Çizim Noktası ───────────────────────────────────────────────────────────
class _DrawPoint {
  final Offset? point;
  final Paint paint;
  _DrawPoint({this.point, required this.paint});
}

// ─── Overlay Tipleri ─────────────────────────────────────────────────────────
class _TextOverlay {
  String text;
  Color color;
  Offset position;
  double fontSize;
  _TextOverlay({required this.text, required this.color})
      : position = const Offset(80, 120), fontSize = 26;
}

class _EmojiOverlay {
  String emoji;
  Offset position;
  _EmojiOverlay({required this.emoji}) : position = const Offset(120, 150);
}

// ─── Çizim Painter ──────────────────────────────────────────────────────────
class _DrawPainter extends CustomPainter {
  final List<_DrawPoint> points;
  _DrawPainter(this.points);

  @override
  void paint(Canvas canvas, Size size) {
    for (int i = 0; i < points.length - 1; i++) {
      final p = points[i];
      final next = points[i + 1];
      if (p.point != null && next.point != null) {
        canvas.drawLine(p.point!, next.point!, p.paint);
      }
    }
  }

  @override
  bool shouldRepaint(_DrawPainter old) => true;
}

// ─── Editör Ekranı ───────────────────────────────────────────────────────────
class _DrawingEditor extends StatefulWidget {
  final File imageFile;
  const _DrawingEditor({required this.imageFile});
  @override
  State<_DrawingEditor> createState() => _DrawingEditorState();
}

class _DrawingEditorState extends State<_DrawingEditor> {
  final _repaintKey = GlobalKey();
  final List<_DrawPoint> _points = [];
  final List<_TextOverlay> _texts = [];
  final List<_EmojiOverlay> _emojis = [];
  Color _color = Colors.red;
  double _strokeWidth = 5.0;
  bool _isDrawing = true;

  final _emojiList = ['😀','😂','❤️','🔥','👍','🎉','😎','💯','✨','🌟','😍','🤩','👏','💪','🥳','😘'];
  final _colors = [Colors.red, Colors.white, Colors.yellow, Colors.green, Colors.blue, Colors.black, Colors.orange, Colors.purple];

  Paint get _currentPaint => Paint()
    ..color = _color
    ..strokeWidth = _strokeWidth
    ..strokeCap = StrokeCap.round
    ..style = PaintingStyle.stroke;

  Future<void> _save() async {
    try {
      final boundary = _repaintKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) { Navigator.pop(context, widget.imageFile); return; }
      final image = await boundary.toImage(pixelRatio: 3.0);
      final bytes = (await image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
      final dir = await getTemporaryDirectory();
      final out = File('${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.png');
      await out.writeAsBytes(bytes);
      if (mounted) Navigator.pop(context, out);
    } catch (_) {
      if (mounted) Navigator.pop(context, widget.imageFile);
    }
  }

  void _addText() {
    showDialog(context: context, builder: (ctx) {
      final ctrl = TextEditingController();
      Color tc = Colors.white;
      return StatefulBuilder(builder: (_, ss) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Yazı Ekle', style: TextStyle(color: Colors.white)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: ctrl, autofocus: true,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(hintText: 'Yazınızı girin...', hintStyle: TextStyle(color: Colors.white38),
              enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white24)))),
          const SizedBox(height: 12),
          Row(children: [
            const Text('Renk: ', style: TextStyle(color: Colors.white54, fontSize: 12)),
            ..._colors.take(5).map((c) => GestureDetector(
              onTap: () => ss(() => tc = c),
              child: Container(width: 26, height: 26, margin: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(color: c, shape: BoxShape.circle,
                  border: Border.all(color: tc == c ? Colors.white : Colors.transparent, width: 2))),
            )),
          ]),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(onPressed: () {
            if (ctrl.text.isNotEmpty) setState(() => _texts.add(_TextOverlay(text: ctrl.text, color: tc)));
            Navigator.pop(ctx);
          }, child: Text('Ekle', style: TextStyle(color: ColorsManager.darkPrimary))),
        ],
      ));
    });
  }

  void _showEmojis() {
    showModalBottomSheet(context: context, backgroundColor: const Color(0xFF1A1A1A),
      builder: (_) => GridView.count(crossAxisCount: 8, shrinkWrap: true, padding: const EdgeInsets.all(12),
        children: _emojiList.map((e) => GestureDetector(
          onTap: () { setState(() => _emojis.add(_EmojiOverlay(emoji: e))); Navigator.pop(context); },
          child: Center(child: Text(e, style: const TextStyle(fontSize: 28))),
        )).toList()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        leading: IconButton(icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context, widget.imageFile)),
        title: const Text('Düzenle', style: TextStyle(color: Colors.white, fontSize: 16)),
        actions: [
          TextButton(onPressed: _save,
            child: Text('Gönder', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold, fontSize: 16))),
        ],
      ),
      body: Column(children: [
        // Çizim alanı
        Expanded(
          child: GestureDetector(
            onPanStart: (d) { if (_isDrawing) setState(() => _points.add(_DrawPoint(point: d.localPosition, paint: _currentPaint))); },
            onPanUpdate: (d) { if (_isDrawing) setState(() => _points.add(_DrawPoint(point: d.localPosition, paint: _currentPaint))); },
            onPanEnd: (_) { if (_isDrawing) setState(() => _points.add(_DrawPoint(point: null, paint: _currentPaint))); },
            child: RepaintBoundary(
              key: _repaintKey,
              child: Stack(fit: StackFit.expand, children: [
                Image.file(widget.imageFile, fit: BoxFit.contain),
                CustomPaint(painter: _DrawPainter(_points)),
                ..._texts.map((t) => _DraggableText(overlay: t, onDelete: () => setState(() => _texts.remove(t)))),
                ..._emojis.map((e) => _DraggableEmoji(overlay: e, onDelete: () => setState(() => _emojis.remove(e)))),
              ]),
            ),
          ),
        ),
        // Araç çubuğu
        Container(
          color: const Color(0xFF111111),
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
          child: Column(children: [
            // Araçlar
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _tool(Icons.brush_rounded, 'Çiz', _isDrawing, () => setState(() => _isDrawing = true)),
              _tool(Icons.text_fields_rounded, 'Yazı', false, _addText),
              _tool(Icons.emoji_emotions_rounded, 'Emoji', false, _showEmojis),
              _tool(Icons.undo_rounded, 'Geri Al', false, () {
                setState(() {
                  if (_points.isNotEmpty) {
                    _points.removeLast();
                    while (_points.isNotEmpty && _points.last.point != null) _points.removeLast();
                  }
                });
              }),
              _tool(Icons.delete_outline_rounded, 'Temizle', false, () => setState(() { _points.clear(); _texts.clear(); _emojis.clear(); })),
            ]),
            const SizedBox(height: 10),
            // Renkler + kalınlık
            Row(children: [
              ..._colors.map((c) => GestureDetector(
                onTap: () => setState(() => _color = c),
                child: Container(width: 28, height: 28, margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(color: c, shape: BoxShape.circle,
                    border: Border.all(color: _color == c ? Colors.white : Colors.white24, width: _color == c ? 2.5 : 1))),
              )),
              const Spacer(),
              const Icon(Icons.line_weight, color: Colors.white38, size: 16),
              SizedBox(width: 100, child: Slider(
                value: _strokeWidth, min: 2, max: 18,
                activeColor: ColorsManager.darkPrimary, inactiveColor: Colors.white24,
                onChanged: (v) => setState(() => _strokeWidth = v),
              )),
            ]),
          ]),
        ),
      ]),
    );
  }

  Widget _tool(IconData icon, String label, bool active, VoidCallback onTap) =>
    GestureDetector(onTap: onTap, child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: active ? ColorsManager.darkPrimary.withOpacity(0.2) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: active ? ColorsManager.darkPrimary : Colors.white12),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: active ? ColorsManager.darkPrimary : Colors.white54, size: 20),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: active ? ColorsManager.darkPrimary : Colors.white38, fontSize: 10)),
      ]),
    ));
}

class _DraggableText extends StatefulWidget {
  final _TextOverlay overlay;
  final VoidCallback onDelete;
  const _DraggableText({required this.overlay, required this.onDelete});
  @override State<_DraggableText> createState() => _DraggableTextState();
}
class _DraggableTextState extends State<_DraggableText> {
  @override
  Widget build(BuildContext context) => Positioned(
    left: widget.overlay.position.dx, top: widget.overlay.position.dy,
    child: GestureDetector(
      onPanUpdate: (d) => setState(() => widget.overlay.position += d.delta),
      onLongPress: widget.onDelete,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(6)),
        child: Text(widget.overlay.text,
          style: TextStyle(color: widget.overlay.color, fontSize: widget.overlay.fontSize,
            fontWeight: FontWeight.bold, shadows: const [Shadow(color: Colors.black, blurRadius: 4)])),
      ),
    ),
  );
}

class _DraggableEmoji extends StatefulWidget {
  final _EmojiOverlay overlay;
  final VoidCallback onDelete;
  const _DraggableEmoji({required this.overlay, required this.onDelete});
  @override State<_DraggableEmoji> createState() => _DraggableEmojiState();
}
class _DraggableEmojiState extends State<_DraggableEmoji> {
  @override
  Widget build(BuildContext context) => Positioned(
    left: widget.overlay.position.dx, top: widget.overlay.position.dy,
    child: GestureDetector(
      onPanUpdate: (d) => setState(() => widget.overlay.position += d.delta),
      onLongPress: widget.onDelete,
      child: Text(widget.overlay.emoji, style: const TextStyle(fontSize: 48)),
    ),
  );
}
