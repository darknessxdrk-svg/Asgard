import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_editor_plus/image_editor_plus.dart';
import 'package:path_provider/path_provider.dart';

/// Fotoğraf düzenleme ekranı
/// Kırpma, çizme, yazı, filtre, sticker destekler
class ImageEditorScreen extends StatelessWidget {
  final Uint8List imageBytes;

  const ImageEditorScreen({super.key, required this.imageBytes});

  /// Fotoğraf seçilince editöre gönder, düzenlenen Uint8List döner
  static Future<Uint8List?> edit(BuildContext context, Uint8List bytes) async {
    final result = await Navigator.push<Uint8List>(
      context,
      MaterialPageRoute(
        builder: (_) => ImageEditor(image: bytes),
        fullscreenDialog: true,
      ),
    );
    return result;
  }

  /// Dosyadan edit
  static Future<File?> editFile(BuildContext context, File file) async {
    final bytes = await file.readAsBytes();
    final edited = await edit(context, bytes);
    if (edited == null) return null;
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final editedFile = File(path);
    await editedFile.writeAsBytes(edited);
    return editedFile;
  }

  @override
  Widget build(BuildContext context) {
    return ImageEditor(image: imageBytes);
  }
}
