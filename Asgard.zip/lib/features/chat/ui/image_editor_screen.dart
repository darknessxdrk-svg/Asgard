import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:pro_image_editor/pro_image_editor.dart';
import 'package:path_provider/path_provider.dart';

class ImageEditorScreen {
  static Future<File?> editFile(BuildContext context, File file) async {
    final bytes = await file.readAsBytes();
    final edited = await editBytes(context, bytes);
    if (edited == null) return null;
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final out = File(path);
    await out.writeAsBytes(edited);
    return out;
  }

  static Future<Uint8List?> editBytes(BuildContext context, Uint8List bytes) async {
    Uint8List? result;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProImageEditor.memory(
          bytes,
          callbacks: ProImageEditorCallbacks(
            onImageEditingComplete: (Uint8List edited) async {
              result = edited;
              if (context.mounted) Navigator.pop(context);
            },
          ),
        ),
        fullscreenDialog: true,
      ),
    );
    return result;
  }
}
