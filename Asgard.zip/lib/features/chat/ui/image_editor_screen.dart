import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_drawing_board/flutter_drawing_board.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:path_provider/path_provider.dart';
import '../../../themes/colors.dart';

class ImageEditorScreen {
  /// Ana editör - önce kırp, sonra çiz/yaz
  static Future<File?> editFile(BuildContext context, File file) async {
    // Adım 1: Kırp
    final cropped = await ImageCropper().cropImage(
      sourcePath: file.path,
      compressQuality: 95,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Kırp',
          toolbarColor: const Color(0xFF111111),
          toolbarWidgetColor: Colors.white,
          backgroundColor: Colors.black,
          activeControlsWidgetColor: ColorsManager.darkPrimary,
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: false,
        ),
      ],
    );

    final croppedFile = cropped != null ? File(cropped.path) : file;

    // Adım 2: Çiz/Yaz/Emoji ekle
    if (!context.mounted) return croppedFile;
    final result = await Navigator.push<File?>(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => _DrawingEditor(imageFile: croppedFile),
      ),
    );
    return result ?? croppedFile;
  }
}

class _DrawingEditor extends StatefulWidget {
  final File imageFile;
  const _DrawingEditor({required this.imageFile});

  @override
  State<_DrawingEditor> createState() => _DrawingEditorState();
}

class _DrawingEditorState extends State<_DrawingEditor> {
  final DrawingController _controller = DrawingController();
  final _repaintKey = GlobalKey();
  Color _color = Colors.red;
  double _strokeWidth = 4.0;
  bool _isText = false;
  bool _isEmoji = false;
  final List<_TextOverlay> _texts = [];
  final List<_EmojiOverlay> _emojis = [];

  final List<String> _emojiList = ['😀','😂','❤️','🔥','👍','🎉','😎','💯','✨','🌟','😍','🤩','👏','🙌','💪','🥳'];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    try {
      final boundary = _repaintKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) return;
      final image = await boundary.toImage(pixelRatio: 3.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) return;
      final bytes = byteData.buffer.asUint8List();
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.png';
      final out = File(path);
      await out.writeAsBytes(bytes);
      if (mounted) Navigator.pop(context, out);
    } catch (e) {
      if (mounted) Navigator.pop(context, widget.imageFile);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context, widget.imageFile),
        ),
        title: const Text('Düzenle', style: TextStyle(color: Colors.white, fontSize: 16)),
        actions: [
          TextButton(
            onPressed: _save,
            child: Text('Gönder', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold, fontSize: 16)),
          ),
        ],
      ),
      body: Column(
        children: [
          // Çizim alanı
          Expanded(
            child: RepaintBoundary(
              key: _repaintKey,
              child: Stack(
                children: [
                  // Fotoğraf
                  Positioned.fill(
                    child: Image.file(widget.imageFile, fit: BoxFit.contain),
                  ),
                  // Çizim
                  Positioned.fill(
                    child: DrawingBoard(
                      controller: _controller,
                      background: Container(color: Colors.transparent),
                      showDefaultActions: false,
                      showDefaultTools: false,
                    ),
                  ),
                  // Text overlay'leri
                  ..._texts.map((t) => _DraggableText(overlay: t, onDelete: () => setState(() => _texts.remove(t)))),
                  // Emoji overlay'leri
                  ..._emojis.map((e) => _DraggableEmoji(overlay: e, onDelete: () => setState(() => _emojis.remove(e)))),
                ],
              ),
            ),
          ),

          // Alt araç çubuğu
          Container(
            color: const Color(0xFF111111),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Column(
              children: [
                // Araçlar
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _ToolBtn(icon: Icons.brush_rounded, label: 'Çiz',
                        active: !_isText && !_isEmoji,
                        onTap: () => setState(() { _isText = false; _isEmoji = false; })),
                    _ToolBtn(icon: Icons.text_fields_rounded, label: 'Yazı',
                        active: _isText,
                        onTap: () => setState(() { _isText = true; _isEmoji = false; _addText(); })),
                    _ToolBtn(icon: Icons.emoji_emotions_rounded, label: 'Emoji',
                        active: _isEmoji,
                        onTap: () => setState(() { _isText = false; _isEmoji = true; _showEmojiPicker(); })),
                    _ToolBtn(icon: Icons.undo_rounded, label: 'Geri Al',
                        active: false,
                        onTap: () => _controller.undo()),
                    _ToolBtn(icon: Icons.delete_outline_rounded, label: 'Temizle',
                        active: false,
                        onTap: () { _controller.clear(); setState(() { _texts.clear(); _emojis.clear(); }); }),
                  ],
                ),
                const SizedBox(height: 8),
                // Renk + kalınlık
                if (!_isText && !_isEmoji) ...[
                  Row(
                    children: [
                      const SizedBox(width: 8),
                      ...[Colors.white, Colors.red, Colors.yellow, Colors.green, Colors.blue, Colors.black]
                          .map((c) => GestureDetector(
                        onTap: () {
                          setState(() => _color = c);
                          _controller.drawConfig.update(color: c);
                        },
                        child: Container(
                          width: 28, height: 28,
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          decoration: BoxDecoration(
                            color: c,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: _color == c ? Colors.white : Colors.white24,
                              width: _color == c ? 2.5 : 1,
                            ),
                          ),
                        ),
                      )),
                      const Spacer(),
                      Icon(Icons.line_weight, color: Colors.white54, size: 18),
                      Slider(
                        value: _strokeWidth,
                        min: 1, max: 20,
                        activeColor: ColorsManager.darkPrimary,
                        inactiveColor: Colors.white24,
                        onChanged: (v) {
                          setState(() => _strokeWidth = v);
                          _controller.drawConfig.update(strokeWidth: v);
                        },
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _addText() {
    showDialog(
      context: context,
      builder: (ctx) {
        final ctrl = TextEditingController();
        Color textColor = Colors.white;
        return StatefulBuilder(builder: (_, setS) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: const Text('Yazı Ekle', style: TextStyle(color: Colors.white)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: ctrl,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(hintText: 'Yazınızı girin...', hintStyle: TextStyle(color: Colors.white38), enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white24))),
              autofocus: true,
            ),
            const SizedBox(height: 12),
            Row(children: [
              const Text('Renk:', style: TextStyle(color: Colors.white54, fontSize: 12)),
              const SizedBox(width: 8),
              ...[Colors.white, Colors.yellow, Colors.red, Colors.green, Colors.blue]
                  .map((c) => GestureDetector(
                onTap: () => setS(() => textColor = c),
                child: Container(width: 24, height: 24, margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(color: c, shape: BoxShape.circle,
                    border: Border.all(color: textColor == c ? Colors.white : Colors.transparent, width: 2))),
              )),
            ]),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
            TextButton(
              onPressed: () {
                if (ctrl.text.isNotEmpty) {
                  setState(() => _texts.add(_TextOverlay(text: ctrl.text, color: textColor)));
                }
                Navigator.pop(ctx);
              },
              child: Text('Ekle', style: TextStyle(color: ColorsManager.darkPrimary)),
            ),
          ],
        ));
      },
    );
  }

  void _showEmojiPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      builder: (_) => GridView.count(
        crossAxisCount: 8,
        shrinkWrap: true,
        padding: const EdgeInsets.all(8),
        children: _emojiList.map((e) => GestureDetector(
          onTap: () {
            setState(() => _emojis.add(_EmojiOverlay(emoji: e)));
            Navigator.pop(context);
          },
          child: Center(child: Text(e, style: const TextStyle(fontSize: 28))),
        )).toList(),
      ),
    );
  }
}

class _TextOverlay {
  String text;
  Color color;
  Offset position;
  double fontSize;
  _TextOverlay({required this.text, required this.color})
      : position = const Offset(100, 100), fontSize = 24;
}

class _EmojiOverlay {
  String emoji;
  Offset position;
  double size;
  _EmojiOverlay({required this.emoji})
      : position = const Offset(150, 150), size = 48;
}

class _DraggableText extends StatefulWidget {
  final _TextOverlay overlay;
  final VoidCallback onDelete;
  const _DraggableText({required this.overlay, required this.onDelete});
  @override State<_DraggableText> createState() => _DraggableTextState();
}

class _DraggableTextState extends State<_DraggableText> {
  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: widget.overlay.position.dx,
      top: widget.overlay.position.dy,
      child: GestureDetector(
        onPanUpdate: (d) => setState(() => widget.overlay.position += d.delta),
        onLongPress: widget.onDelete,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.black38,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(widget.overlay.text,
            style: TextStyle(color: widget.overlay.color, fontSize: widget.overlay.fontSize,
              fontWeight: FontWeight.bold, shadows: const [Shadow(color: Colors.black, blurRadius: 4)])),
        ),
      ),
    );
  }
}

class _DraggableEmoji extends StatefulWidget {
  final _EmojiOverlay overlay;
  final VoidCallback onDelete;
  const _DraggableEmoji({required this.overlay, required this.onDelete});
  @override State<_DraggableEmoji> createState() => _DraggableEmojiState();
}

class _DraggableEmojiState extends State<_DraggableEmoji> {
  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: widget.overlay.position.dx,
      top: widget.overlay.position.dy,
      child: GestureDetector(
        onPanUpdate: (d) => setState(() => widget.overlay.position += d.delta),
        onLongPress: widget.onDelete,
        child: Text(widget.overlay.emoji, style: TextStyle(fontSize: widget.overlay.size)),
      ),
    );
  }
}

class _ToolBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _ToolBtn({required this.icon, required this.label, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: active ? ColorsManager.darkPrimary.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: active ? ColorsManager.darkPrimary : Colors.white12),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: active ? ColorsManager.darkPrimary : Colors.white54, size: 20),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(color: active ? ColorsManager.darkPrimary : Colors.white38, fontSize: 10)),
        ]),
      ),
    );
  }
}
