import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';

import '../../../services/cloudinary_service.dart';
import '../../../themes/colors.dart';

class GroupSettingsScreen extends StatefulWidget {
  final String groupId;
  const GroupSettingsScreen({super.key, required this.groupId});
  @override
  State<GroupSettingsScreen> createState() => _GroupSettingsScreenState();
}

class _GroupSettingsScreenState extends State<GroupSettingsScreen>
    with SingleTickerProviderStateMixin {
  final _db = FirebaseFirestore.instance;
  final _myUid = FirebaseAuth.instance.currentUser!.uid;
  bool _uploading = false;

  // ── Fotoğraf güncelle ──────────────────────────────────────────────────
  Future<void> _updateGroupPhoto() async {
    final source = await _showImageSourceDialog();
    if (source == null) return;
    final picked =
        await ImagePicker().pickImage(source: source, imageQuality: 80);
    if (picked == null) return;
    setState(() => _uploading = true);
    final url = await CloudinaryService.uploadImage(picked.path);
    if (url != null) {
      await _db
          .collection('groups')
          .doc(widget.groupId)
          .update({'photo': url});
    }
    if (mounted) setState(() => _uploading = false);
  }

  Future<ImageSource?> _showImageSourceDialog() async {
    return showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _sheetHandle(),
          const Text('Fotoğraf Seç',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16)),
          const SizedBox(height: 8),
          ListTile(
            leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.photo_library_rounded,
                    color: Colors.blue, size: 22)),
            title: const Text('Galeriden Seç',
                style: TextStyle(color: Colors.white)),
            onTap: () => Navigator.pop(context, ImageSource.gallery),
          ),
          ListTile(
            leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.camera_alt_rounded,
                    color: Colors.orange, size: 22)),
            title:
                const Text('Kamera', style: TextStyle(color: Colors.white)),
            onTap: () => Navigator.pop(context, ImageSource.camera),
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  // ── Grup adı düzenle ──────────────────────────────────────────────────
  Future<void> _editGroupName(String currentName) async {
    final ctrl = TextEditingController(text: currentName);
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: ColorsManager.darkPrimary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.group_rounded,
                  color: ColorsManager.darkPrimary, size: 20)),
          const SizedBox(width: 10),
          const Text('Grup Adı',
              style: TextStyle(color: Colors.white, fontSize: 18)),
        ]),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLength: 50,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Grup adını girin...',
            hintStyle: const TextStyle(color: Colors.white24),
            counterStyle: const TextStyle(color: Colors.white24),
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    color: ColorsManager.darkPrimary.withOpacity(0.3)),
                borderRadius: BorderRadius.circular(12)),
            focusedBorder: OutlineInputBorder(
                borderSide:
                    const BorderSide(color: ColorsManager.darkPrimary),
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal',
                  style: TextStyle(color: Colors.white38))),
          ElevatedButton(
              onPressed: () async {
                if (ctrl.text.trim().isNotEmpty) {
                  await _db
                      .collection('groups')
                      .doc(widget.groupId)
                      .update({'name': ctrl.text.trim()});
                }
                if (ctx.mounted) Navigator.pop(ctx);
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: ColorsManager.darkPrimary,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10))),
              child: const Text('Kaydet',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  // ── Açıklama düzenle ──────────────────────────────────────────────────
  Future<void> _editGroupDesc(String current) async {
    final ctrl = TextEditingController(text: current);
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.info_outline_rounded,
                  color: Colors.blue, size: 20)),
          const SizedBox(width: 10),
          const Text('Grup Açıklaması',
              style: TextStyle(color: Colors.white, fontSize: 18)),
        ]),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLines: 4,
          maxLength: 200,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Grup hakkında bir şeyler yaz...',
            hintStyle: const TextStyle(color: Colors.white24),
            counterStyle: const TextStyle(color: Colors.white24),
            enabledBorder: OutlineInputBorder(
                borderSide:
                    BorderSide(color: Colors.blue.withOpacity(0.3)),
                borderRadius: BorderRadius.circular(12)),
            focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: Colors.blue),
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal',
                  style: TextStyle(color: Colors.white38))),
          ElevatedButton(
              onPressed: () async {
                await _db
                    .collection('groups')
                    .doc(widget.groupId)
                    .update({'description': ctrl.text.trim()});
                if (ctx.mounted) Navigator.pop(ctx);
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10))),
              child: const Text('Kaydet',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  // ── Yönetici yap / al ──────────────────────────────────────────────────
  Future<void> _toggleAdmin(String uid, String name, bool isAdmin) async {
    if (isAdmin) {
      await _db.collection('groups').doc(widget.groupId).update(
          {'admins': FieldValue.arrayRemove([uid])});
      if (mounted) _showSnack('$name yöneticilikten alındı', Colors.orange);
    } else {
      await _db.collection('groups').doc(widget.groupId).update(
          {'admins': FieldValue.arrayUnion([uid])});
      if (mounted) _showSnack('$name yönetici yapıldı', ColorsManager.darkPrimary);
    }
  }

  // ── Üye çıkar ──────────────────────────────────────────────────────────
  Future<void> _removeMember(String uid, String name) async {
    final confirmed = await _confirmDialog(
      icon: Icons.person_remove_rounded,
      iconColor: Colors.red,
      title: '$name Gruptan Çıkar',
      message: '$name grubundan çıkarılacak.',
      confirmText: 'Çıkar',
      confirmColor: Colors.red,
    );
    if (confirmed == true) {
      await _db.collection('groups').doc(widget.groupId).update({
        'members': FieldValue.arrayRemove([uid]),
        'admins': FieldValue.arrayRemove([uid]),
      });
      if (mounted) _showSnack('$name gruptan çıkarıldı', Colors.red);
    }
  }

  // ── Yöneticiliği devret ──────────────────────────────────────────────
  Future<void> _transferOwner(String uid, String name) async {
    final confirmed = await _confirmDialog(
      icon: Icons.swap_horiz_rounded,
      iconColor: Colors.blue,
      title: 'Yöneticiliği Devret',
      message: "Yöneticiliği $name'e devretmek istiyor musunuz? Sen normal üye olacaksın.",
      confirmText: 'Devret',
      confirmColor: Colors.blue,
    );
    if (confirmed == true) {
      await _db.collection('groups').doc(widget.groupId).update(
          {'admins': FieldValue.arrayUnion([uid])});
      await _db.collection('groups').doc(widget.groupId).update(
          {'admins': FieldValue.arrayRemove([_myUid])});
      if (mounted) _showSnack("Yöneticilik $name'e devredildi", Colors.blue);
    }
  }

  // ── Üye ekle ──────────────────────────────────────────────────────────
  Future<void> _addMembers(List<String> currentMembers) async {
    final snap = await _db
        .collection('users')
        .doc(_myUid)
        .collection('contacts')
        .get();

    final contacts = <Map<String, dynamic>>[];
    for (final doc in snap.docs) {
      if (!currentMembers.contains(doc.id)) {
        final u = await _db.collection('users').doc(doc.id).get();
        final data = u.data();
        if (data != null) contacts.add({...data, 'uid': doc.id});
      }
    }

    if (!mounted) return;
    if (contacts.isEmpty) {
      _showSnack('Eklenebilecek kişi yok', Colors.orange);
      return;
    }

    final selected = <String>{};
    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111111),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => DraggableScrollableSheet(
          initialChildSize: 0.75,
          minChildSize: 0.4,
          maxChildSize: 0.95,
          expand: false,
          builder: (_, ctrl) => Column(children: [
            _sheetHandle(),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Row(children: [
                const Text('Üye Ekle',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18)),
                const Spacer(),
                if (selected.isNotEmpty)
                  ElevatedButton(
                    onPressed: () async {
                      Navigator.pop(ctx);
                      for (final uid in selected) {
                        await _db
                            .collection('groups')
                            .doc(widget.groupId)
                            .update({'members': FieldValue.arrayUnion([uid])});
                      }
                      if (mounted) {
                        _showSnack('${selected.length} kişi eklendi',
                            ColorsManager.darkPrimary);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: ColorsManager.darkPrimary,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    child: Text('Ekle (${selected.length})',
                        style: const TextStyle(color: Colors.white)),
                  ),
              ]),
            ),
            const Divider(color: Colors.white10, height: 1),
            Expanded(
              child: ListView.builder(
                controller: ctrl,
                itemCount: contacts.length,
                itemBuilder: (_, i) {
                  final c = contacts[i];
                  final uid = c['uid'] as String;
                  final sel = selected.contains(uid);
                  final photo = (c['profilePic'] ?? '').toString();
                  return ListTile(
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    leading: CircleAvatar(
                      radius: 22,
                      backgroundColor: const Color(0xFF2A2A2A),
                      backgroundImage:
                          photo.isNotEmpty ? NetworkImage(photo) : null,
                      child: photo.isEmpty
                          ? const Icon(Icons.person, color: Colors.white38)
                          : null,
                    ),
                    title: Text(c['name'] ?? '',
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w500)),
                    subtitle: Text('@${c['username'] ?? ''}',
                        style: TextStyle(
                            color: ColorsManager.darkPrimary, fontSize: 12)),
                    trailing: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: sel
                            ? ColorsManager.darkPrimary
                            : Colors.transparent,
                        border: Border.all(
                            color: sel
                                ? ColorsManager.darkPrimary
                                : Colors.white24,
                            width: 2),
                      ),
                      child: sel
                          ? const Icon(Icons.check,
                              size: 14, color: Colors.white)
                          : null,
                    ),
                    onTap: () => setSt(() {
                      sel ? selected.remove(uid) : selected.add(uid);
                    }),
                  );
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ── Gruptan ayrıl ────────────────────────────────────────────────────
  Future<void> _leaveGroup(List<String> admins) async {
    if (admins.contains(_myUid) && admins.length == 1) {
      _showSnack('Ayrılmadan önce başka bir yönetici atamalısın', Colors.orange);
      return;
    }
    final confirmed = await _confirmDialog(
      icon: Icons.exit_to_app_rounded,
      iconColor: Colors.red,
      title: 'Gruptan Ayrıl',
      message: 'Bu gruptan ayrılmak istediğinize emin misiniz?',
      confirmText: 'Ayrıl',
      confirmColor: Colors.red,
    );
    if (confirmed == true) {
      await _db.collection('groups').doc(widget.groupId).update({
        'members': FieldValue.arrayRemove([_myUid]),
        'admins': FieldValue.arrayRemove([_myUid]),
      });
      if (mounted) Navigator.pop(context);
    }
  }

  // ── Grubu sil ──────────────────────────────────────────────────────────
  Future<void> _deleteGroup() async {
    final confirmed = await _confirmDialog(
      icon: Icons.delete_forever_rounded,
      iconColor: Colors.red,
      title: 'Grubu Sil',
      message: 'Bu grup ve tüm mesajlar kalıcı olarak silinecek. Geri alınamaz!',
      confirmText: 'Grubu Sil',
      confirmColor: Colors.red,
    );
    if (confirmed == true) {
      final msgs = await _db
          .collection('groups')
          .doc(widget.groupId)
          .collection('messages')
          .get();
      for (final doc in msgs.docs) {
        await doc.reference.delete();
      }
      await _db.collection('groups').doc(widget.groupId).delete();
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    }
  }

  // ── Üye menüsü ────────────────────────────────────────────────────────
  void _showMemberOptions(String uid, String name, bool isAdmin,
      bool amAdmin, bool isCreator, List<String> admins) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _sheetHandle(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Row(children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: ColorsManager.darkPrimary.withOpacity(0.2),
                child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: const TextStyle(
                        color: ColorsManager.darkPrimary,
                        fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 12),
              Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16)),
                    if (isAdmin)
                      Text(isCreator ? 'Kurucu Yönetici' : 'Yönetici',
                          style: TextStyle(
                              color: ColorsManager.darkPrimary,
                              fontSize: 12)),
                  ]),
            ]),
          ),
          const Divider(color: Colors.white10, height: 1),
          if (amAdmin) ...[
            ListTile(
              leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: (isAdmin ? Colors.orange : Colors.green)
                          .withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10)),
                  child: Icon(
                      isAdmin
                          ? Icons.remove_moderator_outlined
                          : Icons.admin_panel_settings_outlined,
                      color: isAdmin ? Colors.orange : Colors.green,
                      size: 20)),
              title: Text(
                  isAdmin ? 'Yöneticilikten Al' : 'Yönetici Yap',
                  style: const TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _toggleAdmin(uid, name, isAdmin);
              },
            ),
            if (!isAdmin)
              ListTile(
                leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.swap_horiz_rounded,
                        color: Colors.blue, size: 20)),
                title: const Text('Yöneticiliği Devret',
                    style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pop(context);
                  _transferOwner(uid, name);
                },
              ),
            ListTile(
              leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.person_remove_rounded,
                      color: Colors.red, size: 20)),
              title: const Text('Gruptan Çıkar',
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _removeMember(uid, name);
              },
            ),
          ],
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  // ── Yardımcılar ──────────────────────────────────────────────────────
  Widget _sheetHandle() => Container(
        width: 40,
        height: 4,
        margin: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
            color: Colors.white24, borderRadius: BorderRadius.circular(2)),
      );

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))));
  }

  Future<bool?> _confirmDialog({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String message,
    required String confirmText,
    required Color confirmColor,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: iconColor, size: 20)),
          const SizedBox(width: 10),
          Expanded(
              child: Text(title,
                  style: const TextStyle(color: Colors.white, fontSize: 17))),
        ]),
        content: Text(message,
            style: const TextStyle(color: Colors.white70, height: 1.4)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('İptal',
                  style: TextStyle(color: Colors.white38))),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                  backgroundColor: confirmColor,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10))),
              child: Text(confirmText,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  Future<String> _getMemberName(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    return (doc.data() as Map<String, dynamic>?)?['name'] ?? 'Kullanıcı';
  }

  Widget _defaultGroupBg() => Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              ColorsManager.darkPrimary.withOpacity(0.4),
              const Color(0xFF0D0D0D),
            ],
          ),
        ),
        child: const Center(
            child: Icon(Icons.group_rounded,
                color: Colors.white12, size: 100)),
      );

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: _db.collection('groups').doc(widget.groupId).snapshots(),
      builder: (ctx, snap) {
        if (!snap.hasData) {
          return const Scaffold(
              backgroundColor: Color(0xFF0D0D0D),
              body: Center(
                  child: CircularProgressIndicator(
                      color: ColorsManager.darkPrimary)));
        }
        final group = snap.data!.data() as Map<String, dynamic>? ?? {};
        final name = group['name'] ?? 'Grup';
        final photo = group['photo'] ?? '';
        final description = group['description'] ?? '';
        final members = (group['members'] as List? ?? []).cast<String>();
        final admins = ((group['admins'] as List?) ?? [group['createdBy']])
            .whereType<String>()
            .toList();
        final createdBy = group['createdBy'] as String? ?? '';
        final amAdmin = admins.contains(_myUid);
        final isOnlyAdmin = admins.contains(_myUid) && admins.length == 1;

        return Scaffold(
          backgroundColor: const Color(0xFF0D0D0D),
          body: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              // ── Büyüyen AppBar ──────────────────────────────────────
              SliverAppBar(
                expandedHeight: 260.h,
                pinned: true,
                stretch: true,
                backgroundColor: const Color(0xFF0D0D0D),
                iconTheme: const IconThemeData(color: Colors.white),
                actions: [
                  if (amAdmin)
                    IconButton(
                      icon: const Icon(Icons.edit_rounded, color: Colors.white70),
                      tooltip: 'Grup Adını Düzenle',
                      onPressed: () => _editGroupName(name),
                    ),
                  IconButton(
                    icon: const Icon(Icons.more_vert_rounded, color: Colors.white70),
                    onPressed: () => showModalBottomSheet(
                      context: context,
                      backgroundColor: const Color(0xFF1A1A1A),
                      shape: const RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(20))),
                      builder: (_) => SafeArea(
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          _sheetHandle(),
                          ListTile(
                            leading: const Icon(Icons.link_rounded,
                                color: Colors.white70),
                            title: const Text('Grup Bağlantısını Kopyala',
                                style: TextStyle(color: Colors.white)),
                            onTap: () {
                              Navigator.pop(context);
                              Clipboard.setData(ClipboardData(
                                  text: 'asgard://group/${widget.groupId}'));
                              _showSnack('Bağlantı kopyalandı', Colors.green);
                            },
                          ),
                          const SizedBox(height: 8),
                        ]),
                      ),
                    ),
                  ),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  stretchModes: const [
                    StretchMode.zoomBackground,
                    StretchMode.blurBackground,
                  ],
                  background: Stack(fit: StackFit.expand, children: [
                    photo.isNotEmpty
                        ? ColorFiltered(
                            colorFilter: ColorFilter.mode(
                                Colors.black.withOpacity(0.45),
                                BlendMode.darken),
                            child: CachedNetworkImage(
                                imageUrl: photo,
                                fit: BoxFit.cover,
                                errorWidget: (_, __, ___) => _defaultGroupBg()))
                        : _defaultGroupBg(),

                    // Alt gradient
                    Positioned.fill(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.7),
                            ],
                            stops: const [0.5, 1.0],
                          ),
                        ),
                      ),
                    ),

                    // Grup adı
                    Positioned(
                      bottom: 16,
                      left: 16,
                      right: 70,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(name,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 22)),
                          const SizedBox(height: 4),
                          Text('${members.length} üye',
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 13)),
                        ],
                      ),
                    ),

                    // Fotoğraf değiştir
                    if (amAdmin)
                      Positioned(
                        bottom: 16,
                        right: 16,
                        child: GestureDetector(
                          onTap: _uploading ? null : _updateGroupPhoto,
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: ColorsManager.darkPrimary,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black38,
                                    blurRadius: 8,
                                    offset: const Offset(0, 3))
                              ],
                            ),
                            child: _uploading
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2, color: Colors.white))
                                : const Icon(Icons.camera_alt_rounded,
                                    color: Colors.white, size: 20),
                          ),
                        ),
                      ),
                  ]),
                ),
              ),

              SliverList(
                delegate: SliverChildListDelegate([
                  // ── Açıklama ──────────────────────────────────────────
                  _SectionCard(children: [
                    _InfoRow(
                      icon: Icons.info_outline_rounded,
                      iconColor: Colors.blue,
                      label: 'Açıklama',
                      value: description.isEmpty ? 'Açıklama ekle...' : description,
                      valueColor:
                          description.isEmpty ? Colors.white24 : Colors.white70,
                      onTap: amAdmin ? () => _editGroupDesc(description) : null,
                      trailing: amAdmin
                          ? const Icon(Icons.edit_outlined,
                              color: Colors.white24, size: 16)
                          : null,
                    ),
                  ]),

                  Gap(8.h),

                  // ── Yöneticiler ──────────────────────────────────────
                  _SectionCard(children: [
                    _SectionHeader(
                        icon: Icons.admin_panel_settings_rounded,
                        iconColor: ColorsManager.darkPrimary,
                        label: 'YÖNETİCİLER'),
                    ...admins.map((uid) => _MemberTile(
                          uid: uid,
                          myUid: _myUid,
                          admins: admins,
                          createdBy: createdBy,
                          isAdmin: true,
                          onTap: uid != _myUid && amAdmin
                              ? () async {
                                  final n = await _getMemberName(uid);
                                  if (mounted) {
                                    _showMemberOptions(uid, n, true, amAdmin,
                                        uid == createdBy, admins);
                                  }
                                }
                              : null,
                        )),
                  ]),

                  Gap(8.h),

                  // ── Üyeler ───────────────────────────────────────────
                  _SectionCard(children: [
                    _SectionHeader(
                      icon: Icons.people_rounded,
                      iconColor: Colors.white38,
                      label: '${members.length} ÜYE',
                      trailing: amAdmin
                          ? GestureDetector(
                              onTap: () => _addMembers(members),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: ColorsManager.darkPrimary
                                      .withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                      color: ColorsManager.darkPrimary
                                          .withOpacity(0.4)),
                                ),
                                child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.person_add_outlined,
                                          color: ColorsManager.darkPrimary,
                                          size: 14),
                                      const SizedBox(width: 4),
                                      Text('Üye Ekle',
                                          style: TextStyle(
                                              color: ColorsManager.darkPrimary,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600)),
                                    ]),
                              ),
                            )
                          : null,
                    ),
                    // Normal üyeler
                    ...members
                        .where((uid) => !admins.contains(uid))
                        .map((uid) => _MemberTile(
                              uid: uid,
                              myUid: _myUid,
                              admins: admins,
                              createdBy: createdBy,
                              isAdmin: false,
                              onTap: uid != _myUid && amAdmin
                                  ? () async {
                                      final n = await _getMemberName(uid);
                                      if (mounted) {
                                        _showMemberOptions(uid, n, false,
                                            amAdmin, uid == createdBy, admins);
                                      }
                                    }
                                  : null,
                            )),
                  ]),

                  Gap(8.h),

                  // ── Tehlikeli Bölge ──────────────────────────────────
                  _SectionCard(children: [
                    ListTile(
                      leading: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                              color: Colors.red.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10)),
                          child: const Icon(Icons.exit_to_app_rounded,
                              color: Colors.red, size: 20)),
                      title: const Text('Gruptan Ayrıl',
                          style: TextStyle(
                              color: Colors.red, fontWeight: FontWeight.w600)),
                      subtitle: isOnlyAdmin
                          ? const Text('Önce başka yönetici atamalısın',
                              style: TextStyle(
                                  color: Colors.orange, fontSize: 12))
                          : null,
                      onTap: () => _leaveGroup(admins),
                    ),
                    if (amAdmin) ...[
                      const Divider(color: Colors.white10, height: 1),
                      ListTile(
                        leading: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: Colors.red.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(10)),
                            child: const Icon(Icons.delete_forever_rounded,
                                color: Colors.red, size: 20)),
                        title: const Text('Grubu Sil',
                            style: TextStyle(
                                color: Colors.red, fontWeight: FontWeight.w600)),
                        subtitle: const Text('Tüm mesajlar silinir',
                            style: TextStyle(
                                color: Colors.white38, fontSize: 12)),
                        onTap: _deleteGroup,
                      ),
                    ],
                  ]),

                  Gap(32.h),
                ]),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ── Widget yardımcıları ──────────────────────────────────────────────────────

class _SectionCard extends StatelessWidget {
  final List<Widget> children;
  const _SectionCard({required this.children});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF161616),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.06)),
        ),
        child: Column(children: children),
      );
}

class _SectionHeader extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final Widget? trailing;
  const _SectionHeader(
      {required this.icon,
      required this.iconColor,
      required this.label,
      this.trailing});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
        child: Row(children: [
          Icon(icon, color: iconColor, size: 16),
          const SizedBox(width: 8),
          Text(label,
              style: TextStyle(
                  color: iconColor,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2)),
          const Spacer(),
          if (trailing != null) trailing!,
        ]),
      );
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label, value;
  final Color valueColor;
  final VoidCallback? onTap;
  final Widget? trailing;
  const _InfoRow(
      {required this.icon,
      required this.iconColor,
      required this.label,
      required this.value,
      this.valueColor = Colors.white60,
      this.onTap,
      this.trailing});

  @override
  Widget build(BuildContext context) => ListTile(
        leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: iconColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: iconColor, size: 20)),
        title: Text(label,
            style: const TextStyle(color: Colors.white38, fontSize: 11)),
        subtitle:
            Text(value, style: TextStyle(color: valueColor, fontSize: 14)),
        trailing: trailing,
        onTap: onTap,
      );
}

class _MemberTile extends StatelessWidget {
  final String uid, myUid, createdBy;
  final List<String> admins;
  final bool isAdmin;
  final VoidCallback? onTap;

  const _MemberTile({
    required this.uid,
    required this.myUid,
    required this.admins,
    required this.createdBy,
    required this.isAdmin,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isMe = uid == myUid;
    final isCreator = uid == createdBy;

    return FutureBuilder<DocumentSnapshot>(
      future:
          FirebaseFirestore.instance.collection('users').doc(uid).get(),
      builder: (ctx, snap) {
        final data = snap.data?.data() as Map<String, dynamic>?;
        final name = data?['name'] ?? 'Kullanıcı';
        final photo = data?['profilePic'] ?? '';
        final username = data?['username'] ?? '';

        return ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
          leading: Stack(children: [
            CircleAvatar(
              radius: 22,
              backgroundColor: const Color(0xFF2A2A2A),
              backgroundImage:
                  photo.isNotEmpty ? NetworkImage(photo) : null,
              child: photo.isEmpty
                  ? Text(
                      name.isNotEmpty ? name[0].toUpperCase() : '?',
                      style: TextStyle(
                          color: ColorsManager.darkPrimary,
                          fontWeight: FontWeight.bold))
                  : null,
            ),
            if (isAdmin)
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: ColorsManager.darkPrimary,
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: const Color(0xFF161616), width: 1.5),
                  ),
                  child: const Icon(Icons.admin_panel_settings,
                      size: 9, color: Colors.white),
                ),
              ),
          ]),
          title: Row(children: [
            Flexible(
              child: Text(
                isMe ? '$name (Sen)' : name,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (isCreator) ...[
              const SizedBox(width: 6),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                        color: Colors.amber.withOpacity(0.4))),
                child: const Text('Kurucu',
                    style: TextStyle(
                        color: Colors.amber,
                        fontSize: 9,
                        fontWeight: FontWeight.bold)),
              ),
            ] else if (isAdmin) ...[
              const SizedBox(width: 6),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                    color: ColorsManager.darkPrimary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                        color: ColorsManager.darkPrimary.withOpacity(0.4))),
                child: Text('Yönetici',
                    style: TextStyle(
                        color: ColorsManager.darkPrimary,
                        fontSize: 9,
                        fontWeight: FontWeight.bold)),
              ),
            ],
          ]),
          subtitle: username.isNotEmpty
              ? Text('@$username',
                  style: const TextStyle(
                      color: Colors.white38, fontSize: 12))
              : null,
          trailing: onTap != null
              ? const Icon(Icons.more_vert_rounded,
                  color: Colors.white24, size: 18)
              : null,
          onTap: onTap,
          onLongPress: onTap,
        );
      },
    );
  }
}
