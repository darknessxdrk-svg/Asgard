import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_view/photo_view.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/networking/dio_factory.dart';
import '../../../helpers/extensions.dart';
import '../../../helpers/notifications.dart';
import '../../../router/routes.dart';
import '../../../services/cloudinary_service.dart';
import '../../../services/database.dart';
import '../../../services/notification_service.dart';
import '../../../themes/colors.dart';
import 'starred_messages_screen.dart';
import 'ai_assistant_screen.dart';
import '../../tasks/ui/tasks_screen.dart';
import 'secret_chat_page.dart';
import '../../profile/ui/profile_screen.dart';
import '../../call/ui/call_screen.dart';
import 'widgets/message_bar.dart';
import 'widgets/url_preview.dart';
import '../../../core/utils/font_size_provider.dart';

class ChatScreen extends StatefulWidget {
  final String receivedUserName;
  final String receivedUserID;
  final String receivedMToken;
  final String active;
  final String? receivedUserProfilePic;
  const ChatScreen({
    super.key,
    required this.receivedUserName,
    required this.receivedUserID,
    required this.receivedMToken,
    required this.active,
    required this.receivedUserProfilePic,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  Color _chatTheme = const Color(0xFF0D0D0D);

  // ✅ FIX: Chat temasını prefs'den yükle
  Future<void> _loadAutoDelete() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'auto_delete_${widget.receivedUserID}';
    final saved = prefs.getInt(key);
    if (mounted) setState(() => _autoDeleteSeconds = saved);
  }

  Future<void> _loadChatTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final wallpaper = prefs.getString('chat_wallpaper') ?? 'default';
    final color = _wallpaperToColor(wallpaper);
    if (mounted) setState(() => _chatTheme = color);
  }

  Color _wallpaperToColor(String id) {
    switch (id) {
      case 'dark': return const Color(0xFF0D0D0D);
      case 'blue': return const Color(0xFF0D1B2A);
      case 'red': return const Color(0xFF1A0505);
      default: return const Color(0xFF0D0D0D);
    }
  }
  final _chatService = NotificationService();
  final _auth = FirebaseAuth.instance;
  final _picker = ImagePicker();
  final _searchCtrl = TextEditingController();

  bool _searchMode = false;
  String _searchQuery = '';
  Timer? _typingTimer;

  // ── Seçim Modu ────────────────────────────────────────────────────────
  bool _selectionMode = false;
  final Set<String> _selectedMsgIds = {};
  final ScrollController _msgScrollCtrl = ScrollController();
  late final ValueNotifier<Set<String>> _selectionNotifier = ValueNotifier({});

  // ── Engelleme ─────────────────────────────────────────────────────────
  bool _isBlocked = false;

  // ── Otomatik Silme ────────────────────────────────────────────────────
  int? _autoDeleteSeconds;
  // Sabit kullanıcı UID - bir kez set edilir
  late final String _myUID; // null = kapalı

  // ── Alıntı (Reply) ────────────────────────────────────────────────────
  Map<String, dynamic>? _replyToMessage; // alıntılanan mesaj
  String? _highlightedMsgId;
  final Map<String, int> _msgIndexMap = {};

  void _scrollToReply(String msgId) {
    final idx = _msgIndexMap[msgId];
    if (_msgScrollCtrl.hasClients) {
      if (idx != null) {
        final total = _msgIndexMap.length;
        final pos = (total - 1 - idx) * 75.0;
        _msgScrollCtrl.animateTo(pos.clamp(0.0, _msgScrollCtrl.position.maxScrollExtent),
            duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
      } else {
        _msgScrollCtrl.animateTo(_msgScrollCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
      }
    }
    setState(() => _highlightedMsgId = msgId);
    Future.delayed(const Duration(seconds: 2), () { if (mounted) setState(() => _highlightedMsgId = null); });
  }


  /// lastSeen alanı Timestamp veya int olabilir - güvenli oku
  static DateTime? _parseLastSeen(dynamic raw) {
    if (raw == null) return null;
    if (raw is int) return DateTime.fromMillisecondsSinceEpoch(raw);
    if (raw is Timestamp) return raw.toDate();
    return null;
  }
  @override
  void initState() {
    super.initState();
    _myUID = _auth.currentUser?.uid ?? '';
    WidgetsBinding.instance.addObserver(this);
    // Font boyutu değişince mesajları yeniden çiz
    FontSizeProvider.instance.addListener(_onFontSizeChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _markReadIfEnabled();
      _checkBlocked();
      _loadChatTheme();
      _loadAutoDelete();
      DatabaseMethods.deleteExpiredMessages(widget.receivedUserID);
    });
  }

  void _onFontSizeChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _checkBlocked() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('blocked')
        .doc(widget.receivedUserID)
        .get();
    if (mounted) setState(() => _isBlocked = doc.exists);
  }

  Future<void> _toggleBlock() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final ref = FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('blocked')
        .doc(widget.receivedUserID);
    if (_isBlocked) {
      await ref.delete();
      if (mounted) { setState(() => _isBlocked = false); _showSnack('Engel kaldırıldı'); }
    } else {
      await ref.set({'blockedAt': FieldValue.serverTimestamp()});
      if (mounted) { setState(() => _isBlocked = true); _showSnack('Kullanıcı engellendi'); }
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _markReadIfEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    // ✅ FIX: Okundu bilgisi kapalıysa markMessagesAsRead çağırma
    final enabled = prefs.getBool('read_receipts_enabled') ?? true;
    DatabaseMethods.markMessagesAsRead(widget.receivedUserID,
        readReceiptsEnabled: enabled);
  }

  @override
  void dispose() {
    FontSizeProvider.instance.removeListener(_onFontSizeChanged);
    WidgetsBinding.instance.removeObserver(this);
    DatabaseMethods.setTyping(widget.receivedUserID, false);
    DatabaseMethods.updateLastSeen();
    _searchCtrl.dispose();
    _typingTimer?.cancel();
    _selectionNotifier.dispose();
    _msgScrollCtrl.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _markReadIfEnabled();
    } else if (state == AppLifecycleState.paused) {
      DatabaseMethods.updateLastSeen();
    }
  }

  void _onTyping() {
    DatabaseMethods.setTyping(widget.receivedUserID, true);
    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 2), () {
      DatabaseMethods.setTyping(widget.receivedUserID, false);
    });
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    if (_selectionMode) {
      return AppBar(
        backgroundColor: const Color(0xFF1A0000),
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () {
            _selectedMsgIds.clear();
            _selectionNotifier.value = {};
            setState(() => _selectionMode = false);
          },
        ),
        title: ValueListenableBuilder<Set<String>>(
          valueListenable: _selectionNotifier,
          builder: (_, sel, __) => Text('${sel.length} seçildi', style: const TextStyle(color: Colors.white)),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            tooltip: 'Sil',
            onPressed: () async {
              final ids = List<String>.from(_selectedMsgIds);
              setState(() { _selectionMode = false; _selectedMsgIds.clear(); });
              for (final id in ids) {
                await DatabaseMethods.deleteMessageForEveryone(id, widget.receivedUserID);
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.forward, color: Colors.white70),
            tooltip: 'İlet',
            onPressed: () async {
              final msgs = List<String>.from(_selectedMsgIds);
              final myUID = _auth.currentUser?.uid ?? '';
              setState(() { _selectionMode = false; _selectedMsgIds.clear(); _selectionNotifier.value = {}; });
              final texts = <String>[];
              final chatRoomID = DatabaseMethods.getChatRoomID(myUID, widget.receivedUserID);
              for (final id in msgs) {
                try {
                  final doc = await FirebaseFirestore.instance
                      .collection('chats')
                      .doc(chatRoomID)
                      .collection('messages')
                      .doc(id)
                      .get();
                  final content = (doc.data()?['message'] ?? '').toString();
                  if (content.isNotEmpty) texts.add(content);
                } catch (_) {}
              }
              if (!context.mounted || texts.isEmpty) return;
              _showForwardDialog(texts.join('\n'));
            },
          ),
        ],
      );
    }
    return _buildNormalAppBar(context);
  }

  void _showForwardDialog(String text) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const Text('Kişiye İlet', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          StreamBuilder<QuerySnapshot>(
            stream: DatabaseMethods.getContacts(),
            builder: (ctx, snap) {
              final docs = snap.data?.docs ?? [];
              return ListView.builder(
                shrinkWrap: true,
                itemCount: docs.length,
                itemBuilder: (ctx, i) {
                  return FutureBuilder<DocumentSnapshot>(
                    future: FirebaseFirestore.instance.collection('users').doc(docs[i].id).get(),
                    builder: (ctx, uSnap) {
                      final data = uSnap.data?.data() as Map<String, dynamic>?;
                      if (data == null) return const ColoredBox(color: Color(0xFF0D0D0D), child: SizedBox());
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundImage: (data['profilePic'] ?? '').isNotEmpty ? NetworkImage(data['profilePic']) : null,
                          backgroundColor: const Color(0xFF2A2A2A),
                          child: (data['profilePic'] ?? '').isEmpty ? const Icon(Icons.person, color: Colors.white38) : null,
                        ),
                        title: Text(data['name'] ?? '', style: const TextStyle(color: Colors.white)),
                        onTap: () async {
                          Navigator.pop(context);
                          await DatabaseMethods.sendMessage(text, docs[i].id);
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Mesaj iletildi'), backgroundColor: Color(0xFF1A1A1A)),
                            );
                          }
                        },
                      );
                    },
                  );
                },
              );
            },
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _chatTheme,
      resizeToAvoidBottomInset: true,
      appBar: _buildAppBar(context),
      body: SafeArea(
        bottom: true,
        child: Column(
        children: [
          // Sabitlenmiş mesaj banner
          _PinnedMessageBanner(otherUserID: widget.receivedUserID),
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: Opacity(
                    opacity: 0.04,
                    child: Image.asset('assets/images/chat_backgrond.png', fit: BoxFit.cover),
                  ),
                ),
                _buildMessagesList(),
              ],
            ),
          ),
              // ✅ FIX: Engellenmiş kullanıcıya mesaj göndermez
              // Alıntı banner
              if (_replyToMessage != null)
                Container(
                  color: const Color(0xFF1A1A1A),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(children: [
                    Container(width: 3, height: 36, color: ColorsManager.darkPrimary,
                        margin: const EdgeInsets.only(right: 8)),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(
                        _replyToMessage!['senderID'] == _auth.currentUser?.uid ? 'Sen' : widget.receivedUserName,
                        style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        (_replyToMessage!['message'] ?? '').toString().length > 50
                            ? '${(_replyToMessage!['message'] ?? '').toString().substring(0, 50)}...'
                            : (_replyToMessage!['message'] ?? '').toString(),
                        style: const TextStyle(color: Colors.white54, fontSize: 12),
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                      ),
                    ])),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white38, size: 18),
                      onPressed: () => setState(() => _replyToMessage = null),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ]),
                ),
              if (_isBlocked)
                Container(
                  color: const Color(0xFF1A0A0A),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.block, color: Colors.red.shade400, size: 16),
                    const SizedBox(width: 8),
                    Text('Bu kullanıcıyı engellediniz',
                        style: TextStyle(color: Colors.red.shade400, fontSize: 13)),
                    const Spacer(),
                    GestureDetector(
                      onTap: _toggleBlock,
                      child: Text('Kaldır', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold, fontSize: 13)),
                    ),
                  ]),
                )
              else
              CustomMessageBar(
                onSend: (message) async {
                  if (_isBlocked) return; // ekstra güvenlik
                  // /ai komutu kontrolü ÖNCE yapılır - normal mesaj gönderilmez
                  if (message.toLowerCase().startsWith('@ai ')) {
                    final question = message.substring(4).trim();
                    if (question.isEmpty) return;
                    // Kullanıcının /ai mesajını gönder
                    await DatabaseMethods.sendMessage(message, widget.receivedUserID);
                    try {
                      const geminiKey = String.fromEnvironment('GEMINI_API_KEY');
                      if (geminiKey.isEmpty) {
                        await DatabaseMethods.sendMessageAsAI('⚠️ Gemini API anahtarı yapılandırılmamış. GitHub Secrets > GEMINI_API_KEY ekleyin.', widget.receivedUserID);
                        return;
                      }
                      final resp = await http.post(
                        Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$geminiKey'),
                        headers: {'Content-Type': 'application/json'},
                        body: jsonEncode({
                          'system_instruction': {'parts': [{'text': 'Sen Asgard sohbet asistanisin. Kisa ve Turkce cevap ver.'}]},
                          'contents': [{'role': 'user', 'parts': [{'text': question}]}],
                          'generationConfig': {'maxOutputTokens': 600},
                        }),
                      );
                      final data = jsonDecode(resp.body);
                      if (resp.statusCode != 200) {
                        final code = data['error']?['code'] ?? resp.statusCode;
                        final String msg;
                        if (code == 429) msg = '⚠️ AI kota doldu. Biraz bekleyip tekrar deneyin.';
                        else if (code == 403) msg = '⚠️ AI erişim reddedildi. API key geçersiz.';
                        else if (code == 404) msg = '⚠️ AI modeli bulunamadı. Geliştirici ile iletişime geçin.';
                        else msg = '⚠️ AI şu an yanıt veremiyor (kod: $code). Tekrar deneyin.';
                        await DatabaseMethods.sendMessageAsAI(msg, widget.receivedUserID);
                        return;
                      }
                      final reply = data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? 'Yanıt alınamadı';
                      await DatabaseMethods.sendMessageAsAI(reply, widget.receivedUserID);
                    } catch (e) {
                      await DatabaseMethods.sendMessageAsAI('⚠️ Bağlantı hatası. İnternet bağlantını kontrol et.', widget.receivedUserID);
                    }
                  } else {
                    await DatabaseMethods.sendMessage(message, widget.receivedUserID,
                        autoDeleteSeconds: _autoDeleteSeconds,
                        replyTo: _replyToMessage);
                    // Bildirim gönder
                    _sendNotification(message);
                    if (mounted) setState(() => _replyToMessage = null);
                  }
                },
                onShowOptions: () {},
                onSendImage: (url) async {
                  await DatabaseMethods.sendMessage(url, widget.receivedUserID,
                      autoDeleteSeconds: _autoDeleteSeconds);
                  _sendNotification('📷 Fotoğraf');
                },

                onSendAudio: (url) async {
                  await DatabaseMethods.sendMessage(url, widget.receivedUserID,
                      autoDeleteSeconds: _autoDeleteSeconds);
                  _sendNotification('🎤 Sesli mesaj');
                },
              ),
        ],
      ),
      ),
    );
  }

  PreferredSizeWidget _buildNormalAppBar(BuildContext context) {
    if (_searchMode) {
      return AppBar(
        backgroundColor: const Color(0xFF111111),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white70),
          onPressed: () => setState(() { _searchMode = false; _searchQuery = ''; _searchCtrl.clear(); }),
        ),
        title: TextField(
          controller: _searchCtrl,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Mesajlarda ara...',
            hintStyle: TextStyle(color: Colors.white38),
            border: InputBorder.none,
          ),
          onChanged: (v) => setState(() => _searchQuery = v.toLowerCase()),
        ),
      );
    }
    return PreferredSize(
      preferredSize: const Size.fromHeight(kToolbarHeight),
      child: SafeArea(
        bottom: false,
        child: Container(
          height: kToolbarHeight,
          color: const Color(0xFF111111),
          child: Row(
            children: [
          // Geri butonu
          IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white70, size: 20),
            onPressed: () => Navigator.pop(context),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 40),
          ),
          // Avatar
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => ProfileScreen(userID: widget.receivedUserID))),
            child: Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: widget.active == 'true'
                      ? ColorsManager.darkPrimary
                      : const Color(0xFF333333),
                  width: 2,
                ),
              ),
              child: ClipOval(
                child: widget.receivedUserProfilePic != null &&
                        widget.receivedUserProfilePic!.isNotEmpty
                    ? CachedNetworkImage(
                        imageUrl: widget.receivedUserProfilePic!,
                        fit: BoxFit.cover,
                        placeholder: (_, __) => const ColoredBox(color: Color(0xFF1A1A1A)),
                        errorWidget: (_, __, ___) =>
                            Image.asset('assets/images/user.png', fit: BoxFit.cover),
                      )
                    : Image.asset('assets/images/user.png', fit: BoxFit.cover),
              ),
            ),
          ),
          const SizedBox(width: 8),
          // İsim + durum — Expanded ile taşma önlenir
          Expanded(
            child: GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ProfileScreen(userID: widget.receivedUserID))),
              child: StreamBuilder<DocumentSnapshot>(
                stream: DatabaseMethods.getUserStream(widget.receivedUserID),
                builder: (ctx, snap) {
                  final userData = snap.data?.data() as Map<String, dynamic>?;
                  final isOnline = userData?['isOnline'] == 'true';
                  final lastSeenDt = _parseLastSeen(userData?['lastSeen']);
                  return StreamBuilder<DocumentSnapshot>(
                    stream: DatabaseMethods.getTypingStream(widget.receivedUserID),
                    builder: (ctx2, tSnap) {
                      final chatData = tSnap.data?.data() as Map<String, dynamic>?;
                      final isTyping = chatData?['typing_${widget.receivedUserID}'] == true;
                      String subtitle;
                      if (isTyping) {
                        subtitle = 'yazıyor...';
                      } else if (isOnline) {
                        subtitle = 'Çevrimiçi';
                      } else if (lastSeenDt != null) {
                        final diff = DateTime.now().difference(lastSeenDt);
                        if (diff.inMinutes < 1) subtitle = 'Az önce görüldü';
                        else if (diff.inMinutes < 60) subtitle = '${diff.inMinutes} dk önce';
                        else if (diff.inHours < 24) subtitle = DateFormat('HH:mm').format(lastSeenDt);
                        else subtitle = DateFormat('d MMM').format(lastSeenDt);
                      } else {
                        subtitle = 'Çevrimdışı';
                      }
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            widget.receivedUserName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                          Text(
                            subtitle,
                            style: TextStyle(
                              color: isTyping
                                  ? Colors.greenAccent
                                  : isOnline
                                      ? ColorsManager.darkPrimary
                                      : Colors.white38,
                              fontSize: 11,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ),
          // Arama butonları
          IconButton(
            icon: const Icon(Icons.call_rounded, color: Colors.green, size: 20),
            onPressed: () => _startCall(false),
            tooltip: 'Sesli Ara',
          ),
          IconButton(
            icon: const Icon(Icons.videocam_rounded, color: Colors.lightBlue, size: 20),
            onPressed: () => _startCall(true),
            tooltip: 'Görüntülü Ara',
          ),
          IconButton(
            icon: const Icon(Icons.more_vert, color: Colors.white54),
            onPressed: _showChatOptions,
          ),
          const SizedBox(width: 4),
        ],
      ),
    ),
      ),
    );
  }


  void _sendNotification(String message) {
    // receivedMToken boşsa bildirim gönderilmez
    if (widget.receivedMToken.isEmpty) return;
    final myUID = _auth.currentUser?.uid ?? '';
    final myName = _auth.currentUser?.displayName ?? 
                   _auth.currentUser?.email?.split('@').first ?? 'Asgard';
    // Mesaj önizlemesi: resim/ses ise emoji göster
    String preview = message;
    if (_isImageMessage(message)) preview = '📷 Fotoğraf';
    else if (_isAudioMessage(message)) preview = '🎤 Sesli mesaj';
    else if (message.length > 60) preview = '${message.substring(0, 60)}...';

    _chatService.sendPushMessage(
      widget.receivedMToken,
      '',
      preview,
      myName,
      myUID,
      widget.receivedUserProfilePic,
      receiverUID: widget.receivedUserID,
    );
  }

  void _startCall(bool isVideo) {
    final myUID = _auth.currentUser?.uid ?? '';
    // Agora channel name: max 64 karakter, sadece alfanumerik
    final ts = DateTime.now().millisecondsSinceEpoch;
    final callId = 'ch${ts.toString().substring(6)}';
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => CallScreen(
        callId: callId,
        calleeName: widget.receivedUserName,
        calleeUID: widget.receivedUserID,
        isVideoCall: isVideo,
        calleeMToken: widget.receivedMToken,
      ),
    ));
  }

  void _showChatOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111111),
      isScrollControlled: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        ListTile(leading: Icon(Icons.person_outline, color: ColorsManager.darkPrimary),
            title: const Text('Profili Görüntüle', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(userID: widget.receivedUserID))); }),
        ListTile(
            leading: Icon(Icons.block, color: Colors.red.shade400),
            title: Text(_isBlocked ? 'Engeli Kaldır' : 'Engelle', style: TextStyle(color: Colors.red.shade400)),
            onTap: () { Navigator.pop(context); _toggleBlock(); }),
        const Divider(color: Colors.white10, height: 1),
        ListTile(
            leading: const Icon(Icons.star_rounded, color: Colors.amber),
            title: const Text('⭐ Yıldızlı Mesajlar', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => const StarredMessagesScreen())); }),
        ListTile(
            leading: const Icon(Icons.auto_awesome_rounded, color: Colors.purple),
            title: const Text('🤖 AI Asistan', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => const AIAssistantScreen())); }),
        ListTile(
            leading: const Icon(Icons.lock_rounded, color: Colors.green),
            title: const Text('🔒 Gizli Sohbet', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => SecretChatPage(
              otherUid: widget.receivedUserID,
              otherName: widget.receivedUserName,
              otherPhoto: '',
            ))); }),
        ListTile(
            leading: const Icon(Icons.palette_rounded, color: Colors.deepOrange),
            title: const Text('🎨 Sohbet Teması', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _showThemePicker(); }),
        const Divider(color: Colors.white10, height: 1),
        ListTile(
            leading: const Icon(Icons.photo_library_outlined, color: Colors.lightBlue),
            title: const Text('🖼️ Medya & Dosyalar', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _showMediaFilter(); }),
        ListTile(
            leading: Icon(Icons.timer_outlined, color: _autoDeleteSeconds != null ? Colors.orange : Colors.white54),
            title: Text(
              _autoDeleteSeconds == null
                  ? '⏰ Otomatik Silme: Kapalı'
                  : '⏰ Otomatik Silme: ${_autoDeleteSeconds! < 3600 ? "${_autoDeleteSeconds! ~/ 60} dk" : "${_autoDeleteSeconds! ~/ 3600} saat"}',
              style: TextStyle(color: _autoDeleteSeconds != null ? Colors.orange : Colors.white),
            ),
            onTap: () { Navigator.pop(context); _showAutoDeleteDialog(); }),
        ListTile(
            leading: const Icon(Icons.cleaning_services_outlined, color: Colors.redAccent),
            title: const Text('🗑️ Sohbeti Temizle', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _showClearChatDialog(); }),
      ]))),
    );
  }

  void _showClearChatDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Sohbeti Temizle', style: TextStyle(color: Colors.white)),
        content: const Text('Tüm mesajlar nasıl silinsin?', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              _showLoadingDialog();
              final msgs = await DatabaseMethods.getMessages(widget.receivedUserID, _auth.currentUser!.uid).first;
              for (final doc in msgs.docs) {
                await DatabaseMethods.deleteMessageForMe(doc.id, widget.receivedUserID);
              }
              if (mounted) { context.pop(); ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Sohbet temizlendi (sadece senden)'))); }
            },
            child: const Text('Benden Sil', style: TextStyle(color: Colors.orange)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              _showLoadingDialog();
              final myUID = _auth.currentUser!.uid;
              final msgs = await DatabaseMethods.getMessages(widget.receivedUserID, myUID).first;
              for (final doc in msgs.docs) {
                final data = doc.data() as Map<String, dynamic>;
                if (data['senderID'] == myUID) {
                  await DatabaseMethods.deleteMessageForEveryone(doc.id, widget.receivedUserID);
                } else {
                  await DatabaseMethods.deleteMessageForMe(doc.id, widget.receivedUserID);
                }
              }
              if (mounted) { context.pop(); ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Sohbet temizlendi (herkesten)'))); }
            },
            child: const Text('Herkesten Sil', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showAutoDeleteDialog() {
    final options = [
      {'label': 'Kapalı', 'value': null},
      {'label': '1 Dakika', 'value': 60},
      {'label': '5 Dakika', 'value': 300},
      {'label': '1 Saat', 'value': 3600},
      {'label': '1 Gün', 'value': 86400},
      {'label': '1 Hafta', 'value': 604800},
    ];
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Otomatik Silme', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 4),
        const Text('Gönderilen mesajlar belirlenen süre sonra silinir',
            style: TextStyle(color: Colors.white38, fontSize: 12)),
        const SizedBox(height: 8),
        ...options.map((o) {
          final val = o['value'] as int?;
          final selected = _autoDeleteSeconds == val;
          return ListTile(
            leading: Icon(
              val == null ? Icons.timer_off_outlined : Icons.timer_outlined,
              color: selected ? Colors.orange : Colors.white54,
            ),
            title: Text(o['label'] as String,
                style: TextStyle(color: selected ? Colors.orange : Colors.white, fontWeight: selected ? FontWeight.bold : FontWeight.normal)),
            trailing: selected ? const Icon(Icons.check_circle_rounded, color: Colors.orange) : null,
            onTap: () {
              setState(() => _autoDeleteSeconds = val);
              // Kalıcı kaydet
              SharedPreferences.getInstance().then((p) {
                final key = 'auto_delete_${widget.receivedUserID}';
                if (val == null) p.remove(key);
                else p.setInt(key, val);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(val == null ? 'Otomatik silme kapatıldı' : 'Otomatik silme: ${o['label']}'),
                backgroundColor: val == null ? Colors.white24 : Colors.orange,
              ));
            },
          );
        }),
        const SizedBox(height: 8),
      ])),
    );
  }

  void _showMediaFilter() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => _MediaFilterPage(
        chatRoomId: DatabaseMethods.getChatRoomId(widget.receivedUserID, _auth.currentUser!.uid),
        myUID: _auth.currentUser!.uid,
        otherUID: widget.receivedUserID,
        otherName: widget.receivedUserName,
      )),
    );
  }

  Widget _buildMessagesList() {
    final allMessages = DatabaseMethods.getMessages(widget.receivedUserID, _auth.currentUser!.uid);
    return StreamBuilder<QuerySnapshot>(
      stream: allMessages,
      builder: (context, snapshot) {
        if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
        }
        final docs = snapshot.data!.docs;
        final myUID = _auth.currentUser!.uid;

        // Arama filtresi
        final filtered = _searchQuery.isEmpty ? docs : docs.where((d) {
          final msg = ((d.data() as Map)['message'] ?? '').toString().toLowerCase();
          return msg.contains(_searchQuery);
        }).toList();

        if (filtered.isEmpty) {
          return Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.chat_bubble_outline, size: 48.sp, color: Colors.white12),
              Gap(12.h),
              Text(_searchQuery.isEmpty ? 'Henüz mesaj yok' : '"$_searchQuery" bulunamadı',
                  style: TextStyle(color: Colors.white24, fontSize: 14.sp)),
            ]),
          );
        }

        return ListView.builder(
          controller: _msgScrollCtrl,
          reverse: !_searchQuery.isNotEmpty,
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
          itemCount: filtered.length,
          itemBuilder: (context, index) {
            final current = filtered[index];
            final data = current.data() as Map<String, dynamic>;
            final msgId = current.id;

            // Benden gizlendi mi?
            final hiddenFor = List.from(data['hiddenFor'] ?? []);
            if (hiddenFor.contains(myUID)) return const ColoredBox(color: Color(0xFF0D0D0D), child: SizedBox.shrink());

            // Otomatik silinmiş mesajlar deleted=true ile işaretlenir, normal akışta gösterilir

            final next = index < filtered.length - 1 ? filtered[index + 1] : null;
            final ts = data['timestamp'];
            final DateTime time = ts is Timestamp ? ts.toDate() : DateTime.now();
            DateTime? nextTime;
            if (next != null) {
              final nts = (next.data() as Map)['timestamp'];
              nextTime = nts is Timestamp ? nts.toDate() : null;
            }
            final bool isNewDay = nextTime == null || !_isSameDay(time, nextTime);
            final bool isNewSender = next == null ||
                data['senderID'] != (next.data() as Map<String, dynamic>)['senderID'];

            _msgIndexMap[msgId] = index;
            final hl = _highlightedMsgId == msgId;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              color: hl ? ColorsManager.darkPrimary.withOpacity(0.15) : Colors.transparent,
              child: _buildMessageItem(data, msgId, isNewSender, isNewDay, time),
            );
          },
        );
      },
    );
  }

  Widget _buildMessageItem(Map<String, dynamic> data, String msgId, bool isNewSender, bool isNewDay, DateTime time) {
    final bool isAI = data['senderID'] == 'AI_BOT' || data['isAI'] == true;
    final String senderUID = data['senderID']?.toString() ?? '';
    final bool isMine = !isAI && senderUID.isNotEmpty && senderUID == _myUID;
    final String message = data['message'] ?? '';
    final String status = data['status'] ?? 'delivered';
    final bool isDeleted = data['deleted'] == true;
    final bool isEdited = data['edited'] == true;
    final bool isStatusReply = message.startsWith('↩️ Durumuna yanıt:');
    final Map<String, dynamic> reactions = Map<String, dynamic>.from(data['reactions'] ?? {});

    // AI mesajı özel bubble ile göster
    if (isAI) {
      return Column(children: [
        if (isNewDay) _buildDateDivider(time),
        _buildAIBubble(message, time),
      ]);
    }

    Widget bubble;
    if (isDeleted) {
      bubble = _buildDeletedBubble(isMine, isNewSender);
    } else if (_isAudioMessage(message)) {
      bubble = _buildAudioBubble(isMine, isNewSender, message, status, time);
    } else if (_isImageMessage(message)) {
      bubble = _buildImageBubble(isMine, isNewSender, message, msgId, status, time);
    } else if (message.isContainsLink.hasMatch(message)) {
      bubble = _buildLinkBubble(isMine, isNewSender, message, status, time);
    } else {
      final replyTo = data['replyTo'] as Map<String, dynamic>?;
      if (message.startsWith('↩️ Durumuna yanıt: ')) {
        bubble = _buildStatusReplyBubble(message.replaceFirst('↩️ Durumuna yanıt: ', ''), msgId, isMine, isNewSender, status, time);
      } else {
        bubble = _buildTextBubble(message, msgId, isMine, isNewSender, status, time, isEdited, replyTo: replyTo);
      }
    }

    // Seçim modu: checkbox göster — ValueNotifier ile setState yok, scroll korunur
    if (_selectionMode) {
      void _toggle() {
        final newSet = Set<String>.from(_selectedMsgIds);
        if (newSet.contains(msgId)) {
          newSet.remove(msgId);
          if (newSet.isEmpty) {
            _selectedMsgIds.clear();
            _selectionNotifier.value = {};
            setState(() => _selectionMode = false);
            return;
          }
        } else {
          newSet.add(msgId);
        }
        _selectedMsgIds..clear()..addAll(newSet);
        _selectionNotifier.value = Set<String>.from(newSet);
      }

      return Column(children: [
        if (isNewDay) _buildDateDivider(time),
        ValueListenableBuilder<Set<String>>(
          valueListenable: _selectionNotifier,
          builder: (ctx, selected, _) {
            return GestureDetector(
              onTap: _toggle,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                color: selected.contains(msgId)
                    ? ColorsManager.darkPrimary.withOpacity(0.18)
                    : Colors.transparent,
                child: Row(children: [
                  SizedBox(width: 8.w),
                  AnimatedScale(
                    scale: selected.contains(msgId) ? 1.0 : 0.8,
                    duration: const Duration(milliseconds: 150),
                    child: Checkbox(
                      value: selected.contains(msgId),
                      onChanged: (_) => _toggle(),
                      activeColor: ColorsManager.darkPrimary,
                      checkColor: Colors.white,
                      side: const BorderSide(color: Colors.white38),
                    ),
                  ),
                  Expanded(child: Column(children: [
                    bubble,
                    if (reactions.isNotEmpty) _buildReactions(reactions, msgId, isMine: isMine),
                  ])),
                ]),
              ),
            );
          },
        ),
      ]);
    }

    // Normal mod: kaydırma + uzun basma
    return Column(children: [
      if (isNewDay) _buildDateDivider(time),
      Dismissible(
        key: Key('swipe_$msgId'),
        direction: DismissDirection.startToEnd,
        dismissThresholds: const {DismissDirection.startToEnd: 0.25},
        confirmDismiss: (_) async {
          if (!isDeleted) {
            HapticFeedback.lightImpact();
            setState(() => _replyToMessage = {...data, 'msgId': msgId});
          }
          return false;
        },
        background: Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Icon(Icons.reply_rounded, color: ColorsManager.darkPrimary, size: 24),
        ),
        child: GestureDetector(
          onLongPress: () {
            HapticFeedback.mediumImpact();
            _selectedMsgIds.add(msgId);
            _selectionNotifier.value = Set<String>.from(_selectedMsgIds);
            final savedOffset = _msgScrollCtrl.hasClients ? _msgScrollCtrl.offset : 0.0;
            setState(() => _selectionMode = true);
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (_msgScrollCtrl.hasClients && (savedOffset - _msgScrollCtrl.offset).abs() > 1) {
                _msgScrollCtrl.jumpTo(savedOffset);
              }
            });
          },
          onDoubleTap: () => _showMessageMenu(context, data, msgId, isMine, message),
          child: Column(children: [
            bubble,
            if (reactions.isNotEmpty) _buildReactions(reactions, msgId, isMine: isMine),
          ]),
        ),
      ),
    ]);
  }

  void _showMessageMenu(BuildContext ctx, Map<String, dynamic> data, String msgId, bool isMine, String message) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: ctx,
      backgroundColor: const Color(0xFF1A1A1A),
      isScrollControlled: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        // Emoji reaksiyon satırı
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: ['❤️', '😂', '😮', '😢', '👍', '🔥'].map((e) =>
              GestureDetector(
                onTap: () async {
                  Navigator.pop(ctx);
                  await DatabaseMethods.addReaction(msgId, widget.receivedUserID, e);
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.white10, shape: BoxShape.circle),
                  child: Text(e, style: const TextStyle(fontSize: 22)),
                ),
              ),
            ).toList(),
          ),
        ),
        const Divider(color: Colors.white10, height: 1),
        // Mesaj kopyala
        ListTile(
          leading: const Icon(Icons.copy_outlined, color: Colors.white60),
          title: const Text('Kopyala', style: TextStyle(color: Colors.white)),
          onTap: () {
            Clipboard.setData(ClipboardData(text: message));
            Navigator.pop(ctx);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kopyalandı')));
          },
        ),
        // İlet
        ListTile(
          leading: const Icon(Icons.forward_rounded, color: Colors.green),
          title: const Text('İlet', style: TextStyle(color: Colors.white)),
          onTap: () { Navigator.pop(ctx); _showForwardScreen(message); },
        ),
        // Yıldızla
        FutureBuilder<bool>(
          future: DatabaseMethods.isMessageStarred(msgId),
          builder: (_, snap) {
            final starred = snap.data ?? false;
            return ListTile(
              leading: Icon(starred ? Icons.star_rounded : Icons.star_border_rounded, color: Colors.amber),
              title: Text(starred ? 'Yıldızdan Kaldır' : 'Yıldızla', style: const TextStyle(color: Colors.white)),
              onTap: () async {
                Navigator.pop(ctx);
                if (starred) {
                  await DatabaseMethods.unstarMessage(msgId);
                } else {
                  await DatabaseMethods.starMessage(msgId, {...data, 'message': message});
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('⭐ Yıldızlandı'), backgroundColor: Colors.amber));
                }
              },
            );
          },
        ),
        // AI ile yanıtla
        if (!message.startsWith('['))
          ListTile(
            leading: const Icon(Icons.auto_awesome_rounded, color: Colors.purple),
            title: const Text('AI ile Yanıtla', style: TextStyle(color: Colors.white)),
            onTap: () {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute(builder: (_) => AIAssistantScreen(prefilledText: 'Bu mesaja yanıt yaz: "$message"')));
            },
          ),
        // Görev oluştur
        if (!message.startsWith('['))
          ListTile(
            leading: const Icon(Icons.add_task_rounded, color: Colors.green),
            title: const Text('Görev Oluştur', style: TextStyle(color: Colors.white)),
            onTap: () {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute(builder: (_) => TasksScreen(prefilledText: message)));
            },
          ),
        // Çevir
        if (!message.startsWith('['))
          ListTile(
            leading: const Icon(Icons.translate_rounded, color: Colors.lightBlue),
            title: const Text('Çevir', style: TextStyle(color: Colors.white)),
            onTap: () async {
              Navigator.pop(ctx);
              _showTranslation(message);
            },
          ),
        // Sabitle
        ListTile(
          leading: Icon(Icons.push_pin_outlined, color: ColorsManager.darkPrimary),
          title: const Text('Sabitle', style: TextStyle(color: Colors.white)),
          onTap: () async {
            Navigator.pop(ctx);
            await DatabaseMethods.pinMessage(msgId, widget.receivedUserID, message);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mesaj sabitlendi')));
          },
        ),
        // Düzenle (sadece kendi mesajım ve metin ise)
        if (isMine && !_isAudioMessage(message) && !_isImageMessage(message))
          ListTile(
            leading: const Icon(Icons.edit_outlined, color: Colors.blueAccent),
            title: const Text('Düzenle', style: TextStyle(color: Colors.white)),
            onTap: () {
              Navigator.pop(ctx);
              _showEditDialog(msgId, message);
            },
          ),
        // Benden sil
        ListTile(
          leading: const Icon(Icons.delete_outline, color: Colors.orange),
          title: const Text('Benden Sil', style: TextStyle(color: Colors.white)),
          onTap: () async {
            Navigator.pop(ctx);
            await DatabaseMethods.deleteMessageForMe(msgId, widget.receivedUserID);
          },
        ),
        // Herkesten sil (sadece kendi mesajım)
        if (isMine)
          ListTile(
            leading: const Icon(Icons.delete_forever_outlined, color: Colors.red),
            title: const Text('Herkesten Sil', style: TextStyle(color: Colors.red)),
            onTap: () async {
              Navigator.pop(ctx);
              await DatabaseMethods.deleteMessageForEveryone(msgId, widget.receivedUserID);
            },
          ),
          ]),
        ),
      ),
    );
  }

  void _showEditDialog(String msgId, String currentText) {
    final ctrl = TextEditingController(text: currentText);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Mesajı Düzenle', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white),
          maxLines: null,
          decoration: InputDecoration(
            hintText: 'Yeni mesaj',
            hintStyle: const TextStyle(color: Colors.white38),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.3)),
              borderRadius: BorderRadius.circular(10),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: ColorsManager.darkPrimary),
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              final newText = ctrl.text.trim();
              if (newText.isNotEmpty && newText != currentText) {
                await DatabaseMethods.editMessage(msgId, widget.receivedUserID, newText);
              }
              if (mounted) Navigator.pop(ctx);
            },
            child: Text('Kaydet', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildReactions(Map<String, dynamic> reactions, String msgId, {bool isMine = true}) {
    final grouped = <String, int>{};
    for (final e in reactions.values) grouped[e.toString()] = (grouped[e.toString()] ?? 0) + 1;
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: () => _showMessageMenu(context, {}, msgId, false, ''),
        child: Container(
          margin: EdgeInsets.only(bottom: 4.h, right: 8.w),
          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 3.h),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: Colors.white10),
          ),
          child: Row(mainAxisSize: MainAxisSize.min,
              children: grouped.entries.map((e) =>
                Text('${e.key}${e.value > 1 ? e.value.toString() : ''} ',
                    style: const TextStyle(fontSize: 13))).toList()),
        ),
      ),
    );
  }

  Widget _buildAIBubble(String message, DateTime time) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 4.h, bottom: 4.h, left: 8.w, right: 60.w),
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1A0030), Color(0xFF0D001A)],
          ),
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(color: Colors.purple.withOpacity(0.4)),
          boxShadow: [BoxShadow(color: Colors.purple.withOpacity(0.12), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(color: Colors.purple.withOpacity(0.2), borderRadius: BorderRadius.circular(6)),
              child: const Icon(Icons.auto_awesome, color: Colors.purple, size: 12),
            ),
            const SizedBox(width: 6),
            const Text('Asgard AI', style: TextStyle(color: Colors.purple, fontSize: 11, fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 6),
          Text(message, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4)),
          const SizedBox(height: 4),
          Text(DateFormat('h:mm a').format(time), style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ]),
      ),
    );
  }

  Widget _buildDeletedBubble(bool isMine, bool isNewSender) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 60.w : 0, right: isMine ? 0 : 60.w),
        padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 9.h),
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.block, size: 14, color: Colors.white38),
          const SizedBox(width: 6),
          Text('Bu mesaj silindi', style: TextStyle(color: Colors.white38, fontSize: 13.sp, fontStyle: FontStyle.italic)),
        ]),
      ),
    );
  }

  Widget _buildDateDivider(DateTime date) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 12.h),
      child: Row(children: [
        Expanded(child: Divider(color: Colors.white12, thickness: 0.5)),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 10.w),
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.2)),
          ),
          child: Text(DateFormat('d MMM yyyy').format(date), style: TextStyle(color: Colors.white38, fontSize: 11.sp)),
        ),
        Expanded(child: Divider(color: Colors.white12, thickness: 0.5)),
      ]),
    );
  }

  Widget _buildStatusReplyBubble(String text, String msgId, bool isMine, bool isNewSender, String status, DateTime time) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: () { Navigator.popUntil(context, (r) => r.isFirst); },
        onLongPress: () => _showMessageMenu(context, {'message': '↩️ Durumuna yanıt: $text'}, msgId, isMine, text),
        child: Container(
          margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
              left: isMine ? 60.w : 4.w, right: isMine ? 4.w : 60.w),
          decoration: BoxDecoration(
            color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: isMine ? ColorsManager.darkPrimary.withOpacity(0.5) : Colors.white12),
          ),
          child: Column(crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: ColorsManager.darkPrimary.withOpacity(0.12),
                border: Border(left: BorderSide(color: ColorsManager.darkPrimary, width: 3)),
              ),
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 7.h),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text('Duruma yanıt', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 11.sp, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                Text(text, style: TextStyle(color: Colors.white70, fontSize: 13.sp), maxLines: 3, overflow: TextOverflow.ellipsis),
              ]),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Text(DateFormat('h:mm a').format(time), style: TextStyle(color: Colors.white38, fontSize: 10.sp)),
                if (isMine) ...[Gap(4.w), _buildStatusTicks(status)],
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildTextBubble(String message, String msgId, bool isMine, bool isNewSender, String status, DateTime time, bool isEdited, {Map<String, dynamic>? replyTo}) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 60.w : 0, right: isMine ? 0 : 60.w),
        padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 9.h),
        decoration: BoxDecoration(
          color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(18.r), topRight: Radius.circular(18.r),
            bottomLeft: Radius.circular(isMine ? 18.r : (isNewSender ? 4.r : 18.r)),
            bottomRight: Radius.circular(isMine ? (isNewSender ? 4.r : 18.r) : 18.r),
          ),
          border: Border.all(color: isMine ? ColorsManager.darkPrimary.withOpacity(0.5) : Colors.white.withOpacity(0.07)),
          boxShadow: isMine ? [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.12), blurRadius: 8)] : null,
        ),
        child: Column(crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          // Alıntı göster
          if (replyTo != null) ...[
            GestureDetector(
              onTap: () { final rid = replyTo['msgId']?.toString() ?? ''; if (rid.isNotEmpty) _scrollToReply(rid); },
              child: Container(
                margin: const EdgeInsets.only(bottom: 6),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(8),
                  border: Border(left: BorderSide(color: ColorsManager.darkPrimary, width: 3)),
                ),
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text(
                    replyTo['senderID'] == _auth.currentUser?.uid ? 'Sen' : widget.receivedUserName,
                    style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 11.sp, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 2),
                  Builder(builder: (_) {
                    final rm = (replyTo['message'] ?? '').toString();
                    final isPhoto = rm.contains('cloudinary') || rm.contains('firebasestorage') || rm.endsWith('.jpg') || rm.endsWith('.png');
                    return Text(isPhoto ? '📷 Fotoğraf' : rm, style: TextStyle(color: Colors.white60, fontSize: 12.sp), maxLines: 2, overflow: TextOverflow.ellipsis);
                  }),
                ]),
              ),
            ),
          ],
          // Durum yanıtı - WhatsApp stili
          if (message.startsWith('↩️ Durumuna yanıt:')) ...[
            Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              decoration: BoxDecoration(
                color: isMine ? Colors.white10 : Colors.black26,
                borderRadius: BorderRadius.circular(8),
                border: Border(left: BorderSide(color: ColorsManager.darkPrimary, width: 3)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text('Duruma yanıt', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 11, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                Text(
                  message.replaceFirst('↩️ Durumuna yanıt: ', ''),
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                  maxLines: 3, overflow: TextOverflow.ellipsis,
                ),
              ]),
            ),
          ] else ...[],
          if (!message.startsWith('↩️ Durumuna yanıt:'))
          Text(message, style: TextStyle(
            color: Colors.white,
            // ✅ FIX: FontSizeProvider'dan dinamik font boyutu
            fontSize: _isOnlyEmoji(message) ? 36.sp : FontSizeProvider.instance.messageFontSize,
            height: 1.4,
          )),
          Gap(4.h),
          Row(mainAxisSize: MainAxisSize.min, children: [
            if (isEdited) Text('düzenlendi · ', style: TextStyle(color: Colors.white24, fontSize: 9.sp)),
            Text(DateFormat('h:mm a').format(time), style: TextStyle(color: Colors.white38, fontSize: 10.sp)),
            if (isMine) ...[Gap(4.w), _buildStatusTicks(status)],
          ]),
        ]),
      ),
    );
  }

  Widget _buildStatusTicks(String status) {
    if (status == 'sending') return Icon(Icons.check, size: 13.sp, color: Colors.white24);
    final color = status == 'read' ? ColorsManager.darkPrimary : Colors.white54;
    return SizedBox(width: 18.w, height: 13.h,
        child: Stack(children: [
          Positioned(left: 0, child: Icon(Icons.check, size: 13.sp, color: color)),
          Positioned(left: 5.w, child: Icon(Icons.check, size: 13.sp, color: color)),
        ]));
  }

  Widget _buildImageBubble(bool isMine, bool isNewSender, String message, String msgId, String status, DateTime time) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: () => _openFullscreenImage(message),
        onLongPress: () => _showMessageMenu(context, {'message': message}, msgId, isMine, message),
        child: Container(
          margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
              left: isMine ? 60.w : 4.w, right: isMine ? 4.w : 60.w),
          width: 200.w,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: isMine ? ColorsManager.darkPrimary.withOpacity(0.5) : Colors.white12),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(11.r),
            child: Column(
              crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 200.w,
                  height: 200.w,
                  child: CachedNetworkImage(
                    imageUrl: message,
                    fit: BoxFit.cover,
                    placeholder: (c, u) => const Center(child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white24)),
                    errorWidget: (c, u, e) => const Icon(Icons.error_outline_rounded, color: Colors.red),
                  ),
                ),
                Container(
                  color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(DateFormat('h:mm a').format(time), style: TextStyle(color: Colors.white38, fontSize: 10.sp)),
                    if (isMine) ...[Gap(4.w), _buildStatusTicks(status)],
                  ]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }


  Widget _buildAudioBubble(bool isMine, bool isNewSender, String audioUrl, String status, DateTime time) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 60.w : 0, right: isMine ? 0 : 60.w),
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
        decoration: BoxDecoration(
          color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
          borderRadius: BorderRadius.circular(18.r),
          border: Border.all(color: isMine ? ColorsManager.darkPrimary.withOpacity(0.5) : Colors.white12),
        ),
        child: _AudioPlayer(audioUrl: audioUrl, isMine: isMine, time: time, status: status),
      ),
    );
  }

  Widget _buildLinkBubble(bool isMine, bool isNewSender, String message, String status, DateTime time) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 40.w : 0, right: isMine ? 0 : 40.w),
        decoration: BoxDecoration(
          color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(color: isMine ? ColorsManager.darkPrimary.withOpacity(0.4) : Colors.white12),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15.r),
          child: Column(crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
            LinkPreviewWidget(message: message, onLinkPressed: (link) async => await _launchURL(link)),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Text(DateFormat('h:mm a').format(time), style: TextStyle(color: Colors.white38, fontSize: 10.sp)),
                if (isMine) ...[Gap(4.w), _buildStatusTicks(status)],
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  bool _isOnlyEmoji(String text) {
    final stripped = text.replaceAll(RegExp(r'\s'), '');
    if (stripped.isEmpty || stripped.length > 8) return false;
    final emojiRegex = RegExp(
      r'[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}'
      r'\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}'
      r'\u{FE00}-\u{FE0F}\u{1F900}-\u{1F9FF}]+',
      unicode: true,
    );
    return emojiRegex.hasMatch(stripped) && stripped.replaceAll(emojiRegex, '').isEmpty;
  }

  bool _isAudioMessage(String msg) =>
      msg.contains('.aac') || msg.contains('.mp3') || msg.contains('.m4a') ||
      (msg.contains('cloudinary') && msg.contains('asgard_audio'));

  bool _isImageMessage(String msg) =>
      msg.contains('firebasestorage') ||
      (msg.contains('cloudinary') && (msg.contains('asgard_images') || msg.contains('/image/'))) ||
      msg.contains('.jpg') || msg.contains('.png') || msg.contains('.jpeg') ||
      msg.contains('.gif') || msg.contains('.webp');

  bool _isSameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  Future<void> _downloadImageFromUrl(String url) async {
    _showLoadingDialog();
    try {
      final tempDir = await getTemporaryDirectory();
      final path = '${tempDir.path}/img_${DateTime.now().millisecondsSinceEpoch}.jpg';
      await DioFactory.getDio().download(url, path);
      if (!mounted) return;
      context.pop();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Resim indirildi')));
    } catch (e) {
      if (!mounted) return;
      context.pop();
    }
  }

  Future<void> _launchURL(String myUrl) async {
    if (!myUrl.startsWith('http://') && !myUrl.startsWith('https://')) myUrl = 'https://$myUrl';
    await launchUrl(Uri.parse(myUrl), mode: LaunchMode.inAppBrowserView);
  }

  void _showLoadingDialog() {
    showDialog(context: context, barrierDismissible: false,
        builder: (_) => PopScope(canPop: false,
            child: Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary))));
  }

  void _showImageOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111111),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (context) => Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          Gap(16.h),
          _optionTile(Icons.camera_alt, 'Kamera', () async {
            context.pop();
            final f = await _picker.pickImage(source: ImageSource.camera);
            if (f != null) await _uploadAndSend(f.path);
          }),
          Gap(8.h),
          _optionTile(Icons.photo_library, 'Galeri', () async {
            context.pop();
            final f = await _picker.pickImage(source: ImageSource.gallery);
            if (f != null) await _uploadAndSend(f.path);
          }),
        ]),
      ),
    );
  }

  Widget _optionTile(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1A),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.3)),
        ),
        child: Row(children: [
          Icon(icon, color: ColorsManager.darkPrimary),
          Gap(12.w),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 15)),
        ]),
      ),
    );
  }

  Future<void> _uploadAndSend(String filePath) async {
    _showLoadingDialog();
    final url = await CloudinaryService.uploadImage(filePath);
    if (!mounted) return;
    context.pop();
    if (url != null) {
      await DatabaseMethods.sendMessage(url, widget.receivedUserID);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Resim yüklenemedi')));
    }
  }

  void _openFullscreenImage(String url) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => _FullscreenImagePage(url: url)));
  }

  // ── Tema, Çeviri, İleri, Gizli ──────────────────────────────────────────

  void _showThemePicker() {
    final themes = [
      {'name': 'Varsayılan', 'color': const Color(0xFF0D0D0D)},
      {'name': 'Gece Mavisi', 'color': const Color(0xFF0A0E1A)},
      {'name': 'Orman', 'color': const Color(0xFF0A140E)},
      {'name': 'Mor Gece', 'color': const Color(0xFF100A1A)},
      {'name': 'Kahve', 'color': const Color(0xFF140E0A)},
      {'name': 'Deniz', 'color': const Color(0xFF0A1214)},
    ];
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Sohbet Teması', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: 3, shrinkWrap: true, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.4,
            children: themes.map((t) {
              final color = t['color'] as Color;
              final selected = _chatTheme == color;
              return GestureDetector(
                onTap: () async {
                  setState(() => _chatTheme = color);
                  Navigator.pop(context);
                  // ✅ FIX: Seçimi SharedPreferences'a kaydet (sayfa kapandığında kaybolmasın)
                  final prefs = await SharedPreferences.getInstance();
                  final name = t['name'] as String;
                  final id = name == 'Varsayılan' ? 'default'
                      : name == 'Gece Mavisi' ? 'blue'
                      : name == 'Kahve' ? 'red'
                      : name.toLowerCase().replaceAll(' ', '_');
                  await prefs.setString('chat_wallpaper', id);
                },
                child: Container(
                  decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: selected ? ColorsManager.darkPrimary : Colors.white12, width: selected ? 2.5 : 1)),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    if (selected) Icon(Icons.check_circle_rounded, color: ColorsManager.darkPrimary, size: 20),
                    const SizedBox(height: 4),
                    Text(t['name'] as String, style: TextStyle(color: selected ? ColorsManager.darkPrimary : Colors.white60, fontSize: 12)),
                  ]),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 16),
      ])),
    );
  }

  // ✅ FIX: Google Translate placeholder → Gemini ile gerçek çeviri
  void _showTranslation(String message) async {
    String? translatedText;
    bool loading = true;
    String targetLang = 'İngilizce';

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: Row(children: [
            const Icon(Icons.translate_rounded, color: Colors.lightBlue, size: 20),
            const SizedBox(width: 8),
            const Text('Çeviri', style: TextStyle(color: Colors.white, fontSize: 16)),
          ]),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Orijinal:', style: TextStyle(color: Colors.white38, fontSize: 12)),
            const SizedBox(height: 4),
            Text(message, style: const TextStyle(color: Colors.white70, fontSize: 14)),
            const SizedBox(height: 16),
            Container(height: 1, color: Colors.white10),
            const SizedBox(height: 12),
            Row(children: [
              Text('Çeviri ($targetLang):', style: const TextStyle(color: Colors.white38, fontSize: 12)),
              const Spacer(),
              GestureDetector(
                onTap: () async {
                  // Dil seçimi
                  final langs = ['İngilizce', 'Türkçe', 'Almanca', 'Fransızca', 'İspanyolca', 'Arapça', 'Rusça'];
                  final picked = await showDialog<String>(
                    context: ctx,
                    builder: (ctx2) => SimpleDialog(
                      backgroundColor: const Color(0xFF1A1A1A),
                      title: const Text('Dil Seç', style: TextStyle(color: Colors.white)),
                      children: langs.map((l) => SimpleDialogOption(
                        onPressed: () => Navigator.pop(ctx2, l),
                        child: Text(l, style: const TextStyle(color: Colors.white70)),
                      )).toList(),
                    ),
                  );
                  if (picked != null && picked != targetLang) {
                    setS(() { targetLang = picked; loading = true; translatedText = null; });
                    _doTranslate(message, picked).then((t) {
                      if (ctx.mounted) setS(() { translatedText = t; loading = false; });
                    });
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: Colors.lightBlue.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(targetLang, style: const TextStyle(color: Colors.lightBlue, fontSize: 11)),
                    const Icon(Icons.arrow_drop_down, color: Colors.lightBlue, size: 16),
                  ]),
                ),
              ),
            ]),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.lightBlue.withOpacity(0.08), borderRadius: BorderRadius.circular(10)),
              child: loading
                  ? const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.lightBlue)))
                  : SelectableText(translatedText ?? '⚠️ Çeviri yapılamadı',
                      style: TextStyle(color: translatedText != null ? Colors.white : Colors.red, fontSize: 13)),
            ),
          ]),
          actions: [
            if (translatedText != null)
              TextButton(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: translatedText!));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Çeviri kopyalandı')));
                },
                child: const Text('Kopyala', style: TextStyle(color: Colors.lightBlue)),
              ),
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Kapat', style: TextStyle(color: ColorsManager.darkPrimary)),
            ),
          ],
        ),
      ),
    );

    // İlk çeviriyi yap
    translatedText = await _doTranslate(message, targetLang);
    if (context.mounted) {
      // Dialog hâlâ açıksa güncelle — setState yok, dialog kendisi StatefulBuilder
    }
  }

  Future<String?> _doTranslate(String text, String targetLang) async {
    try {
      const geminiKey = String.fromEnvironment('GEMINI_API_KEY');
      if (geminiKey.isEmpty) return '⚠️ GEMINI_API_KEY eksik';
      final response = await http.post(
        Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$geminiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [{'role': 'user', 'parts': [{'text': 'Şu metni $targetLang diline çevir, sadece çeviriyi yaz, açıklama ekleme:\n\n$text'}]}],
          'generationConfig': {'maxOutputTokens': 500},
        }),
      );
      if (response.statusCode != 200) return '⚠️ API hatası: ${response.statusCode}';
      final data = jsonDecode(response.body);
      return data['candidates']?[0]?['content']?['parts']?[0]?['text'];
    } catch (e) {
      return '⚠️ Bağlantı hatası';
    }
  }


  void _showForwardScreen(String message) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7, maxChildSize: 0.95, minChildSize: 0.5, expand: false,
        builder: (_, ctrl) => Column(children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const Text('İlet', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.green.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.green.withOpacity(0.2))),
              child: Text(message.startsWith('[') ? '📎 Medya' : (message.length > 60 ? '${message.substring(0, 60)}...' : message),
                  style: const TextStyle(color: Colors.white70, fontSize: 13)),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('users').doc(_auth.currentUser?.uid)
                .collection('contacts').snapshots(),
            builder: (_, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              return ListView.builder(
                controller: ctrl,
                itemCount: snap.data!.docs.length,
                itemBuilder: (_, i) {
                  final uid = (snap.data!.docs[i].data() as Map)['uid'] ?? snap.data!.docs[i].id;
                  return FutureBuilder<DocumentSnapshot>(
                    future: FirebaseFirestore.instance.collection('users').doc(uid).get(),
                    builder: (_, uSnap) {
                      final data = uSnap.data?.data() as Map<String, dynamic>?;
                      if (data == null) return const ColoredBox(color: Color(0xFF0D0D0D), child: SizedBox.shrink());
                      final name = data['name'] ?? '';
                      final photo = data['profilePic'] ?? '';
                      return ListTile(
                        leading: CircleAvatar(radius: 22,
                            backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                            backgroundColor: const Color(0xFF2A2A2A),
                            child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white38) : null),
                        title: Text(name, style: const TextStyle(color: Colors.white)),
                        trailing: Icon(Icons.forward_rounded, color: ColorsManager.darkPrimary),
                        onTap: () async {
                          Navigator.pop(context);
                          await DatabaseMethods.sendMessage('↪ $message', uid);
                          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text("$name'e iletildi"), backgroundColor: Colors.green));
                        },
                      );
                    },
                  );
                },
              );
            }),
          ),
        ]),
      ),
    );
  }

}

// ── Sabitlenmiş Mesaj Banner ─────────────────────────────────────────────────
class _PinnedMessageBanner extends StatelessWidget {
  final String otherUserID;
  const _PinnedMessageBanner({required this.otherUserID});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: DatabaseMethods.getChatRoomStream(otherUserID),
      builder: (ctx, snap) {
        final data = snap.data?.data() as Map<String, dynamic>?;
        final pinned = data?['pinnedMessage'] as Map<String, dynamic>?;
        if (pinned == null) return const ColoredBox(color: Color(0xFF0D0D0D), child: SizedBox.shrink());
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: ColorsManager.darkPrimary.withOpacity(0.12),
          child: Row(children: [
            Icon(Icons.push_pin, size: 14, color: ColorsManager.darkPrimary),
            const SizedBox(width: 8),
            Expanded(child: Text(pinned['text'] ?? '', style: const TextStyle(color: Colors.white70, fontSize: 12),
                maxLines: 1, overflow: TextOverflow.ellipsis)),
            GestureDetector(
              onTap: () => DatabaseMethods.unpinMessage(otherUserID),
              child: const Icon(Icons.close, size: 16, color: Colors.white38),
            ),
          ]),
        );
      },
    );
  }
}

// ── Audio Player ─────────────────────────────────────────────────────────────
class _AudioPlayer extends StatefulWidget {
  final String audioUrl;
  final bool isMine;
  final DateTime time;
  final String status;
  const _AudioPlayer({required this.audioUrl, required this.isMine, required this.time, required this.status});
  @override State<_AudioPlayer> createState() => _AudioPlayerState();
}

class _AudioPlayerState extends State<_AudioPlayer> with SingleTickerProviderStateMixin {
  late final AudioPlayer _player;
  late final AnimationController _waveCtrl;
  bool _playing = false;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;


  /// lastSeen alanı Timestamp veya int olabilir - güvenli oku
  static DateTime? _parseLastSeen(dynamic raw) {
    if (raw == null) return null;
    if (raw is int) return DateTime.fromMillisecondsSinceEpoch(raw);
    if (raw is Timestamp) return raw.toDate();
    return null;
  }
  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _waveCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))..repeat(reverse: true);
    _player.positionStream.listen((p) { if (mounted) setState(() => _pos = p); });
    _player.durationStream.listen((d) { if (mounted && d != null) setState(() => _dur = d); });
    _player.playingStream.listen((p) { if (mounted) setState(() => _playing = p); });
    _initAudio();
  }

  Future<void> _initAudio() async {
    try { await _player.setUrl(widget.audioUrl); } catch (_) {}
  }

  String _fmt(Duration d) => '${d.inMinutes.toString().padLeft(2, "0")}:${(d.inSeconds % 60).toString().padLeft(2, "0")}';

  @override
  void dispose() { _player.dispose(); _waveCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      GestureDetector(
        onTap: () async {
          if (_playing) { await _player.pause(); }
          else { if (_pos >= _dur && _dur > Duration.zero) await _player.seek(Duration.zero); await _player.play(); }
        },
        child: Container(
          width: 36, height: 36,
          decoration: BoxDecoration(shape: BoxShape.circle,
              color: ColorsManager.darkPrimary, boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.4), blurRadius: 8)]),
          child: Icon(_playing ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 20),
        ),
      ),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        AnimatedBuilder(
          animation: _waveCtrl,
          builder: (_, __) => Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(20, (i) {
                final active = _dur.inMilliseconds > 0 && (i / 20) < (_pos.inMilliseconds / _dur.inMilliseconds);
                final h = _playing ? (4 + (i % 3) * 6 + _waveCtrl.value * 4).toDouble() : (4 + (i % 4) * 4).toDouble();
                return Container(width: 2.5, height: h,
                    decoration: BoxDecoration(color: active ? ColorsManager.darkPrimary : Colors.white24, borderRadius: BorderRadius.circular(2)));
              })),
        ),
        const SizedBox(height: 4),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(_fmt(_pos), style: const TextStyle(color: Colors.white38, fontSize: 10)),
          Text(_fmt(_dur), style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ]),
      ])),
      const SizedBox(width: 8),
      Column(mainAxisSize: MainAxisSize.min, children: [
        Text(DateFormat('h:mm a').format(widget.time), style: const TextStyle(color: Colors.white38, fontSize: 10)),
        if (widget.isMine) SizedBox(width: 18, height: 13,
            child: Stack(children: [
              Positioned(left: 0, child: Icon(Icons.check, size: 13, color: widget.status == 'read' ? ColorsManager.darkPrimary : Colors.white54)),
              Positioned(left: 5, child: Icon(Icons.check, size: 13, color: widget.status == 'read' ? ColorsManager.darkPrimary : Colors.white54)),
            ])),
      ]),
    ]);
  }
}


// ── Medya Filtresi Sayfası ───────────────────────────────────────────────────
class _MediaFilterPage extends StatefulWidget {
  final String chatRoomId;
  final String myUID;
  final String otherUID;
  final String otherName;
  const _MediaFilterPage({required this.chatRoomId, required this.myUID, required this.otherUID, required this.otherName});
  @override State<_MediaFilterPage> createState() => _MediaFilterPageState();
}

class _MediaFilterPageState extends State<_MediaFilterPage> with SingleTickerProviderStateMixin {
  late TabController _tab;
  final Set<String> _selectedIds = {};
  bool _selectMode = false;


  /// lastSeen alanı Timestamp veya int olabilir - güvenli oku
  static DateTime? _parseLastSeen(dynamic raw) {
    if (raw == null) return null;
    if (raw is int) return DateTime.fromMillisecondsSinceEpoch(raw);
    if (raw is Timestamp) return raw.toDate();
    return null;
  }
  @override
  void initState() { super.initState(); _tab = TabController(length: 3, vsync: this); }
  @override void dispose() { _tab.dispose(); super.dispose(); }

  bool _isImage(String msg) =>
      msg.contains('cloudinary') && (msg.contains('asgard_images') || msg.contains('/image/')) ||
      msg.contains('firebasestorage') ||
      msg.endsWith('.jpg') || msg.endsWith('.png') || msg.endsWith('.jpeg') || msg.endsWith('.webp');

  bool _isAudio(String msg) =>
      msg.contains('.aac') || msg.contains('.mp3') || msg.contains('.m4a') ||
      (msg.contains('cloudinary') && msg.contains('asgard_audio'));

  bool _isLink(String msg) => msg.contains('http://') || msg.contains('https://');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: Text(
          _selectMode ? '${_selectedIds.length} seçildi' : '${widget.otherName} - Medya',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          if (_selectMode) ...[
            IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
              onPressed: _selectedIds.isEmpty ? null : () => _showDeleteSelected(context),
            ),
            IconButton(
              icon: const Icon(Icons.close, color: Colors.white70),
              onPressed: () => setState(() { _selectMode = false; _selectedIds.clear(); }),
            ),
          ] else
            IconButton(
              icon: const Icon(Icons.checklist_rounded, color: Colors.white70),
              onPressed: () => setState(() => _selectMode = true),
              tooltip: 'Seç',
            ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: ColorsManager.darkPrimary,
          labelColor: ColorsManager.darkPrimary,
          unselectedLabelColor: Colors.white38,
          tabs: const [Tab(text: 'Resimler'), Tab(text: 'Sesler'), Tab(text: 'Linkler')],
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('chats')
            .doc(widget.chatRoomId)
            .collection('messages')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
          final all = snap.data!.docs.where((d) {
            final data = d.data() as Map<String, dynamic>;
            final hidden = List.from(data['hiddenFor'] ?? []);
            return !hidden.contains(widget.myUID) && data['deleted'] != true;
          }).toList();

          final images = all.where((d) => _isImage((d.data() as Map)['message'] ?? '')).toList();
          final audios = all.where((d) => _isAudio((d.data() as Map)['message'] ?? '')).toList();
          final links  = all.where((d) => _isLink((d.data() as Map)['message'] ?? '') && !_isImage((d.data() as Map)['message'] ?? '')).toList();

          return TabBarView(controller: _tab, children: [
            // ── Resimler ──
            images.isEmpty
                ? const Center(child: Text('Paylaşılan resim yok', style: TextStyle(color: Colors.white38)))
                : GridView.builder(
                    padding: const EdgeInsets.all(4),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3, crossAxisSpacing: 3, mainAxisSpacing: 3),
                    itemCount: images.length,
                    itemBuilder: (_, i) {
                      final doc = images[i];
                      final url = (doc.data() as Map)['message'] as String;
                      final selected = _selectedIds.contains(doc.id);
                      return GestureDetector(
                        onTap: () {
                          if (_selectMode) {
                            setState(() {
                              if (selected) _selectedIds.remove(doc.id);
                              else _selectedIds.add(doc.id);
                            });
                          } else {
                            Navigator.push(context, MaterialPageRoute(
                                builder: (_) => _FullscreenImagePage(url: url)));
                          }
                        },
                        onLongPress: () => setState(() { _selectMode = true; _selectedIds.add(doc.id); }),
                        child: Stack(fit: StackFit.expand, children: [
                          CachedNetworkImage(imageUrl: url, fit: BoxFit.cover,
                              placeholder: (_, __) => Container(color: const Color(0xFF1A1A1A)),
                              errorWidget: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white24)),
                          if (selected)
                            Container(
                              color: ColorsManager.darkPrimary.withOpacity(0.5),
                              child: const Center(child: Icon(Icons.check_circle_rounded, color: Colors.white, size: 30)),
                            ),
                        ]),
                      );
                    },
                  ),

            // ── Sesler ──
            audios.isEmpty
                ? const Center(child: Text('Paylaşılan ses yok', style: TextStyle(color: Colors.white38)))
                : ListView.builder(
                    itemCount: audios.length,
                    itemBuilder: (_, i) {
                      final doc = audios[i];
                      final data = doc.data() as Map<String, dynamic>;
                      final ts = data['timestamp'] as Timestamp?;
                      final time = ts?.toDate() ?? DateTime.now();
                      final selected = _selectedIds.contains(doc.id);
                      return ListTile(
                        leading: Container(
                          width: 42, height: 42,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: selected ? ColorsManager.darkPrimary : ColorsManager.darkPrimary.withOpacity(0.2)),
                          child: Icon(selected ? Icons.check : Icons.mic, color: Colors.white, size: 20),
                        ),
                        title: Text('Sesli Mesaj', style: const TextStyle(color: Colors.white)),
                        subtitle: Text(DateFormat('d MMM, h:mm a').format(time),
                            style: const TextStyle(color: Colors.white38, fontSize: 11)),
                        trailing: _selectMode
                            ? Checkbox(
                                value: selected,
                                onChanged: (_) => setState(() {
                                  if (selected) _selectedIds.remove(doc.id);
                                  else _selectedIds.add(doc.id);
                                }),
                                activeColor: ColorsManager.darkPrimary,
                              )
                            : null,
                        onTap: () {
                          if (_selectMode) {
                            setState(() {
                              if (selected) _selectedIds.remove(doc.id);
                              else _selectedIds.add(doc.id);
                            });
                          }
                        },
                        onLongPress: () => setState(() { _selectMode = true; _selectedIds.add(doc.id); }),
                      );
                    },
                  ),

            // ── Linkler ──
            links.isEmpty
                ? const Center(child: Text('Paylaşılan link yok', style: TextStyle(color: Colors.white38)))
                : ListView.builder(
                    itemCount: links.length,
                    itemBuilder: (_, i) {
                      final doc = links[i];
                      final data = doc.data() as Map<String, dynamic>;
                      final msg = data['message'] as String? ?? '';
                      final ts = data['timestamp'] as Timestamp?;
                      final time = ts?.toDate() ?? DateTime.now();
                      final selected = _selectedIds.contains(doc.id);
                      return ListTile(
                        leading: Container(
                          width: 42, height: 42,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: selected ? Colors.lightBlue : Colors.lightBlue.withOpacity(0.2)),
                          child: Icon(selected ? Icons.check : Icons.link, color: Colors.white, size: 20),
                        ),
                        title: Text(msg, style: const TextStyle(color: Colors.lightBlue, fontSize: 13),
                            maxLines: 2, overflow: TextOverflow.ellipsis),
                        subtitle: Text(DateFormat('d MMM, h:mm a').format(time),
                            style: const TextStyle(color: Colors.white38, fontSize: 11)),
                        onTap: () async {
                          if (_selectMode) {
                            setState(() {
                              if (selected) _selectedIds.remove(doc.id);
                              else _selectedIds.add(doc.id);
                            });
                          } else {
                            var url = msg;
                            if (!url.startsWith('http')) url = 'https://$url';
                            await launchUrl(Uri.parse(url), mode: LaunchMode.inAppBrowserView);
                          }
                        },
                        onLongPress: () => setState(() { _selectMode = true; _selectedIds.add(doc.id); }),
                      );
                    },
                  ),
          ]);
        },
      ),
    );
  }

  void _showDeleteSelected(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Text('${_selectedIds.length} Medyayı Sil', style: const TextStyle(color: Colors.white)),
        content: const Text('Bu medyalar nasıl silinsin?', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              for (final id in _selectedIds) {
                await DatabaseMethods.deleteMessageForMe(id, widget.otherUID);
              }
              setState(() { _selectMode = false; _selectedIds.clear(); });
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Silindi (sadece senden)')));
            },
            child: const Text('Benden Sil', style: TextStyle(color: Colors.orange)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              for (final id in _selectedIds) {
                await DatabaseMethods.deleteMessageForEveryone(id, widget.otherUID);
              }
              setState(() { _selectMode = false; _selectedIds.clear(); });
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Herkesten silindi')));
            },
            child: const Text('Herkesten Sil', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

// ── Tam Ekran Profil Fotoğrafı ───────────────────────────────────────────────
class _FullProfilePhotoPage extends StatelessWidget {
  final String url;
  final String name;
  const _FullProfilePhotoPage({required this.url, required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.black.withOpacity(0.5),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 0.5,
          maxScale: 4.0,
          child: CachedNetworkImage(
            imageUrl: url,
            fit: BoxFit.contain,
            placeholder: (_, __) => const CircularProgressIndicator(color: Colors.white),
            errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white38, size: 120),
          ),
        ),
      ),
    );
  }
}

// ── Fullscreen Image ─────────────────────────────────────────────────────────
class _PollBubble extends StatefulWidget {
  final String question;
  final List<String> options;
  final String messageId;
  final bool isMine;
  const _PollBubble({required this.question, required this.options, required this.messageId, required this.isMine});
  @override State<_PollBubble> createState() => _PollBubbleState();
}

class _PollBubbleState extends State<_PollBubble> {
  int? _voted;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.orange.withOpacity(0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.orange.withOpacity(0.3)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.poll_rounded, color: Colors.orange, size: 18),
          const SizedBox(width: 6),
          const Text('ANKET', style: TextStyle(color: Colors.orange, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
        ]),
        const SizedBox(height: 8),
        Text(widget.question, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
        const SizedBox(height: 10),
        ...List.generate(widget.options.length, (i) {
          final voted = _voted == i;
          return GestureDetector(
            onTap: () => setState(() => _voted = i),
            child: Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: voted ? Colors.orange.withOpacity(0.25) : Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: voted ? Colors.orange.withOpacity(0.6) : Colors.white12),
              ),
              child: Row(children: [
                Icon(voted ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                    color: voted ? Colors.orange : Colors.white38, size: 16),
                const SizedBox(width: 8),
                Expanded(child: Text(widget.options[i],
                    style: TextStyle(color: voted ? Colors.orange : Colors.white70, fontSize: 13))),
              ]),
            ),
          );
        }),
      ]),
    );
  }
}

class _FullscreenImagePage extends StatelessWidget {
  final String url;
  const _FullscreenImagePage({required this.url});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, iconTheme: const IconThemeData(color: Colors.white)),
      body: PhotoView(imageProvider: NetworkImage(url), minScale: PhotoViewComputedScale.contained),
    );
  }
}

// ── Chat AppBar Title Widget ──────────────────────────────────────────────────
// ── Chat AppBar Title ─────────────────────────────────────────────────────────
class _ChatAppBarTitle extends StatelessWidget {
  final String userID;
  final String userName;
  final String profilePic;
  final bool isActive;
  final VoidCallback onTap;

  const _ChatAppBarTitle({
    required this.userID,
    required this.userName,
    required this.profilePic,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            // Avatar
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isActive ? ColorsManager.darkPrimary : const Color(0xFF333333),
                  width: 2,
                ),
              ),
              child: ClipOval(
                child: profilePic.isNotEmpty
                    ? CachedNetworkImage(
                        imageUrl: profilePic,
                        fit: BoxFit.cover,
                        placeholder: (_, __) => const ColoredBox(color: Color(0xFF1A1A1A)),
                        errorWidget: (_, __, ___) => Image.asset('assets/images/user.png', fit: BoxFit.cover),
                      )
                    : Image.asset('assets/images/user.png', fit: BoxFit.cover),
              ),
            ),
            const SizedBox(width: 8),
            // İsim + durum
            Expanded(
              child: StreamBuilder<DocumentSnapshot>(
                stream: DatabaseMethods.getUserStream(userID),
                builder: (ctx, snap) {
                  final userData = snap.data?.data() as Map<String, dynamic>?;
                  final isOnline = userData?['isOnline'] == 'true';
                  // lastSeen: Timestamp veya int olabilir
                  DateTime? lastSeenDt;
                  final rawLastSeen = userData?['lastSeen'];
                  if (rawLastSeen is int) {
                    lastSeenDt = DateTime.fromMillisecondsSinceEpoch(rawLastSeen);
                  } else if (rawLastSeen is Timestamp) {
                    lastSeenDt = rawLastSeen.toDate();
                  }
                  return StreamBuilder<DocumentSnapshot>(
                    stream: DatabaseMethods.getTypingStream(userID),
                    builder: (ctx2, tSnap) {
                      final chatData = tSnap.data?.data() as Map<String, dynamic>?;
                      final isTyping = chatData?['typing_$userID'] == true;
                      String subtitle;
                      if (isTyping) {
                        subtitle = 'yazıyor...';
                      } else if (isOnline) {
                        subtitle = 'Çevrimiçi';
                      } else if (lastSeenDt != null) {
                        final diff = DateTime.now().difference(lastSeenDt);
                        if (diff.inMinutes < 1) subtitle = 'Az önce görüldü';
                        else if (diff.inMinutes < 60) subtitle = '${diff.inMinutes} dk önce';
                        else if (diff.inHours < 24) subtitle = DateFormat('HH:mm').format(lastSeenDt);
                        else subtitle = DateFormat('d MMM').format(lastSeenDt);
                      } else {
                        subtitle = 'Çevrimdışı';
                      }
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            userName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                              height: 1.2,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (isOnline && !isTyping)
                                Container(
                                  width: 6, height: 6,
                                  margin: const EdgeInsets.only(right: 4),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: ColorsManager.darkPrimary,
                                  ),
                                ),
                              Flexible(
                                child: Text(
                                  subtitle,
                                  style: TextStyle(
                                    color: isTyping
                                        ? Colors.greenAccent
                                        : isOnline
                                            ? ColorsManager.darkPrimary
                                            : Colors.white38,
                                    fontSize: 11,
                                    height: 1.2,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                ),
                              ),
                            ],
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
