import '../../home/ui/home_screen.dart';
import '../../../core/widgets/offline_banner.dart';
import '../../../services/message_queue_service.dart';
import '../../../services/local_cache.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_view/photo_view.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/networking/dio_factory.dart';
import '../../../helpers/extensions.dart';
import '../../../helpers/notifications.dart';
import '../../../router/routes.dart';
import '../../../services/cloudinary_service.dart';
import '../../../services/database.dart';
import '../../../services/notification_service.dart';
import '../../../themes/colors.dart';
import 'starred_messages_screen.dart';
import 'ai_assistant_screen.dart';
import '../../tasks/ui/tasks_screen.dart';
import 'secret_chat_page.dart';
import '../../profile/ui/profile_screen.dart';
import '../../call/ui/call_screen.dart';
import 'widgets/message_bar.dart';
import 'widgets/url_preview.dart';
import '../../../core/utils/font_size_provider.dart';
import '../../../helpers/app_state.dart';

// ─────────────────────────────────────────────────────────────────────────────
// CHAT RELOAD BUG FIX — mimari özet:
//  1. Stream initState'de bir kez yaratılır, build()'de asla yeniden yaratılmaz.
//  2. _replyNotifier, _highlightNotifier, _blockedNotifier, _themeNotifier
//     ValueNotifier olarak ayrıştırıldı — setState sadece _selectionMode için.
//  3. Long press / reply / highlight artık tüm sayfayı rebuild etmiyor.
//  4. Scroll pozisyonu korunur.
//  5. Chat sayfası yeniden push edilmez (routes.dart'ta uid kontrolü).
// ─────────────────────────────────────────────────────────────────────────────

class ChatScreen extends StatefulWidget {
  final String receivedUserName;
  final String receivedUserID;
  final String receivedMToken;
  final String active;
  final String? receivedUserProfilePic;

  const ChatScreen({
    super.key,
    required this.receivedUserName,
    required this.receivedUserID,
    required this.receivedMToken,
    required this.active,
    required this.receivedUserProfilePic,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {

  // ── Auth ──────────────────────────────────────────────────────────────────
  final _auth = FirebaseAuth.instance;
  final _picker = ImagePicker();
  late final String _myUID;
  bool _isNavigating = false; // double-push guard
  bool _sendLock = false; // double-send guard
  bool _isLoadingMore = false;
  DocumentSnapshot? _lastMsgDoc;
  final List<QueryDocumentSnapshot> _allMessages = [];

  // ── FIX RELOAD BUG 1: Stream initState'de bir kez yaratılır ───────────────
  late final Stream<QuerySnapshot> _messagesStream;

  // ── FIX RELOAD BUG 2: ValueNotifier'lar — setState yerine ─────────────────
  // Her biri bağımsız, tüm sayfayı rebuild etmez
  final _replyNotifier      = ValueNotifier<Map<String, dynamic>?>(null);
  final _highlightNotifier  = ValueNotifier<String?>(null);
  final _blockedNotifier    = ValueNotifier<bool>(false);
  final _themeNotifier      = ValueNotifier<Color>(const Color(0xFF0D0D0D));
  final _selectionNotifier  = ValueNotifier<Set<String>>({});
  final _searchNotifier     = ValueNotifier<String>('');

  // ── Rate limit ────────────────────────────────────────────────────────────
  DateTime? _lastMsgSent;
  static const _msgRateLimit = Duration(milliseconds: 500);

  // ── Auto delete ───────────────────────────────────────────────────────────
  int? _autoDeleteSeconds;

  // ── Scroll / index ────────────────────────────────────────────────────────
  final ScrollController _msgScrollCtrl = ScrollController();
  final Map<String, int> _msgIndexMap   = {};

  // ── Search ────────────────────────────────────────────────────────────────
  final _searchCtrl = TextEditingController();
  bool _searchMode  = false;

  // ── Selection mode flag — tek setState yeri ───────────────────────────────
  bool _selectionMode = false;
  final Set<String> _selectedMsgIds = {};

  // ── Typing ────────────────────────────────────────────────────────────────
  Timer? _typingTimer;

  // ── Highlight timer ───────────────────────────────────────────────────────
  Timer? _highlightTimer;

  // ── Notifications ─────────────────────────────────────────────────────────
  final _chatService = NotificationService();

  // ── lastSeen safe parse ───────────────────────────────────────────────────
  static DateTime? _parseLastSeen(dynamic raw) {
    if (raw == null) return null;
    if (raw is int) return DateTime.fromMillisecondsSinceEpoch(raw);
    if (raw is Timestamp) return raw.toDate();
    return null;
  }

  @override
  void initState() {
    super.initState();
    _myUID = _auth.currentUser?.uid ?? '';
    WidgetsBinding.instance.addObserver(this);
    FontSizeProvider.instance.addListener(_onFontSizeChanged);

    // ── FIX RELOAD BUG 1: Stream burada, bir kez ──────────────────────────
    _messagesStream = DatabaseMethods.getMessages(
      widget.receivedUserID,
      _myUID,
    );

    // FIX BİLDİRİM: Bu sohbet açıkken o kişiden bildirim gelmesin
    AppState.instance.activeChatUID = widget.receivedUserID;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _markReadIfEnabled();
      _checkBlocked();
      _loadChatTheme();
      _loadAutoDelete();
      DatabaseMethods.deleteExpiredMessages(widget.receivedUserID);
    });
  }

  @override
  void dispose() {
    // FIX BİLDİRİM: Ekrandan çıkınca temizle
    if (AppState.instance.activeChatUID == widget.receivedUserID) {
      AppState.instance.activeChatUID = null;
    }
    FontSizeProvider.instance.removeListener(_onFontSizeChanged);
    WidgetsBinding.instance.removeObserver(this);
    DatabaseMethods.setTyping(widget.receivedUserID, false);
    DatabaseMethods.updateLastSeen();
    _searchCtrl.dispose();
    _typingTimer?.cancel();
    _highlightTimer?.cancel();
    // FIX MEMORY: tüm ValueNotifier'lar dispose ediliyor
    _replyNotifier.dispose();
    _highlightNotifier.dispose();
    _blockedNotifier.dispose();
    _themeNotifier.dispose();
    _selectionNotifier.dispose();
    _searchNotifier.dispose();
    _msgScrollCtrl.dispose();
    super.dispose();
  }

  // ── FIX RELOAD BUG 3: font değişiminde sadece mesaj listesi rebuild edilir ─
  void _onFontSizeChanged() {
    // Sadece listeyi etkiler — ValueNotifier rebuild'i dar tutar
    if (mounted) setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _markReadIfEnabled();
    } else if (state == AppLifecycleState.paused) {
      DatabaseMethods.updateLastSeen();
    }
  }

  Future<void> _loadAutoDelete() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'auto_delete_${widget.receivedUserID}';
    final saved = prefs.getInt(key);
    if (mounted) setState(() => _autoDeleteSeconds = saved);
  }

  Future<void> _loadChatTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final wallpaper = prefs.getString('chat_wallpaper') ?? 'default';
    // FIX RELOAD BUG 2: ValueNotifier — setState yok
    _themeNotifier.value = _wallpaperToColor(wallpaper);
  }

  Color _wallpaperToColor(String id) {
    switch (id) {
      case 'dark':  return const Color(0xFF0D0D0D);
      case 'blue':  return const Color(0xFF0D1B2A);
      case 'red':   return const Color(0xFF1A0505);
      default:      return const Color(0xFF0D0D0D);
    }
  }

  Future<void> _checkBlocked() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final doc = await FirebaseFirestore.instance
        .collection('users').doc(uid)
        .collection('blocked').doc(widget.receivedUserID).get();
    // FIX RELOAD BUG 2: ValueNotifier — setState yok, sadece bottom bar rebuild
    _blockedNotifier.value = doc.exists;
  }

  Future<void> _toggleBlock() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final ref = FirebaseFirestore.instance
        .collection('users').doc(uid)
        .collection('blocked').doc(widget.receivedUserID);
    if (_blockedNotifier.value) {
      await ref.delete();
      _blockedNotifier.value = false;
      _showSnack('Engel kaldırıldı');
    } else {
      await ref.set({'blockedAt': FieldValue.serverTimestamp()});
      _blockedNotifier.value = true;
      _showSnack('Kullanıcı engellendi');
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _markReadIfEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    final enabled = prefs.getBool('read_receipts_enabled') ?? true;
    DatabaseMethods.markMessagesAsRead(widget.receivedUserID,
        readReceiptsEnabled: enabled);
  }

  void _onTyping() {
    DatabaseMethods.setTyping(widget.receivedUserID, true);
    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 2), () {
      DatabaseMethods.setTyping(widget.receivedUserID, false);
    });
  }

  // ── FIX RELOAD BUG 4: reply scroll — push olmaz, scroll eder ─────────────
  Future<void> _loadMoreMessages() async {
    if (_isLoadingMore || _lastMsgDoc == null) return;
    setState(() => _isLoadingMore = true);
    try {
      final more = await DatabaseMethods.loadMoreMessages(
        widget.receivedUserID, _auth.currentUser?.uid ?? '',
        lastDoc: _lastMsgDoc!,
      );
      if (more.docs.isNotEmpty) {
        if (mounted) setState(() {
          _allMessages.addAll(more.docs.cast<QueryDocumentSnapshot>());
          _lastMsgDoc = more.docs.last;
        });
      } else {
        setState(() => _lastMsgDoc = null); // artık mesaj yok
      }
    } catch (_) {}
    setState(() => _isLoadingMore = false);
  }

  void _scrollToReply(String msgId) {
    final idx = _msgIndexMap[msgId];
    if (_msgScrollCtrl.hasClients) {
      if (idx != null) {
        final total = _msgIndexMap.length;
        // reverse=true listede item pozisyonu hesapla
        final pos = (total - 1 - idx) * 75.0;
        _msgScrollCtrl.animateTo(
          pos.clamp(0.0, _msgScrollCtrl.position.maxScrollExtent).toDouble(),
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOut,
        );
      } else {
        _msgScrollCtrl.animateTo(
          _msgScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOut,
        );
      }
    }
    // FIX RELOAD BUG 2: ValueNotifier — setState yok, tüm liste rebuild olmaz
    _highlightNotifier.value = msgId;
    _highlightTimer?.cancel();
    _highlightTimer = Timer(const Duration(seconds: 2), () {
      _highlightNotifier.value = null;
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  // BUILD — ValueListenableBuilder'larla sadece ilgili parça rebuild edilir
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    // FIX RELOAD BUG 2: Scaffold rengi ValueNotifier'dan — setState olmadan
    return ValueListenableBuilder<Color>(
      valueListenable: _themeNotifier,
      builder: (_, theme, __) => Scaffold(
        backgroundColor: theme,
        resizeToAvoidBottomInset: true,
        appBar: _buildAppBar(context),
        body: SafeArea(
          bottom: true,
          child: Column(children: [
            _PinnedMessageBanner(otherUserID: widget.receivedUserID),
            Expanded(
              child: Stack(children: [
                Positioned.fill(
                  child: Opacity(
                    opacity: 0.04,
                    child: Image.asset(
                      'assets/images/chat_backgrond.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                // FIX RELOAD BUG 1: Stream tek — bu widget'ı build() rebuild etse bile
                // StreamBuilder aynı stream'i kullanır, Firestore'a yeniden bağlanmaz
                _MessagesListWidget(
                  stream: _messagesStream,
                  myUID: _myUID,
                  searchNotifier: _searchNotifier,
                  highlightNotifier: _highlightNotifier,
                  selectionNotifier: _selectionNotifier,
                  selectedMsgIds: _selectedMsgIds,
                  msgIndexMap: _msgIndexMap,
                  scrollCtrl: _msgScrollCtrl,
                  receivedUserID: widget.receivedUserID,
                  receivedUserName: widget.receivedUserName,
                  onLongPress: _onMessageLongPress,
                  onDoubleTap: _showMessageMenu,
                  onReplyScroll: _scrollToReply,
                  onSwipeReply: (data, msgId) {
                    // FIX: ValueNotifier — setState yok
                    _replyNotifier.value = {...data, 'msgId': msgId};
                  },
                  onSelectionExit: () {
                    _selectedMsgIds.clear();
                    _selectionNotifier.value = {};
                    setState(() => _selectionMode = false);
                  },
                  onShowMenu: _showMessageMenu,
                  isSelectionMode: _selectionMode,
                ),
              ]),
            ),
            // FIX RELOAD BUG 2: Reply banner ValueNotifier ile
            ValueListenableBuilder<Map<String, dynamic>?>(
              valueListenable: _replyNotifier,
              builder: (_, reply, __) {
                if (reply == null) return const SizedBox.shrink();
                return Container(
                  color: const Color(0xFF1A1A1A),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(children: [
                    Container(
                      width: 3, height: 36,
                      color: ColorsManager.darkPrimary,
                      margin: const EdgeInsets.only(right: 8),
                    ),
                    Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          reply['senderID'] == _myUID ? 'Sen' : widget.receivedUserName,
                          style: TextStyle(
                            color: ColorsManager.darkPrimary,
                            fontSize: 12, fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          (reply['message'] ?? '').toString().length > 50
                              ? '${(reply['message'] ?? '').toString().substring(0, 50)}...'
                              : (reply['message'] ?? '').toString(),
                          style: const TextStyle(color: Colors.white54, fontSize: 12),
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    )),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white38, size: 18),
                      onPressed: () => _replyNotifier.value = null,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ]),
                );
              },
            ),
            // FIX RELOAD BUG 2: MessageBar ValueNotifier ile
            ValueListenableBuilder<bool>(
              valueListenable: _blockedNotifier,
              builder: (_, isBlocked, __) {
                if (isBlocked) {
                  return Container(
                    color: const Color(0xFF1A0A0A),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.block, color: Colors.red.shade400, size: 16),
                      const SizedBox(width: 8),
                      Text('Bu kullanıcıyı engellediniz',
                          style: TextStyle(color: Colors.red.shade400, fontSize: 13)),
                      const Spacer(),
                      GestureDetector(
                        onTap: _toggleBlock,
                        child: Text('Kaldır', style: TextStyle(
                          color: ColorsManager.darkPrimary,
                          fontWeight: FontWeight.bold, fontSize: 13,
                        )),
                      ),
                    ]),
                  );
                }
                return CustomMessageBar(
                  onSend: (message) async {
                    if (isBlocked) return;
                    final now = DateTime.now();
                    if (_lastMsgSent != null &&
                        now.difference(_lastMsgSent!) < _msgRateLimit) return;
                    _lastMsgSent = now;

                    if (message.toLowerCase().startsWith('@ai ')) {
                      final question = message.substring(4).trim();
                      if (question.isEmpty) return;
                      await DatabaseMethods.sendMessage(message, widget.receivedUserID);
                      _handleAI(question);
                    } else {
                      final reply = _replyNotifier.value;
                      await DatabaseMethods.sendMessage(
                        message, widget.receivedUserID,
                        autoDeleteSeconds: _autoDeleteSeconds,
                        replyTo: reply,
                      );
                      _sendNotification(message);
                      _replyNotifier.value = null;
                    }
                  },
                  onShowOptions: () {},
                  onSendImage: (url) async {
                    await DatabaseMethods.sendMessage(url, widget.receivedUserID,
                        autoDeleteSeconds: _autoDeleteSeconds);
                    _sendNotification('📷 Fotoğraf');
                  },
                  onSendAudio: (url) async {
                    await DatabaseMethods.sendMessage(url, widget.receivedUserID,
                        autoDeleteSeconds: _autoDeleteSeconds);
                    _sendNotification('🎤 Sesli mesaj');
                  },
                );
              },
            ),
          ]),
        ),
      ),
    );
  }

  // ── FIX RELOAD BUG 4: Long press scroll pozisyonunu korur ─────────────────
  void _onMessageLongPress(String msgId) {
    HapticFeedback.mediumImpact();
    final savedOffset = _msgScrollCtrl.hasClients ? _msgScrollCtrl.offset : 0.0;
    _selectedMsgIds.add(msgId);
    _selectionNotifier.value = Set<String>.from(_selectedMsgIds);
    setState(() => _selectionMode = true);
    // Scroll pozisyonunu koru
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_msgScrollCtrl.hasClients &&
          (savedOffset - _msgScrollCtrl.offset).abs() > 1) {
        _msgScrollCtrl.jumpTo(savedOffset);
      }
    });
  }

  // ── AppBar ─────────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    if (_selectionMode) {
      return AppBar(
        backgroundColor: const Color(0xFF1A0000),
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () {
            _selectedMsgIds.clear();
            _selectionNotifier.value = {};
            setState(() => _selectionMode = false);
          },
        ),
        title: ValueListenableBuilder<Set<String>>(
          valueListenable: _selectionNotifier,
          builder: (_, sel, __) =>
              Text('${sel.length} seçildi',
                  style: const TextStyle(color: Colors.white)),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            tooltip: 'Sil',
            onPressed: () async {
              final ids = List<String>.from(_selectedMsgIds);
              setState(() { _selectionMode = false; _selectedMsgIds.clear(); });
              for (final id in ids) {
                await DatabaseMethods.deleteMessageForEveryone(
                    id, widget.receivedUserID);
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.forward, color: Colors.white70),
            tooltip: 'İlet',
            onPressed: () async {
              final msgs = List<String>.from(_selectedMsgIds);
              setState(() {
                _selectionMode = false;
                _selectedMsgIds.clear();
                _selectionNotifier.value = {};
              });
              final texts = <String>[];
              final chatRoomID = DatabaseMethods.getChatRoomID(
                  _myUID, widget.receivedUserID);
              for (final id in msgs) {
                try {
                  final doc = await FirebaseFirestore.instance
                      .collection('chats').doc(chatRoomID)
                      .collection('messages').doc(id).get();
                  final content =
                      (doc.data()?['message'] ?? '').toString();
                  if (content.isNotEmpty) texts.add(content);
                } catch (_) {}
              }
              if (!context.mounted || texts.isEmpty) return;
              _showForwardDialog(texts.join('\n'));
            },
          ),
        ],
      );
    }
    if (_searchMode) {
      return AppBar(
        backgroundColor: const Color(0xFF111111),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white70),
          onPressed: () {
            setState(() { _searchMode = false; });
            _searchCtrl.clear();
            _searchNotifier.value = '';
          },
        ),
        title: TextField(
          controller: _searchCtrl,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Mesajlarda ara...',
            hintStyle: TextStyle(color: Colors.white38),
            border: InputBorder.none,
          ),
          onChanged: (v) => _searchNotifier.value = v.toLowerCase(),
        ),
      );
    }
    return _buildNormalAppBar(context);
  }

  PreferredSizeWidget _buildNormalAppBar(BuildContext context) {
    return PreferredSize(
      preferredSize: const Size.fromHeight(kToolbarHeight),
      child: SafeArea(
        bottom: false,
        child: Container(
          height: kToolbarHeight,
          color: const Color(0xFF111111),
          child: Row(children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: Colors.white70, size: 20),
              onPressed: () => Navigator.pop(context),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 40),
            ),
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ProfileScreen(userID: widget.receivedUserID))),
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: widget.active == 'true'
                        ? ColorsManager.darkPrimary
                        : const Color(0xFF333333),
                    width: 2,
                  ),
                ),
                child: ClipOval(child:
                  widget.receivedUserProfilePic != null &&
                      widget.receivedUserProfilePic!.isNotEmpty
                    ? CachedNetworkImage(
                        imageUrl: widget.receivedUserProfilePic!,
                        fit: BoxFit.cover,
                        memCacheWidth: 80,
                        memCacheHeight: 80,
                        placeholder: (_, __) =>
                            const ColoredBox(color: Color(0xFF1A1A1A)),
                        errorWidget: (_, __, ___) =>
                            Image.asset('assets/images/user.png', fit: BoxFit.cover),
                      )
                    : Image.asset('assets/images/user.png', fit: BoxFit.cover),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => ProfileScreen(userID: widget.receivedUserID))),
                child: StreamBuilder<DocumentSnapshot>(
                  stream: DatabaseMethods.getUserStream(widget.receivedUserID),
                  builder: (ctx, snap) {
                    final userData = snap.data?.data() as Map<String, dynamic>?;
                    final isOnline = userData?['isOnline'] == true ||
                        userData?['isOnline'] == 'true';
                    final lastSeenDt = _parseLastSeen(userData?['lastSeen']);
                    return StreamBuilder<DocumentSnapshot>(
                      stream: DatabaseMethods.getTypingStream(widget.receivedUserID),
                      builder: (ctx2, tSnap) {
                        final chatData = tSnap.data?.data() as Map<String, dynamic>?;
                        final isTyping =
                            chatData?['typing_${widget.receivedUserID}'] == true;
                        String subtitle;
                        if (isTyping) {
                          subtitle = 'yazıyor...';
                        } else if (isOnline) {
                          subtitle = 'Çevrimiçi';
                        } else if (lastSeenDt != null) {
                          final diff = DateTime.now().difference(lastSeenDt);
                          if (diff.inMinutes < 1)       subtitle = 'Az önce görüldü';
                          else if (diff.inMinutes < 60) subtitle = '${diff.inMinutes} dk önce';
                          else if (diff.inHours < 24)   subtitle = DateFormat('HH:mm').format(lastSeenDt);
                          else                           subtitle = DateFormat('d MMM').format(lastSeenDt);
                        } else {
                          subtitle = 'Çevrimdışı';
                        }
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(widget.receivedUserName,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600, fontSize: 15),
                              overflow: TextOverflow.ellipsis, maxLines: 1),
                            Text(subtitle,
                              style: TextStyle(
                                color: isTyping ? Colors.greenAccent
                                    : isOnline ? ColorsManager.darkPrimary
                                    : Colors.white38,
                                fontSize: 11),
                              overflow: TextOverflow.ellipsis, maxLines: 1),
                          ],
                        );
                      },
                    );
                  },
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.search, color: Colors.white54, size: 20),
              onPressed: () => setState(() => _searchMode = true),
            ),
            IconButton(
              icon: const Icon(Icons.call_rounded, color: Colors.green, size: 20),
              onPressed: () => _startCall(false),
            ),
            IconButton(
              icon: const Icon(Icons.videocam_rounded, color: Colors.lightBlue, size: 20),
              onPressed: () => _startCall(true),
            ),
            IconButton(
              icon: const Icon(Icons.more_vert, color: Colors.white54),
              onPressed: _showChatOptions,
            ),
            const SizedBox(width: 4),
          ]),
        ),
      ),
    );
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  void _startCall(bool isVideo) {
    final ts = DateTime.now().millisecondsSinceEpoch;
    final callId = 'ch${ts.toString().substring(6)}';
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => CallScreen(
        callId: callId,
        calleeName: widget.receivedUserName,
        calleeUID: widget.receivedUserID,
        isVideoCall: isVideo,
        calleeMToken: widget.receivedMToken,
      ),
    ));
  }

  void _sendNotification(String message) {
    if (widget.receivedMToken.isEmpty) return;
    final myName = _auth.currentUser?.displayName ??
        _auth.currentUser?.email?.split('@').first ?? 'Asgard';
    String preview = message;
    if (_isImageMessage(message)) preview = '📷 Fotoğraf';
    else if (_isAudioMessage(message)) preview = '🎤 Sesli mesaj';
    else if (message.length > 60) preview = '${message.substring(0, 60)}...';
    _chatService.sendPushMessage(
      widget.receivedMToken, '', preview, myName, _myUID,
      widget.receivedUserProfilePic,
      receiverUID: widget.receivedUserID,
    );
  }

  Future<void> _handleAI(String question) async {
    try {
      const geminiKey = String.fromEnvironment('GEMINI_API_KEY');
      if (geminiKey.isEmpty) {
        await DatabaseMethods.sendMessageAsAI(
            '⚠️ Gemini API anahtarı eksik.', widget.receivedUserID);
        return;
      }
      final resp = await http.post(
        Uri.parse(
            'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$geminiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'system_instruction': {'parts': [{'text': 'Sen Asgard asistanısın. Kısa Türkçe cevap ver.'}]},
          'contents': [{'role': 'user', 'parts': [{'text': question}]}],
          'generationConfig': {'maxOutputTokens': 600},
        }),
      );
      final data = jsonDecode(resp.body);
      if (resp.statusCode != 200) {
        final code = data['error']?['code'] ?? resp.statusCode;
        final msg = code == 429 ? '⚠️ AI kota doldu.' : '⚠️ AI yanıt veremedi ($code).';
        await DatabaseMethods.sendMessageAsAI(msg, widget.receivedUserID);
        return;
      }
      final reply = data['candidates']?[0]?['content']?['parts']?[0]?['text']
          ?? 'Yanıt alınamadı';
      await DatabaseMethods.sendMessageAsAI(reply, widget.receivedUserID);
    } catch (_) {
      await DatabaseMethods.sendMessageAsAI(
          '⚠️ Bağlantı hatası.', widget.receivedUserID);
    }
  }

  bool _isAudioMessage(String msg) =>
      msg.contains('.aac') || msg.contains('.mp3') || msg.contains('.m4a') ||
      (msg.contains('cloudinary') && msg.contains('asgard_audio'));

  bool _isImageMessage(String msg) =>
      msg.contains('firebasestorage') ||
      (msg.contains('cloudinary') && (msg.contains('asgard_images') ||
          msg.contains('/image/'))) ||
      msg.endsWith('.jpg') || msg.endsWith('.png') || msg.endsWith('.jpeg') ||
      msg.endsWith('.gif') || msg.endsWith('.webp');

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  void _showLoadingDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => PopScope(
        canPop: false,
        child: Center(child: CircularProgressIndicator(
            color: ColorsManager.darkPrimary)),
      ),
    );
  }

  Future<void> _uploadAndSend(String filePath) async {
    _showLoadingDialog();
    final url = await CloudinaryService.uploadImage(filePath);
    if (!mounted) return;
    context.pop();
    if (url != null) {
      await DatabaseMethods.sendMessage(url, widget.receivedUserID);
    } else {
      _showSnack('Resim yüklenemedi');
    }
  }

  void _openFullscreenImage(String url) {
    Navigator.push(context, MaterialPageRoute(
        builder: (_) => _FullscreenImagePage(url: url)));
  }

  Future<void> _launchURL(String myUrl) async {
    if (!myUrl.startsWith('http')) myUrl = 'https://$myUrl';
    await launchUrl(Uri.parse(myUrl), mode: LaunchMode.inAppBrowserView);
  }

  // ── Chat Options ──────────────────────────────────────────────────────────
  void _showChatOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111111),
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: SingleChildScrollView(child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          ListTile(
            leading: Icon(Icons.person_outline, color: ColorsManager.darkPrimary),
            title: const Text('Profili Görüntüle', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(
                builder: (_) => ProfileScreen(userID: widget.receivedUserID))); },
          ),
          ValueListenableBuilder<bool>(
            valueListenable: _blockedNotifier,
            builder: (_, isBlocked, __) => ListTile(
              leading: Icon(Icons.block, color: Colors.red.shade400),
              title: Text(isBlocked ? 'Engeli Kaldır' : 'Engelle',
                  style: TextStyle(color: Colors.red.shade400)),
              onTap: () { Navigator.pop(context); _toggleBlock(); },
            ),
          ),
          const Divider(color: Colors.white10, height: 1),
          ListTile(
            leading: const Icon(Icons.star_rounded, color: Colors.amber),
            title: const Text('⭐ Yıldızlı Mesajlar', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); Navigator.push(context,
                MaterialPageRoute(builder: (_) => const StarredMessagesScreen())); },
          ),
          ListTile(
            leading: const Icon(Icons.auto_awesome_rounded, color: Colors.purple),
            title: const Text('🤖 AI Asistan', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); Navigator.push(context,
                MaterialPageRoute(builder: (_) => const AIAssistantScreen())); },
          ),
          ListTile(
            leading: const Icon(Icons.lock_rounded, color: Colors.green),
            title: const Text('🔒 Gizli Sohbet', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); Navigator.push(context,
                MaterialPageRoute(builder: (_) => SecretChatPage(
                  otherUid: widget.receivedUserID,
                  otherName: widget.receivedUserName,
                  otherPhoto: '',
                ))); },
          ),
          ListTile(
            leading: const Icon(Icons.palette_rounded, color: Colors.deepOrange),
            title: const Text('🎨 Sohbet Teması', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _showThemePicker(); },
          ),
          const Divider(color: Colors.white10, height: 1),
          ListTile(
            leading: const Icon(Icons.photo_library_outlined, color: Colors.lightBlue),
            title: const Text('🖼️ Medya & Dosyalar', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _showMediaFilter(); },
          ),
          ListTile(
            leading: Icon(Icons.timer_outlined, color: _autoDeleteSeconds != null ? Colors.orange : Colors.white54),
            title: Text(
              _autoDeleteSeconds == null
                  ? '⏰ Otomatik Silme: Kapalı'
                  : '⏰ Otomatik Silme: ${_autoDeleteSeconds! < 3600 ? "${_autoDeleteSeconds! ~/ 60} dk" : "${_autoDeleteSeconds! ~/ 3600} saat"}',
              style: TextStyle(color: _autoDeleteSeconds != null ? Colors.orange : Colors.white),
            ),
            onTap: () { Navigator.pop(context); _showAutoDeleteDialog(); },
          ),
          ListTile(
            leading: const Icon(Icons.cleaning_services_outlined, color: Colors.redAccent),
            title: const Text('🗑️ Sohbeti Temizle', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(context); _showClearChatDialog(); },
          ),
        ],
      ))),
    );
  }

  void _showClearChatDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Sohbeti Temizle', style: TextStyle(color: Colors.white)),
        content: const Text('Tüm mesajlar nasıl silinsin?',
            style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              _showLoadingDialog();
              final msgs = await _messagesStream.first;
              for (final doc in msgs.docs) {
                await DatabaseMethods.deleteMessageForMe(doc.id, widget.receivedUserID);
              }
              if (mounted) {
                context.pop();
                _showSnack('Sohbet temizlendi (sadece senden)');
              }
            },
            child: const Text('Benden Sil', style: TextStyle(color: Colors.orange)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              _showLoadingDialog();
              final msgs = await _messagesStream.first;
              for (final doc in msgs.docs) {
                final data = doc.data() as Map<String, dynamic>;
                if (data['senderID'] == _myUID) {
                  await DatabaseMethods.deleteMessageForEveryone(doc.id, widget.receivedUserID);
                } else {
                  await DatabaseMethods.deleteMessageForMe(doc.id, widget.receivedUserID);
                }
              }
              if (mounted) {
                context.pop();
                _showSnack('Sohbet temizlendi (herkesten)');
              }
            },
            child: const Text('Herkesten Sil', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showAutoDeleteDialog() {
    final options = [
      {'label': 'Kapalı', 'value': null},
      {'label': '1 Dakika', 'value': 60},
      {'label': '5 Dakika', 'value': 300},
      {'label': '1 Saat', 'value': 3600},
      {'label': '1 Gün', 'value': 86400},
      {'label': '1 Hafta', 'value': 604800},
    ];
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Otomatik Silme', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        ...options.map((o) {
          final val = o['value'] as int?;
          final selected = _autoDeleteSeconds == val;
          return ListTile(
            leading: Icon(val == null ? Icons.timer_off_outlined : Icons.timer_outlined,
                color: selected ? Colors.orange : Colors.white54),
            title: Text(o['label'] as String,
                style: TextStyle(color: selected ? Colors.orange : Colors.white,
                    fontWeight: selected ? FontWeight.bold : FontWeight.normal)),
            trailing: selected ? const Icon(Icons.check_circle_rounded, color: Colors.orange) : null,
            onTap: () {
              setState(() => _autoDeleteSeconds = val);
              SharedPreferences.getInstance().then((p) {
                final key = 'auto_delete_${widget.receivedUserID}';
                if (val == null) p.remove(key); else p.setInt(key, val);
              });
              Navigator.pop(context);
            },
          );
        }),
        const SizedBox(height: 8),
      ])),
    );
  }

  void _showMediaFilter() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => _MediaFilterPage(
      chatRoomId: DatabaseMethods.getChatRoomId(widget.receivedUserID, _myUID),
      myUID: _myUID,
      otherUID: widget.receivedUserID,
      otherName: widget.receivedUserName,
    )));
  }

  void _showThemePicker() {
    final themes = [
      {'name': 'Varsayılan', 'id': 'default', 'color': const Color(0xFF0D0D0D)},
      {'name': 'Gece Mavisi', 'id': 'blue',   'color': const Color(0xFF0D1B2A)},
      {'name': 'Orman',       'id': 'forest',  'color': const Color(0xFF0A140E)},
      {'name': 'Mor Gece',    'id': 'purple',  'color': const Color(0xFF100A1A)},
      {'name': 'Kahve',       'id': 'red',     'color': const Color(0xFF140E0A)},
      {'name': 'Deniz',       'id': 'sea',     'color': const Color(0xFF0A1214)},
    ];
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Sohbet Teması', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: 3, shrinkWrap: true,
            crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.4,
            children: themes.map((t) {
              final color = t['color'] as Color;
              return ValueListenableBuilder<Color>(
                valueListenable: _themeNotifier,
                builder: (_, cur, __) {
                  final selected = cur == color;
                  return GestureDetector(
                    onTap: () async {
                      _themeNotifier.value = color; // FIX: setState yok
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.setString('chat_wallpaper', t['id'] as String);
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: selected ? ColorsManager.darkPrimary : Colors.white12,
                          width: selected ? 2.5 : 1,
                        ),
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        if (selected)
                          Icon(Icons.check_circle_rounded, color: ColorsManager.darkPrimary, size: 20),
                        const SizedBox(height: 4),
                        Text(t['name'] as String,
                            style: TextStyle(
                              color: selected ? ColorsManager.darkPrimary : Colors.white60,
                              fontSize: 12,
                            )),
                      ]),
                    ),
                  );
                },
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 16),
      ])),
    );
  }

  // ── Forward / Message Menu ─────────────────────────────────────────────────
  void _showForwardDialog(String text) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Text('Kişiye İlet', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        StreamBuilder<QuerySnapshot>(
          stream: DatabaseMethods.getContacts(),
          builder: (ctx, snap) {
            final docs = snap.data?.docs ?? [];
            return ListView.builder(
              shrinkWrap: true,
              itemCount: docs.length,
              itemBuilder: (ctx, i) => StreamBuilder<DocumentSnapshot>(
                stream: DatabaseMethods.getUserStream(docs[i].id),
                builder: (ctx, uSnap) {
                  final data = uSnap.data?.data() as Map<String, dynamic>?;
                  if (data == null) return const SizedBox.shrink();
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: (data['profilePic'] ?? '').isNotEmpty
                          ? CachedNetworkImageProvider(data['profilePic'], maxWidth: 80, maxHeight: 80)
                          : null,
                      backgroundColor: const Color(0xFF2A2A2A),
                      child: (data['profilePic'] ?? '').isEmpty
                          ? const Icon(Icons.person, color: Colors.white38) : null,
                    ),
                    title: Text(data['name'] ?? '', style: const TextStyle(color: Colors.white)),
                    onTap: () async {
                      Navigator.pop(context);
                      await DatabaseMethods.sendMessage(text, docs[i].id);
                      if (context.mounted) {
                        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Mesaj iletildi')));
                      }
                    },
                  );
                },
              ),
            );
          },
        ),
        const SizedBox(height: 8),
      ])),
    );
  }

  void _showForwardScreen(String message) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7, maxChildSize: 0.95, minChildSize: 0.5, expand: false,
        builder: (_, ctrl) => Column(children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const Text('İlet', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          Expanded(child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users').doc(_myUID)
                .collection('contacts').snapshots(),
            builder: (_, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              return ListView.builder(
                controller: ctrl,
                itemCount: snap.data!.docs.length,
                itemBuilder: (_, i) {
                  final uid = (snap.data!.docs[i].data() as Map)['uid'] ?? snap.data!.docs[i].id;
                  return StreamBuilder<DocumentSnapshot>(
                    stream: DatabaseMethods.getUserStream(uid),
                    builder: (_, uSnap) {
                      final data = uSnap.data?.data() as Map<String, dynamic>?;
                      if (data == null) return const SizedBox.shrink();
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundImage: (data['profilePic'] ?? '').isNotEmpty
                              ? CachedNetworkImageProvider(data['profilePic'], maxWidth: 80, maxHeight: 80)
                              : null,
                          backgroundColor: const Color(0xFF2A2A2A),
                          child: (data['profilePic'] ?? '').isEmpty
                              ? const Icon(Icons.person, color: Colors.white38) : null,
                        ),
                        title: Text(data['name'] ?? '', style: const TextStyle(color: Colors.white)),
                        onTap: () async {
                          Navigator.pop(context);
                          await DatabaseMethods.sendMessage('↪ $message', uid);
                          if (context.mounted) _showSnack("${data['name']}'e iletildi");
                        },
                      );
                    },
                  );
                },
              );
            },
          )),
        ]),
      ),
    );
  }

  void _showMessageMenu(BuildContext ctx, Map<String, dynamic> data,
      String msgId, bool isMine, String message) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: ctx,
      backgroundColor: const Color(0xFF1A1A1A),
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (_) => SafeArea(child: SingleChildScrollView(child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: ['❤️', '😂', '😮', '😢', '👍', '🔥'].map((e) =>
                GestureDetector(
                  onTap: () async {
                    Navigator.pop(ctx);
                    await DatabaseMethods.addReaction(msgId, widget.receivedUserID, e);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: const BoxDecoration(color: Colors.white10, shape: BoxShape.circle),
                    child: Text(e, style: const TextStyle(fontSize: 22)),
                  ),
                ),
              ).toList(),
            ),
          ),
          const Divider(color: Colors.white10, height: 1),
          ListTile(
            leading: const Icon(Icons.copy_outlined, color: Colors.white60),
            title: const Text('Kopyala', style: TextStyle(color: Colors.white)),
            onTap: () {
              Clipboard.setData(ClipboardData(text: message));
              Navigator.pop(ctx);
              _showSnack('Kopyalandı');
            },
          ),
          ListTile(
            leading: const Icon(Icons.forward_rounded, color: Colors.green),
            title: const Text('İlet', style: TextStyle(color: Colors.white)),
            onTap: () { Navigator.pop(ctx); _showForwardScreen(message); },
          ),
          FutureBuilder<bool>(
            future: DatabaseMethods.isMessageStarred(msgId),
            builder: (_, snap) {
              final starred = snap.data ?? false;
              return ListTile(
                leading: Icon(starred ? Icons.star_rounded : Icons.star_border_rounded,
                    color: Colors.amber),
                title: Text(starred ? 'Yıldızdan Kaldır' : 'Yıldızla',
                    style: const TextStyle(color: Colors.white)),
                onTap: () async {
                  Navigator.pop(ctx);
                  if (starred) {
                    await DatabaseMethods.unstarMessage(msgId);
                  } else {
                    await DatabaseMethods.starMessage(msgId, {...data, 'message': message});
                    if (context.mounted) _showSnack('⭐ Yıldızlandı');
                  }
                },
              );
            },
          ),
          if (!message.startsWith('['))
            ListTile(
              leading: const Icon(Icons.translate_rounded, color: Colors.lightBlue),
              title: const Text('Çevir', style: TextStyle(color: Colors.white)),
              onTap: () { Navigator.pop(ctx); _showTranslation(message); },
            ),
          ListTile(
            leading: Icon(Icons.push_pin_outlined, color: ColorsManager.darkPrimary),
            title: const Text('Sabitle', style: TextStyle(color: Colors.white)),
            onTap: () async {
              Navigator.pop(ctx);
              await DatabaseMethods.pinMessage(msgId, widget.receivedUserID, message);
              _showSnack('Mesaj sabitlendi');
            },
          ),
          if (isMine && !_isAudioMessage(message) && !_isImageMessage(message))
            ListTile(
              leading: const Icon(Icons.edit_outlined, color: Colors.blueAccent),
              title: const Text('Düzenle', style: TextStyle(color: Colors.white)),
              onTap: () { Navigator.pop(ctx); _showEditDialog(msgId, message); },
            ),
          ListTile(
            leading: const Icon(Icons.delete_outline, color: Colors.orange),
            title: const Text('Benden Sil', style: TextStyle(color: Colors.white)),
            onTap: () async {
              Navigator.pop(ctx);
              await DatabaseMethods.deleteMessageForMe(msgId, widget.receivedUserID);
            },
          ),
          if (isMine)
            ListTile(
              leading: const Icon(Icons.delete_forever_outlined, color: Colors.red),
              title: const Text('Herkesten Sil',
                  style: TextStyle(color: Colors.red)),
              onTap: () async {
                Navigator.pop(ctx);
                await DatabaseMethods.deleteMessageForEveryone(
                    msgId, widget.receivedUserID);
              },
            ),
        ],
      ))),
    );
  }

  void _showEditDialog(String msgId, String currentText) {
    final ctrl = TextEditingController(text: currentText);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Mesajı Düzenle', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white),
          maxLines: null,
          decoration: InputDecoration(
            hintText: 'Yeni mesaj',
            hintStyle: const TextStyle(color: Colors.white38),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.3)),
              borderRadius: BorderRadius.circular(10),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: ColorsManager.darkPrimary),
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              final newText = ctrl.text.trim();
              if (newText.isNotEmpty && newText != currentText) {
                await DatabaseMethods.editMessage(
                    msgId, widget.receivedUserID, newText);
              }
              if (mounted) Navigator.pop(ctx);
            },
            child: Text('Kaydet', style: TextStyle(
                color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _showTranslation(String message) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          String? translatedText;
          bool loading = true;
          String targetLang = 'İngilizce';
          _doTranslate(message, targetLang).then((t) {
            if (ctx.mounted) setS(() { translatedText = t; loading = false; });
          });
          return AlertDialog(
            backgroundColor: const Color(0xFF1A1A1A),
            title: const Row(children: [
              Icon(Icons.translate_rounded, color: Colors.lightBlue, size: 20),
              SizedBox(width: 8),
              Text('Çeviri', style: TextStyle(color: Colors.white, fontSize: 16)),
            ]),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('Orijinal:', style: TextStyle(color: Colors.white38, fontSize: 12)),
              const SizedBox(height: 4),
              Text(message, style: const TextStyle(color: Colors.white70, fontSize: 14)),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.lightBlue.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: loading
                    ? const Center(child: SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.lightBlue)))
                    : SelectableText(translatedText ?? '⚠️ Çeviri yapılamadı',
                        style: TextStyle(color: translatedText != null ? Colors.white : Colors.red, fontSize: 13)),
              ),
            ]),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text('Kapat', style: TextStyle(color: ColorsManager.darkPrimary)),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<String?> _doTranslate(String text, String targetLang) async {
    try {
      const geminiKey = String.fromEnvironment('GEMINI_API_KEY');
      if (geminiKey.isEmpty) return '⚠️ GEMINI_API_KEY eksik';
      final response = await http.post(
        Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$geminiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [{'role': 'user', 'parts': [{'text': 'Şu metni $targetLang diline çevir, sadece çeviriyi yaz:\n\n$text'}]}],
          'generationConfig': {'maxOutputTokens': 500},
        }),
      );
      if (response.statusCode != 200) return '⚠️ API hatası: ${response.statusCode}';
      final data = jsonDecode(response.body);
      return data['candidates']?[0]?['content']?['parts']?[0]?['text'];
    } catch (_) {
      return '⚠️ Bağlantı hatası';
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// FIX RELOAD BUG — Mesaj listesi ayrı StatefulWidget olarak çıkarıldı.
// ChatScreen'in state'i değişse bile bu widget kendi stream'ini korur.
// ─────────────────────────────────────────────────────────────────────────────
class _MessagesListWidget extends StatefulWidget {
  final Stream<QuerySnapshot> stream;
  final String myUID;
  final String receivedUserID;
  final String receivedUserName;
  final ValueNotifier<String> searchNotifier;
  final ValueNotifier<String?> highlightNotifier;
  final ValueNotifier<Set<String>> selectionNotifier;
  final Set<String> selectedMsgIds;
  final Map<String, int> msgIndexMap;
  final ScrollController scrollCtrl;
  final bool isSelectionMode;
  final void Function(String msgId) onLongPress;
  final void Function(BuildContext ctx, Map<String, dynamic> data,
      String msgId, bool isMine, String message) onDoubleTap;
  final void Function(String msgId) onReplyScroll;
  final void Function(Map<String, dynamic> data, String msgId) onSwipeReply;
  final VoidCallback onSelectionExit;
  final void Function(BuildContext ctx, Map<String, dynamic> data,
      String msgId, bool isMine, String message)? onShowMenu;

  const _MessagesListWidget({
    required this.stream,
    required this.myUID,
    required this.receivedUserID,
    required this.receivedUserName,
    required this.searchNotifier,
    required this.highlightNotifier,
    required this.selectionNotifier,
    required this.selectedMsgIds,
    required this.msgIndexMap,
    required this.scrollCtrl,
    required this.isSelectionMode,
    required this.onLongPress,
    required this.onDoubleTap,
    required this.onReplyScroll,
    required this.onSwipeReply,
    required this.onSelectionExit,
    this.onShowMenu,
  });

  @override
  State<_MessagesListWidget> createState() => _MessagesListWidgetState();
}

class _MessagesListWidgetState extends State<_MessagesListWidget> {
  // FIX RELOAD BUG 5: Mesaj verisi burada önbelleğe alınır —
  // parent rebuild'i listeyi resetlemiyor.
  List<QueryDocumentSnapshot> _cachedDocs = [];

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: widget.stream,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text(snapshot.error.toString(),
              style: const TextStyle(color: Colors.red)));
        }
        if (snapshot.connectionState == ConnectionState.waiting &&
            _cachedDocs.isEmpty) {
          return Center(child: CircularProgressIndicator(
              color: ColorsManager.darkPrimary));
        }
        if (snapshot.hasData) {
          _cachedDocs = snapshot.data!.docs;
        }

        return ValueListenableBuilder<String>(
          valueListenable: widget.searchNotifier,
          builder: (_, searchQuery, __) {
            final filtered = searchQuery.isEmpty
                ? _cachedDocs
                : _cachedDocs.where((d) {
                    final msg = ((d.data() as Map)['message'] ?? '')
                        .toString().toLowerCase();
                    return msg.contains(searchQuery);
                  }).toList();

            if (filtered.isEmpty) {
              return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.chat_bubble_outline, size: 48.sp, color: Colors.white12),
                Gap(12.h),
                Text(searchQuery.isEmpty ? 'Henüz mesaj yok' : '"$searchQuery" bulunamadı',
                    style: TextStyle(color: Colors.white24, fontSize: 14.sp)),
              ]));
            }

            return ListView.builder(
              controller: widget.scrollCtrl,
              reverse: searchQuery.isEmpty,
              padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
              itemCount: filtered.length,
              addRepaintBoundaries: true,
              addAutomaticKeepAlives: false,
              itemBuilder: (context, index) {
                final current = filtered[index];
                final data = current.data() as Map<String, dynamic>;
                final msgId = current.id;

                final hiddenFor = List<dynamic>.from(data['hiddenFor'] ?? []);
                if (hiddenFor.contains(widget.myUID)) {
                  return const SizedBox.shrink();
                }

                final next = index < filtered.length - 1 ? filtered[index + 1] : null;
                final ts = data['timestamp'];
                final DateTime time = ts is Timestamp ? ts.toDate() : DateTime.now();
                DateTime? nextTime;
                if (next != null) {
                  final nts = (next.data() as Map<String,dynamic>?)?['timestamp'];
                  nextTime = nts is Timestamp ? nts.toDate() : null;
                }
                final bool isNewDay =
                    nextTime == null || !_isSameDay(time, nextTime);
                final bool isNewSender = next == null ||
                    data['senderID'] !=
                        (next.data() as Map<String, dynamic>)['senderID'];

                widget.msgIndexMap[msgId] = index;

                // FIX RELOAD BUG 3: Highlight ValueNotifier ile — liste rebuild yok
                return ValueListenableBuilder<String?>(
                  valueListenable: widget.highlightNotifier,
                  builder: (_, hl, __) => AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    color: hl == msgId
                        ? ColorsManager.darkPrimary.withOpacity(0.15)
                        : Colors.transparent,
                    child: _buildItem(context, data, msgId, isNewSender, isNewDay, time),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  Widget _buildItem(BuildContext context, Map<String, dynamic> data,
      String msgId, bool isNewSender, bool isNewDay, DateTime time) {
    final bool isAI = data['senderID'] == 'AI_BOT' || data['isAI'] == true;
    final String senderUID = data['senderID']?.toString() ?? '';
    final bool isMine = !isAI && senderUID.isNotEmpty && senderUID == widget.myUID;
    final String message = (data['message'] ?? '').toString();
    final String status = (data['status'] ?? 'delivered').toString();
    final bool isDeleted = data['deleted'] == true;
    final bool isEdited = data['edited'] == true;
    final Map<String, dynamic> reactions =
        Map<String, dynamic>.from(data['reactions'] ?? {});

    if (isAI) {
      return Column(children: [
        if (isNewDay) _buildDateDivider(time),
        _buildAIBubble(message, time),
      ]);
    }

    Widget bubble;
    if (isDeleted) {
      bubble = _buildDeletedBubble(isMine, isNewSender);
    } else if (_isAudioMessage(message)) {
      bubble = _buildAudioBubble(isMine, isNewSender, message, status, time);
    } else if (_isImageMessage(message)) {
      bubble = _buildImageBubble(isMine, isNewSender, message, msgId, status, time);
    } else if (message.startsWith('↩️ Durumuna yanıt: ')) {
      bubble = _buildStatusReplyBubble(
          message.replaceFirst('↩️ Durumuna yanıt: ', ''),
          msgId, isMine, isNewSender, status, time);
    } else if (_isLink(message)) {
      bubble = _buildLinkBubble(isMine, isNewSender, message, status, time);
    } else {
      final replyTo = data['replyTo'] is Map<String, dynamic>
          ? data['replyTo'] as Map<String, dynamic> : null;
      bubble = _buildTextBubble(message, msgId, isMine, isNewSender,
          status, time, isEdited, replyTo: replyTo);
    }

    // FIX RELOAD BUG 3: Selection ValueNotifier ile — setState yok
    if (widget.isSelectionMode) {
      return Column(children: [
        if (isNewDay) _buildDateDivider(time),
        ValueListenableBuilder<Set<String>>(
          valueListenable: widget.selectionNotifier,
          builder: (ctx, selected, _) {
            void toggle() {
              final newSet = Set<String>.from(widget.selectedMsgIds);
              if (newSet.contains(msgId)) {
                newSet.remove(msgId);
                if (newSet.isEmpty) { widget.onSelectionExit(); return; }
              } else {
                newSet.add(msgId);
              }
              widget.selectedMsgIds..clear()..addAll(newSet);
              widget.selectionNotifier.value = Set<String>.from(newSet);
            }
            return GestureDetector(
              onTap: toggle,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                color: selected.contains(msgId)
                    ? ColorsManager.darkPrimary.withOpacity(0.18)
                    : Colors.transparent,
                child: Row(children: [
                  SizedBox(width: 8.w),
                  AnimatedScale(
                    scale: selected.contains(msgId) ? 1.0 : 0.8,
                    duration: const Duration(milliseconds: 150),
                    child: Checkbox(
                      value: selected.contains(msgId),
                      onChanged: (_) => toggle(),
                      activeColor: ColorsManager.darkPrimary,
                      checkColor: Colors.white,
                      side: const BorderSide(color: Colors.white38),
                    ),
                  ),
                  Expanded(child: Column(children: [
                    bubble,
                    if (reactions.isNotEmpty)
                      _buildReactions(reactions, msgId, isMine: isMine),
                  ])),
                ]),
              ),
            );
          },
        ),
      ]);
    }

    // Normal mod
    return Column(children: [
      if (isNewDay) _buildDateDivider(time),
      Dismissible(
        key: Key('swipe_$msgId'),
        direction: DismissDirection.startToEnd,
        dismissThresholds: const {DismissDirection.startToEnd: 0.25},
        confirmDismiss: (_) async {
          if (!isDeleted) {
            HapticFeedback.lightImpact();
            widget.onSwipeReply(data, msgId);
          }
          return false;
        },
        background: Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Icon(Icons.reply_rounded, color: ColorsManager.darkPrimary, size: 24),
        ),
        child: GestureDetector(
          onLongPress: () => widget.onLongPress(msgId),
          onDoubleTap: () => widget.onDoubleTap(context, data, msgId, isMine, message),
          child: Column(children: [
            bubble,
            if (reactions.isNotEmpty)
              _buildReactions(reactions, msgId, isMine: isMine),
          ]),
        ),
      ),
    ]);
  }

  // ── Bubble builders ────────────────────────────────────────────────────────

  bool _isAudioMessage(String msg) =>
      msg.contains('.aac') || msg.contains('.mp3') || msg.contains('.m4a') ||
      (msg.contains('cloudinary') && msg.contains('asgard_audio'));

  bool _isImageMessage(String msg) =>
      msg.contains('firebasestorage') ||
      (msg.contains('cloudinary') && (msg.contains('asgard_images') ||
          msg.contains('/image/'))) ||
      msg.endsWith('.jpg') || msg.endsWith('.png') || msg.endsWith('.jpeg') ||
      msg.endsWith('.gif') || msg.endsWith('.webp');

  bool _isLink(String msg) {
    final re = RegExp(
      r'((https?://|www\.)[^\s]+)',
      caseSensitive: false,
    );
    return re.hasMatch(msg);
  }

  bool _isOnlyEmoji(String text) {
    final stripped = text.replaceAll(RegExp(r'\s'), '');
    if (stripped.isEmpty || stripped.length > 8) return false;
    final re = RegExp(
      r'[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}'
      r'\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}'
      r'\u{FE00}-\u{FE0F}\u{1F900}-\u{1F9FF}]+',
      unicode: true,
    );
    return re.hasMatch(stripped) && stripped.replaceAll(re, '').isEmpty;
  }

  Widget _buildDateDivider(DateTime date) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 12.h),
      child: Row(children: [
        Expanded(child: Divider(color: Colors.white12, thickness: 0.5)),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 10.w),
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.2)),
          ),
          child: Text(DateFormat('d MMM yyyy').format(date),
              style: TextStyle(color: Colors.white38, fontSize: 11.sp)),
        ),
        Expanded(child: Divider(color: Colors.white12, thickness: 0.5)),
      ]),
    );
  }

  Widget _buildReactions(Map<String, dynamic> reactions, String msgId,
      {bool isMine = true}) {
    final grouped = <String, int>{};
    for (final e in reactions.values) {
      grouped[e.toString()] = (grouped[e.toString()] ?? 0) + 1;
    }
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(bottom: 4.h, right: 8.w, left: 8.w),
        padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 3.h),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1A),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(mainAxisSize: MainAxisSize.min,
          children: grouped.entries.map((e) =>
            Text('${e.key}${e.value > 1 ? e.value.toString() : ''} ',
                style: const TextStyle(fontSize: 13))).toList()),
      ),
    );
  }

  Widget _buildStatusTicks(String status) {
    if (status == 'sending') {
      return Icon(Icons.check, size: 13.sp, color: Colors.white24);
    }
    final color = status == 'read' ? ColorsManager.darkPrimary : Colors.white54;
    return SizedBox(width: 18.w, height: 13.h,
        child: Stack(children: [
          Positioned(left: 0, child: Icon(Icons.check, size: 13.sp, color: color)),
          Positioned(left: 5.w, child: Icon(Icons.check, size: 13.sp, color: color)),
        ]));
  }

  Widget _buildAIBubble(String message, DateTime time) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 4.h, bottom: 4.h, left: 8.w, right: 60.w),
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF1A0030), Color(0xFF0D001A)],
          ),
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(color: Colors.purple.withOpacity(0.4)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(6)),
              child: const Icon(Icons.auto_awesome, color: Colors.purple, size: 12),
            ),
            const SizedBox(width: 6),
            const Text('Asgard AI', style: TextStyle(
                color: Colors.purple, fontSize: 11, fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 6),
          Text(message, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4)),
          const SizedBox(height: 4),
          Text(DateFormat('h:mm a').format(time),
              style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ]),
      ),
    );
  }

  Widget _buildDeletedBubble(bool isMine, bool isNewSender) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 60.w : 0, right: isMine ? 0 : 60.w),
        padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 9.h),
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.block, size: 14, color: Colors.white38),
          const SizedBox(width: 6),
          Text('Bu mesaj silindi',
              style: TextStyle(color: Colors.white38, fontSize: 13.sp,
                  fontStyle: FontStyle.italic)),
        ]),
      ),
    );
  }

  Widget _buildTextBubble(String message, String msgId, bool isMine,
      bool isNewSender, String status, DateTime time, bool isEdited,
      {Map<String, dynamic>? replyTo}) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 60.w : 0, right: isMine ? 0 : 60.w),
        padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 9.h),
        decoration: BoxDecoration(
          color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(18.r), topRight: Radius.circular(18.r),
            bottomLeft: Radius.circular(isMine ? 18.r : (isNewSender ? 4.r : 18.r)),
            bottomRight: Radius.circular(isMine ? (isNewSender ? 4.r : 18.r) : 18.r),
          ),
          border: Border.all(
            color: isMine
                ? ColorsManager.darkPrimary.withOpacity(0.5)
                : Colors.white.withOpacity(0.07),
          ),
        ),
        child: Column(
          crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (replyTo != null) ...[
              GestureDetector(
                onTap: () {
                  final rid = replyTo['msgId']?.toString() ?? '';
                  if (rid.isNotEmpty) widget.onReplyScroll(rid);
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(8),
                    border: Border(left: BorderSide(
                        color: ColorsManager.darkPrimary, width: 3)),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min, children: [
                    Text(
                      replyTo['senderID'] == widget.myUID
                          ? 'Sen' : widget.receivedUserName,
                      style: TextStyle(color: ColorsManager.darkPrimary,
                          fontSize: 11.sp, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 2),
                    Text((replyTo['message'] ?? '').toString(),
                        style: TextStyle(color: Colors.white60, fontSize: 12.sp),
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                  ]),
                ),
              ),
            ],
            Text(message,
              style: TextStyle(
                color: Colors.white,
                fontSize: _isOnlyEmoji(message)
                    ? 36.sp
                    : FontSizeProvider.instance.messageFontSize,
                height: 1.4,
              ),
            ),
            Gap(4.h),
            Row(mainAxisSize: MainAxisSize.min, children: [
              if (isEdited)
                Text('düzenlendi · ',
                    style: TextStyle(color: Colors.white24, fontSize: 9.sp)),
              Text(DateFormat('h:mm a').format(time),
                  style: TextStyle(color: Colors.white38, fontSize: 10.sp)),
              if (isMine) ...[Gap(4.w), _buildStatusTicks(status)],
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildImageBubble(bool isMine, bool isNewSender, String message,
      String msgId, String status, DateTime time) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => _FullscreenImagePage(url: message))),
        onLongPress: () => widget.onDoubleTap(
            context, {'message': message}, msgId, isMine, message),
        child: Container(
          margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
              left: isMine ? 60.w : 4.w, right: isMine ? 4.w : 60.w),
          width: 220.w,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(
              color: isMine
                  ? ColorsManager.darkPrimary.withOpacity(0.5)
                  : Colors.white12,
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(11.r),
            child: Column(
              crossAxisAlignment: isMine
                  ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                CachedNetworkImage(
                  imageUrl: message,
                  width: 220.w,
                  fit: BoxFit.fitWidth,
                  memCacheWidth: 660,
                  placeholder: (c, u) => SizedBox(
                    width: 220.w,
                    height: 180.w,
                    child: const Center(child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white24)),
                  ),
                  errorWidget: (c, u, e) => SizedBox(
                    width: 220.w,
                    height: 100.w,
                    child: const Center(child: Icon(
                        Icons.error_outline_rounded, color: Colors.red)),
                  ),
                ),
                Container(
                  color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(DateFormat('h:mm a').format(time),
                        style: TextStyle(color: Colors.white38, fontSize: 10.sp)),
                    if (isMine) ...[Gap(4.w), _buildStatusTicks(status)],
                  ]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAudioBubble(bool isMine, bool isNewSender, String audioUrl,
      String status, DateTime time) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 60.w : 0, right: isMine ? 0 : 60.w),
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
        decoration: BoxDecoration(
          color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
          borderRadius: BorderRadius.circular(18.r),
          border: Border.all(
            color: isMine
                ? ColorsManager.darkPrimary.withOpacity(0.5)
                : Colors.white12,
          ),
        ),
        child: _AudioPlayer(
          audioUrl: audioUrl, isMine: isMine, time: time, status: status),
      ),
    );
  }

  Widget _buildStatusReplyBubble(String text, String msgId, bool isMine,
      bool isNewSender, String status, DateTime time) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: () {
          Navigator.popUntil(context, (r) => r.isFirst);
        },
        onLongPress: () => widget.onShowMenu?.call(
            context, {'message': '↩️ Durumuna yanıt: $text'}, msgId, isMine, text),
        child: Container(
          margin: EdgeInsets.only(
            top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 60.w : 4.w, right: isMine ? 4.w : 60.w,
          ),
          decoration: BoxDecoration(
            color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(
                color: isMine
                    ? ColorsManager.darkPrimary.withOpacity(0.5)
                    : Colors.white12),
          ),
          child: Column(
            crossAxisAlignment:
                isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: ColorsManager.darkPrimary.withOpacity(0.12),
                  border: Border(
                      left: BorderSide(
                          color: ColorsManager.darkPrimary, width: 3)),
                ),
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 7.h),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('Duruma yanıt',
                          style: TextStyle(
                              color: ColorsManager.darkPrimary,
                              fontSize: 11.sp,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 2),
                      Text(text,
                          style: TextStyle(
                              color: Colors.white70, fontSize: 13.sp),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis),
                    ]),
              ),
              Padding(
                padding:
                    EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(DateFormat('h:mm a').format(time),
                      style: TextStyle(
                          color: Colors.white38, fontSize: 10.sp)),
                  if (isMine) ...[Gap(4.w), _buildStatusTicks(status)],
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLinkBubble(bool isMine, bool isNewSender, String message,
      String status, DateTime time) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 2.h, bottom: isNewSender ? 6.h : 2.h,
            left: isMine ? 40.w : 0, right: isMine ? 0 : 40.w),
        decoration: BoxDecoration(
          color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(
            color: isMine
                ? ColorsManager.darkPrimary.withOpacity(0.4)
                : Colors.white12,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15.r),
          child: Column(
            crossAxisAlignment: isMine
                ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              LinkPreviewWidget(
                message: message,
                onLinkPressed: (link) async {
                  if (!link.startsWith('http')) link = 'https://$link';
                  await launchUrl(Uri.parse(link),
                      mode: LaunchMode.inAppBrowserView);
                },
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(DateFormat('h:mm a').format(time),
                      style: TextStyle(color: Colors.white38, fontSize: 10.sp)),
                  if (isMine) ...[Gap(4.w), _buildStatusTicks(status)],
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Sabitlenmiş Mesaj Banner
// ─────────────────────────────────────────────────────────────────────────────
class _PinnedMessageBanner extends StatelessWidget {
  final String otherUserID;
  const _PinnedMessageBanner({required this.otherUserID});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: DatabaseMethods.getChatRoomStream(otherUserID),
      builder: (ctx, snap) {
        final data = snap.data?.data() as Map<String, dynamic>?;
        final pinned = data?['pinnedMessage'] as Map<String, dynamic>?;
        if (pinned == null) {
          return const SizedBox.shrink();
        }
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: ColorsManager.darkPrimary.withOpacity(0.12),
          child: Row(children: [
            Icon(Icons.push_pin, size: 14, color: ColorsManager.darkPrimary),
            const SizedBox(width: 8),
            Expanded(child: Text(pinned['text'] ?? '',
                style: const TextStyle(color: Colors.white70, fontSize: 12),
                maxLines: 1, overflow: TextOverflow.ellipsis)),
            GestureDetector(
              onTap: () => DatabaseMethods.unpinMessage(otherUserID),
              child: const Icon(Icons.close, size: 16, color: Colors.white38),
            ),
          ]),
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Audio Player
// ─────────────────────────────────────────────────────────────────────────────
class _AudioPlayer extends StatefulWidget {
  final String audioUrl;
  final bool isMine;
  final DateTime time;
  final String status;
  const _AudioPlayer({
    required this.audioUrl, required this.isMine,
    required this.time, required this.status,
  });
  @override State<_AudioPlayer> createState() => _AudioPlayerState();
}

class _AudioPlayerState extends State<_AudioPlayer>
    with SingleTickerProviderStateMixin {
  late final AudioPlayer _player;
  late final AnimationController _waveCtrl;
  // FIX MEMORY: subscription'lar cancel ediliyor
  StreamSubscription? _posSub;
  StreamSubscription? _durSub;
  StreamSubscription? _playSub;
  bool _playing = false;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _waveCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
    _posSub = _player.positionStream.listen(
        (p) { if (mounted) setState(() => _pos = p); });
    _durSub = _player.durationStream.listen(
        (d) { if (mounted && d != null) setState(() => _dur = d); });
    _playSub = _player.playingStream.listen(
        (p) { if (mounted) setState(() => _playing = p); });
    _initAudio();
  }

  Future<void> _initAudio() async {
    try { await _player.setUrl(widget.audioUrl); } catch (_) {}
  }

  String _fmt(Duration d) =>
      '${d.inMinutes.toString().padLeft(2, '0')}:'
      '${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  void dispose() {
    _posSub?.cancel();
    _durSub?.cancel();
    _playSub?.cancel();
    _player.dispose();
    _waveCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      GestureDetector(
        onTap: () async {
          if (_playing) {
            await _player.pause();
          } else {
            if (_pos >= _dur && _dur > Duration.zero) {
              await _player.seek(Duration.zero);
            }
            await _player.play();
          }
        },
        child: Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: ColorsManager.darkPrimary,
            boxShadow: [BoxShadow(
                color: ColorsManager.darkPrimary.withOpacity(0.4), blurRadius: 8)],
          ),
          child: Icon(_playing ? Icons.pause : Icons.play_arrow,
              color: Colors.white, size: 20),
        ),
      ),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        AnimatedBuilder(
          animation: _waveCtrl,
          builder: (_, __) => Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(20, (i) {
              final active = _dur.inMilliseconds > 0 &&
                  (i / 20) < (_pos.inMilliseconds / _dur.inMilliseconds);
              final h = _playing
                  ? (4 + (i % 3) * 6 + _waveCtrl.value * 4).toDouble()
                  : (4 + (i % 4) * 4).toDouble();
              return Container(
                width: 2.5, height: h,
                decoration: BoxDecoration(
                  color: active ? ColorsManager.darkPrimary : Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            }),
          ),
        ),
        const SizedBox(height: 4),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(_fmt(_pos), style: const TextStyle(color: Colors.white38, fontSize: 10)),
          Text(_fmt(_dur), style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ]),
      ])),
      const SizedBox(width: 8),
      Column(mainAxisSize: MainAxisSize.min, children: [
        Text(DateFormat('h:mm a').format(widget.time),
            style: const TextStyle(color: Colors.white38, fontSize: 10)),
        if (widget.isMine)
          SizedBox(width: 18, height: 13,
            child: Stack(children: [
              Positioned(left: 0, child: Icon(Icons.check, size: 13,
                  color: widget.status == 'read'
                      ? ColorsManager.darkPrimary : Colors.white54)),
              Positioned(left: 5, child: Icon(Icons.check, size: 13,
                  color: widget.status == 'read'
                      ? ColorsManager.darkPrimary : Colors.white54)),
            ])),
      ]),
    ]);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Fullscreen Image
// ─────────────────────────────────────────────────────────────────────────────
class _FullscreenImagePage extends StatelessWidget {
  final String url;
  const _FullscreenImagePage({required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: PhotoView(
        imageProvider: NetworkImage(url),
        minScale: PhotoViewComputedScale.contained,
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Media Filter Page
// ─────────────────────────────────────────────────────────────────────────────
class _MediaFilterPage extends StatefulWidget {
  final String chatRoomId, myUID, otherUID, otherName;
  const _MediaFilterPage({
    required this.chatRoomId, required this.myUID,
    required this.otherUID, required this.otherName,
  });
  @override State<_MediaFilterPage> createState() => _MediaFilterPageState();
}

class _MediaFilterPageState extends State<_MediaFilterPage>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  final Set<String> _selectedIds = {};
  bool _selectMode = false;

  @override
  void initState() { super.initState(); _tab = TabController(length: 3, vsync: this); }
  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  bool _isImage(String msg) =>
      (msg.contains('cloudinary') && (msg.contains('asgard_images') ||
          msg.contains('/image/'))) ||
      msg.contains('firebasestorage') ||
      msg.endsWith('.jpg') || msg.endsWith('.png') ||
      msg.endsWith('.jpeg') || msg.endsWith('.webp');

  bool _isAudio(String msg) =>
      msg.contains('.aac') || msg.contains('.mp3') || msg.contains('.m4a') ||
      (msg.contains('cloudinary') && msg.contains('asgard_audio'));



  bool _isLink(String msg) => msg.contains("http://") || msg.contains("https://");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: Text(
          _selectMode ? '${_selectedIds.length} seçildi' : '${widget.otherName} - Medya',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          if (_selectMode) ...[
            IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
              onPressed: _selectedIds.isEmpty ? null : () => _deleteSelected(context),
            ),
            IconButton(
              icon: const Icon(Icons.close, color: Colors.white70),
              onPressed: () => setState(() { _selectMode = false; _selectedIds.clear(); }),
            ),
          ] else
            IconButton(
              icon: const Icon(Icons.checklist_rounded, color: Colors.white70),
              onPressed: () => setState(() => _selectMode = true),
            ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: ColorsManager.darkPrimary,
          labelColor: ColorsManager.darkPrimary,
          unselectedLabelColor: Colors.white38,
          tabs: const [Tab(text: 'Resimler'), Tab(text: 'Sesler'), Tab(text: 'Linkler')],
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('chats').doc(widget.chatRoomId)
            .collection('messages')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(
              color: ColorsManager.darkPrimary));
          final all = snap.data!.docs.where((d) {
            final data = d.data() as Map<String, dynamic>;
            final hidden = List<dynamic>.from(data['hiddenFor'] ?? []);
            return !hidden.contains(widget.myUID) && data['deleted'] != true;
          }).toList();
          final images = all.where((d) => _isImage((d.data() as Map)['message'] ?? '')).toList();
          final audios = all.where((d) => _isAudio((d.data() as Map)['message'] ?? '')).toList();
          final links  = all.where((d) =>
              _isLink((d.data() as Map)['message'] ?? '') &&
              !_isImage((d.data() as Map)['message'] ?? '')).toList();

          return TabBarView(controller: _tab, children: [
            images.isEmpty
                ? const Center(child: Text('Resim yok', style: TextStyle(color: Colors.white38)))
                : GridView.builder(
                    padding: const EdgeInsets.all(4),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3, crossAxisSpacing: 3, mainAxisSpacing: 3),
                    itemCount: images.length,
                    itemBuilder: (_, i) {
                      final doc = images[i];
                      final url = ((doc.data() as Map<String,dynamic>?)?['message'] ?? '') as String;
                      final sel = _selectedIds.contains(doc.id);
                      return GestureDetector(
                        onTap: () {
                          if (_selectMode) {
                            setState(() { if (sel) _selectedIds.remove(doc.id); else _selectedIds.add(doc.id); });
                          } else {
                            Navigator.push(context, MaterialPageRoute(
                                builder: (_) => _FullscreenImagePage(url: url)));
                          }
                        },
                        onLongPress: () => setState(() { _selectMode = true; _selectedIds.add(doc.id); }),
                        child: Stack(fit: StackFit.expand, children: [
                          CachedNetworkImage(imageUrl: url, fit: BoxFit.cover,
                              memCacheWidth: 300, memCacheHeight: 300,
                              placeholder: (_, __) => Container(color: const Color(0xFF1A1A1A)),
                              errorWidget: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white24)),
                          if (sel)
                            Container(
                              color: ColorsManager.darkPrimary.withOpacity(0.5),
                              child: const Center(child: Icon(Icons.check_circle_rounded,
                                  color: Colors.white, size: 30)),
                            ),
                        ]),
                      );
                    }),
            audios.isEmpty
                ? const Center(child: Text('Ses yok', style: TextStyle(color: Colors.white38)))
                : ListView.builder(
                    itemCount: audios.length,
                    itemBuilder: (_, i) {
                      final doc = audios[i];
                      final data = doc.data() as Map<String, dynamic>;
                      final ts = data['timestamp'] as Timestamp?;
                      final time = ts?.toDate() ?? DateTime.now();
                      return ListTile(
                        leading: Container(width: 42, height: 42,
                            decoration: const BoxDecoration(shape: BoxShape.circle,
                                color: Color(0x22E53935)),
                            child: const Icon(Icons.mic, color: Colors.white, size: 20)),
                        title: const Text('Sesli Mesaj', style: TextStyle(color: Colors.white)),
                        subtitle: Text(DateFormat('d MMM, h:mm a').format(time),
                            style: const TextStyle(color: Colors.white38, fontSize: 11)),
                      );
                    }),
            links.isEmpty
                ? const Center(child: Text('Link yok', style: TextStyle(color: Colors.white38)))
                : ListView.builder(
                    itemCount: links.length,
                    itemBuilder: (_, i) {
                      final doc = links[i];
                      final data = doc.data() as Map<String, dynamic>;
                      final msg = (data['message'] ?? '').toString();
                      return ListTile(
                        leading: const Icon(Icons.link, color: Colors.lightBlue),
                        title: Text(msg, style: const TextStyle(color: Colors.lightBlue, fontSize: 13),
                            maxLines: 2, overflow: TextOverflow.ellipsis),
                        onTap: () async {
                          var url = msg;
                          if (!url.startsWith('http')) url = 'https://$url';
                          await launchUrl(Uri.parse(url), mode: LaunchMode.inAppBrowserView);
                        },
                      );
                    }),
          ]);
        },
      ),
    );
  }

  void _deleteSelected(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Text('${_selectedIds.length} Medyayı Sil',
            style: const TextStyle(color: Colors.white)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              for (final id in _selectedIds) {
                await DatabaseMethods.deleteMessageForMe(id, widget.otherUID);
              }
              if (!mounted) return;
              if (mounted) setState(() { _selectMode = false; _selectedIds.clear(); });
            },
            child: const Text('Benden Sil', style: TextStyle(color: Colors.orange)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              for (final id in _selectedIds) {
                await DatabaseMethods.deleteMessageForEveryone(id, widget.otherUID);
              }
              if (!mounted) return;
              if (mounted) setState(() { _selectMode = false; _selectedIds.clear(); });
            },
            child: const Text('Herkesten Sil', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
