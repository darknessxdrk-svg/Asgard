import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../../core/utils/font_size_provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import '../../../services/database.dart';
import 'group_settings_screen.dart';
import '../../../themes/colors.dart';
import 'widgets/message_bar.dart';

class GroupChatPage extends StatefulWidget {
  final String groupId;
  final String groupName;
  const GroupChatPage({super.key, required this.groupId, required this.groupName});
  @override
  State<GroupChatPage> createState() => _GroupChatPageState();
}

class _GroupChatPageState extends State<GroupChatPage> {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;
  final _scrollCtrl = ScrollController();
  bool _aiTyping = false;
  // FIX: stream initState'de bir kez yaratılır
  late final Stream<QuerySnapshot> _messagesStream;
  // FIX STATE: grup mesaj rate limit
  DateTime? _lastMsgSent;
  static const _msgRateLimit = Duration(milliseconds: 500);
  // ✅ FIX: Kullanıcının en altta olup olmadığını takip et
  bool _isAtBottom = true;
  int _prevMsgCount = 0;

  bool _shouldAutoScroll() {
    if (!_scrollCtrl.hasClients) return false;
    final pos = _scrollCtrl.position;
    // Son 150px içindeyse "altta sayılır"
    return (pos.maxScrollExtent - pos.pixels) < 150;
  }

  void _scrollToBottom({bool animated = true}) {
    if (!_scrollCtrl.hasClients) return;
    if (animated) {
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    } else {
      _scrollCtrl.jumpTo(_scrollCtrl.position.maxScrollExtent);
    }
  }

  // /ai komutu işle
  Future<void> _handleMessage(String msg) async {
    if (msg.toLowerCase().startsWith('@ai ')) {
      final question = msg.substring(4).trim();
      if (question.isEmpty) return;
      // Önce kullanıcının mesajını gönder
      await DatabaseMethods.sendGroupMessage(widget.groupId, msg);
      // AI yazıyor göstergesi
      if (mounted) setState(() => _aiTyping = true);
      try {
        const geminiKey = String.fromEnvironment('GEMINI_API_KEY');
        if (geminiKey.isEmpty) {
          await DatabaseMethods.sendGroupMessageAsAI(widget.groupId, '⚠️ Gemini API anahtarı eksik. GitHub Secrets > GEMINI_API_KEY ekleyin.');
          if (mounted) setState(() => _aiTyping = false);
          return;
        }
        final response = await http.post(
          Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$geminiKey'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'system_instruction': {'parts': [{'text': 'Sen Asgard grup sohbeti AI asistanisin. Turkce, kisa cevap ver.'}]}, 'contents': [{'role': 'user', 'parts': [{'text': question}]}], 'generationConfig': {'maxOutputTokens': 600}}),
        );
        final data = jsonDecode(response.body);
        if (response.statusCode != 200) {
          final code = data['error']?['code'] ?? response.statusCode;
          final String msg;
          if (code == 429) msg = '⚠️ AI kota doldu. Biraz bekleyip tekrar deneyin.';
          else if (code == 403) msg = '⚠️ AI erişim reddedildi. API key geçersiz.';
          else msg = '⚠️ AI şu an yanıt veremiyor (kod: $code). Tekrar deneyin.';
          await DatabaseMethods.sendGroupMessageAsAI(widget.groupId, msg);
          return;
        }
        final reply = data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? 'Yanıt alınamadı';
        await DatabaseMethods.sendGroupMessageAsAI(widget.groupId, reply);
      } catch (e) {
        await DatabaseMethods.sendGroupMessageAsAI(widget.groupId, '⚠️ Bağlantı hatası. İnternet bağlantını kontrol et.');
      } finally {
        if (mounted) setState(() => _aiTyping = false);
      }
    } else {
      await DatabaseMethods.sendGroupMessage(widget.groupId, msg);
    }
  }

  @override
  void initState() {
    super.initState();
    FontSizeProvider.instance.addListener(_onFontSizeChanged);
    _messagesStream = DatabaseMethods.getGroupMessages(widget.groupId);
  }

  void _onFontSizeChanged() { if (mounted) setState(() {}); }

  @override
  void dispose() {
    FontSizeProvider.instance.removeListener(_onFontSizeChanged);
    _scrollCtrl.dispose(); // FIX MEMORY: ScrollController leak fix
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: _db.collection('groups').doc(widget.groupId).snapshots(),
      builder: (ctx, groupSnap) {
        final groupData = groupSnap.data?.data() as Map<String, dynamic>?;
        final groupPhoto = groupData?['photo'] ?? '';
        final groupName = groupData?['name'] ?? widget.groupName;
        final members = (groupData?['members'] as List? ?? []);

        return Scaffold(
          backgroundColor: const Color(0xFF0D0D0D),
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(65.h),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF111111),
                border: Border(
                    bottom: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.2))),
              ),
              child: SafeArea(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4.w),
                  child: Row(children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back_ios, color: Colors.white70),
                      onPressed: () => Navigator.pop(context),
                    ),
                    // Tıklanabilir grup profili
                    GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => GroupSettingsScreen(groupId: widget.groupId),
                        ),
                      ),
                      child: Row(children: [
                        // Grup fotoğrafı
                        Container(
                          width: 40.w,
                          height: 40.h,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: ColorsManager.darkPrimary.withOpacity(0.2),
                            border: Border.all(color: ColorsManager.darkPrimary, width: 2),
                          ),
                          child: ClipOval(
                            child: groupPhoto.isNotEmpty
                                ? CachedNetworkImage(
                                    imageUrl: groupPhoto,
                                    fit: BoxFit.cover,
                                    errorWidget: (_, __, ___) => const Icon(
                                        Icons.group,
                                        color: ColorsManager.darkPrimary,
                                        size: 20),
                                  )
                                : const Icon(Icons.group,
                                    color: ColorsManager.darkPrimary, size: 20),
                          ),
                        ),
                        SizedBox(width: 10.w),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(widget.groupName,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16)),
                            if (_aiTyping)
                              Row(children: [
                                SizedBox(
                                  width: 12,
                                  height: 12,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                      color: ColorsManager.darkPrimary),
                                ),
                                const SizedBox(width: 5),
                                Text('AI yazıyor...',
                                    style: TextStyle(
                                        color: ColorsManager.darkPrimary,
                                        fontSize: 11.sp,
                                        fontStyle: FontStyle.italic)),
                              ])
                            else
                              Text('${members.length} üye • profil için dokun',
                                  style: TextStyle(color: Colors.white38, fontSize: 11.sp)),
                          ],
                        ),
                      ]),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.more_vert, color: Colors.white70),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => GroupSettingsScreen(groupId: widget.groupId),
                        ),
                      ),
                    ),
                  ]),
                ),
              ),
            ),
          ),
          body: Stack(children: [
            Positioned.fill(
              child: Opacity(
                opacity: 0.04,
                child: Image.asset('assets/images/chat_backgrond.png',
                    fit: BoxFit.cover),
              ),
            ),
            Column(children: [
              // /ai komut ipucu
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                color: ColorsManager.darkPrimary.withOpacity(0.08),
                child: Row(children: [
                  Icon(Icons.auto_awesome, color: ColorsManager.darkPrimary, size: 13),
                  const SizedBox(width: 6),
                  Text('@ai [soru] yazarak AI\'yı sohbete dahil edebilirsin',
                      style: TextStyle(
                          color: Colors.white38,
                          fontSize: 11.sp,
                          fontStyle: FontStyle.italic)),
                ]),
              ),
              Expanded(child: _buildMessages()),
              CustomMessageBar(
                onSend: _handleMessage,
                onShowOptions: () {},
                onSendAudio: (url) => DatabaseMethods.sendGroupMessage(widget.groupId, url),
              ),
            ]),
          ]),
        );
      },
    );
  }

  void _showSeenBy(BuildContext context, List<String> seenBy) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                  color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.done_all_rounded, color: Colors.blue, size: 18),
            const SizedBox(width: 6),
            Text('${seenBy.length} kişi gördü',
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16)),
          ]),
          const SizedBox(height: 8),
          if (seenBy.isEmpty)
            const Padding(
                padding: EdgeInsets.all(24),
                child: Text('Henüz kimse görmedi',
                    style: TextStyle(color: Colors.white38)))
          else
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 300),
              child: ListView(
                shrinkWrap: true,
                children: seenBy
                    .map((uid) => FutureBuilder<DocumentSnapshot>(
                          future: FirebaseFirestore.instance
                              .collection('users')
                              .doc(uid)
                              .get(),
                          builder: (_, snap) {
                            final d = snap.data?.data() as Map<String, dynamic>?;
                            final name = d?['name'] ?? 'Kullanıcı';
                            final photo = d?['profilePic'] ?? '';
                            return ListTile(
                              leading: CircleAvatar(
                                  radius: 20,
                                  backgroundImage: photo.isNotEmpty
                                      ? NetworkImage(photo)
                                      : null,
                                  backgroundColor: const Color(0xFF2A2A2A),
                                  child: photo.isEmpty
                                      ? const Icon(Icons.person,
                                          color: Colors.white38, size: 20)
                                      : null),
                              title: Text(name,
                                  style: const TextStyle(color: Colors.white)),
                              trailing: const Icon(Icons.done_all_rounded,
                                  color: Colors.blue, size: 16),
                            );
                          },
                        ))
                    .toList(),
              ),
            ),
          const SizedBox(height: 16),
        ]),
      ),
    );
  }

  Widget _buildMessages() {
    return StreamBuilder<QuerySnapshot>(
      stream: _messagesStream,
      builder: (ctx, snap) {
        if (!snap.hasData) {
          return const Center(
              child: CircularProgressIndicator(
                  color: ColorsManager.darkPrimary));
        }
        final msgs = snap.data!.docs;
        if (msgs.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.group_rounded,
                    color: Colors.white12, size: 64),
                const SizedBox(height: 12),
                const Text('Henüz mesaj yok',
                    style: TextStyle(color: Colors.white24)),
                const SizedBox(height: 6),
                Text('@ai [soru] ile AI\'yı dahil et',
                    style: TextStyle(
                        color: ColorsManager.darkPrimary.withOpacity(0.5),
                        fontSize: 12)),
              ],
            ),
          );
        }
        WidgetsBinding.instance.addPostFrameCallback((_) {
          // ✅ FIX: Sadece yeni mesaj geldi VE kullanıcı alttaysa scroll et
          final newCount = msgs.length;
          final isNewMsg = newCount > _prevMsgCount;
          _prevMsgCount = newCount;
          if (isNewMsg && (_isAtBottom || _shouldAutoScroll())) {
            _scrollToBottom();
          }
        });
        return ListView.builder(
          controller: _scrollCtrl,
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
          itemCount: msgs.length,
          itemBuilder: (ctx, i) {
            final doc = msgs[i];
            final data = doc.data() as Map<String, dynamic>;
            final isMine = data['senderID'] == _auth.currentUser?.uid;
            final isAI = data['senderID'] == 'AI_BOT';
            final msg = data['message'] ?? '';
            final time = (data['timestamp'] as Timestamp?)?.toDate() ?? DateTime.now();
            final senderName = data['senderName'] ?? '';
            final seenBy = List<String>.from(data['seenBy'] ?? []);

            if (!isMine && !isAI && !seenBy.contains(_auth.currentUser?.uid)) {
              DatabaseMethods.markGroupMessageSeen(widget.groupId, doc.id);
            }

            // AI mesajı özel görünüm
            if (isAI) {
              return _buildAIBubble(msg, time);
            }

            return GestureDetector(
              onLongPress: () => _showSeenBy(context, seenBy),
              child: Align(
                alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: EdgeInsets.only(
                      top: 2.h,
                      bottom: 4.h,
                      left: isMine ? 60.w : 0,
                      right: isMine ? 0 : 60.w),
                  padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                  decoration: BoxDecoration(
                    color: isMine
                        ? const Color(0xFF1A0A0A)
                        : const Color(0xFF111111),
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(
                        color: isMine
                            ? ColorsManager.darkPrimary.withOpacity(0.4)
                            : Colors.white10),
                  ),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (!isMine)
                          Text(senderName,
                              style: TextStyle(
                                  color: ColorsManager.darkPrimary,
                                  fontSize: 11.sp,
                                  fontWeight: FontWeight.bold)),
                        // /ai komutu ise farklı renkle göster
                        if (msg.toLowerCase().startsWith('@ai '))
                          RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                text: '@ai ',
                                style: TextStyle(
                                    color: ColorsManager.darkPrimary,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15),
                              ),
                              TextSpan(
                                text: msg.substring(4),
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 15),
                              ),
                            ]),
                          )
                        else
                          Text(msg,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 15)),
                        SizedBox(height: 4.h),
                        Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(DateFormat('h:mm a').format(time),
                                  style: TextStyle(
                                      color: Colors.white38,
                                      fontSize: 10.sp)),
                              if (isMine) ...[
                                const SizedBox(width: 4),
                                Icon(
                                  seenBy.length > 1
                                      ? Icons.done_all_rounded
                                      : Icons.done_rounded,
                                  size: 13,
                                  color: seenBy.length > 1
                                      ? Colors.blue
                                      : Colors.white38,
                                ),
                                if (seenBy.length > 1) ...[
                                  const SizedBox(width: 2),
                                  Text('${seenBy.length - 1}',
                                      style: const TextStyle(
                                          color: Colors.blue, fontSize: 10)),
                                ],
                              ],
                            ]),
                      ]),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAIBubble(String msg, DateTime time) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(top: 4.h, bottom: 4.h, right: 40.w),
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFF1A0030),
              const Color(0xFF0D001A),
            ],
          ),
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(color: Colors.purple.withOpacity(0.4)),
          boxShadow: [
            BoxShadow(
                color: Colors.purple.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 2)),
          ],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: Colors.purple.withOpacity(0.2),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Icon(Icons.auto_awesome, color: Colors.purple, size: 12),
            ),
            const SizedBox(width: 6),
            const Text('Asgard AI',
                style: TextStyle(
                    color: Colors.purple,
                    fontSize: 11,
                    fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 6),
          Text(msg.startsWith('🤖 ') ? msg.substring(3) : msg,
              style: TextStyle(color: Colors.white, fontSize: FontSizeProvider.instance.messageFontSize, height: 1.4)),
          const SizedBox(height: 4),
          Text(DateFormat('h:mm a').format(time),
              style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ]),
      ),
    );
  }
}
