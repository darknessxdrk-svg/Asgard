import 'package:flutter/material.dart';

class AudioMessageBubble extends StatelessWidget {
  final String audioUrl;
  final bool isMine;
  final String time;
  final String status;

  const AudioMessageBubble({
    super.key,
    required this.audioUrl,
    required this.isMine,
    required this.time,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: isMine ? const Color(0xFF1A0A0A) : const Color(0xFF111111),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isMine ? Colors.red.withOpacity(0.4) : Colors.white12,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.mic, color: isMine ? Colors.red : Colors.white54, size: 20),
          const SizedBox(width: 8),
          const Text('Ses mesajı', style: TextStyle(color: Colors.white70)),
          const SizedBox(width: 8),
          Text(time, style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ],
      ),
    );
  }
}
