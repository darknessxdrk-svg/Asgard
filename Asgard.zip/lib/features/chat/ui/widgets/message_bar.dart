import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/services.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import '../../../../services/cloudinary_service.dart';
import 'package:flutter/foundation.dart' as foundation;
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:gap/gap.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../../themes/colors.dart';
import '../image_editor_screen.dart';

class CustomMessageBar extends StatefulWidget {
  final Function(String) onSend;
  final VoidCallback onShowOptions;
  final Function(String audioUrl) onSendAudio;
  final VoidCallback? onTyping;
  final Function(String imageUrl)? onSendImage;
  final Function(String fileUrl, String fileName)? onSendFile;
  final Function(double lat, double lng)? onSendLocation;
  final Function(String question, List<String> options)? onSendPoll;

  const CustomMessageBar({
    super.key,
    required this.onSend,
    required this.onShowOptions,
    required this.onSendAudio,
    this.onTyping,
    this.onSendImage,
    this.onSendFile,
    this.onSendLocation,
    this.onSendPoll,
  });

  @override
  State<CustomMessageBar> createState() => _CustomMessageBarState();
}

class _CustomMessageBarState extends State<CustomMessageBar> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();
  bool _showEmoji = false;
  bool _hasText = false;
  bool _isUploading = false;

  final _recorder = FlutterSoundRecorder();
  bool _isRecording = false;
  bool _recorderReady = false;
  Duration _recordDuration = Duration.zero;
  Timer? _recordTimer;
  String? _recordPath;

  @override
  void initState() {
    super.initState();
    _controller.addListener(() {
      setState(() => _hasText = _controller.text.trim().isNotEmpty);
    });
    _initRecorder();
  }

  Future<void> _initRecorder() async {
    final status = await Permission.microphone.request();
    if (status.isGranted) {
      await _recorder.openRecorder();
      if (mounted) setState(() => _recorderReady = true);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    _recorder.closeRecorder();
    _recordTimer?.cancel();
    super.dispose();
  }

  void _toggleEmoji() {
    if (_showEmoji) _focusNode.requestFocus();
    else _focusNode.unfocus();
    setState(() => _showEmoji = !_showEmoji);
  }

  Future<void> _startRecording() async {
    if (!_recorderReady || _isRecording) return;
    final dir = await getTemporaryDirectory();
    _recordPath = '${dir.path}/audio_${DateTime.now().millisecondsSinceEpoch}.aac';
    await _recorder.startRecorder(toFile: _recordPath, codec: Codec.aacADTS);
    if (!mounted) return;
    if (mounted) setState(() { _isRecording = true; _recordDuration = Duration.zero; });
    _recordTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _recordDuration += const Duration(seconds: 1));
    });
  }

  Future<void> _stopAndSendRecording() async {
    if (!_isRecording) return;
    _recordTimer?.cancel();
    await _recorder.stopRecorder();
    if (!mounted) return;
    if (mounted) setState(() { _isRecording = false; _isUploading = true; });
    if (_recordPath != null) await _uploadAndSendAudio(_recordPath!);
    if (mounted) setState(() => _isUploading = false);
  }

  Future<void> _cancelRecording() async {
    if (!_isRecording) return;
    _recordTimer?.cancel();
    await _recorder.stopRecorder();
    if (mounted) setState(() { _isRecording = false; _recordDuration = Duration.zero; });
  }

  Future<void> _uploadAndSendAudio(String path) async {
    try {
      final url = await CloudinaryService.uploadAudio(path);
      if (url != null) widget.onSendAudio(url);
    } catch (e) {
      debugPrint('Audio upload error: $e');
    }
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  bool _isSending = false;
  void _send() {
    if (_isSending) return; // double-send koruması
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _isSending = true;
    widget.onSend(text);
    _controller.clear();
    setState(() { _hasText = false; _isSending = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // İnce üst çizgi
        Container(height: 1, color: Colors.white.withOpacity(0.06)),
        if (_isRecording) _buildRecordingBar() else _buildInputBar(),
        if (_showEmoji && !_isRecording) _buildEmojiPicker(),
      ],
    );
  }

  Widget _buildRecordingBar() {
    return Container(
      color: const Color(0xFF0D0D0D),
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
      child: Row(
        children: [
          GestureDetector(
            onTap: _cancelRecording,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: const BoxDecoration(
                color: Color(0xFF2A0A0A),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
            ),
          ),
          Gap(10.w),
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 10.h),
              decoration: BoxDecoration(
                color: const Color(0xFF111111),
                borderRadius: BorderRadius.circular(24.r),
              ),
              child: Row(
                children: [
                  _PulsingDot(),
                  Gap(8.w),
                  Text(_formatDuration(_recordDuration),
                      style: TextStyle(color: Colors.white, fontSize: 15.sp, fontWeight: FontWeight.w600)),
                  Gap(6.w),
                  Text('Kayıt yapılıyor...', style: TextStyle(color: Colors.white38, fontSize: 12.sp)),
                ],
              ),
            ),
          ),
          Gap(10.w),
          GestureDetector(
            onTap: _stopAndSendRecording,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: ColorsManager.darkPrimary,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.5), blurRadius: 12)],
              ),
              child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      color: const Color(0xFF0D0D0D),
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Emoji
          GestureDetector(
            onTap: _toggleEmoji,
            child: Padding(
              padding: EdgeInsets.only(bottom: 10.h, left: 4.w, right: 2.w),
              child: Icon(
                _showEmoji ? Icons.keyboard_rounded : Icons.emoji_emotions_outlined,
                color: ColorsManager.darkPrimary,
                size: 26,
              ),
            ),
          ),
          // Text field - sadece yuvarlak köşeli input, wrapper yok
          Expanded(
            child: Container(
              constraints: BoxConstraints(maxHeight: 120.h),
              decoration: BoxDecoration(
                color: const Color(0xFF1C1C1C),
                borderRadius: BorderRadius.circular(24.r),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      focusNode: _focusNode,
                      maxLines: 5,
                      minLines: 1,
                      style: TextStyle(color: Colors.white, fontSize: 15.sp),
                      decoration: InputDecoration(
                        hintText: 'Mesaj',
                        hintStyle: TextStyle(color: Colors.white30, fontSize: 15.sp),
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        filled: false,
                        isDense: true,
                        contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
                      ),
                      onTap: () { if (_showEmoji) setState(() => _showEmoji = false); },
                    ),
                  ),
                  // Ataç butonu
                  GestureDetector(
                    onTap: _showAttachMenu,
                    child: Padding(
                      padding: EdgeInsets.only(right: 10.w, bottom: 10.h),
                      child: const Icon(Icons.attach_file_rounded, color: Colors.white38, size: 22),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Gap(8.w),
          // Send / Mic
          GestureDetector(
            onTap: _hasText ? _send : null,
            onLongPress: !_hasText ? _startRecording : _showScheduleDialog,
            child: _isUploading
                ? Container(
                    width: 44.w, height: 44.h,
                    decoration: BoxDecoration(color: ColorsManager.darkPrimary, shape: BoxShape.circle),
                    child: const Padding(padding: EdgeInsets.all(10),
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                  )
                : Container(
                    width: 44.w, height: 44.h,
                    decoration: BoxDecoration(
                      color: _hasText ? ColorsManager.darkPrimary : const Color(0xFF2A2A2A),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      _hasText ? Icons.send_rounded : Icons.mic_rounded,
                      color: Colors.white, size: 20,
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  void _showScheduleDialog() {
    DateTime? selectedTime;
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSt) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Row(children: [
          const Icon(Icons.schedule_send_rounded, color: Colors.purple, size: 20),
          const SizedBox(width: 8),
          const Text('Zamanla', style: TextStyle(color: Colors.white, fontSize: 16)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(_controller.text.isEmpty ? '(Önce mesaj yaz)' : '"${_controller.text}"',
              style: TextStyle(color: _controller.text.isEmpty ? Colors.red.shade300 : Colors.white70, fontSize: 13),
              maxLines: 2, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () async {
              final now = DateTime.now();
              final date = await showDatePicker(
                  context: ctx,
                  initialDate: now.add(const Duration(hours: 1)),
                  firstDate: now, lastDate: now.add(const Duration(days: 30)),
                  builder: (c, child) => Theme(data: ThemeData.dark(), child: child!));
              if (date == null) return;
              final time = await showTimePicker(context: ctx, initialTime: TimeOfDay.now(),
                  builder: (c, child) => Theme(data: ThemeData.dark(), child: child!));
              if (time == null) return;
              setSt(() => selectedTime = DateTime(date.year, date.month, date.day, time.hour, time.minute));
            },
            child: Container(
              width: double.infinity, padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.purple.withOpacity(0.1), borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.purple.withOpacity(selectedTime != null ? 0.6 : 0.2))),
              child: Row(children: [
                const Icon(Icons.calendar_today_rounded, color: Colors.purple, size: 18),
                const SizedBox(width: 10),
                Text(selectedTime != null
                    ? '${selectedTime!.day}/${selectedTime!.month}/${selectedTime!.year} ${selectedTime!.hour}:${selectedTime!.minute.toString().padLeft(2, "0")}'
                    : 'Tarih ve saat seç',
                    style: TextStyle(color: selectedTime != null ? Colors.white : Colors.white38)),
              ]),
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: selectedTime == null || _controller.text.isEmpty ? null : () async {
              final msg = _controller.text.trim();
              final delay = selectedTime!.difference(DateTime.now());
              Navigator.pop(ctx);
              _controller.clear();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text("⏰ Mesaj ${selectedTime!.hour}:${selectedTime!.minute.toString().padLeft(2, '0')}'de gönderilecek"),
                backgroundColor: Colors.purple,
                duration: const Duration(seconds: 3),
              ));
              Future.delayed(delay, () { if (mounted) widget.onSend(msg); });
            },
            child: Text('Zamanla', style: TextStyle(
                color: selectedTime != null && _controller.text.isNotEmpty ? Colors.purple : Colors.white24,
                fontWeight: FontWeight.bold)),
          ),
        ],
      )),
    );
  }

  void _showAttachMenu() {
    final mainContext = context; // State context - bottom sheet kapansa da geçerli
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          // Grid menü
          GridView.count(
            shrinkWrap: true, crossAxisCount: 4,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              _attachItem(Icons.photo_library_rounded, Colors.purple, 'Galeri', () async {
                Navigator.pop(context);
                XFile? picked;
                try {
                  picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
                } on PlatformException catch (e) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Galeri erişim izni gerekli'), backgroundColor: Colors.red));
                  return;
                }
                if (picked == null || picked.path.isEmpty) return;
                // mainContext - State'in context'i, bottom sheet kapansa da geçerli
                final editedFile = await ImageEditorScreen.editFile(mainContext, File(picked.path));
                final finalPath = editedFile?.path ?? picked.path;
                if (!mounted) return;
                if (mounted) setState(() => _isUploading = true);
                final url = await CloudinaryService.uploadImage(finalPath);
                if (url != null) widget.onSendImage?.call(url);
                if (mounted) setState(() => _isUploading = false);
              }),
              _attachItem(Icons.camera_alt_rounded, Colors.red, 'Kamera', () async {
                Navigator.pop(context);
                XFile? picked;
                try {
                  picked = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 85);
                } on PlatformException catch (e) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Kamera erişim izni gerekli'), backgroundColor: Colors.red));
                  return;
                }
                if (picked == null || picked.path.isEmpty) return;
                final editedFile = await ImageEditorScreen.editFile(mainContext, File(picked.path));
                final finalPath = editedFile?.path ?? picked.path;
                if (!mounted) return;
                if (mounted) setState(() => _isUploading = true);
                final url = await CloudinaryService.uploadImage(finalPath);
                if (url != null) widget.onSendImage?.call(url);
                if (mounted) setState(() => _isUploading = false);
              }),
              _attachItem(Icons.insert_drive_file_rounded, Colors.blue, 'Dosya', () async {
                Navigator.pop(context);
                final result = await FilePicker.platform.pickFiles();
                if (result == null || result.files.isEmpty) return;
                final file = result.files.first;
                if (file.path == null) return;
                if (mounted) setState(() => _isUploading = true);
                final url = await CloudinaryService.uploadImage(file.path!);
                if (url != null) widget.onSendFile?.call(url, file.name);
                if (mounted) setState(() => _isUploading = false);
              }),
              _attachItem(Icons.location_on_rounded, Colors.green, 'Konum', () {
                Navigator.pop(context);
                _showLocationPicker();
              }),
              _attachItem(Icons.poll_rounded, Colors.orange, 'Anket', () {
                Navigator.pop(context);
                _showPollCreator();
              }),
            ],
          ),
        ]),
      )),
    );
  }

  Widget _attachItem(IconData icon, Color color, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 52, height: 52,
            decoration: BoxDecoration(color: color.withOpacity(0.15), shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(0.3))),
            child: Icon(icon, color: color, size: 26)),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ]),
    );
  }

  void _showLocationPicker() {
    // Manuel konum girişi (GPS için geolocator paketi gerekir)
    final latCtrl = TextEditingController(text: '41.0082');
    final lngCtrl = TextEditingController(text: '28.9784');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Row(children: [
          Icon(Icons.location_on, color: Colors.green, size: 20),
          const SizedBox(width: 8),
          const Text('Konum Paylaş', style: TextStyle(color: Colors.white, fontSize: 16)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.green.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              const Icon(Icons.info_outline, color: Colors.green, size: 16),
              const SizedBox(width: 8),
              const Expanded(child: Text('Konumunuz karşı tarafa gönderilecek', style: TextStyle(color: Colors.white54, fontSize: 12))),
            ]),
          ),
          const SizedBox(height: 12),
          TextField(controller: latCtrl, style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(labelText: 'Enlem', labelStyle: const TextStyle(color: Colors.white38),
                  enabledBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.white12), borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.green), borderRadius: BorderRadius.circular(8)))),
          const SizedBox(height: 8),
          TextField(controller: lngCtrl, style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(labelText: 'Boylam', labelStyle: const TextStyle(color: Colors.white38),
                  enabledBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.white12), borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.green), borderRadius: BorderRadius.circular(8)))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () {
              final lat = double.tryParse(latCtrl.text) ?? 41.0082;
              final lng = double.tryParse(lngCtrl.text) ?? 28.9784;
              Navigator.pop(ctx);
              widget.onSendLocation?.call(lat, lng);
            },
            child: Text('Gönder', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showPollCreator() {
    final questionCtrl = TextEditingController();
    final option1Ctrl = TextEditingController(text: 'Seçenek 1');
    final option2Ctrl = TextEditingController(text: 'Seçenek 2');
    final option3Ctrl = TextEditingController();
    final option4Ctrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Row(children: [
          Icon(Icons.poll_rounded, color: Colors.orange, size: 20),
          const SizedBox(width: 8),
          const Text('Anket Oluştur', style: TextStyle(color: Colors.white, fontSize: 16)),
        ]),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          _pollField(questionCtrl, 'Soru yaz...', true),
          const SizedBox(height: 12),
          const Text('Seçenekler', style: TextStyle(color: Colors.white38, fontSize: 12)),
          const SizedBox(height: 6),
          _pollField(option1Ctrl, 'Seçenek 1', false),
          const SizedBox(height: 6),
          _pollField(option2Ctrl, 'Seçenek 2', false),
          const SizedBox(height: 6),
          _pollField(option3Ctrl, 'Seçenek 3 (isteğe bağlı)', false),
          const SizedBox(height: 6),
          _pollField(option4Ctrl, 'Seçenek 4 (isteğe bağlı)', false),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () {
              if (questionCtrl.text.trim().isEmpty) return;
              final options = [option1Ctrl.text, option2Ctrl.text, option3Ctrl.text, option4Ctrl.text]
                  .where((s) => s.trim().isNotEmpty).toList();
              if (options.length < 2) return;
              Navigator.pop(ctx);
              widget.onSendPoll?.call(questionCtrl.text.trim(), options);
            },
            child: Text('Oluştur', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _pollField(TextEditingController ctrl, String hint, bool isQuestion) {
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white24),
        filled: true, fillColor: const Color(0xFF252525),
        border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(8)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      ),
      maxLines: isQuestion ? 2 : 1,
    );
  }

  Widget _buildEmojiPicker() {
    final h = MediaQuery.of(context).size.height * 0.35;
    return SizedBox(
      height: (h).clamp(220.0, 320.0).toDouble(),
      child: EmojiPicker(
        textEditingController: _controller,
        config: Config(
          height: (h).clamp(220.0, 320.0).toDouble(),
          emojiViewConfig: EmojiViewConfig(
            backgroundColor: const Color(0xFF0D0D0D),
            emojiSizeMax: 32 * (foundation.defaultTargetPlatform == TargetPlatform.iOS ? 1.20 : 1.0),
            gridPadding: EdgeInsets.zero,
            recentsLimit: 28,
            noRecents: const Text('Henüz emoji yok', style: TextStyle(color: Colors.white38, fontSize: 20)),
            loadingIndicator: const SizedBox.shrink(),
          ),
          skinToneConfig: const SkinToneConfig(
            enabled: true,
            dialogBackgroundColor: Color(0xFF1A1A1A),
            indicatorColor: ColorsManager.darkPrimary,
          ),
          categoryViewConfig: const CategoryViewConfig(
            backgroundColor: Color(0xFF0D0D0D),
            iconColor: Colors.white24,
            iconColorSelected: ColorsManager.darkPrimary,
            indicatorColor: ColorsManager.darkPrimary,
            initCategory: Category.RECENT,
          ),
          bottomActionBarConfig: const BottomActionBarConfig(
            backgroundColor: Color(0xFF111111),
            buttonColor: Color(0xFF111111),
            buttonIconColor: Colors.white54,
          ),
          searchViewConfig: const SearchViewConfig(
            backgroundColor: Color(0xFF111111),
            buttonIconColor: Colors.white54,
          ),
        ),
      ),
    );
  }
}

class _PulsingDot extends StatefulWidget {
  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot> with SingleTickerProviderStateMixin {
  late AnimationController _anim;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..repeat(reverse: true);
  }

  @override
  void dispose() { _anim.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _anim,
      child: Container(
        width: 10, height: 10,
        decoration: BoxDecoration(
          color: Colors.red, shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.6), blurRadius: 6)],
        ),
      ),
    );
  }
}
