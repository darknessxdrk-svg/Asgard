import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:http/http.dart' as http;

import '../../../themes/colors.dart';

class AIAssistantScreen extends StatefulWidget {
  final String? prefilledText; // Sohbetten metin gönder
  const AIAssistantScreen({super.key, this.prefilledText});
  @override State<AIAssistantScreen> createState() => _AIAssistantScreenState();
}

class _AIAssistantScreenState extends State<AIAssistantScreen> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final List<_AiMsg> _messages = [];
  bool _loading = false;

  // Öneriler
  final _suggestions = [
    '✍️ Bu metni düzenle',
    '🌐 İngilizceye çevir',
    '📝 Kısa özet yaz',
    '💡 Fikir öner',
    '😊 Daha samimi yap',
    '🎯 Yanıt yaz',
  ];

  @override
  void initState() {
    super.initState();
    _messages.add(_AiMsg(role: 'assistant',
        content: 'Merhaba! 👋 Asgard AI asistanıyım. Mesaj yazmanıza, çeviriye, özetlemeye veya fikir üretmeye yardım edebilirim.'));
    if (widget.prefilledText != null) {
      _ctrl.text = widget.prefilledText!;
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send([String? text]) async {
    final msg = (text ?? _ctrl.text).trim();
    if (msg.isEmpty || _loading) return;
    _ctrl.clear();
    setState(() {
      _messages.add(_AiMsg(role: 'user', content: msg));
      _loading = true;
    });
    _scrollToBottom();

    try {
      const geminiKey = String.fromEnvironment('GEMINI_API_KEY');
      if (geminiKey.isEmpty) {
        setState(() {
          _messages.add(_AiMsg(role: 'assistant', content: '⚠️ Gemini API anahtarı eksik.\nGitHub Secrets \'da GEMINI_API_KEY ekleyin.'));
          _loading = false;
        });
        return;
      }
      final history = _messages.where((m) => m.role != 'system').map((m) => {'role': m.role, 'content': m.content}).toList();
      final geminiContents = _messages
        .where((m) => m.role == 'user' || m.role == 'assistant')
        .map((m) => {'role': m.role == 'assistant' ? 'model' : 'user', 'parts': [{'text': m.content}]}).toList();
      final response = await http.post(
        Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$geminiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'system_instruction': {'parts': [{'text': 'Sen Asgard AI asistanisin. Turkce, kisa ve yardimci cevaplar veriyorsun.'}]}, 'contents': geminiContents, 'generationConfig': {'maxOutputTokens': 1000}}),
      );
      if (response.statusCode != 200) {
          final errData = jsonDecode(response.body);
          final code = errData['error']?['code'] ?? response.statusCode;
          final String msg;
          if (code == 429) msg = '⚠️ AI kota doldu. Biraz bekleyip tekrar deneyin.';
          else if (code == 403) msg = '⚠️ AI erişim reddedildi. API key geçersiz.';
          else msg = '⚠️ AI şu an yanıt veremiyor (kod: $code). Tekrar deneyin.';
          setState(() { _messages.add(_AiMsg(role: 'assistant', content: msg)); _loading = false; });
          return;
        }
      final data = jsonDecode(response.body);
      final reply = data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? 'Yanit alinamadi';
      setState(() => _messages.add(_AiMsg(role: 'assistant', content: reply)));
    } catch (e) {
      setState(() => _messages.add(_AiMsg(role: 'assistant', content: '⚠️ Bağlantı hatası. Tekrar dene.')));
    } finally {
      setState(() => _loading = false);
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        iconTheme: const IconThemeData(color: Colors.white),
        title: Row(children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [ColorsManager.darkPrimary, Colors.purple]),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.auto_awesome, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Asgard AI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            Text('Yapay Zeka Asistan', style: TextStyle(color: Colors.white38, fontSize: 11)),
          ]),
        ]),
      ),
      body: Column(children: [
        // Hızlı öneriler
        SizedBox(height: 52, child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          itemCount: _suggestions.length,
          itemBuilder: (_, i) => GestureDetector(
            onTap: () => _send(_suggestions[i]),
            child: Container(
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: ColorsManager.darkPrimary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.3)),
              ),
              child: Text(_suggestions[i], style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12.sp)),
            ),
          ),
        )),

        // Mesajlar
        Expanded(child: ListView.builder(
          controller: _scroll,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          itemCount: _messages.length + (_loading ? 1 : 0),
          itemBuilder: (_, i) {
            if (i == _messages.length) return _TypingIndicator();
            final m = _messages[i];
            final isAI = m.role == 'assistant';
            return Align(
              alignment: isAI ? Alignment.centerLeft : Alignment.centerRight,
              child: Container(
                margin: EdgeInsets.only(bottom: 10, left: isAI ? 0 : 40, right: isAI ? 40 : 0),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  gradient: isAI ? LinearGradient(
                    colors: [const Color(0xFF1A1A2E), const Color(0xFF16213E)],
                  ) : LinearGradient(
                    colors: [ColorsManager.darkPrimary.withOpacity(0.8), ColorsManager.darkPrimary],
                  ),
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(16),
                    topRight: const Radius.circular(16),
                    bottomLeft: Radius.circular(isAI ? 4 : 16),
                    bottomRight: Radius.circular(isAI ? 16 : 4),
                  ),
                  border: isAI ? Border.all(color: Colors.purple.withOpacity(0.2)) : null,
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (isAI) Row(children: [
                    const Icon(Icons.auto_awesome, color: Colors.purple, size: 12),
                    const SizedBox(width: 4),
                    const Text('Asgard AI', style: TextStyle(color: Colors.purple, fontSize: 10, fontWeight: FontWeight.bold)),
                  ]),
                  if (isAI) const SizedBox(height: 4),
                  SelectableText(m.content, style: TextStyle(color: Colors.white, fontSize: 14.sp, height: 1.4)),
                  if (isAI) Align(alignment: Alignment.bottomRight, child: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      GestureDetector(
                        onTap: () { Clipboard.setData(ClipboardData(text: m.content));
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kopyalandı'))); },
                        child: const Icon(Icons.copy_rounded, color: Colors.white24, size: 14),
                      ),
                    ]),
                  )),
                ]),
              ),
            );
          },
        )),

        // Input
        Container(
          color: const Color(0xFF111111),
          padding: EdgeInsets.fromLTRB(12.w, 8.h, 12.w, 8.h + MediaQuery.of(context).padding.bottom),
          child: Row(children: [
            Expanded(child: Container(
              decoration: BoxDecoration(color: const Color(0xFF1C1C1C), borderRadius: BorderRadius.circular(24)),
              child: TextField(
                controller: _ctrl, maxLines: 4, minLines: 1,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Bir şey sor...',
                  hintStyle: const TextStyle(color: Colors.white30),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
                ),
                onSubmitted: (_) => _send(),
              ),
            )),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _send,
              child: Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [ColorsManager.darkPrimary, Colors.purple]),
                  shape: BoxShape.circle,
                ),
                child: _loading
                    ? const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _AiMsg {
  final String role, content;
  _AiMsg({required this.role, required this.content});
}

class _TypingIndicator extends StatefulWidget {
  @override State<_TypingIndicator> createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<_TypingIndicator> with TickerProviderStateMixin {
  late List<AnimationController> _ctrls;
  @override
  void initState() {
    super.initState();
    _ctrls = List.generate(3, (i) => AnimationController(vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true, period: Duration(milliseconds: 600 + i * 200)));
  }
  @override void dispose() { for (final c in _ctrls) c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Align(alignment: Alignment.centerLeft,
    child: Container(margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.purple.withOpacity(0.2))),
      child: Row(mainAxisSize: MainAxisSize.min, children: List.generate(3, (i) =>
        AnimatedBuilder(animation: _ctrls[i], builder: (_, __) => Container(
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: 7, height: 7,
          decoration: BoxDecoration(
            color: Colors.purple.withOpacity(0.4 + 0.6 * _ctrls[i].value),
            shape: BoxShape.circle),
        ))))));
}
