import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageStatus { sending, delivered, read }

class Message {
  final String senderID;
  final String senderName;
  final String message;
  final String receiverID;
  final Timestamp timestamp;
  final String status; // 'sending', 'delivered', 'read'

  Message({
    required this.senderID,
    required this.senderName,
    required this.message,
    required this.receiverID,
    required this.timestamp,
    this.status = 'delivered',
  });

  Map<String, dynamic> toMap() {
    return {
      'senderID': senderID,
      'senderName': senderName,
      'message': message,
      'receiverID': receiverID,
      'timestamp': timestamp,
      'status': status,
    };
  }
}
