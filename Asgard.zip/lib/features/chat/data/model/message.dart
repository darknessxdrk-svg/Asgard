import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageStatus { sending, delivered, read }

class Message {
  final String senderID;
  final String senderName;
  final String message;
  final String receiverID;
  final Timestamp timestamp;
  final String status;

  const Message({
    required this.senderID,
    required this.senderName,
    required this.message,
    required this.receiverID,
    required this.timestamp,
    this.status = 'delivered',
  });

  Map<String, dynamic> toMap() {
    return {
      'senderID': senderID,
      'senderName': senderName,
      'message': message,
      'receiverID': receiverID,
      'timestamp': timestamp,
      'status': status,
    };
  }

  // FIX DATA: güvenli fromMap — null/wrong-type crash'leri önler
  factory Message.fromMap(Map<String, dynamic> map) {
    return Message(
      senderID: _str(map['senderID']),
      senderName: _str(map['senderName']),
      message: _str(map['message']),
      receiverID: _str(map['receiverID']),
      timestamp: map['timestamp'] is Timestamp
          ? map['timestamp'] as Timestamp
          : Timestamp.now(),
      status: _str(map['status'], fallback: 'delivered'),
    );
  }

  // FIX DATA: Firestore doc'tan güvenli okuma
  factory Message.fromDoc(DocumentSnapshot doc) {
    final data = doc.data();
    if (data == null || data is! Map<String, dynamic>) {
      return Message(
        senderID: '', senderName: '', message: '',
        receiverID: '', timestamp: Timestamp.now(),
      );
    }
    return Message.fromMap(data);
  }

  /// Firestore verisini güvenli string'e dönüştür — null/int/bool hepsini handle et
  static String _str(dynamic v, {String fallback = ''}) {
    if (v == null) return fallback;
    if (v is String) return v;
    return v.toString();
  }
}

// FIX DATA: Firestore map'lerini güvenli okuyan extension
extension SafeMap on Map<String, dynamic>? {
  String safeStr(String key, {String fallback = ''}) {
    final v = this?[key];
    if (v == null) return fallback;
    if (v is String) return v;
    return v.toString();
  }

  bool safeBool(String key, {bool fallback = false}) {
    final v = this?[key];
    if (v == null) return fallback;
    if (v is bool) return v;
    if (v is String) return v == 'true';
    return fallback;
  }

  int safeInt(String key, {int fallback = 0}) {
    final v = this?[key];
    if (v == null) return fallback;
    if (v is int) return v;
    if (v is double) return v.toInt();
    if (v is String) return int.tryParse(v) ?? fallback;
    return fallback;
  }

  List<T> safeList<T>(String key) {
    final v = this?[key];
    if (v == null) return <T>[];
    if (v is List) return v.whereType<T>().toList();
    return <T>[];
  }
}
