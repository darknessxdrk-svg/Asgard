import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lottie/lottie.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../themes/colors.dart';

class UpdateScreen extends StatefulWidget {
  const UpdateScreen({super.key});
  @override State<UpdateScreen> createState() => _UpdateScreenState();
}

class _UpdateScreenState extends State<UpdateScreen> {
  bool _downloading = false;
  double _progress = 0;
  String _status = '';
  String? _downloadUrl;
  String _version = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadUpdateInfo());
  }

  Future<void> _loadUpdateInfo() async {
    try {
      final doc = await FirebaseFirestore.instance.collection('version').doc('newest').get();
      final data = doc.data() as Map<String, dynamic>?;
      setState(() {
        _downloadUrl = data?['link'] as String?;
        _version = data?['version'] as String? ?? '';
      });
    } catch (_) {}
  }

  Future<void> _downloadAndInstall() async {
    if (_downloadUrl == null || _downloadUrl!.isEmpty) {
      _showError('İndirme linki bulunamadı.');
      return;
    }
    if (Platform.isAndroid) {
      final status = await Permission.requestInstallPackages.status;
      if (!status.isGranted) await Permission.requestInstallPackages.request();
    }
    setState(() { _downloading = true; _progress = 0; _status = 'Bağlanıyor...'; });
    try {
      final dir = await getTemporaryDirectory();
      final savePath = '${dir.path}/asgard_update.apk';
      await Dio().download(
        _downloadUrl!, savePath,
        onReceiveProgress: (received, total) {
          if (total > 0 && mounted) {
            setState(() {
              _progress = received / total;
              final mb = (received / 1048576).toStringAsFixed(1);
              final tmb = (total / 1048576).toStringAsFixed(1);
              _status = '$mb MB / $tmb MB';
            });
          }
        },
        options: Options(responseType: ResponseType.bytes, headers: {'Accept': '*/*'}),
      );
      if (mounted) setState(() { _status = 'Kurulum başlatılıyor...'; });
      final result = await OpenFilex.open(savePath, type: 'application/vnd.android.package-archive');
      if (result.type != ResultType.done && mounted) _showError('Hata: ${result.message}');
    } on DioException catch (e) {
      if (mounted) _showError('İndirme hatası: ${e.message ?? e.type.name}');
    } catch (e) {
      if (mounted) _showError('Hata: $e');
    } finally {
      if (mounted) setState(() { _downloading = false; _progress = 0; _status = ''; });
    }
  }

  void _showError(String msg) {
    setState(() { _downloading = false; _status = ''; });
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: Colors.red.shade800));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            SizedBox(height: 200, child: Lottie.asset('assets/lottie/update.json', repeat: true)),
            const SizedBox(height: 24),
            Text(context.tr('update'),
                style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
            const SizedBox(height: 10),
            if (_version.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: ColorsManager.darkPrimary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.4)),
                ),
                child: Text('Sürüm $_version', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold)),
              ),
            const SizedBox(height: 16),
            Text(context.tr('updateDesc'),
                style: const TextStyle(color: Colors.white54, fontSize: 14, height: 1.5),
                textAlign: TextAlign.center),
            const SizedBox(height: 36),
            if (_downloading) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: _progress, backgroundColor: Colors.white12,
                  color: ColorsManager.darkPrimary, minHeight: 8,
                ),
              ),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(_status, style: const TextStyle(color: Colors.white38, fontSize: 12)),
                Text('${(_progress * 100).toStringAsFixed(0)}%',
                    style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold)),
              ]),
              const SizedBox(height: 20),
            ],
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _downloading ? null : _downloadAndInstall,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _downloading ? Colors.white12 : ColorsManager.darkPrimary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  shadowColor: ColorsManager.darkPrimary.withOpacity(0.5),
                  elevation: _downloading ? 0 : 4,
                ),
                child: _downloading
                    ? const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                        SizedBox(width: 10), Text('İndiriliyor...'),
                      ])
                    : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.download_rounded, size: 20),
                        SizedBox(width: 8), Text('Güncelle', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ]),
              ),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: _downloading ? null : () => SystemNavigator.pop(),
              child: const Text('Çıkış', style: TextStyle(color: Colors.white38, fontSize: 14)),
            ),
          ]),
        ),
      ),
    );
  }
}
