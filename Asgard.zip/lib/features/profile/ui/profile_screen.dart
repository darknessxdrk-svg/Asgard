import '../../../core/utils/string_ext.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:photo_view/photo_view.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';

import '../../../services/cloudinary_service.dart';
import '../../../themes/colors.dart';

class ProfileScreen extends StatefulWidget {
  final String userID;
  const ProfileScreen({super.key, required this.userID});
  @override State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with SingleTickerProviderStateMixin {
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  Map<String, dynamic>? _userData;
  bool _isBlocked = false;
  bool _isMuted = false;
  bool _isMe = false;
  bool _uploadingPhoto = false;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _isMe = _auth.currentUser?.uid == widget.userID;
    _loadUser();
    if (!_isMe) { _checkBlocked(); _checkMuted(); }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadUser() async {
    for (int attempt = 0; attempt < 3; attempt++) {
      try {
        final doc = await _firestore.collection('users').doc(widget.userID).get();
        if (!mounted) return;
        if (doc.exists && doc.data() != null) {
          setState(() => _userData = doc.data());
          return;
        }
        // Doc yok veya boş — kısa bekle ve tekrar dene
        await Future.delayed(const Duration(milliseconds: 500));
      } catch (_) {
        await Future.delayed(const Duration(milliseconds: 500));
      }
    }
  }

  Future<void> _checkBlocked() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final doc = await _firestore
        .collection('users').doc(uid)
        .collection('blocked').doc(widget.userID).get();
    if (mounted) setState(() => _isBlocked = doc.exists);
  }

  Future<void> _checkMuted() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final doc = await _firestore
        .collection('users').doc(uid)
        .collection('muted').doc(widget.userID).get();
    if (mounted) setState(() => _isMuted = doc.exists);
  }

  Future<void> _toggleMute() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final ref = _firestore.collection('users').doc(uid).collection('muted').doc(widget.userID);
    if (_isMuted) {
      await ref.delete();
      if (mounted) { setState(() => _isMuted = false); _snack('Sessiz alma kaldırıldı'); }
    } else {
      await ref.set({'mutedAt': FieldValue.serverTimestamp()});
      if (mounted) { setState(() => _isMuted = true); _snack('Sessize alındı'); }
    }
  }

  Future<void> _toggleBlock() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final ref = _firestore.collection('users').doc(uid).collection('blocked').doc(widget.userID);
    if (_isBlocked) {
      await ref.delete();
      if (mounted) { setState(() => _isBlocked = false); _snack('Engel kaldırıldı'); }
    } else {
      await ref.set({'blockedAt': FieldValue.serverTimestamp()});
      if (mounted) { setState(() => _isBlocked = true); _snack('Kullanıcı engellendi'); }
    }
  }

  Future<void> _changeProfilePhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked == null) return;
    if (mounted) setState(() => _uploadingPhoto = true);
    try {
      final url = await CloudinaryService.uploadImage(picked.path);
      if (url != null) {
        await _firestore.collection('users').doc(widget.userID).update({'profilePic': url});
        await _auth.currentUser?.updatePhotoURL(url);
        await _loadUser();
        _snack('Profil fotoğrafı güncellendi');
      }
    } catch (e) {
      _snack('Yükleme başarısız', error: true);
    }
    if (mounted) setState(() => _uploadingPhoto = false);
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? Colors.red : ColorsManager.darkPrimary,
    ));
  }

  Future<bool?> _confirmDialog(String title, String body) => showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF1A1A1A),
      title: Text(title, style: const TextStyle(color: Colors.white)),
      content: Text(body, style: const TextStyle(color: Colors.white70)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false),
            child: const Text('İptal', style: TextStyle(color: Colors.white54))),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: ColorsManager.darkPrimary),
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text('Onayla'),
        ),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    if (_userData == null) {
      return const Scaffold(
        backgroundColor: Color(0xFF0D0D0D),
        body: Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary)),
      );
    }

    final name = _userData!['name'] ?? '';
    final username = _userData!['username'] ?? '';
    final photo = (_userData!['profilePic'] ?? '').toString();
    final isOnline = (_userData?['isOnline'] == true || _userData?['isOnline'] == 'true');

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverAppBar(
            expandedHeight: 260,
            backgroundColor: const Color(0xFF0D0D0D),
            pinned: true,
            iconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(fit: StackFit.expand, children: [
                if (photo.isNotEmpty)
                  CachedNetworkImage(
                    imageUrl: photo,
                    fit: BoxFit.cover,
                    color: Colors.black54,
                    colorBlendMode: BlendMode.darken,
                  ),
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Color(0xFF0D0D0D)],
                    ),
                  ),
                ),
                Center(
                  child: GestureDetector(
                    onTap: _isMe ? _changeProfilePhoto : null,
                    child: Stack(alignment: Alignment.bottomRight, children: [
                      Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: ColorsManager.darkPrimary, width: 3),
                        ),
                        child: ClipOval(
                          child: photo.isNotEmpty
                              ? CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover)
                              : Container(
                                  color: const Color(0xFF1A1A1A),
                                  child: const Icon(Icons.person, size: 50, color: Colors.white38),
                                ),
                        ),
                      ),
                      if (_isMe)
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: ColorsManager.darkPrimary,
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFF0D0D0D), width: 2),
                          ),
                          child: _uploadingPhoto
                              ? const SizedBox(
                                  width: 14,
                                  height: 14,
                                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                )
                              : const Icon(Icons.camera_alt, size: 14, color: Colors.white),
                        ),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
          // İsim + butonlar (pinned sliver)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Column(children: [
                Text(name,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22.sp,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('@${capFirst(username)}',
                      style: TextStyle(
                          color: ColorsManager.darkPrimary, fontSize: 15.sp)),
                  if (isOnline && !_isMe) ...[
                    const SizedBox(width: 10),
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                          color: Colors.green, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 4),
                    Text('Çevrimiçi',
                        style: TextStyle(color: Colors.green, fontSize: 12.sp)),
                  ],
                ]),
                const SizedBox(height: 24),
                if (!_isMe) ...[
                  Row(children: [
                    Expanded(
                      child: _Btn(
                        icon: Icons.message_rounded,
                        label: 'Mesaj',
                        onTap: () => Navigator.pop(context),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _Btn(
                        icon: _isBlocked ? Icons.block_flipped : Icons.block,
                        label: _isBlocked ? 'Engeli Kaldır' : 'Engelle',
                        color: Colors.red,
                        onTap: () async {
                          final ok = await _confirmDialog(
                            _isBlocked ? 'Engeli kaldır?' : 'Kullanıcıyı engelle?',
                            _isBlocked
                                ? 'Bu kullanıcıyla tekrar mesajlaşabileceksin.'
                                : 'Bu kullanıcı sana mesaj gönderemez.',
                          );
                          if (ok == true) _toggleBlock();
                        },
                      ),
                    ),
                  ]),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                      child: _Btn(
                        icon: Icons.person_remove_rounded,
                        label: 'Kaldır',
                        color: Colors.white54,
                        onTap: () async {
                          final ok = await _confirmDialog(
                              'Kişiyi kaldır?', 'Listenden kaldırılacak.');
                          if (ok == true) {
                            await _firestore
                                .collection('users')
                                .doc(_auth.currentUser?.uid)
                                .collection('contacts')
                                .doc(widget.userID)
                                .delete();
                            if (mounted) Navigator.pop(context);
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _Btn(
                        icon: Icons.report_outlined,
                        label: 'Şikayet',
                        color: Colors.orange,
                        onTap: () => _snack('Şikayet gönderildi'),
                      ),
                    ),
                  ]),
                ],
                if (_isMe) ...[
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: ColorsManager.darkPrimary,
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14.r)),
                      ),
                      onPressed: _changeProfilePhoto,
                      icon: const Icon(Icons.camera_alt_rounded, color: Colors.white),
                      label: const Text('Profil Fotoğrafını Değiştir',
                          style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
                const SizedBox(height: 20),
              ]),
            ),
          ),
          // TabBar pinned
          SliverPersistentHeader(
            pinned: true,
            delegate: _TabBarDelegate(
              TabBar(
                controller: _tabController,
                indicatorColor: ColorsManager.darkPrimary,
                labelColor: ColorsManager.darkPrimary,
                unselectedLabelColor: Colors.white38,
                dividerColor: Colors.white10,
                tabs: const [
                  Tab(icon: Icon(Icons.image_outlined, size: 20), text: 'Fotoğraflar'),
                  Tab(icon: Icon(Icons.videocam_outlined, size: 20), text: 'Videolar'),
                  Tab(icon: Icon(Icons.insert_drive_file_outlined, size: 20), text: 'Dosyalar'),
                ],
              ),
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabController,
          children: [
            _MediaGrid(userID: widget.userID, type: 'images'),
            _MediaGrid(userID: widget.userID, type: 'videos'),
            _MediaGrid(userID: widget.userID, type: 'files'),
          ],
        ),
      ),
    );
  }
}

class _TabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar tabBar;
  _TabBarDelegate(this.tabBar);

  @override
  double get minExtent => tabBar.preferredSize.height;
  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: const Color(0xFF0D0D0D),
      child: tabBar,
    );
  }

  @override
  bool shouldRebuild(_TabBarDelegate oldDelegate) => false;
}

class _Btn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;
  const _Btn({required this.icon, required this.label, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? ColorsManager.darkPrimary;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h),
        decoration: BoxDecoration(
          color: c.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14.r),
          border: Border.all(color: c.withOpacity(0.3)),
        ),
        child: Column(children: [
          Icon(icon, color: c, size: 22),
          SizedBox(height: 4.h),
          Text(label, style: TextStyle(color: c, fontSize: 12.sp)),
        ]),
      ),
    );
  }
}

// ── Medya Galerisi ────────────────────────────────────────────────────────────
class _MediaGrid extends StatelessWidget {
  final String userID;
  final String type;
  const _MediaGrid({required this.userID, required this.type});

  bool _isImage(String url) =>
      url.contains('asgard_images') ||
      url.contains('/image/') ||
      url.endsWith('.jpg') ||
      url.endsWith('.png') ||
      url.endsWith('.jpeg') ||
      url.endsWith('.webp');
  bool _isVideo(String url) =>
      url.contains('asgard_video') ||
      url.endsWith('.mp4') ||
      url.endsWith('.mov');
  bool _isAudio(String url) =>
      url.contains('asgard_audio') ||
      url.endsWith('.aac') ||
      url.endsWith('.mp3');

  @override
  Widget build(BuildContext context) {
    final myUID = FirebaseAuth.instance.currentUser?.uid ?? '';
    final chatRoomID = [myUID, userID]..sort();
    final roomID = chatRoomID.join('_');

    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('chats')
          .doc(roomID)
          .collection('messages')
          .orderBy('timestamp', descending: true)
          .snapshots(),
      builder: (ctx, snap) {
        if (!snap.hasData) {
          return const ColoredBox(
            color: Color(0xFF0D0D0D),
            child: Center(
              child: CircularProgressIndicator(color: ColorsManager.darkPrimary),
            ),
          );
        }

        final allMsgs = snap.data!.docs;
        List<String> filtered = [];

        for (final doc in allMsgs) {
          final msg = (doc.data() as Map)['message']?.toString() ?? '';
          if (type == 'images' && _isImage(msg)) {
            filtered.add(msg);
          } else if (type == 'videos' && _isVideo(msg)) {
            filtered.add(msg);
          } else if (type == 'files' &&
              !_isImage(msg) &&
              !_isVideo(msg) &&
              !_isAudio(msg) &&
              msg.startsWith('http')) {
            filtered.add(msg);
          }
        }

        if (filtered.isEmpty) {
          return ColoredBox(
            color: const Color(0xFF0D0D0D),
            child: Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(
                  type == 'images'
                      ? Icons.image_not_supported_outlined
                      : type == 'videos'
                          ? Icons.videocam_off_outlined
                          : Icons.folder_off_outlined,
                  size: 36,
                  color: Colors.white24,
                ),
                const SizedBox(height: 8),
                Text(
                  type == 'images'
                      ? 'Fotoğraf yok'
                      : type == 'videos'
                          ? 'Video yok'
                          : 'Dosya yok',
                  style: const TextStyle(color: Colors.white38, fontSize: 13),
                ),
              ]),
            ),
          );
        }

        if (type == 'files') {
          return ListView.builder(
            itemCount: filtered.length,
            itemBuilder: (_, i) => ListTile(
              leading: Icon(Icons.insert_drive_file,
                  color: ColorsManager.darkPrimary),
              title: Text('Dosya ${i + 1}',
                  style: const TextStyle(color: Colors.white, fontSize: 13)),
              subtitle: Text(
                filtered[i],
                style:
                    const TextStyle(color: Colors.white38, fontSize: 10),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              onTap: () async => await launchUrl(Uri.parse(filtered[i])),
            ),
          );
        }

        return GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2),
          itemCount: filtered.length,
          itemBuilder: (_, i) => GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => _FullscreenMediaPage(url: filtered[i])),
            ),
            child: CachedNetworkImage(
              imageUrl: filtered[i],
              fit: BoxFit.cover,
              placeholder: (c, u) =>
                  Container(color: const Color(0xFF1A1A1A)),
              errorWidget: (c, u, e) => Container(
                color: const Color(0xFF1A1A1A),
                child:
                    const Icon(Icons.broken_image, color: Colors.white24),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _FullscreenMediaPage extends StatelessWidget {
  final String url;
  const _FullscreenMediaPage({required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () async => await launchUrl(Uri.parse(url)),
          ),
        ],
      ),
      body: PhotoView(
        imageProvider: NetworkImage(url),
        minScale: PhotoViewComputedScale.contained,
      ),
    );
  }
}
