import '../../core/utils/string_ext.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../../themes/colors.dart';

class QRScreen extends StatelessWidget {
  const QRScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('QR Kod', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('users').doc(uid).get(),
        builder: (ctx, snap) {
          final data = snap.data?.data() as Map<String, dynamic>?;
          final username = data?['username'] ?? '';
          final name = data?['name'] ?? '';
          final qrData = 'asgard://user/$uid/$username';

          return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Profilini Paylaş', style: TextStyle(color: Colors.white38, fontSize: 13, letterSpacing: 1)),
            const SizedBox(height: 24),
            // QR Container
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.3), blurRadius: 30, spreadRadius: 2)],
              ),
              child: QrImageView(
                data: qrData,
                version: QrVersions.auto,
                size: 220.w,
                backgroundColor: Colors.white,
                eyeStyle: QrEyeStyle(eyeShape: QrEyeShape.square, color: const Color(0xFF111111)),
                dataModuleStyle: QrDataModuleStyle(dataModuleShape: QrDataModuleShape.square, color: const Color(0xFF111111)),
              ),
            ),
            const SizedBox(height: 28),
            Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 22)),
            const SizedBox(height: 4),
            Text('@${username.capitalizeFirst}', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 15)),
            const SizedBox(height: 32),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _ActionBtn(
                icon: Icons.copy_rounded,
                label: 'Linki Kopyala',
                color: ColorsManager.darkPrimary,
                onTap: () {
                  Clipboard.setData(ClipboardData(text: 'asgard://add/$username'));
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Link kopyalandı')));
                },
              ),
              const SizedBox(width: 16),
              _ActionBtn(
                icon: Icons.share_rounded,
                label: 'Paylaş',
                color: Colors.blue,
                onTap: () {
                  Clipboard.setData(ClipboardData(text: 'Asgard\'da beni bul: asgard://add/$username'));
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Kopyalandı, paylaşabilirsin')));
                },
              ),
            ]),
          ]));
        },
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _ActionBtn({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: color.withOpacity(0.15), shape: BoxShape.circle,
              border: Border.all(color: color.withOpacity(0.4))),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(height: 8),
        Text(label, style: TextStyle(color: color, fontSize: 12)),
      ]),
    );
  }
}
