import '../../../core/utils/string_ext.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../helpers/extensions.dart';
import '../../call/ui/call_screen.dart';

import '../../../router/routes.dart';
import '../../../services/database.dart';
import '../../../themes/colors.dart';
import '../../tabs/calls_tab.dart';
import '../../tabs/chat_tab.dart';
import '../../tabs/updates_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  final _auth = FirebaseAuth.instance;
  final _picker = ImagePicker();
  late TabController _tabController;
  int _currentTab = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging || _currentTab != _tabController.index) {
        setState(() => _currentTab = _tabController.index);
      }
    });
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await DatabaseMethods.setOnline(true);
      await setupInteractedMessage();
    });
  }

  void _showGroupOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          ListTile(
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: ColorsManager.darkPrimary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(Icons.group_add_rounded, color: ColorsManager.darkPrimary),
            ),
            title: const Text('Yeni Grup Oluştur', style: TextStyle(color: Colors.white)),
            subtitle: const Text('Kişilerinden grup kur', style: TextStyle(color: Colors.white38, fontSize: 12)),
            onTap: () { Navigator.pop(context); context.pushNamed(Routes.newGroupScreen); },
          ),
          ListTile(
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.green.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.vpn_key_rounded, color: Colors.green),
            ),
            title: const Text('Davet Koduyla Katıl', style: TextStyle(color: Colors.white)),
            subtitle: const Text('Grup davet kodunu yapıştır', style: TextStyle(color: Colors.white38, fontSize: 12)),
            onTap: () { Navigator.pop(context); _showJoinWithCode(context); },
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  void _showJoinWithCode(BuildContext context) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Davet Koduyla Katıl', style: TextStyle(color: Colors.white)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Sana gönderilen grup davet kodunu yapıştır:',
              style: TextStyle(color: Colors.white60, fontSize: 13)),
          const SizedBox(height: 12),
          TextField(
            controller: ctrl,
            autofocus: true,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Davet kodunu buraya yapıştır',
              hintStyle: const TextStyle(color: Colors.white24),
              filled: true,
              fillColor: const Color(0xFF0D0D0D),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: ColorsManager.darkPrimary)),
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () async {
              final code = ctrl.text.trim();
              if (code.isEmpty) return;
              Navigator.pop(ctx);
              // Grup var mı kontrol et
              try {
                final doc = await FirebaseFirestore.instance
                    .collection('groups').doc(code).get();
                if (!doc.exists) {
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Geçersiz davet kodu'),
                          backgroundColor: Colors.red));
                  return;
                }
                final groupData = doc.data()!;
                final members = List<String>.from(groupData['members'] ?? []);
                final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
                if (!members.contains(uid)) {
                  members.add(uid);
                  await FirebaseFirestore.instance.collection('groups').doc(code)
                      .update({'members': members});
                }
                if (context.mounted) {
                  context.pushNamed(Routes.groupChatPage,
                      arguments: {'groupId': code, 'groupName': groupData['name'] ?? 'Grup'});
                }
              } catch (e) {
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Hata: $e'), backgroundColor: Colors.red));
              }
            },
            child: Text('Katıl', style: TextStyle(color: ColorsManager.darkPrimary,
                fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFF0D0D0D),
        floatingActionButton: _currentTab == 0 ? Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: ColorsManager.darkPrimary.withOpacity(0.5),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: FloatingActionButton(
            onPressed: () => _showGroupOptions(context),
            backgroundColor: ColorsManager.darkPrimary,
            child: const Icon(Icons.group_add_rounded, color: Colors.white),
          ),
        ) : null,
        appBar: AppBar(
          backgroundColor: const Color(0xFF111111),
          elevation: 0,
          scrolledUnderElevation: 0,
          shadowColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Asgard',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22.sp,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                ),
              ),
              SizedBox(width: 6.w),
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: ColorsManager.darkPrimary,
                  boxShadow: [
                    BoxShadow(
                      color: ColorsManager.darkPrimary.withOpacity(0.8),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ],
          ),
          centerTitle: true,
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: ColorsManager.darkPrimary,
            indicatorWeight: 3,
            indicatorSize: TabBarIndicatorSize.tab,
            dividerColor: Colors.transparent,
            labelColor: ColorsManager.darkPrimary,
            unselectedLabelColor: Colors.white30,
            labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            indicator: UnderlineTabIndicator(
              borderSide: BorderSide(color: ColorsManager.darkPrimary, width: 3),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
            ),
            tabs: [
              Tab(text: context.tr('chats')),
              Tab(text: context.tr('updates')),
              Tab(text: context.tr('calls')),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.camera_alt_outlined, size: 22),
              color: Colors.white70,
              onPressed: () async {
                final pickedFile = await _picker.pickImage(source: ImageSource.camera);
                if (pickedFile != null) {
                  if (!context.mounted) return;
                  context.pushNamed(Routes.displayPictureScreen, arguments: [pickedFile, '', '', '']);
                }
              },
            ),
            IconButton(
              icon: const Icon(Icons.search, size: 22),
              color: Colors.white70,
              onPressed: () => _showSearch(context),
            ),
            _buildPopMenu(),
          ],
        ),
        body: Container(
          color: const Color(0xFF0D0D0D),
          child: TabBarView(
            controller: _tabController,
            children: const [ChatsTab(), UpdatesTab(), CallsTab()],
          ),
        ),
      );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    switch (state) {
      case AppLifecycleState.resumed:
        await DatabaseMethods.setOnline(true);
        break;
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        // inactive: bildirim çekme, başka uygulama gibi geçici durumlar - offline yapma
        await DatabaseMethods.setOnline(false);
        break;
      default:
        break;
    }
  }

  Future<void> setupInteractedMessage() async {
    // Uygulama kapalıyken bildirime tıklanarak açıldıysa
    RemoteMessage? initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) _goToNotificationChatPage(initialMessage);
    // Uygulama arka plandayken bildirime tıklanınca
    FirebaseMessaging.onMessageOpenedApp.listen(_goToNotificationChatPage);
  }

  PopupMenuButton _buildPopMenu() {
    return PopupMenuButton(
      color: const Color(0xFF1A1A1A),
      icon: const Icon(Icons.more_vert, color: Colors.white70),
      elevation: 8,
      position: PopupMenuPosition.under,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: Color(0xFF2A2A2A)),
      ),
      itemBuilder: (context) => [
        PopupMenuItem(
          onTap: () => context.pushNamed(Routes.groupCreateScreen),
          child: Row(children: [
            Icon(Icons.group_add_outlined, size: 18, color: ColorsManager.darkPrimary),
            const SizedBox(width: 10),
            const Text('Grup Oluştur', style: TextStyle(color: Colors.white)),
          ]),
        ),
        PopupMenuItem(
          onTap: () => context.pushNamed(Routes.settingsScreen),
          child: Row(children: [
            Icon(Icons.settings_outlined, size: 18, color: ColorsManager.darkPrimary),
            const SizedBox(width: 10),
            Text(context.tr('settings'), style: const TextStyle(color: Colors.white)),
          ]),
        ),
        const PopupMenuDivider(),
        PopupMenuItem(
          onTap: () async {
            try {
              await GoogleSignIn().disconnect();
            } finally {
              await DatabaseMethods.setOnline(false);
              SharedPreferences prefs = await SharedPreferences.getInstance();
              if (prefs.getBool('auth_screen_enabled') != null) {
                await prefs.remove('auth_screen_enabled');
              }
              await _auth.signOut();
              if (!context.mounted) return;
              context.pushNamedAndRemoveUntil(Routes.loginScreen, predicate: (route) => false);
            }
          },
          child: const Row(children: [
            Icon(Icons.logout_outlined, size: 18, color: Colors.redAccent),
            SizedBox(width: 10),
            Text('Çıkış Yap', style: TextStyle(color: Colors.redAccent)),
          ]),
        ),
      ],
    );
  }

  void _goToNotificationChatPage(RemoteMessage message) {
    final type = message.data['type'] ?? '';
    if (type == 'chat') {
      context.pushNamed(Routes.chatScreen, arguments: message.data);
    } else if (type == 'incoming_call') {
      // Bildirime tıklayınca arama ekranına git
      final callId = message.data['callId'] ?? '';
      final callerName = message.data['callerName'] ?? '';
      final callerUID = message.data['callerUID'] ?? '';
      final isVideo = message.data['isVideo'] == 'true';
      if (callId.isNotEmpty) {
        // Arama hâlâ aktif mi kontrol et
        FirebaseFirestore.instance
            .collection('calls')
            .doc(callId)
            .get()
            .then((snap) {
          if (!context.mounted) return;
          final status = snap.data()?['status'] as String? ?? '';
          if (status == 'ringing') {
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => IncomingCallScreen(
                callId: callId,
                callerName: callerName,
                callerUID: callerUID,
                isVideo: isVideo,
              ),
            );
          }
        });
      }
    } else if (type == 'update') {
      context.pushReplacementNamed(Routes.updateScreen);
    } else {
      context.pushReplacementNamed(Routes.homeScreen);
    }
  }

  void _showSearch(BuildContext context) {
    showSearch(context: context, delegate: _ContactSearchDelegate());
  }
}

// ─── Arama ───────────────────────────────────────────────────────────────────
class _ContactSearchDelegate extends SearchDelegate<String> {
  @override
  String get searchFieldLabel => 'Kişi ara...';

  @override
  ThemeData appBarTheme(BuildContext context) {
    return Theme.of(context).copyWith(
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF111111)),
      scaffoldBackgroundColor: const Color(0xFF0D0D0D),
      canvasColor: const Color(0xFF0D0D0D),
      colorScheme: Theme.of(context).colorScheme.copyWith(
        surface: const Color(0xFF0D0D0D),
      ),
      inputDecorationTheme: const InputDecorationTheme(
        hintStyle: TextStyle(color: Colors.white38),
        border: InputBorder.none,
        filled: false,
      ),
      textTheme: const TextTheme(titleLarge: TextStyle(color: Colors.white)),
    );
  }

  @override
  List<Widget> buildActions(BuildContext context) => [
    if (query.isNotEmpty)
      IconButton(icon: const Icon(Icons.clear, color: Colors.white70),
          onPressed: () => query = ''),
  ];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: const Icon(Icons.arrow_back, color: Colors.white),
      onPressed: () => close(context, ''));

  @override
  Widget buildResults(BuildContext context) => _buildList(context);

  @override
  Widget buildSuggestions(BuildContext context) => _buildList(context);

  Widget _buildList(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (query.isEmpty) return const ColoredBox(color: Color(0xFF0D0D0D), child: SizedBox());
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users').doc(uid).collection('contacts').snapshots(),
      builder: (ctx, snap) {
        if (!snap.hasData) return const ColoredBox(color: Color(0xFF0D0D0D), child: Center(child: CircularProgressIndicator()));
        final contacts = snap.data!.docs;
        final items = <Widget>[];
        for (final doc in contacts) {
          items.add(_SearchContactTile(
            key: ValueKey(doc.id),
            uid: doc.id,
            query: query,
            onTap: (cid, data) {
              close(context, cid);
              Navigator.pushNamed(context, Routes.chatScreen, arguments: {
                'name': data['name'] ?? '', 'uid': cid,
                'profilePic': data['profilePic'] ?? '',
                'active': data['isOnline']?.toString() ?? 'false',
                'mtoken': data['mtoken'] ?? '',
              });
            },
          ));
        }
        return ColoredBox(
          color: const Color(0xFF0D0D0D),
          child: ListView(children: items),
        );
      },
    );
  }
}

// ─── Arama Sonuç Tile (gri ekran yok) ────────────────────────────────────────
class _SearchContactTile extends StatefulWidget {
  final String uid;
  final String query;
  final void Function(String uid, Map<String, dynamic> data) onTap;
  const _SearchContactTile({required this.uid, required this.query, required this.onTap, super.key});
  @override State<_SearchContactTile> createState() => _SearchContactTileState();
}

class _SearchContactTileState extends State<_SearchContactTile> {
  Map<String, dynamic>? _data;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance.collection('users').doc(widget.uid).get().then((doc) {
      if (mounted) setState(() { _data = doc.data(); _loaded = true; });
    }).catchError((_) { if (mounted) setState(() => _loaded = true); });
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Container(
        height: 60,
        color: const Color(0xFF0D0D0D),
      );
    }
    final data = _data;
    if (data == null) return const SizedBox.shrink();
    final name = (data['name'] ?? '').toString();
    final username = (data['username'] ?? '').toString();
    final photo = (data['profilePic'] ?? '').toString();
    if (!name.toLowerCase().contains(widget.query.toLowerCase()) &&
        !username.toLowerCase().contains(widget.query.toLowerCase())) {
      return const SizedBox.shrink();
    }
    return Container(
      color: const Color(0xFF0D0D0D),
      child: ListTile(
        tileColor: const Color(0xFF0D0D0D),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF1A1A1A),
          backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
          child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white38) : null,
        ),
        title: Text(name, style: const TextStyle(color: Colors.white)),
        subtitle: Text('@${capFirst(username)}', style: const TextStyle(color: Color(0xFFE53935), fontSize: 12)),
        onTap: () => widget.onTap(widget.uid, data),
      ),
    );
  }
}
