import '../../../core/utils/string_ext.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../helpers/extensions.dart';
import '../../../router/routes.dart';
import '../../../services/database.dart';
import '../../../themes/colors.dart';
import '../../tabs/calls_tab.dart';
import '../../tabs/chat_tab.dart';
import '../../tabs/updates_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  final _auth = FirebaseAuth.instance;
  final _picker = ImagePicker();
  late TabController _tabController;
  int _currentTab = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging || _currentTab != _tabController.index) {
        setState(() => _currentTab = _tabController.index);
      }
    });
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await DatabaseMethods.setOnline(true);
      await setupInteractedMessage();
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFF0D0D0D),
        floatingActionButton: _currentTab == 0 ? Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: ColorsManager.darkPrimary.withOpacity(0.5),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: FloatingActionButton(
            onPressed: () => context.pushNamed(Routes.newGroupScreen),
            backgroundColor: ColorsManager.darkPrimary,
            child: const Icon(Icons.person_add_outlined, color: Colors.white),
          ),
        ) : null,
        appBar: AppBar(
          backgroundColor: const Color(0xFF111111),
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Asgard',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22.sp,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                ),
              ),
              SizedBox(width: 6.w),
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: ColorsManager.darkPrimary,
                  boxShadow: [
                    BoxShadow(
                      color: ColorsManager.darkPrimary.withOpacity(0.8),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ],
          ),
          centerTitle: true,
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: ColorsManager.darkPrimary,
            indicatorWeight: 3,
            indicatorSize: TabBarIndicatorSize.tab,
            dividerColor: Colors.transparent,
            labelColor: ColorsManager.darkPrimary,
            unselectedLabelColor: Colors.white30,
            labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            indicator: UnderlineTabIndicator(
              borderSide: BorderSide(color: ColorsManager.darkPrimary, width: 3),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
            ),
            tabs: [
              Tab(text: context.tr('chats')),
              Tab(text: context.tr('updates')),
              Tab(text: context.tr('calls')),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.camera_alt_outlined, size: 22),
              color: Colors.white70,
              onPressed: () async {
                final pickedFile = await _picker.pickImage(source: ImageSource.camera);
                if (pickedFile != null) {
                  if (!context.mounted) return;
                  context.pushNamed(Routes.displayPictureScreen, arguments: [pickedFile, '', '', '']);
                }
              },
            ),
            IconButton(
              icon: const Icon(Icons.search, size: 22),
              color: Colors.white70,
              onPressed: () => _showSearch(context),
            ),
            _buildPopMenu(),
          ],
        ),
        body: TabBarView(
          controller: _tabController,
          children: const [ChatsTab(), UpdatesTab(), CallsTab()],
        ),
      );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    switch (state) {
      case AppLifecycleState.resumed:
        await DatabaseMethods.setOnline(true);
        break;
      case AppLifecycleState.paused:
        await DatabaseMethods.updateLastSeen();
        break;
      default:
        await DatabaseMethods.setOnline(false);
        break;
    }
  }

  Future<void> setupInteractedMessage() async {
    RemoteMessage? initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) _goToNotificationChatPage(initialMessage);
    FirebaseMessaging.onMessageOpenedApp.listen(_goToNotificationChatPage);
  }

  PopupMenuButton _buildPopMenu() {
    return PopupMenuButton(
      color: const Color(0xFF1A1A1A),
      icon: const Icon(Icons.more_vert, color: Colors.white70),
      elevation: 8,
      position: PopupMenuPosition.under,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: Color(0xFF2A2A2A)),
      ),
      itemBuilder: (context) => [
        PopupMenuItem(
          onTap: () => context.pushNamed(Routes.groupCreateScreen),
          child: Row(children: [
            Icon(Icons.group_add_outlined, size: 18, color: ColorsManager.darkPrimary),
            const SizedBox(width: 10),
            const Text('Grup Oluştur', style: TextStyle(color: Colors.white)),
          ]),
        ),
        PopupMenuItem(
          onTap: () => context.pushNamed(Routes.settingsScreen),
          child: Row(children: [
            Icon(Icons.settings_outlined, size: 18, color: ColorsManager.darkPrimary),
            const SizedBox(width: 10),
            Text(context.tr('settings'), style: const TextStyle(color: Colors.white)),
          ]),
        ),
        const PopupMenuDivider(),
        PopupMenuItem(
          onTap: () async {
            try {
              await GoogleSignIn().disconnect();
            } finally {
              await DatabaseMethods.setOnline(false);
              SharedPreferences prefs = await SharedPreferences.getInstance();
              if (prefs.getBool('auth_screen_enabled') != null) {
                await prefs.remove('auth_screen_enabled');
              }
              await _auth.signOut();
              if (!context.mounted) return;
              context.pushNamedAndRemoveUntil(Routes.loginScreen, predicate: (route) => false);
            }
          },
          child: const Row(children: [
            Icon(Icons.logout_outlined, size: 18, color: Colors.redAccent),
            SizedBox(width: 10),
            Text('Çıkış Yap', style: TextStyle(color: Colors.redAccent)),
          ]),
        ),
      ],
    );
  }

  void _goToNotificationChatPage(RemoteMessage message) {
    if (message.data['type'] == 'chat') {
      context.pushNamed(Routes.chatScreen, arguments: message.data);
    } else if (message.data['type'] == 'update') {
      context.pushReplacementNamed(Routes.updateScreen);
    } else {
      context.pushReplacementNamed(Routes.homeScreen);
    }
  }

  void _showSearch(BuildContext context) {
    showSearch(context: context, delegate: _ContactSearchDelegate());
  }
}

// ─── Arama ───────────────────────────────────────────────────────────────────
class _ContactSearchDelegate extends SearchDelegate<String> {
  @override
  String get searchFieldLabel => 'Kullanıcı veya kişi ara...';

  @override
  ThemeData appBarTheme(BuildContext context) {
    // ✅ FIX: Tüm arka planı siyah yap
    return Theme.of(context).copyWith(
      scaffoldBackgroundColor: const Color(0xFF0D0D0D),
      canvasColor: const Color(0xFF0D0D0D),
      colorScheme: const ColorScheme.dark(
        surface: Color(0xFF111111),
        primary: Color(0xFFE53935),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF111111),
        elevation: 0,
        surfaceTintColor: Color(0xFF111111),
      ),
      inputDecorationTheme: const InputDecorationTheme(
        hintStyle: TextStyle(color: Colors.white38),
        border: InputBorder.none,
        filled: false,
      ),
      textTheme: const TextTheme(
        titleLarge: TextStyle(color: Colors.white, fontSize: 16),
      ),
    );
  }

  @override
  List<Widget> buildActions(BuildContext context) => [
    if (query.isNotEmpty)
      IconButton(
        icon: const Icon(Icons.clear, color: Colors.white70),
        onPressed: () { query = ''; showSuggestions(context); },
      ),
  ];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: const Icon(Icons.arrow_back, color: Colors.white),
      onPressed: () => close(context, ''));

  @override
  Widget buildResults(BuildContext context) => _buildSearchResults(context);

  @override
  Widget buildSuggestions(BuildContext context) => _buildSearchResults(context);

  Widget _buildSearchResults(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;

    // ✅ FIX: query boş olsa bile kişileri göster
    return Container(
      color: const Color(0xFF0D0D0D),
      child: StreamBuilder<QuerySnapshot>(
        // Tüm kullanıcılar içinde ara (bağlantı olmayanlara da ulaş)
        stream: query.isEmpty
            ? FirebaseFirestore.instance
                .collection('users')
                .doc(myUid)
                .collection('contacts')
                .snapshots()
                .asyncMap((snap) async {
                  // Kişi uid'lerini al, sonra user detaylarını çek
                  return snap;
                })
            : FirebaseFirestore.instance
                .collection('users')
                .limit(50)
                .snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator(color: Color(0xFFE53935)));
          }

          return _SearchResultList(
            snapshot: snap.data!,
            query: query,
            myUid: myUid ?? '',
          );
        },
      ),
    );
  }
}

class _SearchResultList extends StatelessWidget {
  final QuerySnapshot snapshot;
  final String query;
  final String myUid;

  const _SearchResultList({
    required this.snapshot,
    required this.query,
    required this.myUid,
  });

  @override
  Widget build(BuildContext context) {
    // Sonuçları filtrele
    final docs = snapshot.docs.where((doc) {
      final data = doc.data() as Map<String, dynamic>?;
      if (data == null) return false;
      if (doc.id == myUid) return false; // Kendini gösterme
      if (query.isEmpty) return true;
      final name = (data['name'] ?? '').toString().toLowerCase();
      final username = (data['username'] ?? '').toString().toLowerCase();
      final q = query.toLowerCase();
      return name.contains(q) || username.contains(q);
    }).toList();

    if (docs.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.search_off_rounded, size: 64, color: Colors.white12),
          const SizedBox(height: 16),
          Text(
            query.isEmpty ? 'Aramak için yazmaya başla' : '"$query" için sonuç yok',
            style: const TextStyle(color: Colors.white38, fontSize: 15),
          ),
        ]),
      );
    }

    return ListView.builder(
      itemCount: docs.length,
      itemBuilder: (ctx, i) {
        // Kişi listesindeyse uid field'ı var, değilse doc.id kullan
        final raw = docs[i].data() as Map<String, dynamic>;
        final isContactDoc = raw.containsKey('uid') && !raw.containsKey('name');

        if (isContactDoc) {
          // Bu bir contacts sub-collection doc'u — user verisini çek
          final cid = raw['uid'] as String? ?? docs[i].id;
          return FutureBuilder<DocumentSnapshot>(
            future: FirebaseFirestore.instance.collection('users').doc(cid).get(),
            builder: (ctx, uSnap) {
              if (!uSnap.hasData) return const SizedBox.shrink();
              final data = uSnap.data!.data() as Map<String, dynamic>?;
              if (data == null) return const SizedBox.shrink();
              if (query.isNotEmpty) {
                final name = (data['name'] ?? '').toString().toLowerCase();
                final username = (data['username'] ?? '').toString().toLowerCase();
                if (!name.contains(query.toLowerCase()) && !username.contains(query.toLowerCase())) {
                  return const SizedBox.shrink();
                }
              }
              return _UserTile(uid: cid, data: data);
            },
          );
        } else {
          // Direkt user doc
          return _UserTile(uid: docs[i].id, data: raw);
        }
      },
    );
  }
}

class _UserTile extends StatelessWidget {
  final String uid;
  final Map<String, dynamic> data;
  const _UserTile({required this.uid, required this.data});

  @override
  Widget build(BuildContext context) {
    final name = (data['name'] ?? '').toString();
    final username = (data['username'] ?? '').toString();
    final photo = (data['profilePic'] ?? '').toString();
    final isOnline = data['isOnline']?.toString() == 'true';

    return ListTile(
      tileColor: const Color(0xFF0D0D0D),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Stack(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: const Color(0xFF1A1A1A),
            backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
            child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white38) : null,
          ),
          if (isOnline)
            Positioned(
              bottom: 0, right: 0,
              child: Container(
                width: 12, height: 12,
                decoration: BoxDecoration(
                  color: const Color(0xFFE53935),
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFF0D0D0D), width: 2),
                ),
              ),
            ),
        ],
      ),
      title: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
      subtitle: Text(
        '@$username',
        style: const TextStyle(color: Color(0xFFE53935), fontSize: 12),
      ),
      trailing: const Icon(Icons.chevron_right, color: Colors.white24, size: 20),
      onTap: () {
        Navigator.pop(context); // Arama ekranını kapat
        Navigator.pushNamed(context, Routes.chatScreen, arguments: {
          'name': name,
          'uid': uid,
          'profilePic': photo,
          'active': data['isOnline']?.toString() ?? 'false',
          'mtoken': data['mtoken'] ?? '',
        });
      },
    );
  }
}
