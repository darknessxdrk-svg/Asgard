import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import '../../../core/widgets/connectivity_wrapper.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

import '../../../core/widgets/login_and_signup_form.dart';
import '../../../core/widgets/modal_fit.dart';
import '../../../core/widgets/no_internet.dart';
import '../../../core/widgets/or_sign_in_with_text.dart';
import '../../../core/widgets/terms_and_conditions_text.dart';
import '../../../services/google_sign_in.dart';
import '../../../themes/colors.dart';
import 'widgets/do_not_have_account.dart';

class BuildLoginScreen extends StatelessWidget {
  const BuildLoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0D0D0D), Color(0xFF1A0000), Color(0xFF0D0D0D)],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(left: 28.w, right: 28.w, bottom: 15.h, top: 10.h),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                context.tr('login'),
                                style: TextStyle(
                                  fontSize: 28.sp,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              Gap(4.h),
                              Row(
                                children: [
                                  Container(
                                    width: 30.w,
                                    height: 3,
                                    decoration: BoxDecoration(
                                      color: ColorsManager.darkPrimary,
                                      borderRadius: BorderRadius.circular(2),
                                      boxShadow: [
                                        BoxShadow(
                                          color: ColorsManager.darkPrimary.withOpacity(0.8),
                                          blurRadius: 8,
                                          spreadRadius: 1,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Gap(4.w),
                                  Container(
                                    width: 10.w,
                                    height: 3,
                                    decoration: BoxDecoration(
                                      color: ColorsManager.darkPrimary.withOpacity(0.4),
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A1A1A),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: const Color(0xFF2A2A2A)),
                            ),
                            child: IconButton(
                              onPressed: () => showCupertinoModalBottomSheet(
                                expand: false,
                                context: context,
                                backgroundColor: Colors.transparent,
                                builder: (context) => const ModalFit(),
                              ),
                              tooltip: context.tr('language'),
                              icon: const Icon(Icons.language_rounded, color: Colors.white70),
                            ),
                          ),
                        ],
                      ),
                      Gap(8.h),
                      Text(
                        context.tr('loginToContinue'),
                        style: TextStyle(fontSize: 14.sp, color: Colors.white38),
                      ),
                      Gap(24.h),
                      EmailAndPassword(),
                      Gap(16.h),
                      const SigninWithGoogleText(),
                      Gap(12.h),
                      Center(
                        child: InkWell(
                          onTap: () async => await GoogleSignin.signInWithGoogle(context),
                          borderRadius: BorderRadius.circular(50),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A1A1A),
                              shape: BoxShape.circle,
                              border: Border.all(color: const Color(0xFF2A2A2A)),
                            ),
                            child: SvgPicture.asset('assets/svgs/google.svg', width: 28.w, height: 28.h),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const TermsAndConditionsText(),
                  Gap(12.h),
                  const DoNotHaveAccountText(),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: ConnectivityWrapper(
        onlineChild: const BuildLoginScreen(),
        offlineChild: const BuildNoInternet(),
      ),
    );
  }
}
