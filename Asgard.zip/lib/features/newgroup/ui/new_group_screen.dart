import '../../core/utils/string_ext.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

import '../../../services/database.dart';
import '../../../themes/colors.dart';

class NewGroupScreen extends StatefulWidget {
  const NewGroupScreen({super.key});

  @override
  State<NewGroupScreen> createState() => _NewGroupScreenState();
}

class _NewGroupScreenState extends State<NewGroupScreen> {
  final _usernameController = TextEditingController();
  bool _isSearching = false;
  Map<String, dynamic>? _foundUser;
  String _searchError = '';

  Future<void> _searchUser() async {
    final query = _usernameController.text.trim().toLowerCase();
    if (query.isEmpty) return;

    setState(() {
      _isSearching = true;
      _foundUser = null;
      _searchError = '';
    });

    final user = await DatabaseMethods.getUserByUsername(query);

    if (!mounted) return;
    setState(() {
      _isSearching = false;
      if (user == null) {
        _searchError = '@$query kullanıcısı bulunamadı';
      } else {
        _foundUser = user;
      }
    });
  }

  Future<void> _addContact(Map<String, dynamic> user) async {
    final uid = user['uid'];
    final alreadyContact = await DatabaseMethods.isContact(uid);

    if (!mounted) return;

    if (alreadyContact) {
      AwesomeDialog(
        context: context,
        dialogType: DialogType.info,
        animType: AnimType.rightSlide,
        title: 'Zaten Eklendi',
        desc: '@${(user['username'] ?? '').capitalizeFirst} zaten kişilerinizde',
      ).show();
      return;
    }

    await DatabaseMethods.addContact(uid);

    if (!mounted) return;
    AwesomeDialog(
      context: context,
      dialogType: DialogType.success,
      animType: AnimType.rightSlide,
      title: 'Eklendi!',
      desc: '@${(user['username'] ?? '').capitalizeFirst} kişilerinize eklendi',
    ).show();

    setState(() {
      _foundUser = null;
      _usernameController.clear();
    });
  }

  @override
  void dispose() {
    _usernameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text(
          'Kişi Ekle',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 0.5),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white70),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Açıklama
            Container(
              padding: EdgeInsets.all(16.w),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A1A),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline, color: ColorsManager.darkPrimary, size: 20),
                  Gap(10.w),
                  const Expanded(
                    child: Text(
                      'Kullanıcı adını yazarak kişi arayabilirsiniz. Sadece eklediğiniz kişilerle mesajlaşabilirsiniz.',
                      style: TextStyle(color: Colors.white60, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
            Gap(24.h),

            // Arama alanı
            Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A1A),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: const Color(0xFF2A2A2A)),
                    ),
                    child: TextField(
                      controller: _usernameController,
                      style: const TextStyle(color: Colors.white),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9_]')),
                      ],
                      onSubmitted: (_) => _searchUser(),
                      decoration: InputDecoration(
                        hintText: 'Kullanıcı adı ara',
                        hintStyle: const TextStyle(color: Colors.white38),
                        prefixText: '@',
                        prefixStyle: TextStyle(
                          color: ColorsManager.darkPrimary,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 14.h),
                      ),
                    ),
                  ),
                ),
                Gap(10.w),
                GestureDetector(
                  onTap: _searchUser,
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: ColorsManager.darkPrimary,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: ColorsManager.darkPrimary.withOpacity(0.5),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: _isSearching
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.search, color: Colors.white, size: 20),
                  ),
                ),
              ],
            ),

            Gap(20.h),

            // Hata mesajı
            if (_searchError.isNotEmpty)
              Center(
                child: Text(_searchError, style: const TextStyle(color: Colors.red, fontSize: 14)),
              ),

            // Bulunan kullanıcı
            if (_foundUser != null) _buildUserCard(_foundUser!),

            Gap(32.h),

            // Mevcut kişiler
            const Text(
              'Kişilerim',
              style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Gap(12.h),
            Expanded(child: _buildContactsList()),
          ],
        ),
      ),
    );
  }

  Widget _buildUserCard(Map<String, dynamic> user) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(
            color: ColorsManager.darkPrimary.withOpacity(0.1),
            blurRadius: 20,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 52.w,
            height: 52.h,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: ColorsManager.darkPrimary.withOpacity(0.5), width: 2),
            ),
            child: ClipOval(
              child: user['profilePic'] != null && user['profilePic'] != ''
                  ? CachedNetworkImage(imageUrl: user['profilePic'], fit: BoxFit.cover)
                  : Image.asset('assets/images/user.png', fit: BoxFit.cover),
            ),
          ),
          Gap(14.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['name'] ?? '',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15),
                ),
                Gap(2.h),
                Text(
                  '@${(user['username'] ?? '').capitalizeFirst}',
                  style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 13),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => _addContact(user),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
              decoration: BoxDecoration(
                color: ColorsManager.darkPrimary,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.4), blurRadius: 8),
                ],
              ),
              child: const Text('Ekle', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactsList() {
    return StreamBuilder<QuerySnapshot>(
      stream: DatabaseMethods.getContacts(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary));
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.people_outline, size: 48, color: Colors.white12),
                Gap(12.h),
                const Text('Henüz kişi eklemediniz', style: TextStyle(color: Colors.white24, fontSize: 14)),
              ],
            ),
          );
        }
        final contactDocs = snapshot.data!.docs;
        return ListView.builder(
          itemCount: contactDocs.length,
          itemBuilder: (context, index) {
            final contactUid = contactDocs[index]['uid'] as String;
            return FutureBuilder<DocumentSnapshot>(
              future: FirebaseFirestore.instance.collection('users').doc(contactUid).get(),
              builder: (context, userSnap) {
                if (!userSnap.hasData) return const SizedBox.shrink();
                final user = userSnap.data!.data() as Map<String, dynamic>?;
                if (user == null) return const SizedBox.shrink();
                return Container(
                  margin: EdgeInsets.only(bottom: 8.h),
                  padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 10.h),
                  decoration: BoxDecoration(
                    color: const Color(0xFF111111),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF1E1E1E)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 42.w,
                        height: 42.h,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: const Color(0xFF2A2A2A)),
                        ),
                        child: ClipOval(
                          child: user['profilePic'] != null && user['profilePic'] != ''
                              ? CachedNetworkImage(imageUrl: user['profilePic'], fit: BoxFit.cover)
                              : Image.asset('assets/images/user.png', fit: BoxFit.cover),
                        ),
                      ),
                      Gap(12.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(user['name'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                            Text('@${(user['username'] ?? '').capitalizeFirst}', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12)),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                        onPressed: () async {
                          await DatabaseMethods.removeContact(contactUid);
                        },
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}
