import '../../../core/utils/string_ext.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../services/database.dart';
import '../../../themes/colors.dart';
import '../../chat/ui/group_chat_page.dart';

class GroupCreateScreen extends StatefulWidget {
  const GroupCreateScreen({super.key});
  @override State<GroupCreateScreen> createState() => _GroupCreateScreenState();
}

class _GroupCreateScreenState extends State<GroupCreateScreen> {
  final _nameCtrl = TextEditingController();
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;
  final Set<String> _selected = {};
  List<Map<String, dynamic>> _contacts = [];
  bool _loading = true;
  bool _creating = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadContacts()());
  }

  Future<void> _loadContacts() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    final snap = await _firestore.collection('users').doc(uid).collection('contacts').get();
    final List<Map<String, dynamic>> contacts = [];
    for (final doc in snap.docs) {
      final u = await _firestore.collection('users').doc(doc.id).get();
      final data = u.data();
      if (data != null) contacts.add({...data, 'uid': doc.id});
    }
    if (mounted) setState(() { _contacts = contacts; _loading = false; });
  }

  Future<void> _createGroup() async {
    if (_nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Grup adı girin')));
      return;
    }
    if (_selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('En az 1 kişi seçin')));
      return;
    }
    setState(() => _creating = true);
    try {
      final groupName = _nameCtrl.text.trim();
      final groupId = await DatabaseMethods.createGroup(groupName, _selected.toList());
      if (mounted) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.push(context, MaterialPageRoute(
          builder: (_) => GroupChatPage(groupId: groupId, groupName: groupName),
        ));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _creating = false);
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Hata olustu'), backgroundColor: Colors.red));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Yeni Grup', style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          if (_creating)
            const Padding(padding: EdgeInsets.all(16),
                child: SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: ColorsManager.darkPrimary)))
          else
            TextButton(
              onPressed: _createGroup,
              child: const Text('Oluştur', style: TextStyle(color: ColorsManager.darkPrimary, fontWeight: FontWeight.bold)),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: ColorsManager.darkPrimary))
          : Column(
              children: [
                // Grup adı
                Padding(
                  padding: EdgeInsets.all(16.r),
                  child: TextField(
                    controller: _nameCtrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Grup adı',
                      hintStyle: const TextStyle(color: Colors.white38),
                      prefixIcon: const Icon(Icons.group, color: ColorsManager.darkPrimary),
                      enabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white12),
                        borderRadius: BorderRadius.circular(14.r),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: ColorsManager.darkPrimary),
                        borderRadius: BorderRadius.circular(14.r),
                      ),
                    ),
                  ),
                ),
                // Seçilen kişiler chip'leri
                if (_selected.isNotEmpty)
                  SizedBox(
                    height: 56.h,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: EdgeInsets.symmetric(horizontal: 12.w),
                      children: _contacts
                          .where((c) => _selected.contains(c['uid']))
                          .map((c) => Padding(
                            padding: EdgeInsets.only(right: 8.w),
                            child: Chip(
                              backgroundColor: ColorsManager.darkPrimary.withOpacity(0.15),
                              side: BorderSide(color: ColorsManager.darkPrimary.withOpacity(0.4)),
                              avatar: CircleAvatar(
                                backgroundImage: (c['profilePic'] ?? '').isNotEmpty
                                    ? NetworkImage(c['profilePic']) : null,
                                backgroundColor: const Color(0xFF1A1A1A),
                                child: (c['profilePic'] ?? '').isEmpty
                                    ? const Icon(Icons.person, size: 14, color: Colors.white38) : null,
                              ),
                              label: Text(c['name'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 12)),
                              deleteIcon: const Icon(Icons.close, size: 14, color: Colors.white54),
                              onDeleted: () => setState(() => _selected.remove(c['uid'])),
                            ),
                          )).toList(),
                    ),
                  ),
                Padding(
                  padding: EdgeInsets.fromLTRB(16.w, 8.h, 16.w, 4.h),
                  child: Row(children: [
                    Text('Kişiler', style: TextStyle(color: Colors.white54, fontSize: 12.sp, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    Text('${_selected.length} seçildi', style: TextStyle(color: ColorsManager.darkPrimary, fontSize: 12.sp)),
                  ]),
                ),
                const Divider(height: 1, color: Colors.white10),
                // Kişi listesi
                Expanded(
                  child: _contacts.isEmpty
                      ? Center(child: Text('Kişi listesi boş', style: TextStyle(color: Colors.white38)))
                      : ColoredBox(
                          color: const Color(0xFF0D0D0D),
                          child: ListView.builder(
                          itemCount: _contacts.length,
                          itemBuilder: (ctx, i) {
                            final c = _contacts[i];
                            final uid = c['uid'] as String;
                            final selected = _selected.contains(uid);
                            final photo = (c['profilePic'] ?? '').toString();
                            return ListTile(
                              tileColor: const Color(0xFF0D0D0D),
                              contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 2.h),
                              leading: CircleAvatar(
                                radius: 22.r,
                                backgroundColor: const Color(0xFF1A1A1A),
                                backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                                child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white38) : null,
                              ),
                              title: Text(c['name'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
                              subtitle: Text('@${(c['username'] ?? capFirst(''))}',
                                  style: TextStyle(color: Colors.white38, fontSize: 12.sp)),
                              trailing: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                width: 26, height: 26,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: selected ? ColorsManager.darkPrimary : Colors.transparent,
                                  border: Border.all(
                                    color: selected ? ColorsManager.darkPrimary : Colors.white24,
                                    width: 2,
                                  ),
                                ),
                                child: selected ? const Icon(Icons.check, size: 14, color: Colors.white) : null,
                              ),
                              onTap: () => setState(() {
                                if (selected) _selected.remove(uid);
                                else _selected.add(uid);
                              }),
                            );
                          },
                        )
                          ),
                ),
              ],
            ),
    );
  }
}
