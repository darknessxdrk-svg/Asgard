import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../themes/colors.dart';
import '../../../services/agora_token_service.dart';
import '../../../services/notification_service.dart';

class CallScreen extends StatefulWidget {
  final String callId;
  final String calleeName;
  final String calleeUID;
  final bool isVideoCall;
  final bool isIncoming;
  final String calleeMToken; // FCM bildirimi için

  static const String _appId =
      String.fromEnvironment('AGORA_APP_ID', defaultValue: '');
  static const String _appCertificate =
      String.fromEnvironment('AGORA_APP_CERTIFICATE', defaultValue: '');

  const CallScreen({
    super.key,
    required this.callId,
    required this.calleeName,
    required this.calleeUID,
    this.isVideoCall = false,
    this.isIncoming = false,
    this.calleeMToken = '',
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  RtcEngine? _engine;
  bool _joined = false;
  bool _remoteJoined = false;
  bool _muted = false;
  bool _speakerOn = true;
  bool _cameraOn = true;
  int? _remoteUid;
  int _seconds = 0;
  bool _callAnswered = false;
  AudioPlayer? _ringtonePlayer;

  // Firestore call doc ref
  late final _callRef = FirebaseFirestore.instance
      .collection('calls')
      .doc(widget.callId);
  final _myUID = FirebaseAuth.instance.currentUser?.uid ?? '';

  @override
  void initState() {
    super.initState();
    if (CallScreen._appId.isEmpty) return;
    if (!widget.isIncoming) {
      // Sadece arayan taraf arama belgesi oluşturur
      _createCallDoc();
    } else {
      // Aranan taraf: zaten cevaplandı, direkt Agora'ya bağlan
      _callAnswered = true;
      _initAgora();
      _startTimer();
    }
    _listenCallDoc();
  }

  // Arayanın Firestore'a çağrı belgesi yazması
  Future<void> _playRingtone() async {
    try {
      _ringtonePlayer = AudioPlayer();
      await _ringtonePlayer!.setAsset('assets/sounds/ringtone.mp3').catchError((_) async {
        // Ses dosyası yoksa sistem URL'i dene
        await _ringtonePlayer!.setUrl(
          'https://www.soundjay.com/phone/sounds/phone-calling-1.mp3',
        );
      });
      await _ringtonePlayer!.setLoopMode(LoopMode.one);
      await _ringtonePlayer!.play();
    } catch (_) {}
  }

  void _stopRingtone() {
    _ringtonePlayer?.stop();
    _ringtonePlayer?.dispose();
    _ringtonePlayer = null;
  }

  Future<void> _createCallDoc() async {
    final callerName = FirebaseAuth.instance.currentUser?.displayName ??
        FirebaseAuth.instance.currentUser?.email?.split('@').first ?? '';
    await _callRef.set({
      'callerId': _myUID,
      'calleeId': widget.calleeUID,
      'callerName': callerName,
      'isVideo': widget.isVideoCall,
      'status': 'ringing',
      'createdAt': FieldValue.serverTimestamp(),
    });
    // FCM bildirimi gönder - uygulama kapalıyken de gelir
    if (widget.calleeMToken.isNotEmpty) {
      try {
        final service = NotificationService();
        await service.sendPushMessage(
          widget.calleeMToken,
          '',
          widget.isVideoCall ? '📹 Görüntülü arama geliyor...' : '📞 Sesli arama geliyor...',
          callerName,
          _myUID,
          null,
        );
      } catch (_) {}
    }
    // 45 saniye sonra cevap yoksa cevapsız arama olarak işaretle
    Future.delayed(const Duration(seconds: 45), () async {
      try {
        final snap = await _callRef.get();
        if (snap.exists && snap.data()?['status'] == 'ringing') {
          await _callRef.update({'status': 'missed'});
          // Cevapsız arama geçmişini her iki tarafa kaydet
          final batch = FirebaseFirestore.instance.batch();
          final missedData = {
            'callerId': _myUID,
            'calleeId': widget.calleeUID,
            'callerName': FirebaseAuth.instance.currentUser?.displayName ?? '',
            'isVideo': widget.isVideoCall,
            'status': 'missed',
            'createdAt': FieldValue.serverTimestamp(),
          };
          batch.set(
            FirebaseFirestore.instance.collection('users').doc(_myUID).collection('call_history').doc(),
            {...missedData, 'isMissed': false, 'direction': 'outgoing'},
          );
          batch.set(
            FirebaseFirestore.instance.collection('users').doc(widget.calleeUID).collection('call_history').doc(),
            {...missedData, 'isMissed': true, 'direction': 'incoming'},
          );
          await batch.commit();
          if (mounted) _endCall();
        }
      } catch (_) {}
    });
  }

  // Aranan kişi cevapladığında tetiklenir
  void _listenCallDoc() {
    // Arayan: çevirme sesi başlat
    if (!widget.isIncoming) _playRingtone();
    _callRef.snapshots().listen((snap) {
      if (!snap.exists || !mounted) return;
      final status = snap.data()?['status'] as String? ?? '';
      if (status == 'answered' && !_callAnswered && !widget.isIncoming) {
        // Karşı taraf cevapladı - çevirme sesini durdur
        _stopRingtone();
        _callAnswered = true;
        _initAgora();
        _startTimer();
      } else if (status == 'ended') {
        _endCall();
      } else if (status == 'rejected') {
        _showSnack('Arama reddedildi');
        _endCall();
      }
    });
  }

  void _startTimer() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() => _seconds++);
      return _callAnswered;
    });
  }

  String get _timeStr {
    final m = _seconds ~/ 60;
    final s = _seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  Future<void> _initAgora() async {
    await [
      Permission.microphone,
      if (widget.isVideoCall) Permission.camera,
    ].request();

    _engine = createAgoraRtcEngine();
    await _engine!.initialize(RtcEngineContext(appId: CallScreen._appId));

    _engine!.registerEventHandler(RtcEngineEventHandler(
      onJoinChannelSuccess: (connection, elapsed) {
        if (mounted) setState(() => _joined = true);
      },
      onUserJoined: (connection, remoteUid, elapsed) {
        if (mounted) setState(() {
          _remoteJoined = true;
          _remoteUid = remoteUid;
        });
      },
      onUserOffline: (connection, remoteUid, reason) {
        if (mounted) {
          setState(() { _remoteJoined = false; _remoteUid = null; });
          _endCall();
        }
      },
      onError: (err, msg) {
        if (mounted) {
          _showSnack('Bağlantı hatası: $err - Agora Console'da Token Security kapalı olmalı');
        }
      },
      onConnectionStateChanged: (connection, state, reason) {
        if (state == ConnectionStateType.connectionStateFailed && mounted) {
          _showSnack('Agora bağlantısı başarısız. Token Security kapalı mı?');
        }
      },
    ));

    if (widget.isVideoCall) {
      await _engine!.enableVideo();
      await _engine!.startPreview();
    }

    // Token üret (App Certificate varsa), yoksa boş string kullan
    final token = AgoraTokenService.buildToken(
      channelName: widget.callId,
      uid: 0,
      expireSeconds: 3600,
    ) ?? '';

    await _engine!.joinChannel(
      token: token,
      channelId: widget.callId,
      uid: 0,
      options: const ChannelMediaOptions(
        channelProfile: ChannelProfileType.channelProfileCommunication,
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
      ),
    );
  }

  void _endCall() {
    _stopRingtone();
    _callRef.update({'status': 'ended'}).catchError((_) {});
    // Arama geçmişine kaydet
    if (_callAnswered) {
      final historyData = {
        'callerId': _myUID,
        'calleeId': widget.calleeUID,
        'callerName': FirebaseAuth.instance.currentUser?.displayName ?? '',
        'isVideo': widget.isVideoCall,
        'status': 'ended',
        'duration': _seconds,
        'createdAt': FieldValue.serverTimestamp(),
      };
      FirebaseFirestore.instance.collection('users').doc(_myUID)
          .collection('call_history').add({...historyData, 'direction': 'outgoing'}).catchError((_) {});
      FirebaseFirestore.instance.collection('users').doc(widget.calleeUID)
          .collection('call_history').add({...historyData, 'direction': 'incoming'}).catchError((_) {});
    }
    _engine?.leaveChannel();
    _engine?.release();
    if (mounted) Navigator.pop(context);
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: const Color(0xFF1A1A1A)));
  }

  @override
  void dispose() {
    _stopRingtone();
    _callRef.update({'status': 'ended'}).catchError((_) {});
    _engine?.leaveChannel();
    _engine?.release();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (CallScreen._appId.isEmpty) {
      return _setupScreen(context);
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Stack(children: [
        // Video alanı
        if (widget.isVideoCall) ...[
          if (_remoteJoined && _remoteUid != null)
            AgoraVideoView(
              controller: VideoViewController.remote(
                rtcEngine: _engine!,
                canvas: VideoCanvas(uid: _remoteUid),
                connection: RtcConnection(channelId: widget.callId),
              ),
            )
          else
            _avatarView(),
          if (_cameraOn && _engine != null)
            Positioned(
              top: 60, right: 16, width: 100, height: 150,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: _engine!,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                ),
              ),
            ),
        ] else
          _avatarView(),

        // Üst bilgi
        Positioned(
          top: 0, left: 0, right: 0,
          child: SafeArea(child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Text(widget.calleeName,
                  style: const TextStyle(color: Colors.white, fontSize: 24,
                      fontWeight: FontWeight.bold,
                      shadows: [Shadow(color: Colors.black54, blurRadius: 8)])),
              const SizedBox(height: 4),
              Text(
                _callAnswered
                    ? (_remoteJoined ? _timeStr : 'Bağlanıyor...')
                    : 'Çağrılıyor...',
                style: TextStyle(
                    color: _remoteJoined ? Colors.greenAccent : Colors.white60,
                    fontSize: 14),
              ),
            ]),
          )),
        ),

        // Alt kontroller
        Positioned(
          bottom: 48, left: 0, right: 0,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            if (_callAnswered) ...[
              _ctrlBtn(
                icon: _muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                label: _muted ? 'Sessiz' : 'Mikrofon',
                active: _muted,
                onTap: () {
                  setState(() => _muted = !_muted);
                  _engine?.muteLocalAudioStream(_muted);
                },
              ),
            ],
            // Kapat
            GestureDetector(
              onTap: _endCall,
              child: Container(
                width: 72, height: 72,
                decoration: const BoxDecoration(
                    color: Colors.red, shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: Colors.red, blurRadius: 20, spreadRadius: 2)]),
                child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 36),
              ),
            ),
            if (_callAnswered) ...[
              if (widget.isVideoCall)
                _ctrlBtn(
                  icon: _cameraOn ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                  label: 'Kamera',
                  active: !_cameraOn,
                  onTap: () {
                    setState(() => _cameraOn = !_cameraOn);
                    _engine?.muteLocalVideoStream(!_cameraOn);
                  },
                )
              else
                _ctrlBtn(
                  icon: _speakerOn ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                  label: 'Hoparlör',
                  active: !_speakerOn,
                  onTap: () {
                    setState(() => _speakerOn = !_speakerOn);
                    _engine?.setEnableSpeakerphone(_speakerOn);
                  },
                ),
            ],
          ]),
        ),
      ]),
    );
  }

  Widget _avatarView() => Container(
    color: const Color(0xFF0A0A0A),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 120, height: 120,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            colors: [ColorsManager.darkPrimary, ColorsManager.darkPrimary.withOpacity(0.4)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.3), blurRadius: 30, spreadRadius: 8)],
        ),
        child: Center(child: Text(
          widget.calleeName.isNotEmpty ? widget.calleeName[0].toUpperCase() : '?',
          style: const TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.bold),
        )),
      ),
    ])),
  );

  Widget _ctrlBtn({required IconData icon, required String label, required bool active, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(
          width: 60, height: 60,
          decoration: BoxDecoration(
            color: active ? ColorsManager.darkPrimary.withOpacity(0.3) : const Color(0xFF1E1E1E),
            shape: BoxShape.circle,
            border: Border.all(color: active ? ColorsManager.darkPrimary : Colors.white12),
          ),
          child: Icon(icon, color: active ? ColorsManager.darkPrimary : Colors.white70, size: 28),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 11)),
      ]),
    );
  }

  Widget _setupScreen(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF0D0D0D),
    appBar: AppBar(
      backgroundColor: const Color(0xFF111111),
      title: Text(widget.isVideoCall ? 'Görüntülü Arama' : 'Sesli Arama',
          style: const TextStyle(color: Colors.white)),
      iconTheme: const IconThemeData(color: Colors.white),
    ),
    body: Center(child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.phone_disabled_rounded, size: 64, color: ColorsManager.darkPrimary),
        const SizedBox(height: 20),
        const Text('AGORA_APP_ID eksik',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text(
          '1. console.agora.io → ücretsiz hesap\n'
          '2. Yeni proje → App ID kopyala\n'
          '3. GitHub Secret: AGORA_APP_ID\n'
          '4. Yeniden build al',
          style: TextStyle(color: Colors.white54, fontSize: 13, height: 1.7),
          textAlign: TextAlign.center,
        ),
      ]),
    )),
  );
}

// ── Gelen Arama Ekranı ────────────────────────────────────────────────────────
class IncomingCallScreen extends StatefulWidget {
  final String callId;
  final String callerName;
  final String callerUID;
  final bool isVideo;

  const IncomingCallScreen({
    super.key,
    required this.callId,
    required this.callerName,
    required this.callerUID,
    required this.isVideo,
  });

  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  AudioPlayer? _ringtone;

  @override
  void initState() {
    super.initState();
    _playRingtone();
  }

  Future<void> _playRingtone() async {
    try {
      _ringtone = AudioPlayer();
      await _ringtone!.setAsset('assets/sounds/incoming_call.mp3').catchError((_) async {
        await _ringtone!.setUrl(
          'https://www.soundjay.com/phone/sounds/phone-calling-1.mp3',
        );
      });
      await _ringtone!.setLoopMode(LoopMode.one);
      await _ringtone!.play();
    } catch (_) {}
  }

  void _stopRingtone() {
    _ringtone?.stop();
    _ringtone?.dispose();
    _ringtone = null;
  }

  @override
  void dispose() {
    _stopRingtone();
    super.dispose();
  }

  @override
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(height: 60),
            Column(children: [
              Container(
                width: 120, height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [ColorsManager.darkPrimary, ColorsManager.darkPrimary.withOpacity(0.4)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.4), blurRadius: 40, spreadRadius: 10)],
                ),
                child: Center(child: Text(
                  widget.callerName.isNotEmpty ? widget.callerName[0].toUpperCase() : '?',
                  style: const TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.bold),
                )),
              ),
              const SizedBox(height: 24),
              Text(widget.callerName,
                  style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(widget.isVideo ? Icons.videocam_rounded : Icons.call_rounded,
                    color: Colors.white54, size: 16),
                const SizedBox(width: 6),
                Text(widget.isVideo ? 'Görüntülü arama geliyor...' : 'Sesli arama geliyor...',
                    style: const TextStyle(color: Colors.white54, fontSize: 15)),
              ]),
            ]),
            Padding(
              padding: const EdgeInsets.only(bottom: 60),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                // Reddet
                Column(children: [
                  GestureDetector(
                    onTap: () {
                      _stopRingtone();
                      FirebaseFirestore.instance.collection('calls').doc(widget.callId)
                          .update({'status': 'rejected'});
                      Navigator.pop(context);
                    },
                    child: Container(
                      width: 72, height: 72,
                      decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: Colors.red, blurRadius: 20, spreadRadius: 2)]),
                      child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 36),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Reddet', style: TextStyle(color: Colors.white54, fontSize: 12)),
                ]),
                // Kabul Et
                Column(children: [
                  GestureDetector(
                    onTap: () async {
                      _stopRingtone();
                      await FirebaseFirestore.instance.collection('calls').doc(widget.callId)
                          .update({'status': 'answered'});
                      if (context.mounted) {
                        Navigator.pushReplacement(context, MaterialPageRoute(
                          builder: (_) => CallScreen(
                            callId: widget.callId,
                            calleeName: widget.callerName,
                            calleeUID: widget.callerUID,
                            isVideoCall: widget.isVideo,
                            isIncoming: true,
                          ),
                        ));
                      }
                    },
                    child: Container(
                      width: 72, height: 72,
                      decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.6), blurRadius: 20, spreadRadius: 2)]),
                      child: Icon(widget.isVideo ? Icons.videocam_rounded : Icons.call_rounded,
                          color: Colors.white, size: 36),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Kabul Et', style: TextStyle(color: Colors.white54, fontSize: 12)),
                ]),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}
