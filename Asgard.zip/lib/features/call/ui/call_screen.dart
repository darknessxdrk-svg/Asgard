import 'dart:async';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../themes/colors.dart';
import '../../../services/notification_service.dart';
import '../../../services/agora_token_service.dart';

class CallScreen extends StatefulWidget {
  final String callId;
  final String calleeName;
  final String calleeUID;
  final bool isVideoCall;
  final bool isIncoming;
  final String calleeMToken;

  const CallScreen({
    super.key,
    required this.callId,
    required this.calleeName,
    required this.calleeUID,
    this.isVideoCall = false,
    this.isIncoming = false,
    this.calleeMToken = '',
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  RtcEngine? _engine;
  bool _joined = false;
  bool _remoteJoined = false;
  bool _muted = false;
  bool _speakerOn = true;
  bool _cameraOn = true;
  int? _remoteUid;
  int _seconds = 0;
  bool _callAnswered = false;
  String _statusText = 'Çağrılıyor...';
  Timer? _timer;
  StreamSubscription? _callSub;
  String _appId = ''; // server'dan gelecek

  late final _callRef = FirebaseFirestore.instance
      .collection('calls')
      .doc(widget.callId);
  final _myUID = FirebaseAuth.instance.currentUser?.uid ?? '';

  @override
  void initState() {
    super.initState();
    if (!widget.isIncoming) {
      _createCallDoc();
    } else {
      _callAnswered = true;
      _statusText = 'Bağlanıyor...';
      _initAgora();
      _startTimer();
    }
    _listenCallDoc();
  }

  void _playTone() {
    try {
      FlutterRingtonePlayer().playRingtone(
        looping: true,
        volume: 1.0,
      );
    } catch (e) {
      try {
        FlutterRingtonePlayer().play(
          android: AndroidSounds.ringtone,
          looping: true,
          volume: 1.0,
          asAlarm: false,
        );
      } catch (_) {}
    }
  }

  void _stopTone() {
    try {
      FlutterRingtonePlayer().stop();
    } catch (_) {}
  }

  Future<void> _createCallDoc() async {
    final callerName = FirebaseAuth.instance.currentUser?.displayName ??
        FirebaseAuth.instance.currentUser?.email?.split('@').first ?? '';
    await _callRef.set({
      'callerId': _myUID,
      'calleeId': widget.calleeUID,
      'callerName': callerName,
      'isVideo': widget.isVideoCall,
      'status': 'ringing',
      'createdAt': FieldValue.serverTimestamp(),
    });

    // FCM bildirimi
    if (widget.calleeMToken.isNotEmpty || widget.calleeUID.isNotEmpty) {
      try {
        final service = NotificationService();
        await service.sendCallNotification(
          receiverToken: widget.calleeMToken,
          callerName: callerName,
          callerUID: _myUID,
          callId: widget.callId,
          isVideo: widget.isVideoCall,
          receiverUID: widget.calleeUID,
        );
      } catch (_) {}
    }

    // 45 sn cevap yoksa missed
    Future.delayed(const Duration(seconds: 45), () async {
      if (!mounted) return;
      try {
        final snap = await _callRef.get();
        if (snap.exists && snap.data()?['status'] == 'ringing') {
          await _callRef.update({'status': 'missed'});
          await _saveMissedCall();
          if (mounted) _endCall();
        }
      } catch (_) {}
    });
  }

  void _listenCallDoc() {
    // Arayan: telefon çevirme sesi
    if (!widget.isIncoming) {
      _playTone();
      if (mounted) setState(() => _statusText = 'Çağrılıyor...');
    }

    _callSub = _callRef.snapshots().listen((snap) {
      if (!snap.exists || !mounted) return;
      final status = snap.data()?['status'] as String? ?? '';

      if (status == 'answered' && !_callAnswered && !widget.isIncoming) {
        _stopTone();
        _callAnswered = true;
        if (mounted) setState(() => _statusText = 'Bağlanıyor...');
        _initAgora();
        _startTimer();
      } else if (status == 'ended') {
        _endCall();
      } else if (status == 'rejected') {
        _stopTone();
        if (mounted) setState(() => _statusText = 'Arama reddedildi');
        Future.delayed(const Duration(seconds: 1), _endCall);
      } else if (status == 'missed') {
        if (mounted) setState(() => _statusText = 'Cevap yok');
        Future.delayed(const Duration(seconds: 1), _endCall);
      }
    });
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        _seconds++;
        if (_remoteJoined) {
          final m = _seconds ~/ 60;
          final s = _seconds % 60;
          _statusText =
              '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
        } else {
          _statusText = 'Bağlanıyor...';
        }
      });
    });
  }

  Future<void> _initAgora() async {
    await [
      Permission.microphone,
      if (widget.isVideoCall) Permission.camera,
    ].request();

    // AppId dart-define'dan, token local'de üretiliyor
    const appId = String.fromEnvironment('AGORA_APP_ID', defaultValue: '');
    _appId = appId;

    if (_appId.isEmpty) {
      if (mounted) setState(() => _statusText = 'Agora yapılandırılmamış');
      return;
    }

    final agoraToken = AgoraTokenService.buildToken(channelName: widget.callId);

    _engine = createAgoraRtcEngine();
    await _engine!.initialize(RtcEngineContext(appId: _appId));

    _engine!.registerEventHandler(RtcEngineEventHandler(
      onJoinChannelSuccess: (connection, elapsed) {
        if (mounted) setState(() => _joined = true);
      },
      onUserJoined: (connection, remoteUid, elapsed) {
        if (mounted) setState(() {
          _remoteJoined = true;
          _remoteUid = remoteUid;
          _statusText = '00:00';
          _seconds = 0;
        });
      },
      onUserOffline: (connection, remoteUid, reason) {
        if (mounted) {
          setState(() { _remoteJoined = false; _remoteUid = null; });
          _endCall();
        }
      },
      onError: (err, msg) {
        if (mounted) setState(() => _statusText = 'Bağlantı hatası ($err)');
      },
      onConnectionStateChanged: (connection, state, reason) {
        if (!mounted) return;
        if (state == ConnectionStateType.connectionStateFailed) {
          setState(() => _statusText = 'Bağlantı başarısız');
        } else if (state == ConnectionStateType.connectionStateReconnecting) {
          setState(() => _statusText = 'Yeniden bağlanıyor...');
        }
      },
    ));

    if (widget.isVideoCall) {
      await _engine!.enableVideo();
      await _engine!.startPreview();
    }

    await _engine!.joinChannel(
      token: agoraToken ?? '',
      channelId: widget.callId,
      uid: 0,
      options: ChannelMediaOptions(
        channelProfile: ChannelProfileType.channelProfileCommunication,
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
        publishMicrophoneTrack: true,
        publishCameraTrack: widget.isVideoCall,
        autoSubscribeAudio: true,
        autoSubscribeVideo: widget.isVideoCall,
      ),
    );

    // 15 saniye içinde bağlanamazsa durum güncelle
    Future.delayed(const Duration(seconds: 15), () {
      if (mounted && !_joined) {
        setState(() => _statusText = 'Bağlanılamadı - Agora ayarlarını kontrol et');
      }
    });
  }

  Future<void> _saveMissedCall() async {
    final callerName = FirebaseAuth.instance.currentUser?.displayName ?? '';
    final batch = FirebaseFirestore.instance.batch();
    final data = {
      'callerId': _myUID,
      'calleeId': widget.calleeUID,
      'callerName': callerName,
      'isVideo': widget.isVideoCall,
      'status': 'missed',
      'createdAt': FieldValue.serverTimestamp(),
    };
    batch.set(
      FirebaseFirestore.instance.collection('users').doc(_myUID)
          .collection('call_history').doc(),
      {...data, 'isMissed': false, 'direction': 'outgoing'},
    );
    batch.set(
      FirebaseFirestore.instance.collection('users').doc(widget.calleeUID)
          .collection('call_history').doc(),
      {...data, 'isMissed': true, 'direction': 'incoming'},
    );
    await batch.commit().catchError((_) {});
  }

  void _endCall() {
    _stopTone();
    _timer?.cancel();
    _callSub?.cancel();
    _callRef.update({'status': 'ended'}).catchError((_) {});
    if (_callAnswered && _seconds > 0) {
      final data = {
        'callerId': _myUID,
        'calleeId': widget.calleeUID,
        'callerName': FirebaseAuth.instance.currentUser?.displayName ?? '',
        'isVideo': widget.isVideoCall,
        'status': 'ended',
        'duration': _seconds,
        'createdAt': FieldValue.serverTimestamp(),
      };
      FirebaseFirestore.instance.collection('users').doc(_myUID)
          .collection('call_history').add({...data, 'direction': 'outgoing'})
          .catchError((_) {});
      FirebaseFirestore.instance.collection('users').doc(widget.calleeUID)
          .collection('call_history').add({...data, 'direction': 'incoming'})
          .catchError((_) {});
    }
    _engine?.leaveChannel();
    _engine?.release();
    _engine = null; // dispose()'un çift çalışmasını engelle
    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    _stopTone();
    _timer?.cancel();
    _callSub?.cancel();
    // _endCall() çağrıldıysa zaten status güncellendi — çift yazımı engelle
    if (_engine != null) {
      _callRef.update({'status': 'ended'}).catchError((_) {});
      _engine?.leaveChannel();
      _engine?.release();
      _engine = null;
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_appId.isEmpty && _engine == null) return _setupScreen(context);

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Stack(children: [
        if (widget.isVideoCall) ...[
          if (_remoteJoined && _remoteUid != null)
            AgoraVideoView(
              controller: VideoViewController.remote(
                rtcEngine: _engine!,
                canvas: VideoCanvas(uid: _remoteUid),
                connection: RtcConnection(channelId: widget.callId),
              ),
            )
          else
            _avatarView(),
          if (_cameraOn && _engine != null)
            Positioned(
              top: 60, right: 16, width: 100, height: 150,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: _engine!,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                ),
              ),
            ),
        ] else
          _avatarView(),

        Positioned(
          top: 0, left: 0, right: 0,
          child: SafeArea(child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Text(widget.calleeName,
                  style: const TextStyle(color: Colors.white, fontSize: 24,
                      fontWeight: FontWeight.bold,
                      shadows: [Shadow(color: Colors.black54, blurRadius: 8)])),
              const SizedBox(height: 4),
              Text(_statusText,
                  style: TextStyle(
                      color: _remoteJoined ? Colors.greenAccent : Colors.white60,
                      fontSize: 14)),
            ]),
          )),
        ),

        Positioned(
          bottom: 48, left: 0, right: 0,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            if (_callAnswered) ...[
              _ctrlBtn(
                icon: _muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                label: _muted ? 'Sessiz' : 'Mikrofon',
                active: _muted,
                onTap: () {
                  setState(() => _muted = !_muted);
                  _engine?.muteLocalAudioStream(_muted);
                },
              ),
            ] else
              const SizedBox(width: 60),
            GestureDetector(
              onTap: _endCall,
              child: Column(children: [
                Container(
                  width: 72, height: 72,
                  decoration: const BoxDecoration(
                      color: Colors.red, shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.red, blurRadius: 20, spreadRadius: 2)]),
                  child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 36),
                ),
                const SizedBox(height: 6),
                const Text('Bitir', style: TextStyle(color: Colors.white38, fontSize: 11)),
              ]),
            ),
            if (_callAnswered) ...[
              if (widget.isVideoCall)
                _ctrlBtn(
                  icon: _cameraOn ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                  label: 'Kamera',
                  active: !_cameraOn,
                  onTap: () {
                    setState(() => _cameraOn = !_cameraOn);
                    _engine?.muteLocalVideoStream(!_cameraOn);
                  },
                )
              else
                _ctrlBtn(
                  icon: _speakerOn ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                  label: 'Hoparlör',
                  active: !_speakerOn,
                  onTap: () {
                    setState(() => _speakerOn = !_speakerOn);
                    _engine?.setEnableSpeakerphone(_speakerOn);
                  },
                ),
            ] else
              const SizedBox(width: 60),
          ]),
        ),
      ]),
    );
  }

  Widget _avatarView() => Container(
    color: const Color(0xFF0A0A0A),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 120, height: 120,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            colors: [ColorsManager.darkPrimary, ColorsManager.darkPrimary.withOpacity(0.4)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.3),
              blurRadius: 30, spreadRadius: 8)],
        ),
        child: Center(child: Text(
          widget.calleeName.isNotEmpty ? widget.calleeName[0].toUpperCase() : '?',
          style: const TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.bold),
        )),
      ),
      const SizedBox(height: 20),
      if (!_callAnswered)
        Text(widget.calleeName,
            style: const TextStyle(color: Colors.white70, fontSize: 18)),
    ])),
  );

  Widget _ctrlBtn({required IconData icon, required String label,
      required bool active, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(
          width: 60, height: 60,
          decoration: BoxDecoration(
            color: active ? ColorsManager.darkPrimary.withOpacity(0.3) : const Color(0xFF1E1E1E),
            shape: BoxShape.circle,
            border: Border.all(color: active ? ColorsManager.darkPrimary : Colors.white12),
          ),
          child: Icon(icon, color: active ? ColorsManager.darkPrimary : Colors.white70, size: 28),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 11)),
      ]),
    );
  }

  Widget _setupScreen(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF0D0D0D),
    appBar: AppBar(
      backgroundColor: const Color(0xFF111111),
      title: Text(widget.isVideoCall ? 'Görüntülü Arama' : 'Sesli Arama',
          style: const TextStyle(color: Colors.white)),
      iconTheme: const IconThemeData(color: Colors.white),
    ),
    body: Center(child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.phone_disabled_rounded, size: 64, color: ColorsManager.darkPrimary),
        const SizedBox(height: 20),
        const Text('AGORA_APP_ID eksik',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
      ]),
    )),
  );
}

// ── Gelen Arama Ekranı ────────────────────────────────────────────────────────
class IncomingCallScreen extends StatefulWidget {
  final String callId;
  final String callerName;
  final String callerUID;
  final bool isVideo;

  const IncomingCallScreen({
    super.key,
    required this.callId,
    required this.callerName,
    required this.callerUID,
    required this.isVideo,
  });

  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  @override
  void initState() {
    super.initState();
    _playTone();
  }

  void _playTone() {
    try {
      FlutterRingtonePlayer().playRingtone(
        looping: true,
        volume: 1.0,
      );
    } catch (e) {
      try {
        FlutterRingtonePlayer().play(
          android: AndroidSounds.ringtone,
          looping: true,
          volume: 1.0,
          asAlarm: false,
        );
      } catch (_) {}
    }
  }

  void _stopTone() {
    try {
      FlutterRingtonePlayer().stop();
    } catch (_) {}
  }

  @override
  void dispose() {
    _stopTone();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(height: 60),
            Column(children: [
              Container(
                width: 120, height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [ColorsManager.darkPrimary,
                        ColorsManager.darkPrimary.withOpacity(0.4)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  boxShadow: [BoxShadow(
                      color: ColorsManager.darkPrimary.withOpacity(0.4),
                      blurRadius: 40, spreadRadius: 10)],
                ),
                child: Center(child: Text(
                  widget.callerName.isNotEmpty
                      ? widget.callerName[0].toUpperCase() : '?',
                  style: const TextStyle(color: Colors.white, fontSize: 52,
                      fontWeight: FontWeight.bold),
                )),
              ),
              const SizedBox(height: 24),
              Text(widget.callerName,
                  style: const TextStyle(color: Colors.white, fontSize: 28,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(widget.isVideo ? Icons.videocam_rounded : Icons.call_rounded,
                    color: Colors.white54, size: 16),
                const SizedBox(width: 6),
                Text(widget.isVideo
                    ? 'Görüntülü arama geliyor...'
                    : 'Sesli arama geliyor...',
                    style: const TextStyle(color: Colors.white54, fontSize: 15)),
              ]),
            ]),
            Padding(
              padding: const EdgeInsets.only(bottom: 60),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(children: [
                    GestureDetector(
                      onTap: () {
                        _stopTone();
                        FirebaseFirestore.instance
                            .collection('calls').doc(widget.callId)
                            .update({'status': 'rejected'});
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: 72, height: 72,
                        decoration: const BoxDecoration(
                            color: Colors.red, shape: BoxShape.circle,
                            boxShadow: [BoxShadow(color: Colors.red,
                                blurRadius: 20, spreadRadius: 2)]),
                        child: const Icon(Icons.call_end_rounded,
                            color: Colors.white, size: 36),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Reddet',
                        style: TextStyle(color: Colors.white54, fontSize: 12)),
                  ]),
                  Column(children: [
                    GestureDetector(
                      onTap: () async {
                        _stopTone();
                        await FirebaseFirestore.instance
                            .collection('calls').doc(widget.callId)
                            .update({'status': 'answered'});
                        if (context.mounted) {
                          Navigator.pushReplacement(context,
                            MaterialPageRoute(
                              builder: (_) => CallScreen(
                                callId: widget.callId,
                                calleeName: widget.callerName,
                                calleeUID: widget.callerUID,
                                isVideoCall: widget.isVideo,
                                isIncoming: true,
                              ),
                            ),
                          );
                        }
                      },
                      child: Container(
                        width: 72, height: 72,
                        decoration: BoxDecoration(
                            color: Colors.green, shape: BoxShape.circle,
                            boxShadow: [BoxShadow(
                                color: Colors.green.withOpacity(0.6),
                                blurRadius: 20, spreadRadius: 2)]),
                        child: Icon(
                            widget.isVideo
                                ? Icons.videocam_rounded
                                : Icons.call_rounded,
                            color: Colors.white, size: 36),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Kabul Et',
                        style: TextStyle(color: Colors.white54, fontSize: 12)),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
