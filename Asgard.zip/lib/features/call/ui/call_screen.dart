import 'package:flutter/material.dart';
import '../../../themes/colors.dart';

class CallScreen extends StatefulWidget {
  final String callId;
  final String calleeName;
  final bool isVideoCall;

  const CallScreen({
    super.key,
    required this.callId,
    required this.calleeName,
    this.isVideoCall = false,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  int _seconds = 0;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() => _seconds++);
      return true;
    });
  }

  String get _timeStr {
    final m = _seconds ~/ 60;
    final s = _seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Stack(children: [
        Container(
          color: const Color(0xFF0A0A0A),
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      ColorsManager.darkPrimary,
                      ColorsManager.darkPrimary.withOpacity(0.4)
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: ColorsManager.darkPrimary.withOpacity(0.3),
                      blurRadius: 30,
                      spreadRadius: 8,
                    )
                  ],
                ),
                child: Center(
                  child: Text(
                    widget.calleeName.isNotEmpty
                        ? widget.calleeName[0].toUpperCase()
                        : '?',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 52,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ]),
          ),
        ),
        Positioned(
          top: 0, left: 0, right: 0,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                Text(widget.calleeName,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 24,
                        fontWeight: FontWeight.bold,
                        shadows: [Shadow(color: Colors.black54, blurRadius: 8)])),
                const SizedBox(height: 4),
                Text(_timeStr,
                    style: const TextStyle(color: Colors.white60, fontSize: 14)),
              ]),
            ),
          ),
        ),
        Positioned(
          bottom: 48, left: 0, right: 0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 72, height: 72,
                  decoration: const BoxDecoration(
                      color: Colors.red, shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.red, blurRadius: 20, spreadRadius: 2)]),
                  child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 36),
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
