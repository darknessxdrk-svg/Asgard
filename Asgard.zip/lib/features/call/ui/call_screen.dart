import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../themes/colors.dart';

/// Sesli ve görüntülü arama — Agora RTC
/// https://console.agora.io → ücretsiz hesap → proje oluştur → App ID al
/// GitHub Secrets: AGORA_APP_ID
class CallScreen extends StatefulWidget {
  final String callId;
  final String calleeName;
  final bool isVideoCall;

  static const String _appId =
      String.fromEnvironment('AGORA_APP_ID', defaultValue: '');

  const CallScreen({
    super.key,
    required this.callId,
    required this.calleeName,
    this.isVideoCall = false,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  RtcEngine? _engine;
  bool _joined = false;
  bool _remoteJoined = false;
  bool _muted = false;
  bool _speakerOn = true;
  bool _cameraOn = true;
  int? _remoteUid;

  @override
  void initState() {
    super.initState();
    if (CallScreen._appId.isNotEmpty) _initAgora();
  }

  Future<void> _initAgora() async {
    // İzinler
    await [Permission.microphone, if (widget.isVideoCall) Permission.camera]
        .request();

    _engine = createAgoraRtcEngine();
    await _engine!.initialize(RtcEngineContext(appId: CallScreen._appId));

    _engine!.registerEventHandler(RtcEngineEventHandler(
      onJoinChannelSuccess: (connection, elapsed) {
        if (mounted) setState(() => _joined = true);
      },
      onUserJoined: (connection, remoteUid, elapsed) {
        if (mounted) setState(() {
          _remoteJoined = true;
          _remoteUid = remoteUid;
        });
      },
      onUserOffline: (connection, remoteUid, reason) {
        if (mounted) setState(() {
          _remoteJoined = false;
          _remoteUid = null;
        });
        Navigator.pop(context);
      },
    ));

    if (widget.isVideoCall) {
      await _engine!.enableVideo();
      await _engine!.startPreview();
    }

    await _engine!.joinChannel(
      token: '',
      channelId: widget.callId,
      uid: 0,
      options: ChannelMediaOptions(
        channelProfile: ChannelProfileType.channelProfileCommunication,
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
      ),
    );
  }

  @override
  void dispose() {
    _engine?.leaveChannel();
    _engine?.release();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (CallScreen._appId.isEmpty) {
      return _setupScreen();
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: Stack(children: [
        // Video alanı
        if (widget.isVideoCall) ...[
          if (_remoteJoined && _remoteUid != null)
            AgoraVideoView(
              controller: VideoViewController.remote(
                rtcEngine: _engine!,
                canvas: VideoCanvas(uid: _remoteUid),
                connection: RtcConnection(channelId: widget.callId),
              ),
            )
          else
            _waitingView(),
          // Küçük kamera (kendi görüntü)
          if (_cameraOn)
            Positioned(
              top: 60, right: 16,
              width: 100, height: 150,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: _engine!,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                ),
              ),
            ),
        ] else
          _voiceCallView(),

        // Üst bilgi
        Positioned(
          top: 0, left: 0, right: 0,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                Text(widget.calleeName,
                    style: const TextStyle(color: Colors.white, fontSize: 22,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(
                  _remoteJoined ? 'Bağlandı' : (_joined ? 'Bekleniyor...' : 'Bağlanıyor...'),
                  style: TextStyle(
                    color: _remoteJoined ? Colors.greenAccent : Colors.white54,
                    fontSize: 14,
                  ),
                ),
              ]),
            ),
          ),
        ),

        // Alt kontroller
        Positioned(
          bottom: 40, left: 0, right: 0,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _ctrlBtn(
              icon: _muted ? Icons.mic_off : Icons.mic,
              color: _muted ? Colors.red : Colors.white24,
              onTap: () {
                setState(() => _muted = !_muted);
                _engine?.muteLocalAudioStream(_muted);
              },
            ),
            // Kapat
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 70, height: 70,
                decoration: const BoxDecoration(
                    color: Colors.red, shape: BoxShape.circle),
                child: const Icon(Icons.call_end, color: Colors.white, size: 32),
              ),
            ),
            if (widget.isVideoCall)
              _ctrlBtn(
                icon: _cameraOn ? Icons.videocam : Icons.videocam_off,
                color: _cameraOn ? Colors.white24 : Colors.red,
                onTap: () {
                  setState(() => _cameraOn = !_cameraOn);
                  _engine?.muteLocalVideoStream(!_cameraOn);
                },
              )
            else
              _ctrlBtn(
                icon: _speakerOn ? Icons.volume_up : Icons.volume_off,
                color: Colors.white24,
                onTap: () {
                  setState(() => _speakerOn = !_speakerOn);
                  _engine?.setEnableSpeakerphone(_speakerOn);
                },
              ),
          ]),
        ),
      ]),
    );
  }

  Widget _waitingView() => Container(
    color: const Color(0xFF1A1A1A),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      CircleAvatar(radius: 60, backgroundColor: const Color(0xFF2A2A2A),
          child: Text(widget.calleeName.isNotEmpty ? widget.calleeName[0].toUpperCase() : '?',
              style: const TextStyle(color: Colors.white, fontSize: 48))),
      const SizedBox(height: 20),
      Text(widget.calleeName,
          style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Bekleniyor...', style: TextStyle(color: Colors.white54)),
    ])),
  );

  Widget _voiceCallView() => Container(
    color: const Color(0xFF0D0D0D),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      CircleAvatar(radius: 80, backgroundColor: ColorsManager.darkPrimary.withOpacity(0.2),
          child: Text(widget.calleeName.isNotEmpty ? widget.calleeName[0].toUpperCase() : '?',
              style: const TextStyle(color: Colors.white, fontSize: 64))),
      const SizedBox(height: 24),
      Text(widget.calleeName,
          style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(
        _remoteJoined ? 'Bağlandı ✓' : (_joined ? 'Çağrılıyor...' : 'Bağlanıyor...'),
        style: TextStyle(color: _remoteJoined ? Colors.greenAccent : Colors.white54, fontSize: 16),
      ),
    ])),
  );

  Widget _ctrlBtn({required IconData icon, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 56, height: 56,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        child: Icon(icon, color: Colors.white, size: 28),
      ),
    );
  }

  Widget _setupScreen() => Scaffold(
    backgroundColor: const Color(0xFF0D0D0D),
    appBar: AppBar(
      backgroundColor: const Color(0xFF111111),
      title: Text(widget.isVideoCall ? 'Görüntülü Arama' : 'Sesli Arama',
          style: const TextStyle(color: Colors.white)),
      iconTheme: const IconThemeData(color: Colors.white),
    ),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.phone_disabled_rounded, size: 64, color: ColorsManager.darkPrimary),
          const SizedBox(height: 20),
          const Text('Arama yapılandırılmamış',
              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text(
            '1. console.agora.io → ücretsiz hesap\n'
            '2. Yeni proje → App ID kopyala\n'
            '3. GitHub Secret: AGORA_APP_ID\n'
            '4. main.yml\'e --dart-define ekle\n'
            '5. Yeniden build al',
            style: TextStyle(color: Colors.white54, fontSize: 13, height: 1.6),
            textAlign: TextAlign.center,
          ),
        ]),
      ),
    ),
  );
}
