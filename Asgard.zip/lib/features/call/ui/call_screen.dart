import 'dart:async';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../themes/colors.dart';
import '../../../services/notification_service.dart';
import '../../../helpers/app_state.dart';

// ─────────────────────────────────────────────────────────────────────────────
// ARAMA AKIŞI:
//
// ARAYAN:
//   initState → _createCallDoc() [status=ringing] → _listenCallDoc()
//   status==answered → _initAgora() → joinChannel(callId)
//   onUserJoined → bağlandı ✅
//
// ALAN:
//   IncomingCallScreen → Kabul Et → status=answered → CallScreen(isIncoming=true)
//   initState → _initAgora() → joinChannel(callId)
//   onJoinChannelSuccess → joined ✅
//   onUserJoined → karşı taraf da katıldı ✅
//
// CHANNEL ID: Firestore'daki callId — her iki taraf aynı channel'a join oluyor
// TOKEN: AGORA_APP_CERTIFICATE yoksa '' (test modu) — App Certificate kapalı olmalı
// ─────────────────────────────────────────────────────────────────────────────

class CallScreen extends StatefulWidget {
  final String callId;
  final String calleeName;
  final String calleeUID;
  final bool isVideoCall;
  final bool isIncoming;
  final String calleeMToken;

  static const String _appId =
      String.fromEnvironment('AGORA_APP_ID', defaultValue: '');

  const CallScreen({
    super.key,
    required this.callId,
    required this.calleeName,
    required this.calleeUID,
    this.isVideoCall = false,
    this.isIncoming = false,
    this.calleeMToken = '',
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  RtcEngine? _engine;
  bool _joined       = false;
  bool _remoteJoined = false;
  bool _muted        = false;
  bool _speakerOn    = true;
  bool _cameraOn     = true;
  int? _remoteUid;
  int  _seconds      = 0;
  bool _callAnswered = false;
  bool _endCallCalled = false;
  bool _agoraInitStarted = false; // çift _initAgora koruması

  String _statusText = '';
  Timer? _timer;
  StreamSubscription? _callSub;
  Timer? _missedCallTimer;

  late final DocumentReference _callRef = FirebaseFirestore.instance
      .collection('calls').doc(widget.callId);
  final String _myUID = FirebaseAuth.instance.currentUser?.uid ?? '';

  @override
  void initState() {
    super.initState();
    AppState.instance.isInCallScreen = true;

    if (CallScreen._appId.isEmpty) {
      setState(() => _statusText = 'AGORA_APP_ID eksik!');
      return;
    }

    if (widget.isIncoming) {
      // ALAN: direk Agora'ya bağlan, Firestore zaten answered
      _callAnswered = true;
      setState(() => _statusText = 'Bağlanıyor...');
      _initAgora();
      _startTimer();
      _listenCallDoc(); // ended/rejected dinle
    } else {
      // ARAYAN: önce Firestore doc yaz, sonra dinle
      setState(() => _statusText = 'Çağrılıyor...');
      _setupOutgoingCall();
    }
  }

  Future<void> _setupOutgoingCall() async {
    await _createCallDoc();
    _listenCallDoc();

    // 45 sn timeout
    _missedCallTimer = Timer(const Duration(seconds: 45), () async {
      if (!mounted || _callAnswered) return;
      try {
        final snap = await _callRef.get();
        final snapData1 = snap.data() as Map<String, dynamic>?;
        if (snap.exists && snapData1?['status'] == 'ringing') {
          await _callRef.update({'status': 'missed'});
          await _saveMissedCall();
          if (mounted) _endCall();
        }
      } catch (_) {}
    });
  }

  Future<void> _createCallDoc() async {
    final callerName = FirebaseAuth.instance.currentUser?.displayName ??
        FirebaseAuth.instance.currentUser?.email?.split('@').first ?? '';
    await _callRef.set({
      'callerId':   _myUID,
      'calleeId':   widget.calleeUID,
      'callerName': callerName,
      'isVideo':    widget.isVideoCall,
      'status':     'ringing',
      'createdAt':  FieldValue.serverTimestamp(),
    });
    debugPrint('[Call] Doc oluşturuldu: ${widget.callId}');

    // FCM bildirimi gönder
    if (widget.calleeMToken.isNotEmpty) {
      try {
        await NotificationService().sendCallNotification(
          receiverToken: widget.calleeMToken,
          callerName:    callerName,
          callerUID:     _myUID,
          callId:        widget.callId,
          isVideo:       widget.isVideoCall,
        );
      } catch (e) {
        debugPrint('[Call] FCM bildirim hatası: $e');
      }
    }
  }

  void _listenCallDoc() {
    _callSub?.cancel();
    _callSub = _callRef.snapshots().listen((snap) {
      if (!snap.exists || !mounted) return;
      final status = ((snap.data() as Map<String, dynamic>?)?['status'] as String?) ?? '';
      debugPrint('[Call] Firestore status: $status');

      switch (status) {
        case 'answered':
          if (!_callAnswered && !widget.isIncoming) {
            _callAnswered = true;
            _missedCallTimer?.cancel();
            if (mounted) setState(() => _statusText = 'Bağlanıyor...');
            // Agora'ya bağlan
            _initAgora();
            _startTimer();
          }
          break;
        case 'ended':
          _endCall();
          break;
        case 'rejected':
          _stopTone();
          if (mounted) setState(() => _statusText = 'Arama reddedildi');
          Timer(const Duration(seconds: 1), _endCall);
          break;
        case 'missed':
          if (mounted) setState(() => _statusText = 'Cevap yok');
          Timer(const Duration(seconds: 1), _endCall);
          break;
      }
    }, onError: (e) {
      debugPrint('[Call] Firestore listener hata: $e');
    });
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        _seconds++;
        if (_remoteJoined) {
          final m = _seconds ~/ 60;
          final s = _seconds % 60;
          _statusText = '${m.toString().padLeft(2,'0')}:${s.toString().padLeft(2,'0')}';
        } else {
          _statusText = 'Bağlanıyor...';
        }
      });
    });
  }

  Future<void> _initAgora() async {
    if (_agoraInitStarted) return; // çift init koruması
    _agoraInitStarted = true;
    debugPrint('[Agora] Init başlıyor. Channel: ${widget.callId}');

    // İzinleri iste
    final perms = [Permission.microphone];
    if (widget.isVideoCall) perms.add(Permission.camera);
    final results = await perms.request();
    debugPrint('[Agora] Mikrofon izni: ${results[Permission.microphone]}');

    // Mikrofon izni yoksa hata ver
    if (results[Permission.microphone] != PermissionStatus.granted) {
      if (mounted) setState(() => _statusText = 'Mikrofon izni gerekli');
      return;
    }

    try {
      _engine = createAgoraRtcEngine();
      await _engine!.initialize(RtcEngineContext(appId: CallScreen._appId));
      debugPrint('[Agora] Engine initialize OK');

      _engine!.registerEventHandler(RtcEngineEventHandler(
        onJoinChannelSuccess: (connection, elapsed) {
          debugPrint('[Agora] ✅ Channel\'a katıldı: ${connection.channelId}, elapsed: ${elapsed}ms');
          if (mounted) setState(() { _joined = true; _statusText = 'Bağlanıyor...'; });
        },
        onUserJoined: (connection, remoteUid, elapsed) {
          debugPrint('[Agora] ✅ Karşı taraf bağlandı: $remoteUid');
          if (mounted) setState(() {
            _remoteJoined = true;
            _remoteUid    = remoteUid;
            _statusText   = '00:00';
            _seconds      = 0;
          });
        },
        onUserOffline: (connection, remoteUid, reason) {
          debugPrint('[Agora] Karşı taraf ayrıldı: $remoteUid, reason: $reason');
          if (mounted) setState(() { _remoteJoined = false; _remoteUid = null; });
          _endCall();
        },
        onError: (err, msg) {
          debugPrint('[Agora] ❌ Hata: $err — $msg');
          if (mounted) setState(() => _statusText = 'Hata: $err');
          // Token hatalarında hemen bitir
          if (err == ErrorCodeType.errInvalidToken ||
              err == ErrorCodeType.errTokenExpired) {
            Timer(const Duration(seconds: 2), _endCall);
          }
        },
        onConnectionStateChanged: (connection, state, reason) {
          debugPrint('[Agora] Bağlantı: $state — $reason');
          if (!mounted) return;
          if (state == ConnectionStateType.connectionStateFailed) {
            setState(() => _statusText = 'Bağlantı başarısız');
            Timer(const Duration(seconds: 3), _endCall);
          } else if (state == ConnectionStateType.connectionStateReconnecting) {
            setState(() => _statusText = 'Yeniden bağlanıyor...');
          }
        },
        onLeaveChannel: (connection, stats) {
          debugPrint('[Agora] Channel\'dan ayrıldı');
        },
      ));

      if (widget.isVideoCall) {
        await _engine!.enableVideo();
        await _engine!.startPreview();
        debugPrint('[Agora] Video etkinleştirildi');
      }

      // TOKEN: AGORA_APP_CERTIFICATE yoksa boş geç (test modu)
      // Agora Console > Project > Security > App Certificate KAPALI olmalı
      // Açıksa AGORA_APP_CERTIFICATE secret'ını da GitHub'a eklemelisin
      debugPrint('[Agora] joinChannel → channelId: ${widget.callId}');
      await _engine!.joinChannel(
        token: '',  // Test modu — App Certificate kapalıysa çalışır
        channelId: widget.callId,
        uid: 0,     // 0 = Agora otomatik UID atar
        options: ChannelMediaOptions(
          channelProfile: ChannelProfileType.channelProfileCommunication,
          clientRoleType: ClientRoleType.clientRoleBroadcaster,
          publishMicrophoneTrack: true,
          publishCameraTrack: widget.isVideoCall,
          autoSubscribeAudio: true,
          autoSubscribeVideo: widget.isVideoCall,
        ),
      );
      debugPrint('[Agora] joinChannel çağrısı yapıldı, onJoinChannelSuccess bekleniyor...');

      // 30 sn içinde karşı taraf bağlanmazsa timeout
      Timer(const Duration(seconds: 30), () {
        if (mounted && !_remoteJoined) {
          debugPrint('[Agora] ⏱ 30sn timeout — karşı taraf bağlanmadı');
          setState(() => _statusText = 'Bağlantı kurulamadı');
          Timer(const Duration(seconds: 2), _endCall);
        }
      });
    } catch (e) {
      debugPrint('[Agora] ❌ initAgora exception: $e');
      if (mounted) setState(() => _statusText = 'Agora başlatılamadı: $e');
    }
  }

  void _playTone() {
    try { FlutterRingtonePlayer().playRingtone(looping: true, volume: 1.0); }
    catch (_) {
      try { FlutterRingtonePlayer().play(android: AndroidSounds.ringtone, looping: true); }
      catch (_) {}
    }
  }

  void _stopTone() {
    try { FlutterRingtonePlayer().stop(); } catch (_) {}
  }

  Future<void> _saveMissedCall() async {
    try {
      final batch = FirebaseFirestore.instance.batch();
      final data = {
        'callerId': _myUID, 'calleeId': widget.calleeUID,
        'callerName': FirebaseAuth.instance.currentUser?.displayName ?? '',
        'isVideo': widget.isVideoCall, 'status': 'missed',
        'createdAt': FieldValue.serverTimestamp(),
      };
      batch.set(FirebaseFirestore.instance.collection('users')
          .doc(_myUID).collection('call_history').doc(),
          {...data, 'isMissed': false, 'direction': 'outgoing'});
      batch.set(FirebaseFirestore.instance.collection('users')
          .doc(widget.calleeUID).collection('call_history').doc(),
          {...data, 'isMissed': true, 'direction': 'incoming'});
      await batch.commit();
    } catch (_) {}
  }

  Future<void> _endCall() async {
    if (_endCallCalled) return;
    _endCallCalled = true;
    debugPrint('[Call] _endCall çağrıldı');

    _stopTone();
    _timer?.cancel();
    _missedCallTimer?.cancel();
    _callSub?.cancel();
    _callRef.update({'status': 'ended'}).catchError((_) {});

    if (_callAnswered && _seconds > 0) {
      final data = {
        'callerId': _myUID, 'calleeId': widget.calleeUID,
        'callerName': FirebaseAuth.instance.currentUser?.displayName ?? '',
        'isVideo': widget.isVideoCall, 'status': 'ended',
        'duration': _seconds, 'createdAt': FieldValue.serverTimestamp(),
      };
      FirebaseFirestore.instance.collection('users').doc(_myUID)
          .collection('call_history').add({...data, 'direction': 'outgoing'}).catchError((_) {});
      FirebaseFirestore.instance.collection('users').doc(widget.calleeUID)
          .collection('call_history').add({...data, 'direction': 'incoming'}).catchError((_) {});
    }

    try {
      await _engine?.leaveChannel();
      await _engine?.release();
      debugPrint('[Agora] Engine release OK');
    } catch (e) {
      debugPrint('[Agora] release hata: $e');
    }
    _engine = null;

    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    AppState.instance.isInCallScreen = false;
    _stopTone();
    _timer?.cancel();
    _missedCallTimer?.cancel();
    _callSub?.cancel();
    try { _engine?.leaveChannel(); _engine?.release(); } catch (_) {}
    _engine = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (CallScreen._appId.isEmpty) {
      return Scaffold(
        backgroundColor: const Color(0xFF0D0D0D),
        appBar: AppBar(backgroundColor: const Color(0xFF111111),
            title: const Text('Arama', style: TextStyle(color: Colors.white))),
        body: const Center(child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.phone_disabled_rounded, size: 64, color: Colors.white38),
            SizedBox(height: 20),
            Text('AGORA_APP_ID eksik', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text('GitHub Secrets\'a AGORA_APP_ID ekleyin\nAgora Console\'da App Certificate KAPALI olmalı',
                style: TextStyle(color: Colors.white38, fontSize: 13), textAlign: TextAlign.center),
          ]),
        )),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Stack(children: [
        // Video alanı
        if (widget.isVideoCall) ...[
          if (_remoteJoined && _remoteUid != null && _engine != null)
            AgoraVideoView(
              controller: VideoViewController.remote(
                rtcEngine: _engine!,
                canvas: VideoCanvas(uid: _remoteUid),
                connection: RtcConnection(channelId: widget.callId),
              ),
            )
          else
            _avatarView(),
          if (_cameraOn && _engine != null && _joined)
            Positioned(top: 60, right: 16, width: 100, height: 150,
              child: ClipRRect(borderRadius: BorderRadius.circular(12),
                child: AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: _engine!,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                ),
              ),
            ),
        ] else
          _avatarView(),

        // Üst: isim + durum
        Positioned(top: 0, left: 0, right: 0,
          child: SafeArea(child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Text(widget.calleeName,
                  style: const TextStyle(color: Colors.white, fontSize: 24,
                      fontWeight: FontWeight.bold,
                      shadows: [Shadow(color: Colors.black54, blurRadius: 8)])),
              const SizedBox(height: 4),
              Text(_statusText,
                  style: TextStyle(
                      color: _remoteJoined ? Colors.greenAccent : Colors.white60,
                      fontSize: 14)),
            ]),
          )),
        ),

        // Alt: kontroller
        Positioned(bottom: 48, left: 0, right: 0,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _callAnswered
                ? _ctrlBtn(icon: _muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                    label: _muted ? 'Sessiz' : 'Mikrofon', active: _muted,
                    onTap: () { setState(() => _muted = !_muted); _engine?.muteLocalAudioStream(_muted); })
                : const SizedBox(width: 60),

            GestureDetector(
              onTap: _endCall,
              child: Column(children: [
                Container(width: 72, height: 72,
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.red, blurRadius: 20, spreadRadius: 2)]),
                  child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 36)),
                const SizedBox(height: 6),
                const Text('Bitir', style: TextStyle(color: Colors.white38, fontSize: 11)),
              ]),
            ),

            _callAnswered
                ? (widget.isVideoCall
                    ? _ctrlBtn(
                        icon: _cameraOn ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                        label: 'Kamera', active: !_cameraOn,
                        onTap: () { setState(() => _cameraOn = !_cameraOn); _engine?.muteLocalVideoStream(!_cameraOn); })
                    : _ctrlBtn(
                        icon: _speakerOn ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                        label: 'Hoparlör', active: !_speakerOn,
                        onTap: () { setState(() => _speakerOn = !_speakerOn); _engine?.setEnableSpeakerphone(_speakerOn); }))
                : const SizedBox(width: 60),
          ]),
        ),
      ]),
    );
  }

  Widget _avatarView() => Container(
    color: const Color(0xFF0A0A0A),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 120, height: 120,
        decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: LinearGradient(colors: [ColorsManager.darkPrimary,
              ColorsManager.darkPrimary.withOpacity(0.4)],
            begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.3), blurRadius: 30, spreadRadius: 8)]),
        child: Center(child: Text(
          widget.calleeName.isNotEmpty ? widget.calleeName[0].toUpperCase() : '?',
          style: const TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.bold)))),
      const SizedBox(height: 20),
      if (!_callAnswered && !widget.isIncoming)
        const Text('Çağrılıyor...', style: TextStyle(color: Colors.white54, fontSize: 16)),
    ])),
  );

  Widget _ctrlBtn({required IconData icon, required String label,
      required bool active, required VoidCallback onTap}) {
    return GestureDetector(onTap: onTap,
      child: Column(children: [
        Container(width: 60, height: 60,
          decoration: BoxDecoration(
            color: active ? ColorsManager.darkPrimary.withOpacity(0.3) : const Color(0xFF1E1E1E),
            shape: BoxShape.circle,
            border: Border.all(color: active ? ColorsManager.darkPrimary : Colors.white12)),
          child: Icon(icon, color: active ? ColorsManager.darkPrimary : Colors.white70, size: 28)),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 11)),
      ]));
  }
}

// ── Gelen Arama Ekranı ────────────────────────────────────────────────────────
class IncomingCallScreen extends StatefulWidget {
  final String callId;
  final String callerName;
  final String callerUID;
  final bool isVideo;

  const IncomingCallScreen({
    super.key,
    required this.callId,
    required this.callerName,
    required this.callerUID,
    required this.isVideo,
  });

  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  // Arama hâlâ geçerli mi kontrol et
  StreamSubscription? _callStatusSub;

  @override
  void initState() {
    super.initState();
    _playTone();
    // Arayan kapattıysa ekranı kapat
    _callStatusSub = FirebaseFirestore.instance
        .collection('calls').doc(widget.callId)
        .snapshots().listen((snap) {
      if (!mounted) return;
      final status = (snap.data() as Map<String, dynamic>?)?['status'] as String? ?? '';
      if (status == 'ended' || status == 'missed') {
        _stopTone();
        Navigator.pop(context);
      }
    });
  }

  @override
  void dispose() {
    _stopTone();
    _callStatusSub?.cancel();
    super.dispose();
  }

  void _playTone() {
    try { FlutterRingtonePlayer().playRingtone(looping: true, volume: 1.0); }
    catch (_) {
      try { FlutterRingtonePlayer().play(android: AndroidSounds.ringtone, looping: true); }
      catch (_) {}
    }
  }

  void _stopTone() { try { FlutterRingtonePlayer().stop(); } catch (_) {} }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const SizedBox(height: 60),
          Column(children: [
            Container(width: 120, height: 120,
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: LinearGradient(colors: [ColorsManager.darkPrimary,
                    ColorsManager.darkPrimary.withOpacity(0.4)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
                boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.4),
                    blurRadius: 40, spreadRadius: 10)]),
              child: Center(child: Text(
                widget.callerName.isNotEmpty ? widget.callerName[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.bold)))),
            const SizedBox(height: 24),
            Text(widget.callerName,
                style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(widget.isVideo ? Icons.videocam_rounded : Icons.call_rounded,
                  color: Colors.white54, size: 16),
              const SizedBox(width: 6),
              Text(widget.isVideo ? 'Görüntülü arama geliyor...' : 'Sesli arama geliyor...',
                  style: const TextStyle(color: Colors.white54, fontSize: 15)),
            ]),
          ]),
          Padding(
            padding: const EdgeInsets.only(bottom: 60),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              // REDDET
              Column(children: [
                GestureDetector(
                  onTap: () {
                    _stopTone();
                    FirebaseFirestore.instance.collection('calls')
                        .doc(widget.callId).update({'status': 'rejected'});
                    Navigator.pop(context);
                  },
                  child: Container(width: 72, height: 72,
                    decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: Colors.red, blurRadius: 20, spreadRadius: 2)]),
                    child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 36)),
                ),
                const SizedBox(height: 8),
                const Text('Reddet', style: TextStyle(color: Colors.white54, fontSize: 12)),
              ]),
              // KABUL ET
              Column(children: [
                GestureDetector(
                  onTap: () async {
                    _stopTone();
                    _callStatusSub?.cancel();
                    // Önce Firestore'a yaz
                    await FirebaseFirestore.instance.collection('calls')
                        .doc(widget.callId).update({'status': 'answered'});
                    if (!context.mounted) return;
                    // Sonra CallScreen'e geç
                    Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (_) => CallScreen(
                        callId:      widget.callId,
                        calleeName:  widget.callerName,
                        calleeUID:   widget.callerUID,
                        isVideoCall: widget.isVideo,
                        isIncoming:  true,
                      )),
                    );
                  },
                  child: Container(width: 72, height: 72,
                    decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.6),
                            blurRadius: 20, spreadRadius: 2)]),
                    child: Icon(widget.isVideo ? Icons.videocam_rounded : Icons.call_rounded,
                        color: Colors.white, size: 36)),
                ),
                const SizedBox(height: 8),
                const Text('Kabul Et', style: TextStyle(color: Colors.white54, fontSize: 12)),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}
