import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../themes/colors.dart';

class CallScreen extends StatefulWidget {
  final String callId;
  final String calleeName;
  final bool isVideoCall;

  static const String _appId =
      String.fromEnvironment('AGORA_APP_ID', defaultValue: '');

  const CallScreen({
    super.key,
    required this.callId,
    required this.calleeName,
    this.isVideoCall = false,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  RtcEngine? _engine;
  bool _joined = false;
  bool _remoteJoined = false;
  bool _muted = false;
  bool _speakerOn = true;
  bool _cameraOn = true;
  int? _remoteUid;
  int _seconds = 0;

  @override
  void initState() {
    super.initState();
    if (CallScreen._appId.isNotEmpty) {
      _initAgora();
    }
    _startTimer();
  }

  void _startTimer() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() => _seconds++);
      return true;
    });
  }

  String get _timeStr {
    final m = _seconds ~/ 60;
    final s = _seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  Future<void> _initAgora() async {
    await [
      Permission.microphone,
      if (widget.isVideoCall) Permission.camera,
    ].request();

    _engine = createAgoraRtcEngine();
    await _engine!.initialize(RtcEngineContext(appId: CallScreen._appId));

    _engine!.registerEventHandler(RtcEngineEventHandler(
      onJoinChannelSuccess: (connection, elapsed) {
        if (mounted) setState(() => _joined = true);
      },
      onUserJoined: (connection, remoteUid, elapsed) {
        if (mounted) setState(() {
          _remoteJoined = true;
          _remoteUid = remoteUid;
        });
      },
      onUserOffline: (connection, remoteUid, reason) {
        if (mounted) {
          setState(() { _remoteJoined = false; _remoteUid = null; });
          Navigator.pop(context);
        }
      },
    ));

    if (widget.isVideoCall) {
      await _engine!.enableVideo();
      await _engine!.startPreview();
    }

    await _engine!.joinChannel(
      token: '',
      channelId: widget.callId,
      uid: 0,
      options: const ChannelMediaOptions(
        channelProfile: ChannelProfileType.channelProfileCommunication,
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
      ),
    );
  }

  @override
  void dispose() {
    _engine?.leaveChannel();
    _engine?.release();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (CallScreen._appId.isEmpty) {
      return _setupScreen(context);
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Stack(children: [
        // --- Video alanı ---
        if (widget.isVideoCall) ...[
          if (_remoteJoined && _remoteUid != null)
            AgoraVideoView(
              controller: VideoViewController.remote(
                rtcEngine: _engine!,
                canvas: VideoCanvas(uid: _remoteUid),
                connection: RtcConnection(channelId: widget.callId),
              ),
            )
          else
            _avatarView(),
          if (_cameraOn)
            Positioned(
              top: 60, right: 16,
              width: 100, height: 150,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: _engine!,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                ),
              ),
            ),
        ] else
          _avatarView(),

        // --- Üst bilgi ---
        Positioned(
          top: 0, left: 0, right: 0,
          child: SafeArea(child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Text(widget.calleeName,
                  style: const TextStyle(color: Colors.white, fontSize: 24,
                      fontWeight: FontWeight.bold,
                      shadows: [Shadow(color: Colors.black54, blurRadius: 8)])),
              const SizedBox(height: 4),
              Text(
                _remoteJoined ? _timeStr
                    : _joined ? 'Bekleniyor...'
                    : 'Bağlanıyor...',
                style: TextStyle(
                    color: _remoteJoined ? Colors.greenAccent : Colors.white60,
                    fontSize: 14),
              ),
            ]),
          )),
        ),

        // --- Alt kontroller ---
        Positioned(
          bottom: 48, left: 0, right: 0,
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _ctrlBtn(
                icon: _muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                label: _muted ? 'Sessiz' : 'Mikrofon',
                active: _muted,
                onTap: () {
                  setState(() => _muted = !_muted);
                  _engine?.muteLocalAudioStream(_muted);
                },
              ),
              // Kapat
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 72, height: 72,
                  decoration: const BoxDecoration(
                      color: Colors.red, shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.red, blurRadius: 20, spreadRadius: 2)]),
                  child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 36),
                ),
              ),
              if (widget.isVideoCall)
                _ctrlBtn(
                  icon: _cameraOn ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                  label: 'Kamera',
                  active: !_cameraOn,
                  onTap: () {
                    setState(() => _cameraOn = !_cameraOn);
                    _engine?.muteLocalVideoStream(!_cameraOn);
                  },
                )
              else
                _ctrlBtn(
                  icon: _speakerOn ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                  label: 'Hoparlör',
                  active: !_speakerOn,
                  onTap: () {
                    setState(() => _speakerOn = !_speakerOn);
                    _engine?.setEnableSpeakerphone(_speakerOn);
                  },
                ),
            ]),
          ]),
        ),
      ]),
    );
  }

  Widget _avatarView() => Container(
    color: const Color(0xFF0A0A0A),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 120, height: 120,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            colors: [ColorsManager.darkPrimary, ColorsManager.darkPrimary.withOpacity(0.4)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          boxShadow: [BoxShadow(color: ColorsManager.darkPrimary.withOpacity(0.3),
              blurRadius: 30, spreadRadius: 8)],
        ),
        child: Center(child: Text(
          widget.calleeName.isNotEmpty ? widget.calleeName[0].toUpperCase() : '?',
          style: const TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.bold),
        )),
      ),
    ])),
  );

  Widget _ctrlBtn({required IconData icon, required String label,
      required bool active, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(
          width: 60, height: 60,
          decoration: BoxDecoration(
            color: active ? ColorsManager.darkPrimary.withOpacity(0.3) : const Color(0xFF1E1E1E),
            shape: BoxShape.circle,
            border: Border.all(color: active ? ColorsManager.darkPrimary : Colors.white12),
          ),
          child: Icon(icon, color: active ? ColorsManager.darkPrimary : Colors.white70, size: 28),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 11)),
      ]),
    );
  }

  Widget _setupScreen(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF0D0D0D),
    appBar: AppBar(
      backgroundColor: const Color(0xFF111111),
      title: Text(widget.isVideoCall ? 'Görüntülü Arama' : 'Sesli Arama',
          style: const TextStyle(color: Colors.white)),
      iconTheme: const IconThemeData(color: Colors.white),
    ),
    body: Center(child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.phone_disabled_rounded, size: 64, color: ColorsManager.darkPrimary),
        const SizedBox(height: 20),
        const Text('AGORA_APP_ID eksik',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text(
          '1. console.agora.io → ücretsiz hesap\n'
          '2. Yeni proje → App ID kopyala\n'
          '3. GitHub Secret: AGORA_APP_ID\n'
          '4. Yeniden build al',
          style: TextStyle(color: Colors.white54, fontSize: 13, height: 1.7),
          textAlign: TextAlign.center,
        ),
      ]),
    )),
  );
}
