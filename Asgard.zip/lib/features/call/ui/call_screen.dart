import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';

import '../../../themes/colors.dart';

/// Sesli ve görüntülü arama ekranı — Zego Cloud WebRTC
/// Zego Console'dan ücretsiz AppID ve AppSign alın:
/// https://console.zegocloud.com → Hesap oluştur → Yeni proje
///
/// Ardından GitHub Secrets'a ekleyin:
///   ZEGO_APP_ID  (sayısal, örn: 1234567890)
///   ZEGO_APP_SIGN (string, örn: "abc123...")
/// ve main.yml'e --dart-define ekleyin.
class CallScreen extends StatelessWidget {
  final String callId;
  final String calleeName;
  final bool isVideoCall;

  // GitHub Secrets → dart-define
  static const int _appId = int.fromEnvironment('ZEGO_APP_ID', defaultValue: 0);
  static const String _appSign =
      String.fromEnvironment('ZEGO_APP_SIGN', defaultValue: '');

  const CallScreen({
    super.key,
    required this.callId,
    required this.calleeName,
    this.isVideoCall = false,
  });

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const SizedBox.shrink();

    if (_appId == 0 || _appSign.isEmpty) {
      return Scaffold(
        backgroundColor: const Color(0xFF0D0D0D),
        appBar: AppBar(
          backgroundColor: const Color(0xFF111111),
          title: const Text('Arama', style: TextStyle(color: Colors.white)),
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.phone_disabled_rounded,
                  size: 64, color: ColorsManager.darkPrimary),
              const SizedBox(height: 20),
              const Text('Arama yapılandırılmamış',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text(
                'Sesli/görüntülü arama için:\n'
                '1. console.zegocloud.com → ücretsiz hesap\n'
                '2. Yeni proje → AppID ve AppSign al\n'
                '3. GitHub Secrets\'a ZEGO_APP_ID ve ZEGO_APP_SIGN ekle\n'
                '4. main.yml\'e --dart-define ekle\n'
                '5. Yeniden build al',
                style: TextStyle(color: Colors.white54, fontSize: 13, height: 1.6),
                textAlign: TextAlign.center,
              ),
            ]),
          ),
        ),
      );
    }

    return ZegoUIKitPrebuiltCall(
      appID: _appId,
      appSign: _appSign,
      userID: user.uid,
      userName: user.displayName ?? user.email ?? 'Kullanıcı',
      callID: callId,
      config: isVideoCall
          ? ZegoUIKitPrebuiltCallConfig.oneOnOneVideoCall()
          : ZegoUIKitPrebuiltCallConfig.oneOnOneVoiceCall(),
    );
  }
}
