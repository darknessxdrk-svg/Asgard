import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../themes/colors.dart';
import '../../themes/styles.dart';

class ModalFit extends StatelessWidget {
  const ModalFit({super.key});

  @override
  Widget build(BuildContext context) {
    final langs = [
      ('Türkçe', '🇹🇷', 'tr'),
      ('English', '🇬🇧', 'en'),
      ('Español', '🇪🇸', 'es'),
      ('Français', '🇫🇷', 'fr'),
      ('Deutsch', '🇩🇪', 'de'),
      ('Português', '🇧🇷', 'pt'),
      ('Русский', '🇷🇺', 'ru'),
      ('中文', '🇨🇳', 'zh'),
      ('日本語', '🇯🇵', 'ja'),
      ('한국어', '🇰🇷', 'ko'),
      ('हिन्दी', '🇮🇳', 'hi'),
      ('Italiano', '🇮🇹', 'it'),
      ('عربي', '🇸🇦', 'ar'),
    ];

    final current = context.locale.languageCode;

    return Material(
      color: const Color(0xFF111111),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40, height: 4,
            margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(2)),
          ),
          const Padding(
            padding: EdgeInsets.only(bottom: 12),
            child: Text('Dil Seç',
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
          ),
          ...langs.map((l) {
            final (name, flag, code) = l;
            final isActive = current == code;
            return Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                leading: Text(flag, style: const TextStyle(fontSize: 22)),
                title: Text(name, style: TextStyles.font16White600Weight),
                tileColor: const Color(0xFF111111),
                trailing: isActive
                    ? Icon(Icons.check_circle_rounded,
                        color: ColorsManager.darkPrimary)
                    : null,
                onTap: isActive
                    ? null
                    : () async {
                        await context.setLocale(Locale(code));
                        if (context.mounted) Navigator.pop(context);
                      },
              ),
              Container(
                  color: Colors.white10,
                  height: 0.5.h,
                  width: double.infinity),
            ]);
          }),
          SizedBox(height: 20.h),
        ],
      ),
    );
  }
}
