import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../../helpers/app_regex.dart';
import '../../../themes/colors.dart';
import '../../../themes/styles.dart';
import '../../helpers/extensions.dart';
import '../../router/routes.dart';
import '../../services/database.dart';
import 'app_button.dart';
import 'app_text_form_field.dart';
import 'password_validations.dart';

// ignore: must_be_immutable
class EmailAndPassword extends StatefulWidget {
  final bool? isSignUpPage;
  final bool? isPasswordPage;
  late GoogleSignInAccount? googleUser;
  late OAuthCredential? credential;
  EmailAndPassword({
    super.key,
    this.isSignUpPage,
    this.isPasswordPage,
    this.googleUser,
    this.credential,
  });

  @override
  State<EmailAndPassword> createState() => _EmailAndPasswordState();
}

class _EmailAndPasswordState extends State<EmailAndPassword> {
  bool isObscureText = true;
  bool hasMinLength = false;
  bool _checkingUsername = false;
  bool _usernameAvailable = true;
  String _usernameError = '';
  Timer? _debounce;

  late final _auth = FirebaseAuth.instance;
  late TextEditingController nameController = TextEditingController();
  late TextEditingController usernameController = TextEditingController();
  late TextEditingController emailController = TextEditingController();
  late TextEditingController passwordController = TextEditingController();
  late TextEditingController passwordConfirmationController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        children: [
          if (widget.isSignUpPage == true) nameField(),
          if (widget.isSignUpPage == true) usernameField(),
          if (widget.isPasswordPage == null) emailField(),
          passwordField(),
          Gap(18.h),
          if (widget.isSignUpPage == true || widget.isPasswordPage == true)
            passwordConfirmationField(),
          if (widget.isSignUpPage == null && widget.isPasswordPage == null)
            forgetPasswordTextButton(context),
          Gap(10.h),
          PasswordValidations(hasMinLength: hasMinLength),
          Gap(20.h),
          loginOrSignUpOrPasswordButton(context),
        ],
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    _debounce?.cancel();
    usernameController.dispose();
    passwordConfirmationController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Column emailField() {
    return Column(
      children: [
        AppTextFormField(
          hint: context.tr('email'),
          validator: (value) {
            if (value == null || value.isEmpty || !AppRegex.isEmailValid(value)) {
              return context.tr('pleaseEnterValid', args: ['Email']);
            }
          },
          controller: emailController,
        ),
        Gap(18.h),
      ],
    );
  }

  Column usernameField() {
    return Column(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(
              controller: usernameController,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9_]')),
                LengthLimitingTextInputFormatter(20),
              ],
              onChanged: (value) {
                _debounce?.cancel();
                if (value.length >= 3) {
                  setState(() => _checkingUsername = true);
                  _debounce = Timer(const Duration(milliseconds: 600), () async {
                    try {
                      final available = await DatabaseMethods.isUsernameAvailable(value.toLowerCase());
                      if (mounted) setState(() {
                        _checkingUsername = false;
                        _usernameAvailable = available;
                        _usernameError = available ? '' : 'Bu kullanıcı adı alınmış';
                      });
                    } catch (e) {
                      if (mounted) setState(() => _checkingUsername = false);
                    }
                  });
                } else {
                  setState(() {
                    _checkingUsername = false;
                    _usernameAvailable = true;
                    _usernameError = '';
                  });
                }
              },
              decoration: InputDecoration(
                hintText: 'kullaniciadi',
                hintStyle: TextStyle(color: Colors.white38, fontSize: 14.sp),
                prefixText: '@',
                prefixStyle: TextStyle(
                  color: ColorsManager.darkPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16.sp,
                ),
                suffixIcon: _checkingUsername
                    ? SizedBox(
                        width: 20,
                        height: 20,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: ColorsManager.darkPrimary,
                          ),
                        ),
                      )
                    : usernameController.text.length >= 3
                        ? Icon(
                            _usernameAvailable ? Icons.check_circle : Icons.cancel,
                            color: _usernameAvailable ? Colors.green : Colors.red,
                          )
                        : null,
                isDense: true,
                filled: true,
                fillColor: const Color(0xFF1A1A1A),
                contentPadding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 17.h),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: usernameController.text.length >= 3
                        ? (_usernameAvailable ? Colors.green.withOpacity(0.5) : Colors.red.withOpacity(0.5))
                        : const Color(0xFF2A2A2A),
                    width: 1.5,
                  ),
                  borderRadius: BorderRadius.circular(30),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ColorsManager.darkPrimary, width: 2),
                  borderRadius: BorderRadius.circular(30),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.red, width: 1.5),
                  borderRadius: BorderRadius.circular(30),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.red, width: 1.5),
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty || value.length < 3) {
                  return 'Kullanıcı adı en az 3 karakter olmalı';
                }
                if (!_usernameAvailable) return 'Bu kullanıcı adı alınmış';
              },
            ),
            if (_usernameError.isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: 6.h, left: 16.w),
                child: Text(_usernameError, style: const TextStyle(color: Colors.red, fontSize: 12)),
              ),
          ],
        ),
        Gap(18.h),
      ],
    );
  }

  Widget forgetPasswordTextButton(BuildContext context) {
    return TextButton(
      onPressed: () => context.pushNamed(Routes.forgetScreen),
      child: Align(
        alignment: context.locale.toString() == 'ar'
            ? Alignment.centerLeft
            : Alignment.centerRight,
        child: Text(context.tr('forgetPassword'), style: TextStyles.font15Green500Weight),
      ),
    );
  }

  getToken() async {
    final fcmToken = await FirebaseMessaging.instance.getToken();
    return fcmToken;
  }

  @override
  void initState() {
    super.initState();
    setupPasswordControllerListener();
  }

  AppButton loginButton(BuildContext context) {
    return AppButton(
      buttonText: context.tr('login'),
      textStyle: TextStyles.font15DarkBlue500Weight,
      onPressed: () async {
        if (formKey.currentState!.validate()) {
          try {
            final c = await _auth.signInWithEmailAndPassword(
              email: emailController.text,
              password: passwordController.text,
            );
            if (c.user!.emailVerified) {
              await DatabaseMethods.addUserDetails(
                {
                  'name': _auth.currentUser?.displayName,
                  'email': _auth.currentUser?.email,
                  'profilePic': _auth.currentUser?.photoURL,
                  'uid': _auth.currentUser?.uid ?? '',
                  'mtoken': await getToken(),
                  'isOnline': true,
                },
                SetOptions(merge: true),
              );
              if (!context.mounted) return;
              // Hesabı kaydet (email + uid)
              final prefs2 = await SharedPreferences.getInstance();
              final loginEmail = _auth.currentUser?.email ?? '';
              final loginUid = _auth.currentUser?.uid ?? '';
              if (loginEmail.isNotEmpty) {
                final savedEmails = prefs2.getStringList('saved_account_emails') ?? [];
                if (!savedEmails.contains(loginEmail)) {
                  savedEmails.add(loginEmail);
                  await prefs2.setStringList('saved_account_emails', savedEmails);
                }
              }
              if (loginUid.isNotEmpty) {
                final savedUids = prefs2.getStringList('saved_account_uids') ?? [];
                if (!savedUids.contains(loginUid)) {
                  savedUids.add(loginUid);
                  await prefs2.setStringList('saved_account_uids', savedUids);
                }
              }
              if (!context.mounted) return;
              if (context.mounted) context.pushNamedAndRemoveUntil(Routes.homeScreen, predicate: (route) => false);
            } else {
              await _auth.signOut();
              if (!context.mounted) return;
              AwesomeDialog(
                context: context,
                dialogType: DialogType.info,
                animType: AnimType.rightSlide,
                title: context.tr('emailNotVerified'),
                desc: context.tr('emailNotVerifiedDesc'),
              ).show();
            }
          } on FirebaseAuthException catch (e) {
            if (!context.mounted) return;
            AwesomeDialog(
              context: context,
              dialogType: DialogType.error,
              animType: AnimType.rightSlide,
              title: context.tr('error'),
              desc: e.code == 'user-not-found'
                  ? context.tr('userNotFound')
                  : e.code == 'wrong-password'
                      ? context.tr('wrongPassword')
                      : e.code,
            ).show();
          }
        }
      },
    );
  }

  loginOrSignUpOrPasswordButton(BuildContext context) {
    if (widget.isSignUpPage == true) return signUpButton(context);
    if (widget.isSignUpPage == null && widget.isPasswordPage == null) return loginButton(context);
    if (widget.isPasswordPage!) return passwordButton(context);
  }

  Column nameField() {
    return Column(
      children: [
        AppTextFormField(
          hint: context.tr('name'),
          validator: (value) {
            if (value == null || value.isEmpty || value.startsWith(' ')) {
              return context.tr('pleaseEnterValid', args: ['Name']);
            }
          },
          controller: nameController,
        ),
        Gap(18.h),
      ],
    );
  }

  AppButton passwordButton(BuildContext context) {
    return AppButton(
      buttonText: context.tr('createPassword'),
      textStyle: TextStyles.font15DarkBlue500Weight,
      onPressed: () async {
        if (formKey.currentState!.validate()) {
          try {
            await _auth.createUserWithEmailAndPassword(
              email: widget.googleUser!.email,
              password: passwordController.text,
            );
            await _auth.currentUser?.linkWithCredential(widget.credential!);
            await _auth.currentUser?.updateDisplayName(widget.googleUser?.displayName);
            await _auth.currentUser?.updatePhotoURL(widget.googleUser?.photoUrl);
            await DatabaseMethods.addUserDetails({
              'name': widget.googleUser!.displayName,
              'profilePic': widget.googleUser!.photoUrl,
              'email': widget.googleUser!.email,
              'uid': _auth.currentUser?.uid ?? '',
              'mtoken': await getToken(),
              'isOnline': true,
            });
            if (!context.mounted) return;
            await AwesomeDialog(
              context: context,
              dialogType: DialogType.success,
              animType: AnimType.rightSlide,
              title: context.tr('success'),
              desc: context.tr('accountCreated'),
            ).show();
            if (!context.mounted) return;
            // Hesabı kaydet
              final prefs2 = await SharedPreferences.getInstance();
              final savedEmails = prefs2.getStringList('saved_account_emails') ?? [];
              final loginEmail = _auth.currentUser?.email ?? '';
              if (loginEmail.isNotEmpty && !savedEmails.contains(loginEmail)) {
                savedEmails.add(loginEmail);
                await prefs2.setStringList('saved_account_emails', savedEmails);
              }
              if (!context.mounted) return;
              if (context.mounted) context.pushNamedAndRemoveUntil(Routes.homeScreen, predicate: (route) => false);
          } on FirebaseAuthException catch (e) {
            if (!context.mounted) return;
            AwesomeDialog(
              context: context,
              dialogType: DialogType.error,
              animType: AnimType.rightSlide,
              title: context.tr('error'),
              desc: e.code == 'email-already-in-use' ? context.tr('emailAlreadyExists') : e.message,
            ).show();
          }
        }
      },
    );
  }

  Widget passwordConfirmationField() {
    return AppTextFormField(
      controller: passwordConfirmationController,
      hint: context.tr('confirmPassword'),
      isObscureText: isObscureText,
      suffixIcon: GestureDetector(
        onTap: () => setState(() => isObscureText = !isObscureText),
        child: Icon(isObscureText ? Icons.visibility_off : Icons.visibility, color: Colors.white),
      ),
      validator: (value) {
        if (value != passwordController.text) return context.tr('passwordsDontMatch');
        if (value == null || value.isEmpty || !AppRegex.isPasswordValid(value)) {
          return context.tr('pleaseEnterValid', args: ['Password']);
        }
      },
    );
  }

  AppTextFormField passwordField() {
    return AppTextFormField(
      controller: passwordController,
      hint: context.tr('password'),
      isObscureText: isObscureText,
      suffixIcon: GestureDetector(
        onTap: () => setState(() => isObscureText = !isObscureText),
        child: Icon(isObscureText ? Icons.visibility_off : Icons.visibility, color: Colors.white),
      ),
      validator: (value) {
        if (value == null || value.isEmpty || !AppRegex.isPasswordValid(value)) {
          return context.tr('pleaseEnterValid', args: ['Password']);
        }
      },
    );
  }

  void setupPasswordControllerListener() {
    passwordController.addListener(() {
      setState(() => hasMinLength = AppRegex.isPasswordValid(passwordController.text));
    });
  }

  AppButton signUpButton(BuildContext context) {
    return AppButton(
      buttonText: context.tr('createAccount'),
      textStyle: TextStyles.font15DarkBlue500Weight,
      onPressed: () async {
        if (formKey.currentState!.validate()) {
          if (!_usernameAvailable) {
            AwesomeDialog(
              context: context,
              dialogType: DialogType.error,
              animType: AnimType.rightSlide,
              title: 'Hata',
              desc: 'Bu kullanıcı adı alınmış',
            ).show();
            return;
          }
          // Kayıt anında son kez kontrol et (race condition önle)
          final rawUsername = usernameController.text.trim().toLowerCase();
          final finalAvailable = await DatabaseMethods.isUsernameAvailable(rawUsername);
          if (!finalAvailable) {
            if (!context.mounted) return;
            AwesomeDialog(
              context: context,
              dialogType: DialogType.error,
              animType: AnimType.rightSlide,
              title: 'Hata',
              desc: 'Bu kullanıcı adı az önce başkası tarafından alındı. Farklı bir ad seçin.',
            ).show();
            return;
          }
          try {
            await _auth.createUserWithEmailAndPassword(
              email: emailController.text,
              password: passwordController.text,
            );
            final newUid = _auth.currentUser?.uid ?? '';
            if (newUid.isEmpty) throw Exception('Auth hatası: kullanıcı oluşturulamadı');
            await _auth.currentUser?.updateDisplayName(nameController.text);
            await _auth.currentUser?.sendEmailVerification();
            // Atomik kullanıcı adı rezervasyonu
            final reserved = await DatabaseMethods.reserveUsername(rawUsername, newUid);
            if (!reserved) {
              await _auth.currentUser?.delete();
              if (!context.mounted) return;
              AwesomeDialog(
                context: context,
                dialogType: DialogType.error,
                animType: AnimType.rightSlide,
                title: 'Hata',
                desc: 'Bu kullanıcı adı kayıt sırasında başkası tarafından alındı. Tekrar deneyin.',
              ).show();
              return;
            }
            await DatabaseMethods.addUserDetails({
              'name': nameController.text,
              'username': rawUsername,
              'email': emailController.text,
              'profilePic': '',
              'uid': newUid,
              'mtoken': await getToken(),
              'isOnline': false,
            });
            await _auth.signOut();
            if (!context.mounted) return;
            await AwesomeDialog(
              context: context,
              dialogType: DialogType.success,
              animType: AnimType.rightSlide,
              title: context.tr('success'),
              desc: context.tr('verifyYourEmail'),
            ).show();
            if (!context.mounted) return;
            context.pushNamedAndRemoveUntil(Routes.loginScreen, predicate: (route) => false);
          } on FirebaseAuthException catch (e) {
            if (!context.mounted) return;
            AwesomeDialog(
              context: context,
              dialogType: DialogType.error,
              animType: AnimType.rightSlide,
              title: context.tr('error'),
              desc: e.code == 'email-already-in-use' ? context.tr('emailAlreadyExists') : e.message,
            ).show();
          }
        }
      },
    );
  }
}
