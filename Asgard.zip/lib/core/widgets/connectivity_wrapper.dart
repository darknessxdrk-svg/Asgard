import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

class ConnectivityWrapper extends StatefulWidget {
  final Widget onlineChild;
  final Widget offlineChild;

  const ConnectivityWrapper({
    super.key,
    required this.onlineChild,
    required this.offlineChild,
  });

  @override
  State<ConnectivityWrapper> createState() => _ConnectivityWrapperState();
}

class _ConnectivityWrapperState extends State<ConnectivityWrapper> {
  bool _isConnected = true; // Başlangıçta bağlı varsay
  // FIX: stream her build'de yeniden yaratılmasın
  final Stream<List<ConnectivityResult>> _connectivityStream = Connectivity().onConnectivityChanged;

  @override
  void initState() {
    super.initState();
    _checkInitial();
  }

  Future<void> _checkInitial() async {
    final results = await Connectivity().checkConnectivity();
    if (mounted) {
      setState(() {
        _isConnected = results.isNotEmpty &&
            !results.every((r) => r == ConnectivityResult.none);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ConnectivityResult>>(
      stream: _connectivityStream,
      builder: (context, snapshot) {
        bool connected;
        if (snapshot.hasData) {
          final results = snapshot.data!;
          connected = results.isNotEmpty &&
              !results.every((r) => r == ConnectivityResult.none);
        } else {
          connected = _isConnected;
        }
        return connected ? widget.onlineChild : widget.offlineChild;
      },
    );
  }
}
