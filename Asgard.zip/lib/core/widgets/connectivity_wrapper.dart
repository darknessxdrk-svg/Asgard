import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

/// İnternet bağlantısını izler.
/// 
/// SORUN: connectivity_plus Android'de uygulama ilk açılınca bazen
/// yanlış 'none' döndürüyor — OS henüz network durumunu raporlamadı.
/// 
/// ÇÖZÜM:
/// 1. Optimistic başlangıç (_isConnected = true)
/// 2. Offline bildirimi 2 saniye debounce — geçici kopukluklara tepki vermez
/// 3. İlk kontrol yavaşsa 3 saniye sonra tekrar dene
/// 4. StreamBuilder yerine manuel listener — daha güvenilir
class ConnectivityWrapper extends StatefulWidget {
  final Widget onlineChild;
  final Widget offlineChild;

  const ConnectivityWrapper({
    super.key,
    required this.onlineChild,
    required this.offlineChild,
  });

  @override
  State<ConnectivityWrapper> createState() => _ConnectivityWrapperState();
}

class _ConnectivityWrapperState extends State<ConnectivityWrapper> {
  bool _isConnected = true; // optimistic başlangıç
  bool _offlineConfirmed = false; // debounce teyidi
  Timer? _offlineDebounce;
  StreamSubscription<List<ConnectivityResult>>? _sub;
  final _connectivity = Connectivity();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initConnectivity());
  }

  Future<void> _initConnectivity() async {
    // İlk kontrol
    await _check();

    // Stream dinle
    _sub = _connectivity.onConnectivityChanged.listen(_handleChange);

    // Android'de bazen ilk kontrol yanlış gelir — 2sn sonra tekrar dene
    Future.delayed(const Duration(seconds: 2), () async {
      if (mounted && !_isConnected) {
        await _check();
      }
    });
  }

  Future<void> _check() async {
    try {
      final results = await _connectivity.checkConnectivity();
      final connected = results.isNotEmpty &&
          !results.every((r) => r == ConnectivityResult.none);
      _handleConnectionState(connected);
    } catch (_) {
      // Kontrol başarısız = bağlı varsay (false negative'i önle)
    }
  }

  void _handleChange(List<ConnectivityResult> results) {
    final connected = results.isNotEmpty &&
        !results.every((r) => r == ConnectivityResult.none);
    _handleConnectionState(connected);
  }

  void _handleConnectionState(bool connected) {
    if (connected) {
      // Bağlantı geldi → anında göster
      _offlineDebounce?.cancel();
      _offlineDebounce = null;
      if (mounted && (!_isConnected || _offlineConfirmed)) {
        setState(() {
          _isConnected = true;
          _offlineConfirmed = false;
        });
      }
    } else {
      // Bağlantı koptu → 2 saniye bekle, hâlâ kopuksa göster (geçici kopukluğa tepki verme)
      _offlineDebounce?.cancel();
      _offlineDebounce = Timer(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() {
            _isConnected = false;
            _offlineConfirmed = true;
          });
        }
      });
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    _offlineDebounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Sadece offline kesinleştiğinde offlineChild göster
    return _offlineConfirmed ? widget.offlineChild : widget.onlineChild;
  }
}
