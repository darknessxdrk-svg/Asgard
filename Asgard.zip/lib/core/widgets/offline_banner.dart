import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import '../../services/message_queue_service.dart';

/// Offline durumunda üstte gösterilen banner
/// Kuyrukta bekleyen mesaj sayısını gösterir
class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ConnectivityResult>>(
      stream: Connectivity().onConnectivityChanged,
      builder: (context, snap) {
        final isOnline = snap.data?.any((r) => r != ConnectivityResult.none) ?? true;
        final queueLen = MessageQueueService.instance.queueLength;

        if (isOnline && queueLen == 0) return const SizedBox.shrink();

        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
          color: isOnline ? Colors.orange.shade700 : Colors.red.shade800,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                isOnline ? Icons.cloud_upload_rounded : Icons.cloud_off_rounded,
                color: Colors.white,
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(
                isOnline
                    ? 'Bağlantı sağlandı, $queueLen mesaj gönderiliyor...'
                    : queueLen > 0
                        ? 'Çevrimdışı • $queueLen mesaj bekliyor'
                        : 'Çevrimdışı',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w500),
              ),
            ],
          ),
        );
      },
    );
  }
}
