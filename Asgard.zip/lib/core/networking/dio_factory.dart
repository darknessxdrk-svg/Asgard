import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

class DioFactory {
  static Dio? dio;
  DioFactory._();

  static void addDioInterceptor() {
    // ✅ FIX: Sadece debug modda log göster
    if (kDebugMode) {
      dio?.interceptors.add(
        PrettyDioLogger(
          requestBody: true,
          requestHeader: true,
          responseHeader: false,
        ),
      );
    }
  }

  static Dio getDio() {
    const connectTimeout = Duration(seconds: 15);
    const receiveTimeout = Duration(seconds: 30);
    const sendTimeout    = Duration(seconds: 30); // FIX NETWORK: sendTimeout eksikti
    if (dio == null) {
      dio = Dio();
      dio!
        ..options.connectTimeout = connectTimeout
        ..options.receiveTimeout = receiveTimeout
        ..options.sendTimeout    = sendTimeout; // FIX NETWORK: büyük dosya gönderiminde timeout
      addDioInterceptor();
      return dio!;
    } else {
      return dio!;
    }
  }
}
