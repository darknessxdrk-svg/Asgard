extension StringExt on String {
  /// @username → @Username (ilk harf büyük)
  String get capitalizeFirst =>
      isEmpty ? this : this[0].toUpperCase() + substring(1);

  /// "darkness" → "Darkness"
  String get usernameDisplay => capitalizeFirst;
}
