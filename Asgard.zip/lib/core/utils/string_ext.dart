extension StringExt on String {
  String get capitalizeFirst {
    final s = this;
    if (s.isEmpty) return s;
    return s[0].toUpperCase() + s.substring(1);
  }

  String get usernameDisplay => capitalizeFirst;
}

/// Extension olmadan güvenli capitalize - her yerden kullanılabilir
String capFirst(String s) {
  if (s.isEmpty) return s;
  return s[0].toUpperCase() + s.substring(1);
}
