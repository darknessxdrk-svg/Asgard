import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Uygulama genelinde font boyutunu yönetir.
class FontSizeProvider extends ChangeNotifier {
  double _messageFontSize = 15.0;
  double get messageFontSize => _messageFontSize;

  static final FontSizeProvider instance = FontSizeProvider._();
  FontSizeProvider._() { _load(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _messageFontSize = _labelToSize(prefs.getString('fontSize') ?? 'Orta');
    notifyListeners();
  }

  Future<void> setFontSize(String label) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('fontSize', label);
    _messageFontSize = _labelToSize(label);
    notifyListeners();
  }

  double _labelToSize(String label) {
    switch (label) {
      case 'Küçük': return 12.0;
      case 'Büyük': return 18.0;
      case 'Çok Büyük': return 21.0;
      default: return 15.0;
    }
  }
}
