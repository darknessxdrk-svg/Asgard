import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../features/chat/ui/chat_page.dart';
import '../features/create_password/ui/create_password.dart';
import '../features/display_picture/ui/display_picture_screen.dart';
import '../features/forget_password/ui/forget_screen.dart';
import '../features/home/ui/home_screen.dart';
import '../features/local_auth/auth.dart';
import '../features/login/ui/login_screen.dart';
import '../features/newgroup/ui/new_group_screen.dart';
import '../features/newgroup/ui/group_create_screen.dart';
import '../features/settings/ui/settings_screen.dart';
import '../features/signup/ui/sign_up_sceen.dart';
import '../features/update/ui/update.dart';
import 'routes.dart';

class AppRoute {
  Route onGenerateRoute(RouteSettings routeSettings) {
    switch (routeSettings.name) {
      case Routes.authScreen:
        return MaterialPageRoute(builder: (_) => const Auth());

      case Routes.updateScreen:
        return MaterialPageRoute(builder: (_) => const UpdateScreen());

      case Routes.chatScreen:
        final arguments = routeSettings.arguments;
        if (arguments is Map<String, dynamic>) {
          final name = arguments['name']?.toString() ?? '';
          final uid = arguments['uid']?.toString() ?? '';
          final mtoken = arguments['mtoken']?.toString() ?? '';
          final active = (arguments['isOnline'] ?? arguments['active'])?.toString() ?? 'false';
          final profilePic = arguments['profilePic']?.toString();
          if (uid.isNotEmpty) {
            return MaterialPageRoute(
              builder: (_) => ChatScreen(
                receivedUserName: name,
                receivedUserID: uid,
                receivedMToken: mtoken,
                active: active,
                receivedUserProfilePic: profilePic,
              ),
            );
          }
        }
        // ✅ FIX: null yerine fallback route
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      case Routes.forgetScreen:
        return MaterialPageRoute(builder: (_) => const ForgetScreen());

      case Routes.loginScreen:
        return MaterialPageRoute(builder: (_) => const LoginScreen());

      case Routes.signupScreen:
        return MaterialPageRoute(builder: (_) => const SignUpScreen());

      case Routes.createPassword:
        final arguments = routeSettings.arguments;
        if (arguments is List && arguments.length >= 2) {
          return MaterialPageRoute(
            builder: (_) => CreatePassword(
              googleUser: arguments[0],
              credential: arguments[1],
            ),
          );
        }
        return MaterialPageRoute(builder: (_) => const LoginScreen());

      case Routes.settingsScreen:
        return MaterialPageRoute(builder: (_) => const SettingsScreen());

      case Routes.groupCreateScreen:
        return MaterialPageRoute(builder: (_) => const GroupCreateScreen());

      case Routes.newGroupScreen:
        return MaterialPageRoute(builder: (_) => const NewGroupScreen());

      case Routes.displayPictureScreen:
        final arguments = routeSettings.arguments;
        if (arguments is List && arguments.length >= 4) {
          return MaterialPageRoute(
            builder: (_) => DisplayPictureScreen(
              image: arguments[0] as XFile,
              token: arguments[1] as String,
              receivedMToken: arguments[2] as String,
              receivedUserID: arguments[3] as String,
            ),
          );
        }
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      case Routes.homeScreen:
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      default:
        // ✅ FIX: Bilinmeyen route için HomeScreen
        return MaterialPageRoute(builder: (_) => const HomeScreen());
    }
  }
}
