import 'package:flutter/material.dart';

class ColorsManager {
  // Genel
  static const Color gray = Color(0xFF757575);
  static Color gray400 = Colors.grey.shade400;
  static const Color mediumLightShadeOfGray = Color(0xFF9E9E9E);

  // ── KARANLIK MOD: Siyah & Kırmızı ──
  static const Color darkBackground    = Color(0xFF0D0D0D);
  static const Color darkSurface       = Color(0xFF1A1A1A);
  static const Color darkAppBar        = Color(0xFF111111);
  static const Color darkPrimary       = Color(0xFFE53935);
  static const Color darkPrimaryLight  = Color(0xFFFF5252);
  static const Color darkPrimaryDark   = Color(0xFFB71C1C);

  // ── AYDINLIK MOD: Beyaz & Mavi ──
  static const Color lightBackground   = Color(0xFFF5F7FA);
  static const Color lightSurface      = Color(0xFFFFFFFF);
  static const Color lightAppBar       = Color(0xFF1565C0);
  static const Color lightPrimary      = Color(0xFF1976D2);
  static const Color lightPrimaryLight = Color(0xFF42A5F5);
  static const Color lightPrimaryDark  = Color(0xFF0D47A1);

  // Eski kod uyumluluğu için (kodun geri kalanı bozulmasın)
  static const Color darkBlue                = Color(0xFF1A1A1A);
  static const Color lightShadeOfGray        = Color(0xFFF5F7FA);
  static const Color coralRed               = Color(0xFFE53935);
  static const Color backgroundDefaultColor  = Color(0xFF0D0D0D);
  static const Color greenPrimary           = Color(0xFFE53935); // Kırmızıya güncellendi
  static const Color appBarBackgroundColor  = Color(0xFF111111);
}
