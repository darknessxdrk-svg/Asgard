import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../features/chat/data/model/message.dart';

class DatabaseMethods {
  static String getChatRoomId(String uid1, String uid2) {
    final ids = [uid1, uid2]..sort();
    return ids.join('_');
  }

  static final _auth = FirebaseAuth.instance;
  static final _fireStore = FirebaseFirestore.instance;

  static Future<void> addUserDetails(Map<String, dynamic> data,
      [SetOptions? options]) async {
    await _fireStore
        .collection('users')
        .doc(_auth.currentUser!.uid)
        .set(data, options);
  }

  static Future<void> updateUserDetails(Map<String, dynamic> data,
      [SetOptions? options]) async {
    try {
      await _fireStore
          .collection('users')
          .doc(_auth.currentUser!.uid)
          .set(data, SetOptions(merge: true));
    } catch (e) {
      // Kullanıcı dokümanı yoksa veya auth null ise sessizce geç
    }
  }

  static Future<bool> isUsernameAvailable(String username) async {
    final query = await _fireStore
        .collection('users')
        .where('username', isEqualTo: username.toLowerCase())
        .limit(1)
        .get();
    return query.docs.isEmpty;
  }

  static Future<Map<String, dynamic>?> getUserByUsername(String username) async {
    final query = await _fireStore
        .collection('users')
        .where('username', isEqualTo: username.toLowerCase())
        .limit(1)
        .get();
    if (query.docs.isEmpty) return null;
    return query.docs.first.data();
  }

  static Future<void> addContact(String contactUid) async {
    final myUid = _auth.currentUser!.uid;
    await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .set({'uid': contactUid, 'addedAt': Timestamp.now()});
  }

  static Future<void> removeContact(String contactUid) async {
    final myUid = _auth.currentUser!.uid;
    await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .delete();
  }

  static Stream<QuerySnapshot> getContacts() {
    final myUid = _auth.currentUser!.uid;
    return _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .snapshots();
  }

  static Future<bool> isContact(String contactUid) async {
    final myUid = _auth.currentUser!.uid;
    final doc = await _fireStore
        .collection('users')
        .doc(myUid)
        .collection('contacts')
        .doc(contactUid)
        .get();
    return doc.exists;
  }

  static String getChatRoomID(String uid1, String uid2) {
    List<String> ids = [uid1, uid2];
    ids.sort();
    return ids.join('_');
  }

  static Stream<QuerySnapshot> getMessages(String userID, String otherUserID) {
    String chatRoomID = getChatRoomID(userID, otherUserID);
    return _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  static Future<void> sendMessage(String message, String receiverID) async {
    final currentUserID = _auth.currentUser!.uid;
    final currentUserName = _auth.currentUser!.displayName ?? _auth.currentUser!.email?.split('@').first ?? '';
    final timestamp = Timestamp.now();
    final chatRoomID = getChatRoomID(currentUserID, receiverID);

    Message newMessage = Message(
      senderID: currentUserID,
      senderName: currentUserName,
      message: message,
      receiverID: receiverID,
      timestamp: timestamp,
      status: 'delivered',
    );

    await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .add(newMessage.toMap());

    // Karşı taraf bizi eklememiş olsa bile mesajı görebilsin
    // Her iki tarafın contacts'ına da ekle
    try {
      final myData = (await _fireStore.collection('users').doc(currentUserID).get()).data() ?? {};
      final theirData = (await _fireStore.collection('users').doc(receiverID).get()).data() ?? {};
      // Karşı tarafın listesine bizi ekle
      await _fireStore.collection('users').doc(receiverID)
          .collection('contacts').doc(currentUserID)
          .set({'uid': currentUserID, 'addedAt': timestamp}, SetOptions(merge: true));
      // Bizim listemize karşı tarafı ekle
      await _fireStore.collection('users').doc(currentUserID)
          .collection('contacts').doc(receiverID)
          .set({'uid': receiverID, 'addedAt': timestamp}, SetOptions(merge: true));
    } catch (e) { /* sessiz geç */ }
  }

  // Mesajları okundu olarak işaretle
  static Future<void> markMessagesAsRead(String otherUserID) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);

    final unread = await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .where('receiverID', isEqualTo: myUID)
        .where('status', isEqualTo: 'delivered')
        .get();

    final batch = _fireStore.batch();
    for (var doc in unread.docs) {
      batch.update(doc.reference, {'status': 'read'});
    }
    await batch.commit();
  }
  // ── Grup metodları ──────────────────────────────────────────────────────
  static Future<String> createGroup(String name, List<String> memberUIDs) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final members = {...memberUIDs, uid!}.toList();
    final doc = await _fireStore.collection('groups').add({
      'name': name,
      'members': members,
      'admins': [uid],
      'photo': '',
      'description': '',
      'createdBy': uid,
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': '',
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  static Stream<QuerySnapshot> getUserGroups() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    // orderBy kaldırıldı - composite index gerektiriyor, client-side sort yapılıyor
    return _fireStore.collection('groups')
        .where('members', arrayContains: uid)
        .snapshots();
  }


  // AI mesajı özel sender ile gönder (birebir sohbet)
  static Future<void> sendMessageAsAI(String message, String receiverID) async {
    final currentUserID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(currentUserID, receiverID);
    final timestamp = Timestamp.now();
    await _fireStore
        .collection('chats')
        .doc(chatRoomID)
        .collection('messages')
        .add({
      'senderID': 'AI_BOT',
      'senderName': 'Asgard AI',
      'message': message,
      'receiverID': receiverID,
      'timestamp': timestamp,
      'status': 'delivered',
      'isAI': true,
    });
  }

  static Future<void> sendGroupMessage(String groupId, String message) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final user = await _fireStore.collection('users').doc(uid).get();
    final name = user.data()?['name'] ?? '';
    final msgRef = _fireStore.collection('groups').doc(groupId).collection('messages');
    final msgId = msgRef.doc().id;
    await msgRef.doc(msgId).set({
      'message': message,
      'senderID': uid,
      'senderName': name,
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'delivered',
      'seenBy': [uid],
    });
    await _fireStore.collection('groups').doc(groupId).update({
      'lastMessage': message.startsWith('[') ? '📎 Medya' : message,
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
  }


  static Future<void> sendGroupMessageAsAI(String groupId, String message) async {
    final msgRef = _fireStore.collection('groups').doc(groupId).collection('messages');
    final msgId = msgRef.doc().id;
    await msgRef.doc(msgId).set({
      'message': message,
      'senderID': 'AI_BOT',
      'senderName': 'Asgard AI',
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'delivered',
      'seenBy': [],
    });
    await _fireStore.collection('groups').doc(groupId).update({
      'lastMessage': '🤖 AI: ${message.length > 40 ? message.substring(0, 40) + '...' : message}',
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> markGroupMessageSeen(String groupId, String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore.collection('groups').doc(groupId)
        .collection('messages').doc(messageId)
        .update({'seenBy': FieldValue.arrayUnion([uid])});
  }

  static Stream<QuerySnapshot> getGroupMessages(String groupId) {
    return _fireStore.collection('groups').doc(groupId).collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots();
  }

  // ── Mesaj Silme ──────────────────────────────────────────────────────────
  static Future<void> deleteMessageForMe(String messageId, String otherUserID) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore.collection('chats').doc(chatRoomID).collection('messages').doc(messageId);
    final doc = await ref.get();
    final data = doc.data() ?? {};
    final List hiddenFor = List.from(data['hiddenFor'] ?? []);
    hiddenFor.add(myUID);
    await ref.update({'hiddenFor': hiddenFor});
  }

  static Future<void> deleteMessageForEveryone(String messageId, String otherUserID) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).collection('messages').doc(messageId)
        .update({'message': '🚫 Bu mesaj silindi', 'deleted': true});
  }

  // ── Mesaj Düzenleme ──────────────────────────────────────────────────────
  static Future<void> editMessage(String messageId, String otherUserID, String newText) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).collection('messages').doc(messageId)
        .update({'message': newText, 'edited': true});
  }

  // ── Mesaj Sabitleme ──────────────────────────────────────────────────────
  static Future<void> pinMessage(String messageId, String otherUserID, String messageText) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).update({
      'pinnedMessage': {'id': messageId, 'text': messageText},
    });
  }

  static Future<void> unpinMessage(String otherUserID) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).update({'pinnedMessage': FieldValue.delete()});
  }

  static Stream<DocumentSnapshot> getChatRoomStream(String otherUserID) {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    return _fireStore.collection('chats').doc(chatRoomID).snapshots();
  }

  // ── Emoji Reaksiyon ──────────────────────────────────────────────────────
  static Future<void> addReaction(String messageId, String otherUserID, String emoji) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    final ref = _fireStore.collection('chats').doc(chatRoomID).collection('messages').doc(messageId);
    await ref.update({'reactions.$myUID': emoji});
  }

  // ── Yazıyor Göstergesi ───────────────────────────────────────────────────
  static Future<void> setTyping(String otherUserID, bool isTyping) async {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    await _fireStore.collection('chats').doc(chatRoomID).set({
      'typing_$myUID': isTyping,
    }, SetOptions(merge: true));
  }

  static Stream<DocumentSnapshot> getTypingStream(String otherUserID) {
    final myUID = _auth.currentUser!.uid;
    final chatRoomID = getChatRoomID(myUID, otherUserID);
    return _fireStore.collection('chats').doc(chatRoomID).snapshots();
  }

  // ── Son Görülme ──────────────────────────────────────────────────────────
  static Future<void> updateLastSeen() async {
    final myUID = _auth.currentUser!.uid;
    await _fireStore.collection('users').doc(myUID).update({
      'lastSeen': DateTime.now().millisecondsSinceEpoch,
      'isOnline': 'false',
    });
  }

  static Stream<DocumentSnapshot> getUserStream(String uid) {
    return _fireStore.collection('users').doc(uid).snapshots();
  }


  // ── Favori Mesajlar ──────────────────────────────────────────────────────
  static Future<void> starMessage(String messageId, Map<String, dynamic> msgData) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore.collection('users').doc(uid)
        .collection('starred').doc(messageId).set({
      ...msgData,
      'starredAt': Timestamp.now(),
      'originalMessageId': messageId,
    });
  }

  static Future<void> unstarMessage(String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _fireStore.collection('users').doc(uid)
        .collection('starred').doc(messageId).delete();
  }

  static Stream<QuerySnapshot> getStarredMessages() {
    final uid = _auth.currentUser?.uid;
    return _fireStore.collection('users').doc(uid)
        .collection('starred')
        .orderBy('starredAt', descending: true)
        .snapshots();
  }

  static Future<bool> isMessageStarred(String messageId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return false;
    final doc = await _fireStore.collection('users').doc(uid)
        .collection('starred').doc(messageId).get();
    return doc.exists;
  }

}