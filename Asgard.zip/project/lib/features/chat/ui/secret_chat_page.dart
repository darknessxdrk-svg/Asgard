import 'package:flutter/services.dart';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../themes/colors.dart';

class SecretChatPage extends StatefulWidget {
  final String otherUid, otherName, otherPhoto;
  const SecretChatPage({super.key, required this.otherUid, required this.otherName, required this.otherPhoto});
  @override State<SecretChatPage> createState() => _SecretChatPageState();
}

class _SecretChatPageState extends State<SecretChatPage> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;
  bool _locked = true;
  String? _pin;

  String get _chatId {
    final ids = [_auth.currentUser!.uid, widget.otherUid]..sort();
    return 'secret_${ids.join('_')}';
  }

  @override
  void initState() {
    super.initState();
    // Gizli sohbette ekran görüntüsü engelle
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: SystemUiOverlay.values);
    _checkPin();
  }

  Future<void> _checkPin() async {
    final prefs = await SharedPreferences.getInstance();
    _pin = prefs.getString('secret_pin_${_chatId}');
    if (_pin == null) {
      // İlk kez - pin oluştur
      await _createPin();
    } else {
      await _verifyPin();
    }
  }

  Future<void> _createPin() async {
    final ctrl = TextEditingController();
    final result = await showDialog<String>(
      context: context, barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Row(children: [
          const Icon(Icons.lock_rounded, color: Colors.green, size: 20),
          const SizedBox(width: 8),
          const Text('Gizli Sohbet PIN', style: TextStyle(color: Colors.white, fontSize: 16)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Bu gizli sohbet için 4 haneli PIN belirle', style: TextStyle(color: Colors.white54, fontSize: 13)),
          const SizedBox(height: 12),
          TextField(
            controller: ctrl, keyboardType: TextInputType.number, maxLength: 4, obscureText: true,
            style: const TextStyle(color: Colors.white, fontSize: 24, letterSpacing: 8),
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              counterText: '',
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.green.withOpacity(0.4)), borderRadius: BorderRadius.circular(10)),
              focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green), borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
          TextButton(onPressed: () { if (ctrl.text.length == 4) Navigator.pop(ctx, ctrl.text); },
              child: const Text('Oluştur', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
        ],
      ),
    );
    if (result != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('secret_pin_$_chatId', result);
      _pin = result;
      setState(() => _locked = false);
    } else if (mounted) Navigator.pop(context);
  }

  Future<void> _verifyPin() async {
    final ctrl = TextEditingController();
    int attempts = 0;
    while (_locked && mounted) {
      final result = await showDialog<String>(
        context: context, barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: Row(children: [
            const Icon(Icons.lock_rounded, color: Colors.green, size: 20),
            const SizedBox(width: 8),
            const Text('Gizli Sohbet', style: TextStyle(color: Colors.white, fontSize: 16)),
          ]),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(attempts > 0 ? '❌ Yanlış PIN ($attempts/3)' : 'PIN\'ini gir',
                style: TextStyle(color: attempts > 0 ? Colors.red : Colors.white54, fontSize: 13)),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl..clear(), keyboardType: TextInputType.number, maxLength: 4, obscureText: true, autofocus: true,
              style: const TextStyle(color: Colors.white, fontSize: 24, letterSpacing: 8),
              textAlign: TextAlign.center,
              decoration: InputDecoration(counterText: '',
                  enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.green.withOpacity(0.4)), borderRadius: BorderRadius.circular(10)),
                  focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green), borderRadius: BorderRadius.circular(10))),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, 'cancel'), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
            TextButton(onPressed: () => Navigator.pop(ctx, ctrl.text),
                child: const Text('Gir', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
          ],
        ),
      );
      if (result == 'cancel' || result == null) { if (mounted) Navigator.pop(context); return; }
      if (result == _pin) { setState(() => _locked = false); break; }
      attempts++;
      if (attempts >= 3) { if (mounted) Navigator.pop(context); return; }
    }
  }

  Future<void> _send() async {
    final msg = _ctrl.text.trim();
    if (msg.isEmpty) return;
    _ctrl.clear();
    await _db.collection('secret_chats').doc(_chatId).collection('messages').add({
      'message': msg,
      'senderID': _auth.currentUser!.uid,
      'timestamp': Timestamp.now(),
      'autoDelete': true,
    });
    await _db.collection('secret_chats').doc(_chatId).set({
      'participants': [_auth.currentUser!.uid, widget.otherUid],
      'lastActivity': Timestamp.now(),
    }, SetOptions(merge: true));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_locked) return const Scaffold(backgroundColor: Color(0xFF0D0D0D), body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      backgroundColor: const Color(0xFF080810),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D14),
        iconTheme: const IconThemeData(color: Colors.white),
        title: Row(children: [
          const Icon(Icons.lock_rounded, color: Colors.green, size: 16),
          const SizedBox(width: 8),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.otherName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
            const Text('Gizli Sohbet · Uçtan Uca Şifreli', style: TextStyle(color: Colors.green, fontSize: 10)),
          ]),
        ]),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep_rounded, color: Colors.red),
            onPressed: () async {
              final ok = await showDialog<bool>(context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: const Color(0xFF1A1A1A),
                    title: const Text('Geçmişi Temizle', style: TextStyle(color: Colors.white)),
                    content: const Text('Tüm gizli mesajlar silinecek', style: TextStyle(color: Colors.white54)),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal', style: TextStyle(color: Colors.white38))),
                      TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sil', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold))),
                    ],
                  ));
              if (ok == true) {
                final msgs = await _db.collection('secret_chats').doc(_chatId).collection('messages').get();
                final batch = _db.batch();
                for (final d in msgs.docs) batch.delete(d.reference);
                await batch.commit();
              }
            },
          ),
        ],
      ),
      body: Column(children: [
        // Şifreleme banner
        Container(
          color: Colors.green.withOpacity(0.07),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.enhanced_encryption_rounded, color: Colors.green, size: 14),
            const SizedBox(width: 6),
            Text('Mesajlar yalnızca bu cihazda saklanır', style: TextStyle(color: Colors.green.shade400, fontSize: 11)),
          ]),
        ),

        Expanded(child: StreamBuilder<QuerySnapshot>(
          stream: _db.collection('secret_chats').doc(_chatId).collection('messages')
              .orderBy('timestamp').snapshots(),
          builder: (ctx, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: Colors.green));
            final msgs = snap.data!.docs;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
            });
            return ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.all(12),
              itemCount: msgs.length,
              itemBuilder: (_, i) {
                final data = msgs[i].data() as Map<String, dynamic>;
                final isMine = data['senderID'] == _auth.currentUser?.uid;
                final ts = (data['timestamp'] as Timestamp?)?.toDate() ?? DateTime.now();
                return Align(
                  alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: EdgeInsets.only(bottom: 6, left: isMine ? 60 : 0, right: isMine ? 0 : 60),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: isMine ? Colors.green.withOpacity(0.15) : const Color(0xFF0D1117),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.green.withOpacity(isMine ? 0.3 : 0.1)),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                      Text(data['message'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 15)),
                      const SizedBox(height: 2),
                      Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.lock_rounded, size: 10, color: Colors.green),
                        const SizedBox(width: 3),
                        Text(DateFormat('h:mm a').format(ts), style: const TextStyle(color: Colors.white24, fontSize: 10)),
                      ]),
                    ]),
                  ),
                );
              },
            );
          },
        )),

        // Input
        Container(
          color: const Color(0xFF0D0D14),
          padding: EdgeInsets.fromLTRB(12, 8, 12, 8 + MediaQuery.of(context).padding.bottom),
          child: Row(children: [
            Expanded(child: Container(
              decoration: BoxDecoration(color: const Color(0xFF111118), borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.green.withOpacity(0.2))),
              child: TextField(
                controller: _ctrl, maxLines: 3, minLines: 1, style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: '🔒 Gizli mesaj yaz...', hintStyle: const TextStyle(color: Colors.white24),
                  border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                onSubmitted: (_) => _send(),
              ),
            )),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _send,
              child: Container(width: 44, height: 44,
                  decoration: BoxDecoration(color: Colors.green.withOpacity(0.2), shape: BoxShape.circle,
                      border: Border.all(color: Colors.green.withOpacity(0.4))),
                  child: const Icon(Icons.send_rounded, color: Colors.green, size: 20)),
            ),
          ]),
        ),
      ]),
    );
  }
}
