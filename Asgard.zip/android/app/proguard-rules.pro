# Flutter
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-dontwarn io.flutter.**

# Firebase
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.**
-dontwarn com.google.android.gms.**

# App
-keep class com.asgard.** { *; }

# Gson / JSON
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keep class sun.misc.Unsafe { *; }

# Cloudinary / HTTP
-keep class okhttp3.** { *; }
-keep class okio.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**

# Crypto / googleapis_auth
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**
-keep class com.google.api.** { *; }
-dontwarn com.google.api.**

# open_filex
-keep class com.crazecoder.openfile.** { *; }

# flutter_secure_storage
-keep class com.it_nomads.fluttersecurestorage.** { *; }

# flutter_sound
-keep class com.dooboolab.fluttersound.** { *; }
-dontwarn com.dooboolab.**

# permission_handler
-keep class com.baseflow.permissionhandler.** { *; }

# image_picker / file_picker
-keep class io.flutter.plugins.imagepicker.** { *; }

# Suppress warnings
-dontwarn javax.annotation.**
-dontwarn org.conscrypt.**
