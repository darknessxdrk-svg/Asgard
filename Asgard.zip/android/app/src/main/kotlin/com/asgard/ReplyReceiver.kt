package com.asgard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.Timestamp
import android.util.Log

class ReplyReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_REPLY = "com.asgard.ACTION_REPLY"
        const val KEY_REPLY_TEXT = "reply_text"
        const val EXTRA_SENDER_UID = "sender_uid"
        const val EXTRA_NOTIF_ID = "notif_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_REPLY) return

        // Yazılan metni al
        val remoteInput = RemoteInput.getResultsFromIntent(intent) ?: return
        val replyText = remoteInput.getCharSequence(KEY_REPLY_TEXT)?.toString()?.trim() ?: return
        if (replyText.isEmpty()) return

        val senderUID = intent.getStringExtra(EXTRA_SENDER_UID) ?: return
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, 0)

        // Bildirimi kapat
        NotificationManagerCompat.from(context).cancel(notifId)

        // Firebase başlat
        FirebaseApp.initializeApp(context)
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser ?: return
        val myUID = currentUser.uid

        // ChatRoom ID hesapla (alfabetik sıra)
        val ids = listOf(myUID, senderUID).sorted()
        val roomID = ids.joinToString("_")

        // Firestore'a mesajı yaz
        val db = FirebaseFirestore.getInstance()
        val message = hashMapOf(
            "senderID" to myUID,
            "receiverID" to senderUID,
            "message" to replyText,
            "timestamp" to Timestamp.now(),
            "status" to "delivered",
            "senderName" to (currentUser.displayName ?: "")
        )

        db.collection("chats")
            .document(roomID)
            .collection("messages")
            .add(message)
            .addOnSuccessListener {
                Log.d("ReplyReceiver", "Mesaj gönderildi: $replyText")
            }
            .addOnFailureListener { e ->
                Log.e("ReplyReceiver", "Mesaj gönderilemedi", e)
            }
    }
}
