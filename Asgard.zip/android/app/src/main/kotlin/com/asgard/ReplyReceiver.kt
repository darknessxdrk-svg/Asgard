package com.asgard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ReplyReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_REPLY = "com.asgard.ACTION_REPLY"
        const val KEY_REPLY_TEXT = "reply_text"
        const val EXTRA_SENDER_UID = "sender_uid"
        const val EXTRA_NOTIF_ID = "notif_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        if (intent.action != ACTION_REPLY) return

        val bundle = RemoteInput.getResultsFromIntent(intent) ?: return
        val replyText = bundle.getCharSequence(KEY_REPLY_TEXT)?.toString()?.trim() ?: return
        // FIX ANDROID: input validation — boş, çok uzun veya tehlikeli içerik reddet
        if (replyText.isEmpty() || replyText.length > 4000) return

        // FIX ANDROID: senderUID format doğrulama — Firebase UID 20-128 alfanumerik karakter
        val senderUID = intent.getStringExtra(EXTRA_SENDER_UID)
            ?.takeIf { it.matches(Regex("[a-zA-Z0-9]{20,128}")) } ?: return
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, 0)

        // Bildirimi kapat
        NotificationManagerCompat.from(context).cancel(notifId)

        // Firebase başlat
        FirebaseApp.initializeApp(context)
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser ?: return
        val myUID = currentUser.uid
        val myName = currentUser.displayName ?: ""

        // ChatRoom ID (alfabetik sıra)
        val ids = listOf(myUID, senderUID).sorted()
        val roomID = "${ids[0]}_${ids[1]}"

        val message: Map<String, Any> = mapOf(
            "senderID" to myUID,
            "receiverID" to senderUID,
            "message" to replyText,
            "timestamp" to Timestamp.now(),
            "status" to "delivered",
            "senderName" to myName
        )

        FirebaseFirestore.getInstance()
            .collection("chats")
            .document(roomID)
            .collection("messages")
            .add(message)
            .addOnSuccessListener {
                Log.d("ReplyReceiver", "Mesaj gönderildi")
            }
            .addOnFailureListener { e ->
                Log.e("ReplyReceiver", "Hata: ${e.message}")
            }
    }
}
