package com.asgard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class CallActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_REJECT = "com.asgard.ACTION_REJECT"
        const val EXTRA_CALL_ID = "call_id"
        const val EXTRA_NOTIF_ID = "notif_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val callId = intent.getStringExtra(EXTRA_CALL_ID) ?: return
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, 0)

        NotificationManagerCompat.from(context).cancel(notifId)

        if (intent.action == ACTION_REJECT) {
            FirebaseApp.initializeApp(context)
            FirebaseFirestore.getInstance()
                .collection("calls")
                .document(callId)
                .update("status", "rejected")
                .addOnFailureListener { e -> Log.e("CallActionReceiver", "Hata: ${e.message}") }
        }
    }
}
