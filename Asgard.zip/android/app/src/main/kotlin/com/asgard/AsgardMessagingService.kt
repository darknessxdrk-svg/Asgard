package com.asgard

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class AsgardMessagingService : FirebaseMessagingService() {

    companion object {
        const val MSG_CHANNEL_ID = "asgardappid"
        const val CALL_CHANNEL_ID = "asgard_calls"
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val data = remoteMessage.data
        val type = data["type"] ?: "chat"
        createChannels()
        when (type) {
            "chat" -> showMessageNotification(data)
            "incoming_call" -> showCallNotification(data)
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val msgChannel = NotificationChannel(
                MSG_CHANNEL_ID, "Asgard Mesajlar",
                NotificationManager.IMPORTANCE_HIGH
            )
            msgChannel.enableVibration(true)
            nm.createNotificationChannel(msgChannel)

            val callChannel = NotificationChannel(
                CALL_CHANNEL_ID, "Aramalar",
                NotificationManager.IMPORTANCE_HIGH
            )
            callChannel.enableVibration(true)
            nm.createNotificationChannel(callChannel)
        }
    }

    private fun showMessageNotification(data: Map<String, String>) {
        val title = data["name"] ?: data["title"] ?: return
        val body = data["body"] ?: return
        val senderUID = data["uid"] ?: return
        val notifId = senderUID.hashCode()

        // RemoteInput inline reply
        val remoteInput = RemoteInput.Builder(ReplyReceiver.KEY_REPLY_TEXT)
            .setLabel("Mesaj yaz...")
            .build()

        val replyIntent = Intent(applicationContext, ReplyReceiver::class.java)
        replyIntent.action = ReplyReceiver.ACTION_REPLY
        replyIntent.putExtra(ReplyReceiver.EXTRA_SENDER_UID, senderUID)
        replyIntent.putExtra(ReplyReceiver.EXTRA_NOTIF_ID, notifId)

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

        val replyPendingIntent = PendingIntent.getBroadcast(
            applicationContext, notifId, replyIntent, flags
        )

        val replyAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_send, "Yanıtla 💬", replyPendingIntent
        ).addRemoteInput(remoteInput).build()

        // Görüldü
        val markReadIntent = Intent(applicationContext, MarkReadReceiver::class.java)
        markReadIntent.action = MarkReadReceiver.ACTION_MARK_READ
        markReadIntent.putExtra(MarkReadReceiver.EXTRA_NOTIF_ID, notifId)
        val markReadPendingIntent = PendingIntent.getBroadcast(
            applicationContext, notifId + 1, markReadIntent, flags
        )
        val markReadAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_view, "Görüldü ✓", markReadPendingIntent
        ).build()

        // Tıklayınca uygulamayı aç
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val immutableFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_IMMUTABLE else 0
        val openPendingIntent = PendingIntent.getActivity(
            applicationContext, 0, openIntent, immutableFlags
        )

        val notification = NotificationCompat.Builder(applicationContext, MSG_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .addAction(replyAction)
            .addAction(markReadAction)
            .build()

        NotificationManagerCompat.from(applicationContext).notify(notifId, notification)
    }

    private fun showCallNotification(data: Map<String, String>) {
        val callerName = data["callerName"] ?: return
        val callId = data["callId"] ?: return
        val isVideo = data["isVideo"] == "true"
        val callerUID = data["callerUID"] ?: ""
        val notifId = callId.hashCode()

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

        // Reddet
        val rejectIntent = Intent(applicationContext, CallActionReceiver::class.java)
        rejectIntent.action = CallActionReceiver.ACTION_REJECT
        rejectIntent.putExtra(CallActionReceiver.EXTRA_CALL_ID, callId)
        rejectIntent.putExtra(CallActionReceiver.EXTRA_NOTIF_ID, notifId)
        val rejectPendingIntent = PendingIntent.getBroadcast(
            applicationContext, notifId, rejectIntent, flags
        )

        // Cevapla - uygulamayı aç
        val acceptIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (acceptIntent != null) {
            acceptIntent.putExtra("call_id", callId)
            acceptIntent.putExtra("caller_name", callerName)
            acceptIntent.putExtra("caller_uid", callerUID)
            acceptIntent.putExtra("is_video", isVideo)
            acceptIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val immutableFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_IMMUTABLE else 0
        val acceptPendingIntent = PendingIntent.getActivity(
            applicationContext, notifId + 1, acceptIntent, immutableFlags
        )

        val rejectAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_call, "Reddet 📵", rejectPendingIntent
        ).build()

        val acceptAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_call, "Cevapla 📞", acceptPendingIntent
        ).build()

        val notification = NotificationCompat.Builder(applicationContext, CALL_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(callerName)
            .setContentText(if (isVideo) "📹 Görüntülü arama" else "📞 Sesli arama")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(acceptPendingIntent, true)
            .setOngoing(true)
            .setAutoCancel(false)
            .addAction(rejectAction)
            .addAction(acceptAction)
            .build()

        NotificationManagerCompat.from(applicationContext).notify(notifId, notification)
    }
}
