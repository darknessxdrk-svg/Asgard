package com.asgard

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class AsgardMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val data = remoteMessage.data
        if (data.isEmpty()) return
        val type = data["type"] ?: "chat"
        createChannels()
        when (type) {
            "chat" -> showMessageNotification(data)
            "incoming_call" -> showCallNotification(data)
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Token yenileme - Flutter tarafı handle eder
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(
                "asgardappid", "Asgard Mesajlar", NotificationManager.IMPORTANCE_HIGH
            ).apply { enableVibration(true) })
            nm.createNotificationChannel(NotificationChannel(
                "asgard_calls", "Aramalar", NotificationManager.IMPORTANCE_HIGH
            ).apply { enableVibration(true) })
        }
    }

    // FIX ANDROID: FLAG_MUTABLE sadece RemoteInput gerektiren yerlerde (reply)
    // Diğer tüm PendingIntent'ler IMMUTABLE olmalı — intent spoofing riski
    private fun mutableFlags() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
    else PendingIntent.FLAG_UPDATE_CURRENT

    private fun immutableFlags() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    else PendingIntent.FLAG_UPDATE_CURRENT

    private fun showMessageNotification(data: Map<String, String>) {
        // FIX FCM: payload doğrulama — boş/tehlikeli değerleri reddet (spoof koruması)
        val rawTitle = data["name"] ?: data["title"] ?: return
        val rawBody = data["body"] ?: return
        val senderUID = data["uid"]?.takeIf { it.matches(Regex("[a-zA-Z0-9]{20,128}")) } ?: return
        // Başlık/içerik sanitize — max uzunluk sınırı
        val title = rawTitle.take(64)
        val body = rawBody.take(256)
        val notifId = senderUID.hashCode()

        val remoteInput = RemoteInput.Builder(ReplyReceiver.KEY_REPLY_TEXT)
            .setLabel("Mesaj yaz...").build()

        val replyIntent = Intent(applicationContext, ReplyReceiver::class.java)
        replyIntent.action = ReplyReceiver.ACTION_REPLY
        replyIntent.putExtra(ReplyReceiver.EXTRA_SENDER_UID, senderUID)
        replyIntent.putExtra(ReplyReceiver.EXTRA_NOTIF_ID, notifId)
        // FIX ANDROID: Reply PendingIntent MUTABLE olmalı (RemoteInput zorunluluğu)
        val replyPI = PendingIntent.getBroadcast(
            applicationContext, notifId, replyIntent, mutableFlags()
        )

        val markIntent = Intent(applicationContext, MarkReadReceiver::class.java)
        markIntent.action = MarkReadReceiver.ACTION_MARK_READ
        markIntent.putExtra(MarkReadReceiver.EXTRA_NOTIF_ID, notifId)
        // FIX ANDROID: markRead IMMUTABLE — değiştirilmesi gerekmez
        val markPI = PendingIntent.getBroadcast(
            applicationContext, notifId + 1, markIntent, immutableFlags()
        )

        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val openPI = PendingIntent.getActivity(
            applicationContext, 0, openIntent, immutableFlags()
        )

        val replyAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_send, "Yanıtla", replyPI
        ).addRemoteInput(remoteInput).build()

        val markAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_view, "Görüldü", markPI
        ).build()

        val notif = NotificationCompat.Builder(applicationContext, "asgardappid")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openPI)
            .addAction(replyAction)
            .addAction(markAction)
            .build()

        NotificationManagerCompat.from(applicationContext).notify(notifId, notif)
    }

    private fun showCallNotification(data: Map<String, String>) {
        // FIX FCM: callId format doğrulama — injection koruması
        val callerName = (data["callerName"] ?: return).take(64)
        val callId = data["callId"]?.takeIf { it.matches(Regex("[a-zA-Z0-9_-]{4,64}")) } ?: return
        val isVideo = data["isVideo"] == "true"
        val callerUID = data["callerUID"] ?: ""
        val notifId = callId.hashCode()

        val rejectIntent = Intent(applicationContext, CallActionReceiver::class.java)
        rejectIntent.action = CallActionReceiver.ACTION_REJECT
        rejectIntent.putExtra(CallActionReceiver.EXTRA_CALL_ID, callId)
        rejectIntent.putExtra(CallActionReceiver.EXTRA_NOTIF_ID, notifId)
        // FIX ANDROID: reject IMMUTABLE — payload değişmemeli
        val rejectPI = PendingIntent.getBroadcast(
            applicationContext, notifId, rejectIntent, immutableFlags()
        )

        val acceptIntent = packageManager.getLaunchIntentForPackage(packageName)
        acceptIntent?.putExtra("call_id", callId)
        acceptIntent?.putExtra("caller_name", callerName)
        acceptIntent?.putExtra("caller_uid", callerUID)
        acceptIntent?.putExtra("is_video", isVideo)
        acceptIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val acceptPI = PendingIntent.getActivity(
            applicationContext, notifId + 1, acceptIntent, immutableFlags()
        )

        val rejectAction = NotificationCompat.Action(
            android.R.drawable.ic_menu_call, "Reddet", rejectPI
        )
        val acceptAction = NotificationCompat.Action(
            android.R.drawable.ic_menu_call, "Cevapla", acceptPI
        )

        val notif = NotificationCompat.Builder(applicationContext, "asgard_calls")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(callerName)
            .setContentText(if (isVideo) "Görüntülü arama" else "Sesli arama")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(acceptPI, true)
            .setOngoing(true)
            .setAutoCancel(false)
            .addAction(rejectAction)
            .addAction(acceptAction)
            .build()

        NotificationManagerCompat.from(applicationContext).notify(notifId, notif)
    }
}
