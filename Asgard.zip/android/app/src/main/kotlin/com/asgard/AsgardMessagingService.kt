package com.asgard

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class AsgardMessagingService : FirebaseMessagingService() {

    companion object {
        const val MSG_CHANNEL_ID = "asgardappid"
        const val CALL_CHANNEL_ID = "asgard_calls"
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val data = message.data
        val type = data["type"] ?: "chat"

        createChannels()

        when (type) {
            "chat" -> showMessageNotification(data)
            "incoming_call" -> showCallNotification(data)
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            nm.createNotificationChannel(NotificationChannel(
                MSG_CHANNEL_ID, "Asgard Mesajlar",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { enableVibration(true) })

            nm.createNotificationChannel(NotificationChannel(
                CALL_CHANNEL_ID, "Aramalar",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { enableVibration(true) })
        }
    }

    private fun showMessageNotification(data: Map<String, String>) {
        val title = data["name"] ?: data["title"] ?: return
        val body = data["body"] ?: return
        val senderUID = data["uid"] ?: return
        val notifId = senderUID.hashCode()

        // RemoteInput - inline reply
        val remoteInput = RemoteInput.Builder(ReplyReceiver.KEY_REPLY_TEXT)
            .setLabel("Mesaj yaz...")
            .build()

        val replyIntent = Intent(this, ReplyReceiver::class.java).apply {
            action = ReplyReceiver.ACTION_REPLY
            putExtra(ReplyReceiver.EXTRA_SENDER_UID, senderUID)
            putExtra(ReplyReceiver.EXTRA_NOTIF_ID, notifId)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

        val replyPendingIntent = PendingIntent.getBroadcast(
            this, notifId, replyIntent, flags
        )

        val replyAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_send, "Yanıtla 💬", replyPendingIntent
        ).addRemoteInput(remoteInput).build()

        // Görüldü aksiyonu
        val markReadIntent = Intent(this, MarkReadReceiver::class.java).apply {
            action = MarkReadReceiver.ACTION_MARK_READ
            putExtra(MarkReadReceiver.EXTRA_NOTIF_ID, notifId)
        }
        val markReadPendingIntent = PendingIntent.getBroadcast(
            this, notifId + 1, markReadIntent, flags
        )
        val markReadAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_view, "Görüldü ✓", markReadPendingIntent
        ).build()

        // Tıklayınca uygulamayı aç
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val openPendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_IMMUTABLE
            else PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, MSG_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .addAction(replyAction)
            .addAction(markReadAction)
            .build()

        NotificationManagerCompat.from(this).notify(notifId, notification)
    }

    private fun showCallNotification(data: Map<String, String>) {
        val callerName = data["callerName"] ?: return
        val callId = data["callId"] ?: return
        val isVideo = data["isVideo"] == "true"
        val callerUID = data["callerUID"] ?: ""
        val notifId = callId.hashCode()

        // Reddet
        val rejectIntent = Intent(this, CallActionReceiver::class.java).apply {
            action = CallActionReceiver.ACTION_REJECT
            putExtra(CallActionReceiver.EXTRA_CALL_ID, callId)
            putExtra(CallActionReceiver.EXTRA_NOTIF_ID, notifId)
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

        val rejectPendingIntent = PendingIntent.getBroadcast(
            this, notifId, rejectIntent, flags
        )

        // Cevapla - uygulamayı aç
        val acceptIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            putExtra("call_id", callId)
            putExtra("caller_name", callerName)
            putExtra("caller_uid", callerUID)
            putExtra("is_video", isVideo)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val acceptPendingIntent = PendingIntent.getActivity(
            this, notifId + 1, acceptIntent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_IMMUTABLE
            else PendingIntent.FLAG_UPDATE_CURRENT
        )

        val rejectAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_call, "Reddet 📵", rejectPendingIntent
        ).build()

        val acceptAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_call, "Cevapla 📞", acceptPendingIntent
        ).build()

        val notification = NotificationCompat.Builder(this, CALL_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(callerName)
            .setContentText(if (isVideo) "📹 Görüntülü arama" else "📞 Sesli arama")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(acceptPendingIntent, true)
            .setOngoing(true)
            .setAutoCancel(false)
            .addAction(rejectAction)
            .addAction(acceptAction)
            .build()

        NotificationManagerCompat.from(this).notify(notifId, notification)
    }
}
